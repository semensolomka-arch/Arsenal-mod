package com.example.armorhud;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import net.minecraft.util.math.Matrix4f;

public class ArmorText {

    /** Проценты ("87%") или оставшаяся прочность ("312") - максимальная прочность не показывается. */
    public static MutableText format(ItemStack stack, ArmorHudConfig.Mode mode) {
        int max = stack.getMaxDamage();
        int left = Math.max(0, max - stack.getDamage());
        String str;
        if (mode == ArmorHudConfig.Mode.PERCENT) {
            str = Math.round(left * 100f / max) + "%";
        } else {
            str = String.valueOf(left);
        }
        float ratio = Math.max(0f, Math.min(1f, left / (float) max));
        int rgb = java.awt.Color.HSBtoRGB(ratio / 3f, 1f, 1f) & 0xFFFFFF;
        return new LiteralText(str).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb)));
    }

    /** Квадрат с текстурой предмета (в координатах "текстового" пространства над головой). */
    public static void iconQuad(VertexConsumer vc, Matrix4f m, float x, float y, float s, Sprite sp, int light) {
        float u0 = sp.getMinU(), u1 = sp.getMaxU(), v0 = sp.getMinV(), v1 = sp.getMaxV();
        vc.vertex(m, x, y, 0f).color(255, 255, 255, 255).texture(u0, v0).light(light).next();
        vc.vertex(m, x, y + s, 0f).color(255, 255, 255, 255).texture(u0, v1).light(light).next();
        vc.vertex(m, x + s, y + s, 0f).color(255, 255, 255, 255).texture(u1, v1).light(light).next();
        vc.vertex(m, x + s, y, 0f).color(255, 255, 255, 255).texture(u1, v0).light(light).next();
    }
}
