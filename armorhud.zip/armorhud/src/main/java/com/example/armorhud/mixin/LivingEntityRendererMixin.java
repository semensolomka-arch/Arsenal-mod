package com.example.armorhud.mixin;

import com.example.armorhud.ArmorHudConfig;
import com.example.armorhud.ArmorText;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.util.math.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(
        method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("TAIL")
    )
    private void armorhud$drawDurability(LivingEntity entity, float yaw, float tickDelta,
                                         MatrixStack matrices, VertexConsumerProvider vcp,
                                         int light, CallbackInfo ci) {
        if (!ArmorHudConfig.showOthers) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (entity == mc.player || entity instanceof ArmorStandEntity || !entity.isAlive()) return;
        if (mc.options.hudHidden) return;
        if (entity.squaredDistanceTo(mc.gameRenderer.getCamera().getPos()) > 32 * 32) return;

        // Только если надета ПОЛНАЯ броня (все 4 слота) - то, что и так видно на модели
        List<ItemStack> stacks = new ArrayList<>();
        for (ItemStack stack : entity.getArmorItems()) {
            if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem) || !stack.isDamageable()) return;
            stacks.add(stack);
        }
        if (stacks.size() != 4) return;
        Collections.reverse(stacks); // getArmorItems(): ботинки -> шлем, нам нужен шлем сверху

        TextRenderer tr = mc.textRenderer;
        List<MutableText> texts = new ArrayList<>();
        int maxW = 0;
        for (ItemStack s : stacks) {
            MutableText t = ArmorText.format(s, ArmorHudConfig.othersMode);
            texts.add(t);
            maxW = Math.max(maxW, tr.getWidth(t));
        }

        final int n = stacks.size();
        final int row = 10;   // шаг строк
        final int icon = 9;   // размер иконки
        float x0 = -(icon + 3 + maxW) / 2.0F;

        matrices.push();
        matrices.translate(0.0, entity.getHeight() + 0.55, 0.0);
        matrices.multiply(mc.getEntityRenderDispatcher().getRotation());
        matrices.scale(-0.025F, -0.025F, 0.025F);
        Matrix4f matrix = matrices.peek().getModel();

        // Сначала все иконки (один слой), потом весь текст - меньше переключений слоёв
        for (int i = 0; i < n; i++) {
            float y = -n * row + i * row;
            Sprite sprite = mc.getItemRenderer().getModels().getModel(stacks.get(i)).getSprite();
            ArmorText.iconQuad(vcp.getBuffer(RenderLayer.getText(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE)),
                    matrix, x0, y, icon, sprite, light);
        }
        for (int i = 0; i < n; i++) {
            float y = -n * row + i * row;
            // seeThrough = false -> текст и иконки не видны сквозь стены
            tr.draw(texts.get(i), x0 + icon + 3, y + 1, 0xFFFFFFFF, true, matrix, vcp, false, 0, light);
        }
        matrices.pop();
    }
}
