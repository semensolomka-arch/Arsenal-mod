package com.example.armorhud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArmorHudClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ArmorHudConfig.load();
        HudRenderCallback.EVENT.register(ArmorHudClient::renderSelf);
    }

    private static void renderSelf(MatrixStack matrices, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ArmorHudConfig.showSelf || mc.player == null || mc.options.hudHidden) return;

        // getArmorItems() идёт от ботинок к шлему - разворачиваем: слева направо шлем -> ботинки
        List<ItemStack> stacks = new ArrayList<>();
        for (ItemStack s : mc.player.getArmorItems()) {
            if (!s.isEmpty() && s.isDamageable()) stacks.add(s);
        }
        if (stacks.isEmpty()) return;
        Collections.reverse(stacks);

        int n = stacks.size();
        List<MutableText> texts = new ArrayList<>();
        int[] cellW = new int[n];
        int total = 0;
        for (int i = 0; i < n; i++) {
            MutableText t = ArmorText.format(stacks.get(i), ArmorHudConfig.selfMode);
            texts.add(t);
            cellW[i] = Math.max(18, mc.textRenderer.getWidth(t) + 2);
            total += cellW[i];
        }
        total += (n - 1) * 2; // промежутки между ячейками

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Ряд левее хотбара и левее слота левой руки (слот левой руки: ещё 29 px влево от хотбара)
        int right = sw / 2 - 91 - 29 - 4;
        int x = Math.max(2, right - total);
        int top = sh - 27; // иконка 16 px сверху, под ней число (всё на высоте хотбара, ниже чата)

        for (int i = 0; i < n; i++) {
            int iconX = x + (cellW[i] - 16) / 2;
            mc.getItemRenderer().renderGuiItemIcon(stacks.get(i), iconX, top);
            float textX = x + (cellW[i] - mc.textRenderer.getWidth(texts.get(i))) / 2.0F;
            mc.textRenderer.drawWithShadow(matrices, texts.get(i), textX, top + 17, 0xFFFFFF);
            x += cellW[i] + 2;
        }
    }
}
