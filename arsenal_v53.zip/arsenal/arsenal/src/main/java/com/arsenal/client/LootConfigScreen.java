package com.arsenal.client;

import com.arsenal.event.CargoLoot;
import com.arsenal.shulker.ShulkerEvent;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Экран настройки лута (Mod Menu). Правит config/arsenal_cargo.json (грузы и золотая лихорадка)
 * и config/arsenal_shulker.json (шалкеры замка): вес, количество, удаление и добавление предметов.
 * После сохранения настройки сразу перечитываются, в своём мире (хост) менять лут можно на ходу.
 */
public class LootConfigScreen extends Screen {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final String[] FILES = {"arsenal_cargo.json", "arsenal_shulker.json"};
    private static final String[] FILE_NAMES = {"Грузы и золотые шалкеры", "Шалкеры замка"};

    private final Screen parent;
    private final JsonObject[] roots = new JsonObject[2];
    private final String[] originals = new String[2];

    private int fileIdx;
    private int tableIdx;
    private int page;
    private String message = "";
    private int messageColor = 0xAAAAAA;
    private String addText = "";

    private final List<Row> rows = new ArrayList<>();
    private TextFieldWidget addField;

    private static final class Row {
        JsonObject entry;
        TextFieldWidget weight;
        TextFieldWidget min;
        TextFieldWidget max;
        String label;
        int y;
    }

    public LootConfigScreen(Screen parent) {
        super(new LiteralText("Arsenal: лут"));
        this.parent = parent;
        for (int i = 0; i < 2; i++) {
            load(i);
        }
    }

    // ------------------------------------------------------------------ файлы

    private void load(int i) {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve(FILES[i]);
            if (!Files.exists(file)) {
                // файл создаётся самим модом из настроек по умолчанию
                if (i == 0) {
                    CargoLoot.load();
                } else {
                    ShulkerEvent.reloadConfig();
                }
            }
            if (Files.exists(file)) {
                roots[i] = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
                originals[i] = GSON.toJson(roots[i]);
            }
        } catch (Exception ex) {
            roots[i] = null;
            System.err.println("[Arsenal] Экран лута: не прочитать " + FILES[i] + ": " + ex);
        }
    }

    private List<String> tables() {
        List<String> out = new ArrayList<>();
        JsonObject root = roots[fileIdx];
        if (root != null && root.has("loot")) {
            for (Map.Entry<String, JsonElement> en : root.getAsJsonObject("loot").entrySet()) {
                if (en.getValue().isJsonObject() && en.getValue().getAsJsonObject().has("entries")) {
                    out.add(en.getKey());
                }
            }
        }
        return out;
    }

    private JsonArray entries() {
        List<String> t = tables();
        if (t.isEmpty()) {
            return null;
        }
        tableIdx = Math.max(0, Math.min(tableIdx, t.size() - 1));
        return roots[fileIdx].getAsJsonObject("loot").getAsJsonObject(t.get(tableIdx)).getAsJsonArray("entries");
    }

    private void save() {
        commit();
        for (int i = 0; i < 2; i++) {
            if (roots[i] == null) {
                continue;
            }
            String now = GSON.toJson(roots[i]);
            if (now.equals(originals[i])) {
                continue;
            }
            try {
                Path file = FabricLoader.getInstance().getConfigDir().resolve(FILES[i]);
                Files.write(file, now.getBytes(StandardCharsets.UTF_8));
                originals[i] = now;
                if (i == 0) {
                    CargoLoot.load();
                } else {
                    ShulkerEvent.reloadConfig();
                }
            } catch (Exception ex) {
                System.err.println("[Arsenal] Не удалось сохранить " + FILES[i] + ": " + ex);
            }
        }
        this.client.openScreen(parent);
    }

    // ------------------------------------------------------------------ экран

    private int rowsPerPage() {
        return Math.max(3, Math.min(12, (this.height - 130) / 22));
    }

    @Override
    protected void init() {
        rows.clear();
        int left = (this.width - 362) / 2;

        // выбор файла и таблицы
        this.addButton(new ButtonWidget(left, 20, 178, 20, new LiteralText("Файл: " + FILE_NAMES[fileIdx]), b -> {
            commit();
            fileIdx = (fileIdx + 1) % 2;
            tableIdx = 0;
            page = 0;
            rebuild();
        }));
        List<String> tables = tables();
        String tName = tables.isEmpty() ? "-" : tables.get(Math.max(0, Math.min(tableIdx, tables.size() - 1)));
        this.addButton(new ButtonWidget(left + 184, 20, 178, 20, new LiteralText("Таблица: " + tName), b -> {
            commit();
            if (!tables.isEmpty()) {
                tableIdx = (tableIdx + 1) % tables.size();
            }
            page = 0;
            rebuild();
        }));

        JsonArray entries = entries();
        int per = rowsPerPage();
        int total = entries == null ? 0 : entries.size();
        int pages = Math.max(1, (total + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));

        if (entries != null) {
            for (int i = 0; i < per; i++) {
                int idx = page * per + i;
                if (idx >= total) {
                    break;
                }
                JsonObject e = entries.get(idx).getAsJsonObject();
                Row r = new Row();
                r.entry = e;
                r.label = describe(e);
                r.y = 56 + i * 22;
                r.weight = numField(left + 196, r.y, 38, e.has("weight") ? e.get("weight").getAsInt() : 10);
                if (e.has("min") || e.has("max")) {
                    int mn = e.has("min") ? e.get("min").getAsInt() : 1;
                    int mx = e.has("max") ? e.get("max").getAsInt() : mn;
                    r.min = numField(left + 238, r.y, 38, mn);
                    r.max = numField(left + 280, r.y, 38, mx);
                }
                final JsonObject target = e;
                this.addButton(new ButtonWidget(left + 322, r.y, 40, 20, new LiteralText("Удал."), b -> {
                    commit();
                    JsonArray arr = entries();
                    for (int k = 0; arr != null && k < arr.size(); k++) {
                        if (arr.get(k) == target) {
                            arr.remove(k);
                            break;
                        }
                    }
                    rebuild();
                }));
                rows.add(r);
            }
        }

        // страницы
        int py = this.height - 54;
        this.addButton(new ButtonWidget(left, py, 24, 20, new LiteralText("<"), b -> {
            commit();
            page--;
            rebuild();
        }));
        this.addButton(new ButtonWidget(left + 338, py, 24, 20, new LiteralText(">"), b -> {
            commit();
            page++;
            rebuild();
        }));

        // добавление предмета и кнопки
        int by = this.height - 28;
        addField = new TextFieldWidget(this.textRenderer, left, by, 150, 20, new LiteralText("id"));
        addField.setMaxLength(100);
        addField.setText(addText);
        this.addButton(addField);
        this.addButton(new ButtonWidget(left + 154, by, 70, 20, new LiteralText("Добавить"), b -> addItem()));
        this.addButton(new ButtonWidget(left + 228, by, 78, 20, new LiteralText("Сохранить"), b -> save()));
        this.addButton(new ButtonWidget(left + 310, by, 52, 20, new LiteralText("Отмена"), b -> this.client.openScreen(parent)));
    }

    private TextFieldWidget numField(int x, int y, int w, int value) {
        TextFieldWidget f = new TextFieldWidget(this.textRenderer, x, y, w, 20, new LiteralText(""));
        f.setMaxLength(6);
        f.setTextPredicate(s -> s.matches("\\d*"));
        f.setText(String.valueOf(value));
        this.addButton(f);
        return f;
    }

    private void rebuild() {
        addText = addField == null ? addText : addField.getText();
        this.init(this.client, this.width, this.height);
    }

    /** Переносит числа из полей в данные (до перелистывания, смены таблицы, удаления и сохранения). */
    private void commit() {
        for (Row r : rows) {
            Integer w = parse(r.weight);
            if (w != null) {
                r.entry.addProperty("weight", w);
            }
            if (r.min != null && r.max != null) {
                Integer mn = parse(r.min);
                Integer mx = parse(r.max);
                if (mn != null && mn >= 1) {
                    r.entry.addProperty("min", mn);
                }
                if (mx != null && mx >= 1) {
                    int lo = r.entry.has("min") ? r.entry.get("min").getAsInt() : 1;
                    r.entry.addProperty("max", Math.max(lo, mx));
                }
            }
        }
    }

    private static Integer parse(TextFieldWidget f) {
        try {
            return f == null || f.getText().isEmpty() ? null : Integer.valueOf(f.getText());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private void addItem() {
        commit();
        JsonArray entries = entries();
        String text = addField.getText().trim();
        if (entries == null) {
            return;
        }
        Identifier id = Identifier.tryParse(text.contains(":") ? text : "minecraft:" + text);
        if (id == null || !Registry.ITEM.getOrEmpty(id).isPresent()) {
            message = "Нет такого предмета: " + text;
            messageColor = 0xFF5555;
            return;
        }
        JsonObject e = new JsonObject();
        e.addProperty("item", id.toString());
        e.addProperty("min", 1);
        e.addProperty("max", 1);
        e.addProperty("weight", 10);
        entries.add(e);
        addText = "";
        page = Integer.MAX_VALUE;
        message = "Добавлено: " + id + " (вес 10)";
        messageColor = 0x55FF55;
        this.init(this.client, this.width, this.height);
    }

    private static String describe(JsonObject e) {
        try {
            if (e.has("kit")) {
                return "Кит " + e.get("kit").getAsString() + ": " + (e.has("part") ? e.get("part").getAsString() : "?");
            }
            if (e.has("special")) {
                return "Особое: " + e.get("special").getAsString();
            }
            if (e.has("mythic")) {
                return "Мифическая сфера";
            }
            if (e.has("item")) {
                String id = e.get("item").getAsString();
                Item item = Registry.ITEM.getOrEmpty(new Identifier(id)).orElse(null);
                String name = item == null ? id : item.getName().getString();
                if (e.has("enchantment")) {
                    String lv = e.has("levels") ? " " + e.get("levels") : "";
                    return name + ": " + e.get("enchantment").getAsString().replace("minecraft:", "") + lv;
                }
                if (e.has("potion")) {
                    return name + ": " + e.get("potion").getAsString().replace("minecraft:", "");
                }
                return name;
            }
        } catch (Exception ex) {
            // показываем как есть
        }
        return e.toString();
    }

    @Override
    public void tick() {
        for (Row r : rows) {
            r.weight.tick();
            if (r.min != null) {
                r.min.tick();
                r.max.tick();
            }
        }
        if (addField != null) {
            addField.tick();
        }
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        int left = (this.width - 362) / 2;
        drawCenteredText(matrices, this.textRenderer, this.title, this.width / 2, 6, 0xFFFFFF);

        if (roots[fileIdx] == null) {
            drawCenteredText(matrices, this.textRenderer, new LiteralText("Файл " + FILES[fileIdx] + " не найден"),
                    this.width / 2, 70, 0xFF5555);
        } else {
            this.textRenderer.drawWithShadow(matrices, "Предмет", left, 44, 0xAAAAAA);
            this.textRenderer.drawWithShadow(matrices, "Вес", left + 196, 44, 0xAAAAAA);
            this.textRenderer.drawWithShadow(matrices, "Мин", left + 238, 44, 0xAAAAAA);
            this.textRenderer.drawWithShadow(matrices, "Макс", left + 280, 44, 0xAAAAAA);
            for (Row r : rows) {
                int w = parse(r.weight) == null ? 10 : parse(r.weight);
                this.textRenderer.drawWithShadow(matrices, this.textRenderer.trimToWidth(r.label, 188), left, r.y + 6,
                        w == 0 ? 0x777777 : 0xFFFFFF);
            }
        }

        JsonArray entries = entries();
        int per = rowsPerPage();
        int total = entries == null ? 0 : entries.size();
        int pages = Math.max(1, (total + per - 1) / per);
        drawCenteredText(matrices, this.textRenderer, new LiteralText("Страница " + (page + 1) + " / " + pages
                + "   (записей: " + total + ")"), this.width / 2, this.height - 48, 0xAAAAAA);
        if (!message.isEmpty()) {
            drawCenteredText(matrices, this.textRenderer, new LiteralText(message), this.width / 2, this.height - 66, messageColor);
        } else {
            drawCenteredText(matrices, this.textRenderer, new LiteralText("Вес 0 = предмет не выпадает. Изменения применяются кнопкой «Сохранить»."),
                    this.width / 2, this.height - 66, 0x888888);
        }
        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        this.client.openScreen(parent);
    }
}
