package com.arsenal.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Кнопка настройки в Mod Menu: открывает экран лута грузов и шалкеров. */
public class ArsenalModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return LootConfigScreen::new;
    }
}
