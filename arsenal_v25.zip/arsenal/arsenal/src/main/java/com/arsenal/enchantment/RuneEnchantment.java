package com.arsenal.enchantment;

import com.arsenal.rune.RuneType;
import com.arsenal.rune.Runes;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;

/**
 * Служебное зачарование: хранит руну на тотеме или талисмане.
 * Из стола, лута и торговли не берётся, в креативе книг не даёт, название рисуется цветом красителя руны.
 */
public class RuneEnchantment extends Enchantment {
    private final RuneType type;

    public RuneEnchantment(RuneType type) {
        super(Rarity.VERY_RARE, null, new EquipmentSlot[0]);
        this.type = type;
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean isAcceptableItem(ItemStack stack) {
        return Runes.canCarry(stack.getItem());
    }

    @Override
    public boolean isTreasure() {
        return true;
    }

    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }

    @Override
    public boolean isAvailableForRandomSelection() {
        return false;
    }

    @Override
    public Text getName(int level) {
        return new TranslatableText(this.getTranslationKey()).formatted(type.color);
    }
}
