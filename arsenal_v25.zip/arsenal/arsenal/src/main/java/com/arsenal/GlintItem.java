package com.arsenal;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Предмет, который всегда выглядит зачарованным (с переливом). */
public class GlintItem extends Item {
    public GlintItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
