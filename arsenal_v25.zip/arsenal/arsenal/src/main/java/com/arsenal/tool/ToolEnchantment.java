package com.arsenal.tool;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.function.Predicate;

/**
 * Общий класс для новых зачарований инструментов и луков (логика в ToolEnchants и миксинах).
 * items: на какие предметы можно наложить; maxLevel: максимальный уровень;
 * tableMaxLevel: до какого уровня можно получить в столе зачарований (0 = в столе не выпадает).
 */
public class ToolEnchantment extends Enchantment {
    private final Predicate<Item> items;
    private final int maxLevel;
    private final int tableMaxLevel;

    public ToolEnchantment(Rarity rarity, EnchantmentTarget target, Predicate<Item> items, int maxLevel, int tableMaxLevel) {
        super(rarity, target, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
        this.items = items;
        this.maxLevel = maxLevel;
        this.tableMaxLevel = tableMaxLevel;
    }

    @Override
    public int getMaxLevel() {
        return maxLevel;
    }

    @Override
    public boolean isAcceptableItem(ItemStack stack) {
        return items.test(stack.getItem());
    }

    // Стол зачарований: I на любом столе, II на столах повыше, III на самых высоких
    @Override
    public int getMinPower(int level) {
        if (level > tableMaxLevel) {
            return 10000;
        }
        return 1 + (level - 1) * 10;
    }

    @Override
    public int getMaxPower(int level) {
        return getMinPower(level) + (level > tableMaxLevel ? 50 : 40);
    }

    @Override
    public boolean isAvailableForRandomSelection() {
        return tableMaxLevel > 0;
    }

    // В торговле книгами с жителями не появляется
    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
}
