package com.arsenal.priv;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Блок привата. Выглядит как обычный блок (железный, золотой...), но защищает территорию вокруг.
 * Владелец и прочность хранятся в PrivateManager. Ломает только владелец: падает приват, с Shift падает материал.
 */
public class PrivateBlock extends Block {
    public final PrivateType type;

    public PrivateBlock(Settings settings, PrivateType type) {
        super(settings);
        this.type = type;
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.onPlaced(world, pos, state, placer, stack);
        if (!world.isClient && placer instanceof ServerPlayerEntity) {
            ServerPlayerEntity player = (ServerPlayerEntity) placer;
            PrivateManager.add((net.minecraft.server.world.ServerWorld) world, pos, player.getUuid(),
                    player.getGameProfile().getName(), type, PrivateBlockItem.durabilityOf(stack, type));
        }
    }

    @Override
    public void onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        if (!world.isClient && !player.isCreative()) {
            ItemStack drop;
            if (player.isSneaking()) {
                drop = new ItemStack(type.shiftDrop());
            } else {
                PrivateManager.Entry e = PrivateManager.get(world, pos);
                drop = PrivateBlockItem.stackWith(type, e == null ? type.durability : e.durability);
            }
            Block.dropStack(world, pos, drop);
        }
        super.onBreak(world, pos, state, player);
    }

    @Override
    public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.isOf(newState.getBlock())) {
            PrivateManager.remove(world, pos);
        }
        super.onStateReplaced(state, world, pos, newState, moved);
    }
}
