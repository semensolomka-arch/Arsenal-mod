package com.arsenal.castle;

/** Размеры замка и его точки (из схемы zamok.schem). */
public final class CastleConstants {
    public static final int WIDTH = 83;   // по X
    public static final int HEIGHT = 84;  // по Y
    public static final int LENGTH = 79;  // по Z

    /** Границы замка в мире: он стоит по центру на 0,0. */
    public static final int MIN_X = -(WIDTH / 2);
    public static final int MAX_X = MIN_X + WIDTH - 1;
    public static final int MIN_Z = -(LENGTH / 2);
    public static final int MAX_Z = MIN_Z + LENGTH - 1;

    /** Слой схемы, в котором лежит поверхность земли (верхний блок земли). */
    public static final int SURFACE_LAYER = 8;

    /** Точка спавна внутри схемы (где стоят ноги): открытая под небом площадка на уровне земли. */
    public static final int SPAWN_X = 66;
    public static final int SPAWN_Y = 9;
    public static final int SPAWN_Z = 39;

    private CastleConstants() {
    }
}
