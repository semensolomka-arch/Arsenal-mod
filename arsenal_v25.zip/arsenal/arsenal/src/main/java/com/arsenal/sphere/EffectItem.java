package com.arsenal.sphere;

import com.arsenal.NameDecor;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/**
 * Сфера или талисман. Если fixed != null, эффекты фиксированные (Флеш, Цербер, Stinger, Eternity, Infinity),
 * иначе уровни хранятся на предмете в зачарованиях (обычная/эпическая/легендарная/мифическая сфера, талисман).
 */
public class EffectItem extends Item {
    private final Formatting color;
    private final int[] fixed;
    /** Если задан, название оформляется как у Stinger/Eternity/Infinity: мерцающие символы по краям. */
    private final TextColor decor;
    /** Если задан, это готовые величины эффектов (в порядке SphereEffect) вместо уровень * perLevel. */
    private final double[] amounts;

    public EffectItem(Settings settings, Formatting color, int[] fixed) {
        this(settings, color, fixed, null);
    }

    public EffectItem(Settings settings, Formatting color, int[] fixed, TextColor decor) {
        this(settings, color, fixed, decor, null);
    }

    public EffectItem(Settings settings, Formatting color, int[] fixed, TextColor decor, double[] amounts) {
        super(settings);
        this.color = color;
        this.fixed = fixed;
        this.decor = decor;
        this.amounts = amounts;
    }

    /** Величина эффекта для атрибута: готовое значение или уровень * perLevel. */
    public double amount(ItemStack stack, SphereEffect effect) {
        if (amounts != null) {
            return amounts[effect.ordinal()];
        }
        return effects(stack)[effect.ordinal()] * effect.perLevel;
    }

    /** Уровни эффектов в порядке SphereEffect. */
    public int[] effects(ItemStack stack) {
        if (fixed != null) {
            return fixed.clone();
        }
        int[] result = new int[SphereEffect.COUNT];
        for (SphereEffect e : SphereEffect.values()) {
            if (e.enchantment != null) {
                result[e.ordinal()] = EnchantmentHelper.getLevel(e.enchantment, stack);
            }
        }
        return result;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public Text getName(ItemStack stack) {
        if (decor != null) {
            return NameDecor.decorate(new TranslatableText(this.getTranslationKey(stack)), decor);
        }
        return new TranslatableText(this.getTranslationKey(stack)).formatted(color);
    }

    // У предметов с фиксированными эффектами нет зачарований, поэтому рисуем строки эффектов сами
    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        if (fixed == null) {
            return;
        }
        if (amounts != null) {
            if (amounts[SphereEffect.SPEED.ordinal()] > 0) {
                tooltip.add(new TranslatableText("tooltip.arsenal.bonus_speed",
                        Math.round(amounts[SphereEffect.SPEED.ordinal()] * 100)).formatted(Formatting.GRAY));
            }
            if (amounts[SphereEffect.DAMAGE.ordinal()] > 0) {
                tooltip.add(new TranslatableText("tooltip.arsenal.bonus_damage",
                        Math.round(amounts[SphereEffect.DAMAGE.ordinal()])).formatted(Formatting.GRAY));
            }
            return;
        }
        for (SphereEffect e : SphereEffect.values()) {
            int level = fixed[e.ordinal()];
            if (level > 0) {
                tooltip.add(new TranslatableText("enchantment.arsenal.sphere_" + e.id)
                        .append(new LiteralText(" "))
                        .append(new TranslatableText("enchantment.level." + level))
                        .formatted(Formatting.GRAY));
            }
        }
    }
}
