package com.arsenal.exp;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

/** Меню /exp: обычный сундук 3x9, предметы из него взять нельзя, клик по бутыльку = переработка. */
public class ExpScreenHandler extends GenericContainerScreenHandler {
    private final SimpleInventory menu;

    public ExpScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu) {
        super(ScreenHandlerType.GENERIC_9X3, syncId, playerInventory, menu, 3);
        this.menu = menu;
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < 27) {
            if ((actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)
                    && player instanceof ServerPlayerEntity) {
                ExpMenu.onClick((ServerPlayerEntity) player, slotIndex, actionType == SlotActionType.QUICK_MOVE, menu);
            }
            return ItemStack.EMPTY;
        }
        if (actionType == SlotActionType.QUICK_MOVE
                || actionType == SlotActionType.PICKUP_ALL
                || actionType == SlotActionType.QUICK_CRAFT) {
            return ItemStack.EMPTY;
        }
        return super.onSlotClick(slotIndex, clickData, actionType, player);
    }
}
