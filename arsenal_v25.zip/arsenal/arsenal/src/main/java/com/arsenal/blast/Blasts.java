package com.arsenal.blast;

import com.arsenal.Arsenal;
import com.arsenal.Lore;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Регистрация взрывчатого вещества, динамита А/Б, C4, разрывной волны и стиллеров. */
public final class Blasts {
    /** Фиолетовый цвет названий (динамит Б, стиллер, концы градиентов). */
    public static final int PURPLE = 0xAA33FF;

    public static Item EXPLOSIVE_SUBSTANCE;
    private static final Map<BlastKind, Block> BLOCKS = new EnumMap<>(BlastKind.class);

    private Blasts() {
    }

    public static Block block(BlastKind kind) {
        return BLOCKS.get(kind);
    }

    public static void init(ItemGroup group) {
        // Взрывчатое вещество: крафт из 9 пороха (рецепт в data/arsenal/recipes), пока без другого применения
        EXPLOSIVE_SUBSTANCE = Registry.register(Registry.ITEM, new Identifier(Arsenal.MODID, "explosive_substance"),
                new Item(new Item.Settings().group(group)) {
                    @Override
                    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
                        Lore.addTooltip(tooltip, "tooltip.arsenal.explosive_substance.", 3, 0xC8A2FF);
                    }
                });

        for (BlastKind kind : BlastKind.values()) {
            Block block = Registry.register(Registry.BLOCK, new Identifier(Arsenal.MODID, kind.id),
                    new BlastBlock(AbstractBlock.Settings.of(Material.TNT).breakInstantly().sounds(BlockSoundGroup.GRASS), kind));
            BLOCKS.put(kind, block);
            Registry.register(Registry.ITEM, new Identifier(Arsenal.MODID, kind.id),
                    new BlastBlockItem(block, new Item.Settings().group(group), kind));
        }
    }

    public static void addCreativeStacks(List<ItemStack> stacks) {
        stacks.add(new ItemStack(EXPLOSIVE_SUBSTANCE));
        for (BlastKind kind : BlastKind.values()) {
            stacks.add(new ItemStack(BLOCKS.get(kind)));
        }
    }
}
