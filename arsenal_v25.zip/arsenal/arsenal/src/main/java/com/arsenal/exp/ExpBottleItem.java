package com.arsenal.exp;

import com.arsenal.GlintItem;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/**
 * Бутылёк опыта на N уровней: берёшь в руку и жмёшь ПКМ, опыт добавляется сразу (бутылёк не бросается).
 * Даёт столько очков опыта, сколько нужно, чтобы с нуля дойти до N уровня.
 */
public class ExpBottleItem extends GlintItem {
    private final int levels;
    private final int color;

    public ExpBottleItem(Settings settings, int levels, int color) {
        super(settings);
        this.levels = levels;
        this.color = color;
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(this.getTranslationKey(stack)).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(color)));
    }

    public int points() {
        return ExpCommand.pointsForLevel(levels);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            int score = user.getScore();
            user.addExperience(points());
            user.setScore(score);
            if (!user.isCreative()) {
                stack.decrement(1);
            }
            world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6F, 1.0F);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(new TranslatableText("tooltip.arsenal.exp_bottle", levels, points()).formatted(Formatting.GRAY));
    }
}
