package com.arsenal.mixin;

import com.arsenal.combat.Combat;
import net.minecraft.entity.Entity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** В режиме боя никакие команды не работают, даже у операторов. Команды сервера и командных блоков не затрагиваются. */
@Mixin(CommandManager.class)
public abstract class CommandManagerMixin {
    @Inject(method = "execute", at = @At("HEAD"), cancellable = true)
    private void arsenal$noCommandsInCombat(ServerCommandSource source, String command, CallbackInfoReturnable<Integer> cir) {
        Entity entity = source.getEntity();
        if (entity instanceof ServerPlayerEntity && Combat.isInCombat((ServerPlayerEntity) entity)) {
            ((ServerPlayerEntity) entity).sendMessage(
                    new LiteralText("В режиме боя нельзя использовать команды").formatted(Formatting.RED), false);
            cir.setReturnValue(0);
        }
    }
}
