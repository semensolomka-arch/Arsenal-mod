package com.arsenal.mixin;

import com.arsenal.protection.SpawnProtection;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Взрывы не разрушают блоки в зоне замка и на территории приватов; блок привата теряет прочность. */
@Mixin(Explosion.class)
public abstract class ExplosionMixin {
    @Shadow
    @Final
    private World world;

    @Inject(method = "affectWorld", at = @At("HEAD"))
    private void arsenal$protectSpawn(boolean particles, CallbackInfo ci) {
        java.util.List<net.minecraft.util.math.BlockPos> affected = ((Explosion) (Object) this).getAffectedBlocks();
        affected.removeIf(pos -> SpawnProtection.contains(world, pos) || com.arsenal.TrapManager.isProtected(pos)
                || com.arsenal.event.EventManager.inZone(world, pos));
        if (world.isClient) {
            return;
        }
        // приваты: блок привата теряет прочность (защищённые только от C4), остальные блоки на территории взрыв не ломает.
        // Сначала всё решаем по состоянию до взрыва, потом применяем удары по приватам.
        java.util.List<net.minecraft.util.math.BlockPos> hits = new java.util.ArrayList<>();
        java.util.Iterator<net.minecraft.util.math.BlockPos> it = affected.iterator();
        while (it.hasNext()) {
            net.minecraft.util.math.BlockPos pos = it.next();
            com.arsenal.priv.PrivateManager.Entry entry = com.arsenal.priv.PrivateManager.get(world, pos);
            if (entry != null) {
                it.remove();
                if (!entry.type.c4Only) {
                    hits.add(pos.toImmutable());
                }
            } else if (com.arsenal.priv.Privates.EXPLOSION_PROOF_REGION && com.arsenal.priv.PrivateManager.isCovered(world, pos)) {
                it.remove();
            }
        }
        for (net.minecraft.util.math.BlockPos pos : hits) {
            com.arsenal.priv.Privates.explosionHit((net.minecraft.server.world.ServerWorld) world, pos);
        }
    }
}
