package com.arsenal;

import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Language;

import java.util.List;

/**
 * Цветные названия и описания предметов (трапки, стан, ком снега и т.д.).
 * В строках из lang-файла кусок в двойных квадратных скобках [[вот так]] красится цветом выделения,
 * остальной текст белый. Заголовок "Особенности:" тёмно-серый.
 */
public final class Lore {
    private static final int WHITE = 0xFFFFFF;

    private Lore() {
    }

    private static int lerp(int a, int b, double t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) Math.round(ar + (br - ar) * t);
        int g = (int) Math.round(ag + (bg - ag) * t);
        int bl = (int) Math.round(ab + (bb - ab) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Название с градиентом по буквам. mirror: от from к to и обратно (как в плагине). */
    public static MutableText gradient(String text, int from, int to, boolean mirror) {
        MutableText result = new LiteralText("");
        int n = text.length();
        for (int i = 0; i < n; i++) {
            double t = n <= 1 ? 0.0 : (double) i / (n - 1);
            if (mirror) {
                t = 1.0 - Math.abs(2.0 * t - 1.0);
            }
            Style style = Style.EMPTY.withColor(TextColor.fromRgb(lerp(from, to, t))).withItalic(false);
            result.append(new LiteralText(String.valueOf(text.charAt(i))).setStyle(style));
        }
        return result;
    }

    /** Название предмета из lang-файла, окрашенное градиентом. */
    public static MutableText gradientName(String translationKey, int from, int to, boolean mirror) {
        return gradient(Language.getInstance().get(translationKey), from, to, mirror);
    }

    /** Строка описания: [[...]] цветом выделения, остальное белым. */
    public static MutableText parse(String s, int highlight) {
        MutableText result = new LiteralText("");
        int pos = 0;
        while (pos < s.length()) {
            int open = s.indexOf("[[", pos);
            int close = open < 0 ? -1 : s.indexOf("]]", open + 2);
            if (open < 0 || close < 0) {
                result.append(piece(s.substring(pos), WHITE));
                break;
            }
            if (open > pos) {
                result.append(piece(s.substring(pos, open), WHITE));
            }
            result.append(piece(s.substring(open + 2, close), highlight));
            pos = close + 2;
        }
        return result;
    }

    private static Text piece(String text, int color) {
        return new LiteralText(text).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(color)).withItalic(false));
    }

    /** Пустая строка, заголовок "Особенности:" и строки prefix1..prefixN из lang-файла. */
    public static void addTooltip(List<Text> tooltip, String prefix, int lines, int highlight) {
        Language lang = Language.getInstance();
        tooltip.add(new LiteralText(""));
        tooltip.add(new LiteralText(lang.get("tooltip.arsenal.header")).formatted(Formatting.DARK_GRAY));
        for (int i = 1; i <= lines; i++) {
            if (!lang.hasTranslation(prefix + i)) {
                continue;   // в другом языке строк может быть меньше
            }
            tooltip.add(parse(lang.get(prefix + i), highlight));
        }
    }
}
