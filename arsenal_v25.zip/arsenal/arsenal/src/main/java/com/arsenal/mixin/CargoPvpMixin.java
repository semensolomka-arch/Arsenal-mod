package com.arsenal.mixin;

import com.arsenal.event.EventManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** В зоне мирного груза нет PvP: игрок не может ранить игрока, ни стоя в зоне, ни стреляя в неё. */
@Mixin(LivingEntity.class)
public abstract class CargoPvpMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void arsenal$cargoPeace(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Object self = this;
        if (!(self instanceof PlayerEntity)) {
            return;
        }
        Entity attacker = source.getAttacker();
        if (!(attacker instanceof PlayerEntity) || attacker == self) {
            return;
        }
        PlayerEntity victim = (PlayerEntity) self;
        if (EventManager.peaceAt(victim.world, victim.getX(), victim.getZ())
                || EventManager.peaceAt(attacker.world, attacker.getX(), attacker.getZ())) {
            cir.setReturnValue(false);
        }
    }
}
