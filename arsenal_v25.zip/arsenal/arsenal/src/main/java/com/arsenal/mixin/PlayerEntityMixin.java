package com.arsenal.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    /** После поедания: чарка (зачарованное золотое яблоко) 3 минуты, обычное золотое яблоко 10 секунд. */
    @Inject(method = "eatFood", at = @At("HEAD"))
    private void arsenal$enchantedAppleCooldown(World world, ItemStack stack, CallbackInfoReturnable<ItemStack> cir) {
        if (world.isClient) {
            return;
        }
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (stack.getItem() == Items.ENCHANTED_GOLDEN_APPLE) {
            self.getItemCooldownManager().set(Items.ENCHANTED_GOLDEN_APPLE, 20 * 60 * 3);
        } else if (stack.getItem() == Items.GOLDEN_APPLE) {
            self.getItemCooldownManager().set(Items.GOLDEN_APPLE, 20 * 10);
        }
    }
}
