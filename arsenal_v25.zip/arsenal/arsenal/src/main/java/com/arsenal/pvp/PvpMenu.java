package com.arsenal.pvp;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Меню /pvp: "Поиск PvP", "Доступные игры" и "Просмотр инвентаря". */
public final class PvpMenu {
    private static final int SLOT_DUEL = 11;
    private static final int SLOT_CANCEL = 13;
    private static final int SLOT_DEADLY = 15;
    private static final int SLOT_INFO = 18;

    private PvpMenu() {
    }

    // ---------------------------------------------------------------- поиск

    public static void openSearch(ServerPlayerEntity player) {
        SimpleInventory inv = new SimpleInventory(27);
        for (int i = 0; i < 27; i++) {
            inv.setStack(i, ItemStack.EMPTY);
        }
        inv.setStack(SLOT_DUEL, searchButton(Items.LIME_CONCRETE, "► Поиск поединка", Formatting.GREEN));
        inv.setStack(SLOT_DEADLY, searchButton(Items.MAGENTA_CONCRETE, "► Поиск смертельной схватки", Formatting.LIGHT_PURPLE));

        ItemStack cancel = new ItemStack(Items.RED_CONCRETE);
        cancel.setCustomName(plain("► Отменить поиск", Formatting.RED));
        lore(cancel, text(""), bar(w("Нажмите, чтобы "), c("отменить", Formatting.RED)), bar(w("статус поиска")));
        inv.setStack(SLOT_CANCEL, cancel);

        ItemStack info = new ItemStack(Items.NETHER_STAR);
        info.setCustomName(plain("Полезная информация", Formatting.AQUA));
        lore(info, text(""),
                bar(w("Нажав на "), c("зеленую кнопку", Formatting.GREEN), w(" или")),
                bar(c("фиолетовую кнопку", Formatting.LIGHT_PURPLE), w(" вы активируете")),
                bar(w("поиск оппонента, оповестив об этом")),
                bar(w("весь сервер")),
                text(""),
                bar(c("Красная кнопка", Formatting.RED), w(" отменяет статус")),
                bar(w("поиска")),
                text(""),
                bar(w("Когда соперник найдется, вы будете")),
                bar(w("телепортированы к нему в радиусе")),
                bar(w("30 блоков, о чем оповестят обоих игроков")),
                text(""),
                bar(w("Главная задача – победить своего")),
                bar(w("соперника. Наградой послужат все")),
                bar(w("ресурсы проигравшего и знаменательные")),
                bar(w("поздравление в чате. Приятной битвы!")));
        inv.setStack(SLOT_INFO, info);

        open(player, inv, 3, "Поиск PvP", (p, slot, button) -> {
            if (slot == SLOT_DUEL) {
                p.closeHandledScreen();
                PvpManager.startSearch(p, PvpManager.Kind.DUEL);
            } else if (slot == SLOT_DEADLY) {
                p.closeHandledScreen();
                PvpManager.startSearch(p, PvpManager.Kind.DEADLY);
            } else if (slot == SLOT_CANCEL) {
                p.closeHandledScreen();
                PvpManager.cancelSearch(p);
            }
        });
    }

    private static ItemStack searchButton(net.minecraft.item.Item item, String title, Formatting color) {
        ItemStack stack = new ItemStack(item);
        stack.setCustomName(plain(title, color));
        lore(stack, text(""),
                bar(w("Нажмите, чтобы "), c("начать поиск", color)),
                bar(w("противника для ПВП")));
        return stack;
    }

    // ---------------------------------------------------------------- список

    public static void openList(ServerPlayerEntity viewer) {
        SimpleInventory inv = new SimpleInventory(54);
        for (int i = 0; i < 54; i++) {
            inv.setStack(i, ItemStack.EMPTY);
        }
        for (int i = 0; i < 54; i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == 5 || col == 0 || col == 8) {
                ItemStack pane = new ItemStack(((row + col) % 2 == 0) ? Items.BLUE_STAINED_GLASS_PANE : Items.ORANGE_STAINED_GLASS_PANE);
                pane.setCustomName(new LiteralText(" "));
                inv.setStack(i, pane);
            }
        }
        Map<Integer, UUID> slots = new HashMap<>();
        Map<Integer, PvpManager.Kind> kinds = new HashMap<>();
        int slot = 10;
        for (Map.Entry<UUID, PvpManager.Kind> e : PvpManager.searchers().entrySet()) {
            ServerPlayerEntity target = viewer.getServer().getPlayerManager().getPlayer(e.getKey());
            if (target == null) {
                continue;
            }
            while (slot % 9 == 0 || slot % 9 == 8) {
                slot++;
            }
            if (slot >= 45) {
                break;
            }
            inv.setStack(slot, head(target, e.getValue()));
            slots.put(slot, e.getKey());
            kinds.put(slot, e.getValue());
            slot++;
        }
        open(viewer, inv, 6, "Доступные игры", (p, s, button) -> {
            UUID id = slots.get(s);
            if (id == null) {
                return;
            }
            if (button == 1) {
                ServerPlayerEntity target = p.getServer().getPlayerManager().getPlayer(id);
                if (target == null) {
                    p.sendMessage(new LiteralText("Игрок не в сети").formatted(Formatting.RED), false);
                    return;
                }
                p.getServer().execute(() -> openInventory(p, target));
            } else {
                p.closeHandledScreen();
                PvpManager.accept(p, id, kinds.get(s));
            }
        });
    }

    private static ItemStack head(ServerPlayerEntity target, PvpManager.Kind kind) {
        String name = target.getGameProfile().getName();
        ItemStack stack = new ItemStack(Items.PLAYER_HEAD);
        NbtCompound tag = new NbtCompound();
        tag.putString("SkullOwner", name);
        stack.setTag(tag);
        stack.setCustomName(plain("● " + kind.title + " с: " + name, Formatting.GOLD));

        PvpStats.Stat st = PvpStats.get(target.getUuid(), name);
        List<Text> lines = new ArrayList<>();
        lines.add(text(""));
        lines.add(plain("Победы", Formatting.GREEN));
        lines.add(stat("Всего: " + st.wins));
        lines.add(stat("За этот вайп: " + st.winsWipe));
        lines.add(text(""));
        lines.add(plain("Поражения", Formatting.RED));
        lines.add(stat("Всего: " + st.losses));
        lines.add(stat("За этот вайп: " + st.lossesWipe));
        lines.add(text(""));
        lines.add(kind == PvpManager.Kind.DUEL
                ? plain("Поединок пройдёт на далёких координатах", Formatting.GRAY)
                : plain("Смертельная схватка пройдёт на арене " + PvpManager.ARENA + "x" + PvpManager.ARENA, Formatting.LIGHT_PURPLE));
        lines.add(text(""));
        lines.add(plain("► Левый клик – начать " + (kind == PvpManager.Kind.DUEL ? "поединок" : "схватку"), Formatting.GOLD));
        lines.add(plain("► Правый клик – инвентарь игрока", Formatting.AQUA));
        lore(stack, lines.toArray(new Text[0]));
        return stack;
    }

    private static Text stat(String s) {
        MutableText t = new LiteralText("▌").formatted(Formatting.AQUA);
        t.append(new LiteralText(s).formatted(Formatting.WHITE));
        return t.styled(st -> st.withItalic(false));
    }

    // ---------------------------------------------------------------- инвентарь

    private static void openInventory(ServerPlayerEntity viewer, ServerPlayerEntity target) {
        SimpleInventory inv = new SimpleInventory(54);
        for (int i = 0; i < 54; i++) {
            ItemStack pane = new ItemStack(Items.GRAY_STAINED_GLASS_PANE);
            pane.setCustomName(new LiteralText(" "));
            inv.setStack(i, pane);
        }
        // верхний ряд: шлем, нагрудник, поножи, ботинки, вторая рука
        for (int i = 0; i < 4; i++) {
            inv.setStack(i, target.inventory.armor.get(3 - i).copy());
        }
        inv.setStack(4, target.inventory.offHand.get(0).copy());
        // основной инвентарь 9..35, хотбар 36..44
        for (int i = 9; i < 36; i++) {
            inv.setStack(i, target.inventory.main.get(i).copy());
        }
        for (int i = 0; i < 9; i++) {
            inv.setStack(36 + i, target.inventory.main.get(i).copy());
        }
        ItemStack back = new ItemStack(Items.ARROW);
        back.setCustomName(plain("◀ Назад к списку", Formatting.YELLOW));
        inv.setStack(49, back);
        open(viewer, inv, 6, "Просмотр инвентаря", (p, slot, button) -> {
            if (slot == 49) {
                p.getServer().execute(() -> {
                    p.closeHandledScreen();
                    openList(p);
                });
            }
        });
    }

    // ---------------------------------------------------------------- утилиты

    private static void open(ServerPlayerEntity player, SimpleInventory inv, int rows, String title, PvpScreenHandler.Click click) {
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new PvpScreenHandler(syncId, playerInventory, inv, rows, click),
                new LiteralText(title)));
    }

    private static Text text(String s) {
        return new LiteralText(s);
    }

    private static MutableText w(String s) {
        return new LiteralText(s).formatted(Formatting.WHITE);
    }

    private static MutableText c(String s, Formatting color) {
        return new LiteralText(s).formatted(color);
    }

    private static Text plain(String s, Formatting color) {
        return new LiteralText(s).formatted(color).styled(st -> st.withItalic(false));
    }

    /** Строка с голубой полосой слева. */
    private static Text bar(MutableText... parts) {
        MutableText line = new LiteralText("▌ ").formatted(Formatting.AQUA);
        for (MutableText part : parts) {
            line.append(part);
        }
        return line.styled(st -> st.withItalic(false));
    }

    private static void lore(ItemStack stack, Text... lines) {
        NbtList list = new NbtList();
        for (Text line : lines) {
            list.add(NbtString.of(Text.Serializer.toJson(line)));
        }
        stack.getOrCreateSubTag("display").put("Lore", list);
    }
}
