package com.arsenal.sphere;

import com.arsenal.Arsenal;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.List;

public final class Spheres {
    private Spheres() {
    }

    /** Вектор уровней: скорость, урон, броня, скорость атаки, макс. здоровье. */
    public static int[] v(int speed, int damage, int armor, int attackSpeed, int health) {
        return new int[]{speed, damage, armor, attackSpeed, health};
    }

    private static int[] one(SphereEffect effect, int level) {
        int[] r = new int[SphereEffect.COUNT];
        r[effect.ordinal()] = level;
        return r;
    }

    /** Предмет с уровнями эффектов, записанными в зачарования. */
    public static ItemStack stack(Item item, int[] levels) {
        ItemStack s = new ItemStack(item);
        for (SphereEffect e : SphereEffect.values()) {
            if (levels[e.ordinal()] > 0) {
                s.addEnchantment(e.enchantment, levels[e.ordinal()]);
            }
        }
        return s;
    }

    /** Сумма уровней = "очки" сферы: 1 обычная, 2 эпическая, 3-4 легендарная, 5 мифическая. */
    public static int points(int[] levels) {
        int sum = 0;
        for (int l : levels) {
            sum += l;
        }
        return sum;
    }

    /** Сфера или талисман с одним случайным эффектом заданного уровня. */
    public static ItemStack randomEffect(Item item, int level, java.util.Random rnd) {
        SphereEffect[] all = SphereEffect.values();
        return stack(item, one(all[rnd.nextInt(all.length)], level));
    }

    /** Мифическая сфера с одним из трёх наборов, как в креативе. */
    public static ItemStack mythic(java.util.Random rnd) {
        int i = rnd.nextInt(3);
        return stack(Arsenal.SPHERE_MYTHIC, i == 0 ? v(0, 3, 2, 0, 0) : i == 1 ? v(0, 2, 3, 0, 0) : v(2, 0, 3, 0, 0));
    }

    /** Набор для креативной вкладки. */
    public static void addCreativeStacks(List<ItemStack> out) {
        for (SphereEffect e : SphereEffect.values()) {
            out.add(stack(Arsenal.SPHERE_COMMON, one(e, 1)));
        }
        for (SphereEffect e : SphereEffect.values()) {
            out.add(stack(Arsenal.SPHERE_EPIC, one(e, 2)));
        }
        for (SphereEffect e : SphereEffect.values()) {
            out.add(stack(Arsenal.SPHERE_LEGENDARY, one(e, 3)));
        }
        for (SphereEffect e : SphereEffect.values()) {
            out.add(stack(Arsenal.TALISMAN_COMMON, one(e, 1)));
        }
        for (SphereEffect e : SphereEffect.values()) {
            out.add(stack(Arsenal.TALISMAN, one(e, 2)));
        }
        for (SphereEffect e : SphereEffect.values()) {
            out.add(stack(Arsenal.TALISMAN_LEGENDARY, one(e, 3)));
        }
        // три мифические: урон 3 + броня 2, броня 3 + урон 2, броня 3 + скорость 2
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(0, 3, 2, 0, 0)));
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(0, 2, 3, 0, 0)));
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(2, 0, 3, 0, 0)));
        out.add(new ItemStack(Arsenal.SPHERE_FLASH));
        out.add(new ItemStack(Arsenal.SPHERE_CERBERUS));
        out.add(new ItemStack(Arsenal.SPHERE_STINGER));
        out.add(new ItemStack(Arsenal.SPHERE_ETERNITY));
        out.add(new ItemStack(Arsenal.TALISMAN_STINGER));
        out.add(new ItemStack(Arsenal.TALISMAN_ETERNITY));
        out.add(new ItemStack(Arsenal.TALISMAN_INFINITY));
        out.add(new ItemStack(Arsenal.TALISMAN_DRAGON));
    }
}
