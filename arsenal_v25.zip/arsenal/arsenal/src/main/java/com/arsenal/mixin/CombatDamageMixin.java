package com.arsenal.mixin;

import com.arsenal.combat.Combat;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Режим боя: урон игрока по игроку (удар, стрела, трезубец, зелье, взрыв от игрока). Мобы режим боя не включают. */
@Mixin(LivingEntity.class)
public abstract class CombatDamageMixin {
    @Inject(method = "damage", at = @At("RETURN"))
    private void arsenal$combat(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ()) {
            return;
        }
        Object self = this;
        Entity attacker = source.getAttacker();
        if (self instanceof ServerPlayerEntity && attacker instanceof ServerPlayerEntity) {
            Combat.tag((ServerPlayerEntity) attacker, (ServerPlayerEntity) self);
        }
    }
}
