package com.arsenal.artifact;

import com.arsenal.Arsenal;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;

/**
 * Рецепт наковальни: Артефакт + предмет-эффект Хранителя опыта = Артефакт с этим эффектом, 10 уровней.
 * Предметы-эффекты между собой не совмещаются, только с Артефактом.
 */
public final class ArtifactAnvil {
    public static final int EFFECT_COST = 10;

    public static class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private ArtifactAnvil() {
    }

    /** null = это не наш рецепт, остаётся обычное поведение наковальни. */
    public static Result compute(ItemStack left, ItemStack right) {
        if (left.getItem() == Arsenal.ARTIFACT) {
            return add(left, right);
        }
        if (right.getItem() == Arsenal.ARTIFACT) {
            return add(right, left);
        }
        return null;
    }

    private static Result add(ItemStack artifact, ItemStack other) {
        ArtifactEffect effect = ArtifactEffect.byItem(other.getItem());
        if (effect == null || effect.enchantment == null) {
            return null;
        }
        if (EnchantmentHelper.getLevel(effect.enchantment, artifact) > 0) {
            return null; // такой эффект на Артефакте уже есть
        }
        ItemStack result = artifact.copy();
        result.setCount(1);
        result.addEnchantment(effect.enchantment, 1);
        return new Result(result, EFFECT_COST);
    }
}
