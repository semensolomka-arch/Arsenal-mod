package com.arsenal.item;

import com.arsenal.artifact.ArtifactEffect;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/** Предмет-эффект Хранителя опыта. Сам по себе ничего не делает в руке, эффект работает из инвентаря. */
public class KeeperItem extends Item {
    private final ArtifactEffect effect;

    public KeeperItem(Settings settings, ArtifactEffect effect) {
        super(settings);
        this.effect = effect;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return effect.glint;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(new TranslatableText("item.arsenal.keeper_" + effect.id + ".desc").formatted(Formatting.GRAY));
        tooltip.add(new TranslatableText("item.arsenal.keeper.footer").formatted(Formatting.DARK_GRAY));
    }
}
