package com.arsenal;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

import java.util.Random;

/** Логика зачарований Критический и Разрушитель. */
public final class WeaponEffects {
    /** Критический I / II: шанс. */
    private static final float[] CRIT_CHANCE = {0.0F, 0.10F, 0.20F};
    /** Критический I / II: на сколько больше урона. */
    private static final float[] CRIT_BONUS = {0.0F, 0.15F, 0.20F};
    /** Разрушитель I / II / III: на сколько быстрее ломается броня. III бывает только на мече Цербера. */
    private static final float[] DESTROYER = {0.0F, 0.10F, 0.25F, 0.40F};

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private WeaponEffects() {
    }

    /** Оружие в руке атакующего, если это обычный ближний удар (не стрела, не шипы, не магия). */
    public static ItemStack meleeWeapon(DamageSource source) {
        Entity attacker = source.getAttacker();
        if (!(attacker instanceof LivingEntity) || attacker != source.getSource()) {
            return ItemStack.EMPTY;
        }
        String name = source.getName();
        if (!"player".equals(name) && !"mob".equals(name)) {
            return ItemStack.EMPTY;
        }
        return ((LivingEntity) attacker).getMainHandStack();
    }

    /** Критический: возвращает новый урон. */
    public static float applyCritical(LivingEntity target, ItemStack weapon, float damage, Random random) {
        int level = EnchantmentHelper.getLevel(Arsenal.CRITICAL, weapon);
        if (level <= 0) {
            return damage;
        }
        int i = Math.min(level, CRIT_CHANCE.length - 1);
        if (random.nextFloat() >= CRIT_CHANCE[i]) {
            return damage;
        }
        if (target.world instanceof ServerWorld) {
            ((ServerWorld) target.world).spawnParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY() + target.getHeight() * 0.5D, target.getZ(),
                    10, 0.3D, 0.3D, 0.3D, 0.2D);
        }
        // звук: обычный крит накладывается на звук удара по щиту
        target.world.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1.0F, 1.0F);
        target.world.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        return damage * (1.0F + CRIT_BONUS[i]);
    }

    /**
     * Разрушитель: броня игрока ломается быстрее на 10/25/40%.
     * Ванильный износ одной части брони = max(1, урон / 4); добавляем к нему нужный процент
     * (дробная часть разыгрывается шансом, так что в среднем получается ровно столько процентов).
     */
    public static void applyDestroyer(LivingEntity target, ItemStack weapon, float rawDamage, Random random) {
        int level = EnchantmentHelper.getLevel(Arsenal.DESTROYER, weapon);
        if (level <= 0 || !(target instanceof PlayerEntity)) {
            return;
        }
        float percent = DESTROYER[Math.min(level, DESTROYER.length - 1)];
        int base = Math.max(1, (int) (rawDamage / 4.0F));
        float extra = base * percent;
        int wear = (int) extra;
        if (random.nextFloat() < extra - wear) {
            wear++;
        }
        if (wear <= 0) {
            return;
        }
        for (EquipmentSlot slot : ARMOR) {
            ItemStack stack = target.getEquippedStack(slot);
            if (stack.getItem() instanceof ArmorItem && stack.isDamageable()) {
                stack.damage(wear, target, e -> e.sendEquipmentBreakStatus(slot));
            }
        }
    }
}
