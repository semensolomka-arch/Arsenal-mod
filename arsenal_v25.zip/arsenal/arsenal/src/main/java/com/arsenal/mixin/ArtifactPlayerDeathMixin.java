package com.arsenal.mixin;

import com.arsenal.artifact.ArtifactEffects;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Смерть игрока: Охотник (50% опыта убитого) и Телекинез. */
@Mixin(ServerPlayerEntity.class)
public abstract class ArtifactPlayerDeathMixin {
    @Inject(method = "onDeath", at = @At("RETURN"))
    private void arsenal$artifactPlayerKill(DamageSource source, CallbackInfo ci) {
        ArtifactEffects.onKill((ServerPlayerEntity) (Object) this, source);
    }
}
