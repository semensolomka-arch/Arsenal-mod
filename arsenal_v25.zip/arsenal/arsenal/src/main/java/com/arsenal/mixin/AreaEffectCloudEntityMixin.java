package com.arsenal.mixin;

import com.arsenal.artifact.ArtifactEffects;
import net.minecraft.entity.AreaEffectCloudEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** То же для туманных (затяжных) зелий: пока облако накладывает эффекты, считаем их "от зелья". */
@Mixin(AreaEffectCloudEntity.class)
public abstract class AreaEffectCloudEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void arsenal$cloudStart(CallbackInfo ci) {
        ArtifactEffects.fromPotion = true;
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void arsenal$cloudEnd(CallbackInfo ci) {
        ArtifactEffects.fromPotion = false;
    }
}
