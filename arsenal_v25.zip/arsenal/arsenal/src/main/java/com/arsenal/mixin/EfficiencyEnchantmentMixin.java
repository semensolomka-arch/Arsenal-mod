package com.arsenal.mixin;

import net.minecraft.enchantment.EfficiencyEnchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Эффективность стакается в наковальне до X, а из стола зачарований максимум V. */
@Mixin(EfficiencyEnchantment.class)
public class EfficiencyEnchantmentMixin {
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void arsenal$maxLevel(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(10);
    }

    @Inject(method = "getMinPower", at = @At("HEAD"), cancellable = true)
    private void arsenal$tableLimit(int level, CallbackInfoReturnable<Integer> cir) {
        if (level > 5) {
            cir.setReturnValue(10000);
        }
    }
}
