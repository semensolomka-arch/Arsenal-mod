package com.arsenal.item;

import com.arsenal.rune.RuneType;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/** Руна: в наковальне её можно вложить в тотем бессмертия или талисман (10 уровней). */
public class RuneItem extends Item {
    public final RuneType type;

    public RuneItem(Settings settings, RuneType type) {
        super(settings);
        this.type = type;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(this.getTranslationKey(stack)).formatted(type.color);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(new TranslatableText("item.arsenal.rune_" + type.id + ".desc").formatted(Formatting.GRAY));
        tooltip.add(new TranslatableText("item.arsenal.rune.footer").formatted(Formatting.DARK_GRAY));
    }
}
