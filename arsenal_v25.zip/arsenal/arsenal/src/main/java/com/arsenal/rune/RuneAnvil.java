package com.arsenal.rune;

import com.arsenal.item.RuneItem;
import net.minecraft.item.ItemStack;

/**
 * Рецепт наковальни: тотем бессмертия или талисман + руна = тот же предмет с этой руной (10 уровней).
 * Одну и ту же руну дважды вложить нельзя, несовместимых рун нет.
 */
public final class RuneAnvil {
    public static class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private RuneAnvil() {
    }

    /** null = это не наш рецепт. */
    public static Result compute(ItemStack left, ItemStack right) {
        if (Runes.canCarry(left.getItem()) && right.getItem() instanceof RuneItem) {
            return add(left, ((RuneItem) right.getItem()).type);
        }
        if (Runes.canCarry(right.getItem()) && left.getItem() instanceof RuneItem) {
            return add(right, ((RuneItem) left.getItem()).type);
        }
        return null;
    }

    private static Result add(ItemStack carrier, RuneType rune) {
        if (rune.enchantment == null || Runes.has(carrier, rune)) {
            return null;
        }
        ItemStack result = carrier.copy();
        result.setCount(1);
        result.addEnchantment(rune.enchantment, 1);
        return new Result(result, Runes.ANVIL_COST);
    }
}
