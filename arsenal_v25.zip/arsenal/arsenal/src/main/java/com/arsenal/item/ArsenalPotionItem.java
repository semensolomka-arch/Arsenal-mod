package com.arsenal.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

/** Стакуемое зелье Arsenal с обычной анимацией питья. */
public class ArsenalPotionItem extends Item {
    public final boolean strength;
    public final int level;
    public final int duration;

    public ArsenalPotionItem(boolean strength, int level, int duration, Settings settings) {
        super(settings);
        this.strength = strength;
        this.level = level;
        this.duration = duration;
    }

    /** Начинаем пить; эффект не применяется до завершения анимации. */
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    /** Обычная длительность питья зелья в Minecraft — 32 тика. */
    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 32;
    }

    /** Используем стандартную анимацию питья и звук. */
    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }

    /** Вызывается только после того, как игрок закончил пить. */
    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient) {
            StatusEffect effect = strength ? StatusEffects.STRENGTH : StatusEffects.SPEED;
            user.addStatusEffect(new StatusEffectInstance(effect, duration, level - 1, false, true, true));
        }

        if (user instanceof PlayerEntity && ((PlayerEntity) user).abilities.creativeMode) {
            return stack;
        }

        stack.decrement(1);
        return stack.isEmpty() ? ItemStack.EMPTY : stack;
    }
}
