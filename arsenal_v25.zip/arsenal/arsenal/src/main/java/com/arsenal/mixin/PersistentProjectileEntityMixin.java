package com.arsenal.mixin;

import com.arsenal.tool.ToolEnchants;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Оглушение: стрела запоминает, что выпущена луком или арбалетом с этим зачарованием,
 * и при попадании с шансом 5% даёт Замедление IV и Слепоту I на 10 секунд.
 */
@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityMixin {
    @Unique
    private boolean arsenal$stunning;

    @Inject(method = "<init>(Lnet/minecraft/entity/EntityType;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;)V",
            at = @At("RETURN"))
    private void arsenal$tagStun(EntityType<?> type, LivingEntity owner, World world, CallbackInfo ci) {
        if ((Object) this instanceof TridentEntity) {
            return;
        }
        ItemStack weapon = owner.isUsingItem() ? owner.getActiveItem() : owner.getMainHandStack();
        if (!(weapon.getItem() instanceof BowItem || weapon.getItem() instanceof CrossbowItem)) {
            weapon = owner.getOffHandStack();
        }
        if (weapon.getItem() instanceof BowItem || weapon.getItem() instanceof CrossbowItem) {
            arsenal$stunning = EnchantmentHelper.getLevel(ToolEnchants.STUNNING, weapon) > 0;
        }
    }

    @Inject(method = "onEntityHit", at = @At("TAIL"))
    private void arsenal$stunOnHit(EntityHitResult hit, CallbackInfo ci) {
        if (!arsenal$stunning) {
            return;
        }
        Entity e = hit.getEntity();
        if (!(e instanceof LivingEntity) || e.world.isClient) {
            return;
        }
        LivingEntity target = (LivingEntity) e;
        if (target.hurtTime <= 0 || e.world.random.nextFloat() >= ToolEnchants.STUN_CHANCE) {
            return;
        }
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 3));
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0));
    }
}
