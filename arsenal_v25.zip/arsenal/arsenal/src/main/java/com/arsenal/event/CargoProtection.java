package com.arsenal.event;

import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorStandItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.DecorationItem;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MinecartItem;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * Защита зоны груза: нельзя ломать и ставить блоки, лить воду и лаву, ставить огонь и рамки.
 * Шалкеры груза до открытия не открываются. Операторы в творческом режиме могут всё.
 */
final class CargoProtection {
    private static final String BUILD = "В зоне груза нельзя ломать и строить";

    private CargoProtection() {
    }

    private static boolean places(Item item) {
        return item instanceof BlockItem || item instanceof FlintAndSteelItem || item instanceof FireChargeItem
                || item instanceof ArmorStandItem || item instanceof DecorationItem || item instanceof MinecartItem;
    }

    private static void deny(PlayerEntity player, String message) {
        if (player instanceof ServerPlayerEntity) {
            SpawnProtection.deny((ServerPlayerEntity) player, message);
        }
    }

    static void init() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || !EventManager.inZone(world, pos) || SpawnProtection.bypass(player)) {
                return true;
            }
            deny(player, BUILD);
            return false;
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (EventManager.inZone(world, pos) && !SpawnProtection.bypass(player)) {
                if (!world.isClient) {
                    deny(player, BUILD);
                }
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            BlockPos clicked = hit.getBlockPos();
            BlockPos target = clicked.offset(hit.getSide());
            boolean zone = EventManager.inZone(world, clicked) || EventManager.inZone(world, target);
            if (!zone || SpawnProtection.bypass(player)) {
                return ActionResult.PASS;
            }
            ItemStack stack = player.getStackInHand(hand);
            int st = EventManager.shulkerState(world, clicked);
            if (st == 0) {
                if (!world.isClient) {
                    deny(player, "Груз ещё закрыт, осталось " + EventManager.untilOpen());
                }
                return ActionResult.FAIL;
            }
            if (st == 1 && !(player.isSneaking() && places(stack.getItem()))) {
                return ActionResult.PASS;
            }
            if (places(stack.getItem())) {
                if (!world.isClient) {
                    deny(player, BUILD);
                }
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!(stack.getItem() instanceof BucketItem) || SpawnProtection.bypass(player)) {
                return TypedActionResult.pass(stack);
            }
            HitResult hit = player.raycast(5.0D, 1.0F, true);
            if (hit.getType() == HitResult.Type.BLOCK && EventManager.inZone(world, ((BlockHitResult) hit).getBlockPos())) {
                if (!world.isClient) {
                    deny(player, BUILD);
                }
                return TypedActionResult.fail(stack);
            }
            return TypedActionResult.pass(stack);
        });
    }
}
