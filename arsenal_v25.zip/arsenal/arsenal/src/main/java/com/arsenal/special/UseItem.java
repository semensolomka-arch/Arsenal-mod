package com.arsenal.special;

import com.arsenal.Lore;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Предмет с действием по ПКМ в руке (взрывная трапка, взрывная штучка, светильник Джейка). */
public class UseItem extends Item {
    public interface Action {
        /** Возвращает true, если предмет сработал (тогда он тратится внутри Action). */
        boolean run(ServerPlayerEntity player, ItemStack stack);
    }

    private final Action action;
    private final boolean glint;
    private final String tooltipKey;
    private final int lines;
    private final int highlight;
    private final int nameFrom;
    private final int nameTo;

    public UseItem(Settings settings, Action action, boolean glint, String tooltipKey, int lines, int highlight,
                   int nameFrom, int nameTo) {
        super(settings);
        this.action = action;
        this.glint = glint;
        this.tooltipKey = tooltipKey;
        this.lines = lines;
        this.highlight = highlight;
        this.nameFrom = nameFrom;
        this.nameTo = nameTo;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return glint;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient || !(user instanceof ServerPlayerEntity)) {
            return TypedActionResult.success(stack, world.isClient());
        }
        boolean ok = action.run((ServerPlayerEntity) user, stack);
        return ok ? TypedActionResult.success(stack) : TypedActionResult.fail(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, tooltipKey + ".", lines, highlight);
    }

    @Override
    public Text getName(ItemStack stack) {
        // градиент туда и обратно, как в плагине
        return Lore.gradientName(this.getTranslationKey(stack), nameFrom, nameTo, true);
    }
}
