package com.arsenal.mixin;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.item.LingeringPotionItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Also sets the effective stack limit at ItemStack level for vanilla potions. */
@Mixin(ItemStack.class)
public abstract class PotionItemStackMixin {
    @Inject(method = "getMaxCount", at = @At("HEAD"), cancellable = true)
    private void arsenal$stackPotionStacks(CallbackInfoReturnable<Integer> cir) {
        Item item = ((ItemStack) (Object) this).getItem();
        if (item instanceof PotionItem || item instanceof SplashPotionItem || item instanceof LingeringPotionItem) {
            cir.setReturnValue(64);
        }
    }
}
