package com.arsenal.item;

import com.arsenal.Abilities;
import com.arsenal.GlintItem;
import com.arsenal.Lore;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Трапка в руке: ПКМ - клетка вокруг игрока. */
public class TrapItem extends GlintItem {
    public TrapItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            Abilities.useTrap((ServerPlayerEntity) user, stack);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(this.getTranslationKey(stack)).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xFF55FF)).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal.trap.", 5, 0xFF55FF);
    }
}
