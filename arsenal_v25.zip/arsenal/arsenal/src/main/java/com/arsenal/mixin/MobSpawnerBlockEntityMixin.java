package com.arsenal.mixin;

import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.MobSpawnerEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 1) Только что поставленный спавнер без данных пустой (без моба): моба в него вставляют яйцом призыва.
 * 2) Спавнер с мобом в предмете (например, после стиллера) ставит с этим мобом любой игрок:
 * в ванили это умеют только операторы в творческом режиме.
 */
@Mixin(MobSpawnerBlockEntity.class)
public abstract class MobSpawnerBlockEntityMixin {
    @Inject(method = "<init>", at = @At("TAIL"))
    private void arsenal$emptyByDefault(CallbackInfo ci) {
        ((MobSpawnerBlockEntity) (Object) this).getLogic().setSpawnEntry(new MobSpawnerEntry(1, new NbtCompound()));
    }

    @Inject(method = "copyItemDataRequiresOperator", at = @At("HEAD"), cancellable = true)
    private void arsenal$anyPlayerCanPlaceData(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }
}
