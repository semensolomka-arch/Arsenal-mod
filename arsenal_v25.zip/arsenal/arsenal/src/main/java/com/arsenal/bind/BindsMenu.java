package com.arsenal.bind;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumMap;

/**
 * Меню /binds "Горячие клавиши" (сундук 3x9).
 * Во втором ряду предметы (слоты 10..15). В описании каждого список действий, выбранное оранжевое.
 * Клик ЛКМ: следующее действие, ПКМ: предыдущее. Розовая панель в третьем ряду сбрасывает всё.
 */
public final class BindsMenu {
    /** Первый слот предметов (второй ряд, вторая колонка). */
    private static final int FIRST_SLOT = 10;
    private static final int RESET_SLOT = 22;
    /** Порядок действий в списке (как в Key). */
    private static final Binds.Key[] KEYS = Binds.Key.values();

    private BindsMenu() {
    }

    public static void open(ServerPlayerEntity player) {
        SimpleInventory inventory = new SimpleInventory(27);
        fill(player, inventory);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new BindsScreenHandler(syncId, playerInventory, inventory),
                new LiteralText("Горячие клавиши")));
    }

    private static void fill(ServerPlayerEntity player, SimpleInventory inventory) {
        for (int i = 0; i < inventory.size(); i++) {
            inventory.setStack(i, ItemStack.EMPTY);
        }
        EnumMap<Binds.Bind, Binds.Key> current = Binds.of(player);
        Binds.Bind[] binds = Binds.Bind.values();
        for (int i = 0; i < binds.length; i++) {
            inventory.setStack(FIRST_SLOT + i, bindStack(binds[i], current.get(binds[i])));
        }

        ItemStack reset = new ItemStack(Items.PINK_STAINED_GLASS_PANE);
        reset.setCustomName(new LiteralText("Выключить всё").formatted(Formatting.GREEN).styled(s -> s.withItalic(false)));
        MutableText click = new LiteralText("► ").formatted(Formatting.GREEN)
                .append(new LiteralText("Нажмите, чтобы сбросить горячие клавиши").formatted(Formatting.WHITE));
        lore(reset, new LiteralText(""), click.styled(s -> s.withItalic(false)));
        inventory.setStack(RESET_SLOT, reset);
    }

    private static ItemStack bindStack(Binds.Bind bind, Binds.Key selected) {
        ItemStack stack = new ItemStack(bind.item());
        // название предмета с его цветом
        Text itemName = stack.getName();
        stack.setCustomName(itemName.shallowCopy().styled(s -> s.withItalic(false)));

        java.util.List<Text> lines = new java.util.ArrayList<>();
        lines.add(new LiteralText(""));
        lines.add(plain("Действие:", Formatting.GRAY));
        for (Binds.Key key : KEYS) {
            boolean on = key == selected;
            MutableText line = new LiteralText("   ● ").formatted(on ? Formatting.GOLD : Formatting.AQUA);
            line.append(new LiteralText(key.title).formatted(on ? Formatting.GOLD : Formatting.WHITE));
            lines.add(line.styled(s -> s.withItalic(false)));
        }
        lines.add(new LiteralText(""));
        lines.add(footer(new LiteralText(condition(selected)).formatted(Formatting.WHITE)));
        MutableText second = new LiteralText("вы активируете предмет ").formatted(Formatting.WHITE);
        second.append(itemName.shallowCopy().styled(s -> s.withItalic(false)));
        lines.add(footer(second));
        lore(stack, lines.toArray(new Text[0]));
        return stack;
    }

    private static String condition(Binds.Key key) {
        switch (key) {
            case DROP:
                return "При выбросе Незеритового меча,";
            case OFFHAND:
                return "При взятии во вторую руку Незеритового меча,";
            case USE:
                return "При нажатии ПКМ с Незеритовым мечом в руке,";
            default:
                return "При ручной активации,";
        }
    }

    /** Строка с голубой полосой слева. */
    private static Text footer(MutableText text) {
        MutableText line = new LiteralText("▍ ").formatted(Formatting.AQUA);
        line.append(text);
        return line.styled(s -> s.withItalic(false));
    }

    private static Text plain(String s, Formatting color) {
        return new LiteralText(s).formatted(color).styled(st -> st.withItalic(false));
    }

    private static void lore(ItemStack stack, Text... lines) {
        NbtList list = new NbtList();
        for (Text line : lines) {
            list.add(NbtString.of(Text.Serializer.toJson(line)));
        }
        NbtCompound display = stack.getOrCreateSubTag("display");
        display.put("Lore", list);
    }

    /** clickData: 0 = ЛКМ (следующее действие), 1 = ПКМ (предыдущее). */
    static void onClick(ServerPlayerEntity player, int slot, int clickData, SimpleInventory menu) {
        if (slot == RESET_SLOT) {
            Binds.resetAll(player);
            fill(player, menu);
            return;
        }
        Binds.Bind[] binds = Binds.Bind.values();
        int index = slot - FIRST_SLOT;
        if (index < 0 || index >= binds.length) {
            return;
        }
        Binds.Key now = Binds.of(player).get(binds[index]);
        int step = clickData == 1 ? KEYS.length - 1 : 1;
        Binds.set(player, binds[index], KEYS[(now.ordinal() + step) % KEYS.length]);
        fill(player, menu);
    }
}
