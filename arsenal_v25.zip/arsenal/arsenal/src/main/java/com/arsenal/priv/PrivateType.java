package com.arsenal.priv;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/** Виды приватов: размер территории (куб), прочность (сколько взрывов выдерживает), стойкость к взрыву и цвет названия. */
public enum PrivateType {
    /** Обычные блоки: поставленные без Shift они работают как приват. */
    IRON("private_iron", 5, 1, 6.0F, 0xD8D8D8, false),
    GOLD("private_gold", 7, 1, 6.0F, 0xFFD700, false),
    DIAMOND("private_diamond", 11, 1, 6.0F, 0x55FFFF, false),
    EMERALD("private_emerald", 21, 1, 3.0F, 0x55FF55, false),
    /** 2 прочности, повреждают только C4 и разрывная волна. */
    NETHERITE("private_netherite", 31, 2, 12.0F, 0xB48CFF, true),
    /** Отдельный блок из креатива (текстура древних обломков), 4 прочности, только C4 и разрывная волна. */
    UNIQUE("private_unique", 31, 4, 1200.0F, 0xFF55FF, true);

    public final String id;
    public final int size;
    /** Сколько блоков от центра до края (для 5 это 2, для 31 это 15). */
    public final int half;
    public final int durability;
    public final float resistance;
    public final int color;
    /** Приват выдерживает любые взрывы, кроме C4 и разрывной волны. */
    public final boolean c4Only;

    /** Заполняется (только у UNIQUE, остальные это обычные блоки)  при регистрации. */
    public Block block;
    public Item item;

    PrivateType(String id, int size, int durability, float resistance, int color, boolean c4Only) {
        this.c4Only = c4Only;
        this.id = id;
        this.size = size;
        this.half = size / 2;
        this.durability = durability;
        this.resistance = resistance;
        this.color = color;
    }

    /** Блок, который виден в мире (обычный или свой блок уникального привата). */
    public Block displayBlock() {
        return this == UNIQUE ? block : vanillaBlock();
    }

    public String translationKey() {
        return displayBlock().getTranslationKey();
    }

    /** Приват по блоку (только обычные блоки; уникальный находится по своему блоку). */
    public static PrivateType ofBlock(Block b) {
        for (PrivateType t : values()) {
            if (t != UNIQUE && t.vanillaBlock() == b) {
                return t;
            }
        }
        return b == UNIQUE.block ? UNIQUE : null;
    }

    /** Новый предмет привата (полная прочность). */
    public net.minecraft.item.ItemStack freshStack() {
        return PrivateBlockItem.stackWith(this, durability);
    }

    /** Обычный блок, который ставится при установке с Shift. */
    public Block vanillaBlock() {
        switch (this) {
            case IRON:
                return Blocks.IRON_BLOCK;
            case GOLD:
                return Blocks.GOLD_BLOCK;
            case DIAMOND:
                return Blocks.DIAMOND_BLOCK;
            case EMERALD:
                return Blocks.EMERALD_ORE;
            case NETHERITE:
                return Blocks.NETHERITE_BLOCK;
            default:
                return Blocks.ANCIENT_DEBRIS;
        }
    }

    /** Что падает, если ломать приват с Shift (изумрудная руда даёт изумруд). */
    public Item shiftDrop() {
        switch (this) {
            case IRON:
                return Items.IRON_BLOCK;
            case GOLD:
                return Items.GOLD_BLOCK;
            case DIAMOND:
                return Items.DIAMOND_BLOCK;
            case EMERALD:
                return Items.EMERALD;
            case NETHERITE:
                return Items.NETHERITE_BLOCK;
            default:
                return Items.ANCIENT_DEBRIS;
        }
    }

    public boolean canBePlainBlock() {
        return this != UNIQUE;
    }
}
