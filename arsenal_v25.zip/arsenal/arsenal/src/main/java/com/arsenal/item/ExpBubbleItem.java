package com.arsenal.item;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * Пузырь опыта: ПКМ с ним в руке (из хотбара) чинит на 25% от максимальной прочности
 * всю надетую броню с Починкой. Кулдаун 3 минуты. Если чинить нечего, предмет не тратится.
 */
public class ExpBubbleItem extends Item {
    public static final int COOLDOWN_TICKS = 20 * 60 * 3;
    public static final int REPAIR_PERCENT = 25;

    public ExpBubbleItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true; // как у обычного пузырька опыта
    }

    private static boolean canRepair(ItemStack armor) {
        return !armor.isEmpty() && armor.isDamaged() && EnchantmentHelper.getLevel(Enchantments.MENDING, armor) > 0;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        boolean anything = false;
        for (ItemStack armor : user.getArmorItems()) {
            if (canRepair(armor)) {
                anything = true;
                break;
            }
        }
        if (!anything) {
            if (!world.isClient) {
                user.sendMessage(new LiteralText("Нечего чинить: нужна надетая повреждённая броня с Починкой.")
                        .formatted(Formatting.YELLOW), true);
            }
            return TypedActionResult.fail(stack);
        }

        if (!world.isClient) {
            for (ItemStack armor : user.getArmorItems()) {
                if (canRepair(armor)) {
                    int amount = Math.max(1, armor.getMaxDamage() * REPAIR_PERCENT / 100);
                    armor.setDamage(Math.max(0, armor.getDamage() - amount));
                }
            }
            world.playSound(null, user.getX(), user.getY(), user.getZ(),
                    SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
            user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
            if (!user.isCreative()) {
                stack.decrement(1);
            }
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
