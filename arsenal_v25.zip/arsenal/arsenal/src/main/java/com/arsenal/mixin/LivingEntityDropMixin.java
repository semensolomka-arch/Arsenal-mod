package com.arsenal.mixin;

import com.arsenal.tool.Filters;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Запоминает, кто убил моба, пока выпадает его добыча (нужно зачарованию Фильтр). */
@Mixin(LivingEntity.class)
public abstract class LivingEntityDropMixin {
    @Inject(method = "drop(Lnet/minecraft/entity/damage/DamageSource;)V", at = @At("HEAD"))
    private void arsenal$dropStart(DamageSource source, CallbackInfo ci) {
        Filters.killer = source.getAttacker();
    }

    @Inject(method = "drop(Lnet/minecraft/entity/damage/DamageSource;)V", at = @At("RETURN"))
    private void arsenal$dropEnd(DamageSource source, CallbackInfo ci) {
        Filters.killer = null;
    }
}
