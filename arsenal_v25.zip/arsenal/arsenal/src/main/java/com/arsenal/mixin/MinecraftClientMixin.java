package com.arsenal.mixin;

import com.arsenal.bind.Binds;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.network.PacketByteBuf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехватывает Q и F ДО ванильной обработки (настройки: /binds).
 * Если на клавишу что-то забиндено и в руке оружие, нажатие "съедается" (оружие не выбрасывается,
 * руки не меняются), а серверу уходит пакет. Что именно сработает и что написать в чат,
 * решает сервер. Если на клавишу ничего не забиндено, всё работает как в ванили.
 */
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void arsenal$handleKeys(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient) (Object) this;
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.currentScreen != null || player.isSpectator()) {
            return;
        }
        arsenal$handle(mc, player, Binds.Key.DROP, mc.options.keyDrop);        // Q (выброс)
        arsenal$handle(mc, player, Binds.Key.OFFHAND, mc.options.keySwapHands); // F (смена рук)
    }

    private static void arsenal$handle(MinecraftClient mc, ClientPlayerEntity player, Binds.Key key, KeyBinding keyBinding) {
        if (!Binds.keyAvailable(player, key) || Binds.boundTo(player, key).isEmpty()) {
            return;
        }
        boolean pressed = false;
        while (keyBinding.wasPressed()) {
            pressed = true;
        }
        if (pressed) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeByte(key.ordinal());
            ClientPlayNetworking.send(Binds.USE_BIND, buf);
        }
    }
}
