package com.arsenal.expkeeper;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Меню "Хранитель опыта": обычный сундук 3x3 ряда, но предметы из него взять нельзя,
 * клик по зелью = покупка эффекта. Работает только на сервере, клиенту мод для меню не нужен.
 */
public class KeeperScreenHandler extends GenericContainerScreenHandler {
    private final SimpleInventory menu;

    public KeeperScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu) {
        super(ScreenHandlerType.GENERIC_9X3, syncId, playerInventory, menu, 3);
        this.menu = menu;
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        // слоты меню (0..26): ничего не двигаем, только обрабатываем клик
        if (slotIndex >= 0 && slotIndex < 27) {
            if ((actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)
                    && player instanceof ServerPlayerEntity) {
                ExpKeeper.onMenuClick((ServerPlayerEntity) player, slotIndex, menu);
            }
            return ItemStack.EMPTY;
        }
        // нельзя закинуть вещи в меню шифт-кликом, двойным кликом или перетаскиванием
        if (actionType == SlotActionType.QUICK_MOVE
                || actionType == SlotActionType.PICKUP_ALL
                || actionType == SlotActionType.QUICK_CRAFT) {
            return ItemStack.EMPTY;
        }
        return super.onSlotClick(slotIndex, clickData, actionType, player);
    }
}
