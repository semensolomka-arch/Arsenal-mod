package com.arsenal.castle;

import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.Heightmap;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;
import java.util.zip.GZIPInputStream;

/**
 * Один раз при создании мира выравнивает местность вокруг (ровная зона привата и пологий склон за ней),
 * ставит замок по центру на 0,0, выравнивает под него основание и переносит туда спавн. Данные замка лежат в ресурсе /castle/castle.bin (сделан из zamok.schem).
 * Чтобы построить замок ещё раз, удали файл arsenal_castle_placed.txt из папки мира.
 */
public final class CastleBuilder {
    private static final String MARKER = "arsenal_castle_placed.txt";
    /** 2 = отправить клиентам, 16 = без обновления соседей (состояния блоков остаются как в схеме). */
    private static final int FLAGS = 2 | 16;
    /** Ширина пологого склона за границей защищённой зоны (в блоках). */
    private static final int SLOPE_WIDTH = 60;
    /** Не ниже этого уровня верхнего блока земли (чуть выше уровня моря), чтобы замок не оказался в воде. */
    private static final int MIN_GROUND_TOP = 63;
    /** На каком расстоянии от края замка срезанная земля плавно сливается с настоящей (в блоках). */
    private static final int EDGE_BLEND = 30;

    private CastleBuilder() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(CastleBuilder::onServerStarted);
    }

    private static void onServerStarted(MinecraftServer server) {
        Path marker = server.getSavePath(WorldSavePath.ROOT).resolve(MARKER);
        if (Files.exists(marker)) {
            return;
        }
        try {
            build(server);
            Files.write(marker, "ok".getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось построить замок: " + e);
            e.printStackTrace();
        }
    }

    // ---------------- данные ----------------

    private static class Data {
        int w, h, l;
        int spawnX, spawnY, spawnZ;
        String[] palette;
        int[] runIndex;
        int[] runLength;
        int[] beX, beY, beZ;
        String[] beState;
        int[] trimX, trimZ, trimG;
    }

    private static Data load() throws IOException {
        InputStream resource = CastleBuilder.class.getResourceAsStream("/castle/castle.bin");
        if (resource == null) {
            throw new IOException("нет файла castle.bin в моде");
        }
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(resource)))) {
            byte[] magic = new byte[4];
            in.readFully(magic);
            if (!"ARSC".equals(new String(magic, StandardCharsets.US_ASCII))) {
                throw new IOException("неверный формат castle.bin");
            }
            Data d = new Data();
            d.w = in.readInt();
            d.h = in.readInt();
            d.l = in.readInt();
            d.spawnX = in.readInt();
            d.spawnY = in.readInt();
            d.spawnZ = in.readInt();
            d.palette = new String[in.readInt()];
            for (int i = 0; i < d.palette.length; i++) {
                d.palette[i] = readString(in);
            }
            int runs = in.readInt();
            d.runIndex = new int[runs];
            d.runLength = new int[runs];
            for (int i = 0; i < runs; i++) {
                d.runIndex[i] = readVarInt(in);
                d.runLength[i] = readVarInt(in);
            }
            int entities = in.readInt();
            d.beX = new int[entities];
            d.beY = new int[entities];
            d.beZ = new int[entities];
            d.beState = new String[entities];
            for (int i = 0; i < entities; i++) {
                d.beX[i] = in.readInt();
                d.beY[i] = in.readInt();
                d.beZ[i] = in.readInt();
                d.beState[i] = readString(in);
            }
            int trims = in.readInt();
            d.trimX = new int[trims];
            d.trimZ = new int[trims];
            d.trimG = new int[trims];
            for (int i = 0; i < trims; i++) {
                d.trimX[i] = in.readInt();
                d.trimZ[i] = in.readInt();
                d.trimG[i] = in.readInt();
            }
            return d;
        }
    }

    private static String readString(DataInputStream in) throws IOException {
        byte[] bytes = new byte[in.readInt()];
        in.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int value = 0;
        int shift = 0;
        while (true) {
            int b = in.readUnsignedByte();
            value |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) {
                return value;
            }
            shift += 7;
        }
    }

    // ---------------- блоки ----------------

    private static BlockState parseState(String text) {
        String name = text;
        String props = null;
        int bracket = text.indexOf('[');
        if (bracket >= 0) {
            name = text.substring(0, bracket);
            props = text.substring(bracket + 1, text.length() - 1);
        }
        Block block = Registry.BLOCK.get(new Identifier(name));
        BlockState state = block.getDefaultState();
        if (props != null && !props.isEmpty()) {
            for (String pair : props.split(",")) {
                int eq = pair.indexOf('=');
                if (eq < 0) {
                    continue;
                }
                Property<?> property = block.getStateManager().getProperty(pair.substring(0, eq));
                if (property != null) {
                    state = withProperty(state, property, pair.substring(eq + 1));
                }
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withProperty(BlockState state, Property<T> property, String value) {
        Optional<T> parsed = property.parse(value);
        return parsed.isPresent() ? state.with(property, parsed.get()) : state;
    }

    // ---------------- рельеф ----------------

    /** Верхний блок настоящей земли в колонке: деревья, листва, растения и вода не считаются. */
    private static int groundTopAt(ServerWorld world, int x, int z, BlockPos.Mutable pos) {
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        while (y > 1) {
            pos.set(x, y, z);
            BlockState state = world.getBlockState(pos);
            if (!state.getMaterial().blocksMovement() || state.isIn(BlockTags.LEAVES) || state.isIn(BlockTags.LOGS)) {
                y--;
            } else {
                break;
            }
        }
        return y;
    }

    /**
     * Вся защищённая зона становится ровной (на высоте замка, горы срезаются, ямы и вода засыпаются).
     * За её границей на SLOPE_WIDTH блоков высота плавно переходит в настоящий рельеф, поэтому нет резких обрывов.
     */
    private static void flatten(ServerWorld world, int groundTop, int pMinX, int pMaxX, int pMinZ, int pMaxZ,
                                BlockPos.Mutable pos) {
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState dirt = Blocks.DIRT.getDefaultState();
        BlockState grass = Blocks.GRASS_BLOCK.getDefaultState();
        BlockState water = Blocks.WATER.getDefaultState();
        int waterTop = world.getSeaLevel() - 1; // верхний блок воды у уровня моря

        for (int x = pMinX - SLOPE_WIDTH; x <= pMaxX + SLOPE_WIDTH; x++) {
            for (int z = pMinZ - SLOPE_WIDTH; z <= pMaxZ + SLOPE_WIDTH; z++) {
                int dx = Math.max(0, Math.max(pMinX - x, x - pMaxX));
                int dz = Math.max(0, Math.max(pMinZ - z, z - pMaxZ));
                double dist = Math.sqrt((double) dx * dx + (double) dz * dz);
                if (dist >= SLOPE_WIDTH) {
                    continue;
                }
                boolean inside = dist <= 0;

                int natural = groundTopAt(world, x, z, pos);
                int target;
                if (inside) {
                    target = groundTop;
                } else {
                    double t = dist / SLOPE_WIDTH;
                    double smooth = t * t * (3 - 2 * t);
                    target = (int) Math.round(groundTop + (natural - groundTop) * smooth);
                }
                target = Math.max(2, Math.min(250, target));
                if (!inside && target == natural) {
                    continue; // рельеф уже подходит, деревья и всё остальное оставляем
                }

                // какой верхний слой был у земли: песок оставляем песком, остальное делаем травой
                pos.set(x, natural, z);
                BlockState naturalTop = world.getBlockState(pos);
                pos.set(x, natural + 1, z);
                boolean wet = !world.getBlockState(pos).getFluidState().isEmpty();
                boolean sandy = !wet && (naturalTop.isOf(Blocks.SAND) || naturalTop.isOf(Blocks.RED_SAND));
                BlockState surface = sandy ? naturalTop : grass;
                BlockState soft = sandy ? naturalTop : dirt;

                // сносим всё выше цели: горы, деревья, воду
                int top = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
                for (int y = top - 1; y > target; y--) {
                    pos.set(x, y, z);
                    if (!world.getBlockState(pos).isAir()) {
                        world.setBlockState(pos, air, FLAGS);
                    }
                }
                // засыпаем ямы землёй
                for (int y = natural + 1; y < target; y++) {
                    pos.set(x, y, z);
                    world.setBlockState(pos, soft, FLAGS);
                }
                // поверхность
                pos.set(x, target, z);
                world.setBlockState(pos, surface, FLAGS);
                // при срезе гор под поверхностью три слоя земли, чтобы не торчал голый камень
                if (target <= natural) {
                    for (int y = target - 1; y >= target - 3 && y >= 1; y--) {
                        pos.set(x, y, z);
                        world.setBlockState(pos, soft, FLAGS);
                    }
                }
                // ниже уровня моря над новой поверхностью остаётся вода, а не воздух (иначе по краям встают водяные стены)
                for (int y = target + 1; y <= waterTop; y++) {
                    pos.set(x, y, z);
                    world.setBlockState(pos, water, FLAGS);
                }
            }
        }
    }

    // ---------------- постройка ----------------

    private static void build(MinecraftServer server) throws IOException {
        Data d = load();
        ServerWorld world = server.getOverworld();
        int minX = CastleConstants.MIN_X;
        int minZ = CastleConstants.MIN_Z;

        // границы защищённой зоны и кольца склона вокруг неё
        int pMinX = CastleConstants.MIN_X - SpawnProtection.MARGIN;
        int pMaxX = CastleConstants.MAX_X + SpawnProtection.MARGIN;
        int pMinZ = CastleConstants.MIN_Z - SpawnProtection.MARGIN;
        int pMaxZ = CastleConstants.MAX_Z + SpawnProtection.MARGIN;

        // подгружаем (и при необходимости генерируем) все чанки области
        for (int cx = (pMinX - SLOPE_WIDTH) >> 4; cx <= (pMaxX + SLOPE_WIDTH) >> 4; cx++) {
            for (int cz = (pMinZ - SLOPE_WIDTH) >> 4; cz <= (pMaxZ + SLOPE_WIDTH) >> 4; cz++) {
                world.getChunk(cx, cz);
            }
        }

        BlockPos.Mutable pos = new BlockPos.Mutable();

        // высота земли замка: медиана по сетке точек (деревья и воду не считаем), но не ниже уровня моря
        int[] heights = new int[9];
        int n = 0;
        for (int gx = 0; gx < 3; gx++) {
            for (int gz = 0; gz < 3; gz++) {
                int x = minX + 10 + gx * (d.w - 21) / 2;
                int z = minZ + 10 + gz * (d.l - 21) / 2;
                heights[n++] = groundTopAt(world, x, z, pos);
            }
        }
        Arrays.sort(heights);
        int groundTop = Math.max(MIN_GROUND_TOP, heights[4]); // верхний блок земли
        int baseY = groundTop - CastleConstants.SURFACE_LAYER;
        baseY = Math.max(5, Math.min(baseY, 256 - d.h));
        groundTop = baseY + CastleConstants.SURFACE_LAYER;

        // ровная площадка на всей защищённой зоне + пологий склон вокруг неё
        long started = System.currentTimeMillis();
        flatten(world, groundTop, pMinX, pMaxX, pMinZ, pMaxZ, pos);
        System.out.println("[Arsenal] Местность выровнена за " + (System.currentTimeMillis() - started) + " мс");

        // блоки схемы (воздух тоже ставится, поэтому всё лишнее в объёме замка сносится)
        BlockState[] states = new BlockState[d.palette.length];
        for (int i = 0; i < states.length; i++) {
            states[i] = parseState(d.palette[i]);
        }
        int index = 0;
        int layer = d.l * d.w;
        for (int r = 0; r < d.runIndex.length; r++) {
            BlockState state = states[d.runIndex[r]];
            for (int k = 0; k < d.runLength[r]; k++) {
                int y = index / layer;
                int rest = index % layer;
                int z = rest / d.w;
                int x = rest % d.w;
                pos.set(minX + x, baseY + y, minZ + z);
                world.setBlockState(pos, state, FLAGS);
                index++;
            }
        }

        // основание: если под замком пустота, вода или лава, заполняем камнем
        BlockState stone = Blocks.STONE.getDefaultState();
        for (int x = 0; x < d.w; x++) {
            for (int z = 0; z < d.l; z++) {
                for (int y = baseY - 1; y >= Math.max(1, baseY - 40); y--) {
                    pos.set(minX + x, y, minZ + z);
                    BlockState current = world.getBlockState(pos);
                    if (current.isAir() || !current.getFluidState().isEmpty() || current.getMaterial().isReplaceable()) {
                        world.setBlockState(pos, stone, FLAGS);
                    } else {
                        break;
                    }
                }
            }
        }

        // у краёв замка срезаем холмы из схемы (земля выше уровня площадки без построек), чтобы не торчал обрыв
        BlockState grassTop = Blocks.GRASS_BLOCK.getDefaultState();
        BlockState dirtBelow = Blocks.DIRT.getDefaultState();
        BlockState airState = Blocks.AIR.getDefaultState();
        for (int i = 0; i < d.trimX.length; i++) {
            int x = d.trimX[i];
            int z = d.trimZ[i];
            int g = d.trimG[i];
            int edge = Math.min(Math.min(x, d.w - 1 - x), Math.min(z, d.l - 1 - z));
            double t = Math.min(1.0, edge / (double) EDGE_BLEND);
            double smooth = t * t * (3 - 2 * t);
            int targetRel = CastleConstants.SURFACE_LAYER
                    + (int) Math.round((g - CastleConstants.SURFACE_LAYER) * smooth);
            if (targetRel >= g) {
                continue;
            }
            for (int y = targetRel + 1; y < d.h; y++) {
                pos.set(minX + x, baseY + y, minZ + z);
                if (!world.getBlockState(pos).isAir()) {
                    world.setBlockState(pos, airState, FLAGS);
                }
            }
            pos.set(minX + x, baseY + targetRel, minZ + z);
            world.setBlockState(pos, grassTop, FLAGS);
            for (int y = targetRel - 1; y >= targetRel - 3 && y >= 0; y--) {
                pos.set(minX + x, baseY + y, minZ + z);
                world.setBlockState(pos, dirtBelow, FLAGS);
            }
        }

        // бочки, воронки, таблички, костры и т.п. (с содержимым) ставим командой setblock
        ServerCommandSource source = server.getCommandSource().withSilent();
        for (int i = 0; i < d.beState.length; i++) {
            String command = "setblock " + (minX + d.beX[i]) + " " + (baseY + d.beY[i]) + " " + (minZ + d.beZ[i])
                    + " " + d.beState[i] + " replace";
            server.getCommandManager().execute(source, command);
        }

        // спавн на открытой площадке у замка, точно в этой точке
        BlockPos spawn = new BlockPos(minX + d.spawnX, baseY + d.spawnY, minZ + d.spawnZ);
        world.setSpawnPos(spawn, 0.0F);
        server.getCommandManager().execute(server.getCommandSource().withSilent(), "gamerule spawnRadius 0");

        System.out.println("[Arsenal] Замок построен: основание на высоте " + baseY + ", спавн " + spawn.getX() + " "
                + spawn.getY() + " " + spawn.getZ());
    }
}
