package com.arsenal.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

/**
 * Снаряд для "Кома снега". Тип сущности ванильный (снежок), поэтому клиенту
 * не нужен отдельный рендерер, вся логика только на сервере.
 * Урона нет вообще: ванильный удар снежка (damage 0 / 3 у блейзов) не вызываем.
 */
public class SnowClumpEntity extends SnowballEntity {
    public SnowClumpEntity(World world, LivingEntity owner) {
        super(world, owner);
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        // super.onEntityHit(hit) специально НЕ вызываем: он наносит урон
        if (hit.getEntity() instanceof LivingEntity) {
            LivingEntity target = (LivingEntity) hit.getEntity();
            // уровень эффекта = amplifier + 1
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20 * 10, 5));  // замедление 6, 10 сек
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 20 * 1, 2));  // слепота 3, 1 сек
        }
    }
}
