package com.arsenal.mixin;

import com.arsenal.tool.Filters;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Фильтр: отфильтрованные предметы из добычи моба просто не появляются. */
@Mixin(Entity.class)
public abstract class EntityDropMixin {
    @Inject(method = "dropStack(Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/ItemEntity;",
            at = @At("HEAD"), cancellable = true)
    private void arsenal$filterDrop(ItemStack stack, float yOffset, CallbackInfoReturnable<ItemEntity> cir) {
        if (Filters.isDropFiltered((Entity) (Object) this, stack)) {
            cir.setReturnValue(null);
        }
    }
}
