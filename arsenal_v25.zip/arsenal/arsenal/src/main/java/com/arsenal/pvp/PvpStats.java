package com.arsenal.pvp;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Победы и поражения игроков (всего и за вайп). Хранится в папке мира: arsenal_pvp_stats.json. */
public final class PvpStats {
    public static final class Stat {
        public String name = "";
        public int wins;
        public int losses;
        public int winsWipe;
        public int lossesWipe;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<UUID, Stat> STATS = new HashMap<>();
    private static Path file;

    private PvpStats() {
    }

    public static Stat get(UUID uuid, String name) {
        Stat s = STATS.computeIfAbsent(uuid, u -> new Stat());
        if (name != null && !name.isEmpty()) {
            s.name = name;
        }
        return s;
    }

    public static void win(UUID uuid, String name) {
        Stat s = get(uuid, name);
        s.wins++;
        s.winsWipe++;
        save();
    }

    public static void loss(UUID uuid, String name) {
        Stat s = get(uuid, name);
        s.losses++;
        s.lossesWipe++;
        save();
    }

    /** Новый вайп: счётчики "за этот вайп" обнуляются. */
    public static void wipe() {
        for (Stat s : STATS.values()) {
            s.winsWipe = 0;
            s.lossesWipe = 0;
        }
        save();
    }

    public static void load(MinecraftServer server) {
        STATS.clear();
        file = server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_pvp_stats.json");
        try {
            if (!Files.exists(file)) {
                return;
            }
            JsonArray array = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement el : array) {
                JsonObject o = el.getAsJsonObject();
                Stat s = new Stat();
                s.name = o.get("name").getAsString();
                s.wins = o.get("wins").getAsInt();
                s.losses = o.get("losses").getAsInt();
                s.winsWipe = o.get("winsWipe").getAsInt();
                s.lossesWipe = o.get("lossesWipe").getAsInt();
                STATS.put(UUID.fromString(o.get("uuid").getAsString()), s);
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать arsenal_pvp_stats.json: " + ex);
        }
    }

    public static void save() {
        if (file == null) {
            return;
        }
        try {
            JsonArray array = new JsonArray();
            for (Map.Entry<UUID, Stat> e : STATS.entrySet()) {
                JsonObject o = new JsonObject();
                o.addProperty("uuid", e.getKey().toString());
                o.addProperty("name", e.getValue().name);
                o.addProperty("wins", e.getValue().wins);
                o.addProperty("losses", e.getValue().losses);
                o.addProperty("winsWipe", e.getValue().winsWipe);
                o.addProperty("lossesWipe", e.getValue().lossesWipe);
                array.add(o);
            }
            Files.write(file, GSON.toJson(array).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось сохранить arsenal_pvp_stats.json: " + ex);
        }
    }

    public static void clear() {
        STATS.clear();
        file = null;
    }
}
