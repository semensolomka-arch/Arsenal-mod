package com.arsenal.tool;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.registry.Registry;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Зачарование "Фильтр" (меч, кирка): предметы из личного списка игрока не выпадают
 * из мобов (меч) и блоков (кирка). Список ведут команды:
 *   /setfilter: предмет в основной руке добавить в список (повторно: убрать из списка);
 *   /filter reset: очистить список; /filter list: показать список.
 * Списки хранятся в config/arsenal_filters.json.
 */
public final class Filters {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<UUID, Set<String>> DATA = new HashMap<>();
    private static boolean loaded;

    /** Кто убил моба в этот момент (ставится на время выпадения добычи, см. LivingEntityDropMixin). */
    public static Entity killer;

    private Filters() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(CommandManager.literal("setfilter").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayer();
                ItemStack held = p.getMainHandStack();
                if (held.isEmpty()) {
                    ctx.getSource().sendFeedback(new LiteralText("Возьми в основную руку предмет, который не должен выпадать")
                            .formatted(Formatting.RED), false);
                    return 0;
                }
                ensureLoaded();
                String id = idOf(held);
                Set<String> set = DATA.computeIfAbsent(p.getUuid(), k -> new LinkedHashSet<>());
                String name = held.getName().getString();
                if (set.remove(id)) {
                    ctx.getSource().sendFeedback(new LiteralText("Фильтр: " + name + " снова будет выпадать")
                            .formatted(Formatting.YELLOW), false);
                } else {
                    set.add(id);
                    ctx.getSource().sendFeedback(new LiteralText("Фильтр: " + name + " больше не будет выпадать")
                            .formatted(Formatting.GREEN), false);
                }
                save();
                return 1;
            }));
            dispatcher.register(CommandManager.literal("filter")
                    .then(CommandManager.literal("reset").executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayer();
                        ensureLoaded();
                        DATA.remove(p.getUuid());
                        save();
                        ctx.getSource().sendFeedback(new LiteralText("Фильтр сброшен: теперь выпадает всё")
                                .formatted(Formatting.GREEN), false);
                        return 1;
                    }))
                    .then(CommandManager.literal("list").executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayer();
                        ensureLoaded();
                        Set<String> set = DATA.get(p.getUuid());
                        String text = set == null || set.isEmpty() ? "Фильтр пуст" : "Не выпадает: " + String.join(", ", set);
                        ctx.getSource().sendFeedback(new LiteralText(text), false);
                        return 1;
                    })));
        });
    }

    private static String idOf(ItemStack stack) {
        return Registry.ITEM.getId(stack.getItem()).toString();
    }

    public static boolean hasFilters(PlayerEntity p) {
        ensureLoaded();
        Set<String> set = DATA.get(p.getUuid());
        return set != null && !set.isEmpty();
    }

    public static boolean isFiltered(PlayerEntity p, ItemStack stack) {
        ensureLoaded();
        Set<String> set = DATA.get(p.getUuid());
        return set != null && set.contains(idOf(stack));
    }

    /** Вызывается из EntityDropMixin: true, если этот предмет из убитого моба выпадать не должен. */
    public static boolean isDropFiltered(Entity self, ItemStack stack) {
        if (killer == null || !(self instanceof LivingEntity) || !(killer instanceof ServerPlayerEntity)) {
            return false;
        }
        ServerPlayerEntity p = (ServerPlayerEntity) killer;
        if (EnchantmentHelper.getLevel(ToolEnchants.FILTER, p.getMainHandStack()) <= 0) {
            return false;
        }
        return isFiltered(p, stack);
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_filters.json");
    }

    private static void ensureLoaded() {
        if (loaded) {
            return;
        }
        loaded = true;
        try {
            Path f = file();
            if (!Files.exists(f)) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> en : root.entrySet()) {
                Set<String> set = new LinkedHashSet<>();
                for (JsonElement el : en.getValue().getAsJsonArray()) {
                    set.add(el.getAsString());
                }
                DATA.put(UUID.fromString(en.getKey()), set);
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_filters.json: " + ex);
        }
    }

    private static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, Set<String>> en : DATA.entrySet()) {
                JsonArray arr = new JsonArray();
                for (String s : en.getValue()) {
                    arr.add(s);
                }
                root.add(en.getKey().toString(), arr);
            }
            Files.write(file(), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_filters.json: " + ex);
        }
    }
}
