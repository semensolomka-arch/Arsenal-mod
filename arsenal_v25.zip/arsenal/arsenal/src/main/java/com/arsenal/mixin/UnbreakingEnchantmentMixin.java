package com.arsenal.mixin;

import net.minecraft.enchantment.UnbreakingEnchantment;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Random;

@Mixin(UnbreakingEnchantment.class)
public class UnbreakingEnchantmentMixin {
    /** Прочность стакается в наковальне до V (на броне и на любом инструменте). */
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void arsenal$maxLevel(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(5);
    }

    /** Из стола зачарований максимум III: IV и V стол выдать не может (слишком большая "стоимость"). */
    @Inject(method = "getMinPower", at = @At("HEAD"), cancellable = true)
    private void arsenal$tableLimit(int level, CallbackInfoReturnable<Integer> cir) {
        if (level > 3) {
            cir.setReturnValue(10000);
        }
    }

    /**
     * В ваниле у брони шанс предотвратить поломку на 60% ниже, чем у инструментов (прочность V даёт ей всего
     * около 33% вместо 83%), поэтому броня с зачарованием и без почти не отличалась.
     * Теперь для всех предметов одинаково: шанс не потратить прочность = уровень / (уровень + 1).
     */
    @Inject(method = "shouldPreventDamage", at = @At("HEAD"), cancellable = true)
    private static void arsenal$sameForArmor(ItemStack item, int level, Random random,
                                             CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(random.nextInt(level + 1) > 0);
    }
}
