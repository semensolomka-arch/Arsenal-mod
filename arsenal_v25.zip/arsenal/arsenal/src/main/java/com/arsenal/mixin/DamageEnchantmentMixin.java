package com.arsenal.mixin;

import net.minecraft.enchantment.DamageEnchantment;
import net.minecraft.enchantment.Enchantments;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DamageEnchantment.class)
public class DamageEnchantmentMixin {
    /**
     * Острота, Небесная кара (Smite) и Бич членистоногих стакаются в наковальне до VII
     * (4+4 = V, 5+5 = VI, 6+6 = VII).
     */
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void arsenal$maxLevel(CallbackInfoReturnable<Integer> cir) {
        Object self = this;
        if (self == Enchantments.SHARPNESS || self == Enchantments.SMITE || self == Enchantments.BANE_OF_ARTHROPODS) {
            cir.setReturnValue(7);
        }
    }

    /** Из стола зачарований по-прежнему максимум V: VI и VII стол выдать не может. */
    @Inject(method = "getMinPower", at = @At("HEAD"), cancellable = true)
    private void arsenal$tableLimit(int level, CallbackInfoReturnable<Integer> cir) {
        if (level > 5) {
            cir.setReturnValue(10000);
        }
    }
}
