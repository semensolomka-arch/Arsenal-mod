package com.arsenal.sphere;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;

import java.util.UUID;

/**
 * Пять эффектов сфер. Работают через атрибуты игрока (а не через зелья), поэтому
 * молоко и другие зелья на них не влияют. Порядок = индекс в массиве уровней.
 */
public enum SphereEffect {
    SPEED("speed", EntityAttributes.GENERIC_MOVEMENT_SPEED, EntityAttributeModifier.Operation.MULTIPLY_TOTAL, 0.20,
            "3f1c6a52-8b0e-4d63-9a41-5b7d2e0c1a01"),             // +20% скорости за уровень
    DAMAGE("damage", EntityAttributes.GENERIC_ATTACK_DAMAGE, EntityAttributeModifier.Operation.ADDITION, 1.0,
            "3f1c6a52-8b0e-4d63-9a41-5b7d2e0c1a02"),             // +1 урон за уровень
    ARMOR("armor", EntityAttributes.GENERIC_ARMOR, EntityAttributeModifier.Operation.ADDITION, 1.0,
            "3f1c6a52-8b0e-4d63-9a41-5b7d2e0c1a03"),             // +1 очко брони (половинка значка) за уровень
    ATTACK_SPEED("attack_speed", EntityAttributes.GENERIC_ATTACK_SPEED, EntityAttributeModifier.Operation.MULTIPLY_TOTAL, 0.10,
            "3f1c6a52-8b0e-4d63-9a41-5b7d2e0c1a04"),             // +10% скорости атаки за уровень (как Спешка I)
    HEALTH("health", EntityAttributes.GENERIC_MAX_HEALTH, EntityAttributeModifier.Operation.ADDITION, 2.0,
            "3f1c6a52-8b0e-4d63-9a41-5b7d2e0c1a05");             // +1 сердце (2 хп) за уровень

    public static final int COUNT = 5;

    public final String id;
    public final EntityAttribute attribute;
    public final EntityAttributeModifier.Operation operation;
    public final double perLevel;
    public final UUID uuid;

    /** Зачарование-хранилище уровня на предмете. Заполняется при регистрации. */
    public Enchantment enchantment;

    SphereEffect(String id, EntityAttribute attribute, EntityAttributeModifier.Operation operation, double perLevel, String uuid) {
        this.id = id;
        this.attribute = attribute;
        this.operation = operation;
        this.perLevel = perLevel;
        this.uuid = UUID.fromString(uuid);
    }
}
