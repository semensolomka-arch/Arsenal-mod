package com.arsenal.blast;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.TntEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

/**
 * Зажжённая взрывчатка. Тип сущности ванильный (TNT), поэтому клиенту не нужен свой рендерер:
 * он видит обычный мигающий TNT. Время до взрыва и сам взрыв (сила, вода, обсидиан) решает сервер.
 */
public class BlastEntity extends TntEntity {
    private final BlastKind kind;

    public BlastEntity(World world, double x, double y, double z, LivingEntity igniter, BlastKind kind) {
        super(world, x, y, z, igniter);
        this.kind = kind;
        this.setFuse(kind.fuseTicks);
    }

    /** То же, что TntEntity.tick(), только взрыв свой. */
    @Override
    public void tick() {
        if (!this.hasNoGravity()) {
            this.setVelocity(this.getVelocity().add(0.0D, -0.04D, 0.0D));
        }
        this.move(MovementType.SELF, this.getVelocity());
        this.setVelocity(this.getVelocity().multiply(0.98D));
        if (this.onGround) {
            this.setVelocity(this.getVelocity().multiply(0.7D, -0.5D, 0.7D));
        }
        int fuse = this.getFuse() - 1;
        this.setFuse(fuse);
        if (fuse <= 0) {
            this.remove();
            if (!this.world.isClient) {
                BlastUtil.explode((ServerWorld) this.world, this, this.getX(), this.getBodyY(0.0625D), this.getZ(), kind);
            }
        } else {
            this.updateWaterState();
        }
    }
}
