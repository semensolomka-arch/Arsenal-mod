package com.arsenal.mixin;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.ProtectionEnchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ProtectionEnchantment.class)
public class ProtectionEnchantmentMixin {
    /** Все виды защиты (обычная, от огня, от взрывов, от снарядов) совместимы друг с другом, и в столе, и в наковальне. */
    @Inject(method = "canAccept", at = @At("HEAD"), cancellable = true)
    private void arsenal$compatible(Enchantment other, CallbackInfoReturnable<Boolean> cir) {
        if (other instanceof ProtectionEnchantment) {
            cir.setReturnValue(other != (Object) this);
        }
    }

    /**
     * Защита, Огнеупорность, Взрывоустойчивость и Защита от снарядов стакаются в наковальне до V (4+4).
     * Невесомость (падение) остаётся с максимумом IV.
     */
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void arsenal$maxLevel(CallbackInfoReturnable<Integer> cir) {
        Object self = this;
        if (self == Enchantments.PROTECTION || self == Enchantments.FIRE_PROTECTION
                || self == Enchantments.BLAST_PROTECTION || self == Enchantments.PROJECTILE_PROTECTION) {
            cir.setReturnValue(5);
        }
    }

    /** Из стола зачарований по-прежнему максимум IV: V стол выдать не может. */
    @Inject(method = "getMinPower", at = @At("HEAD"), cancellable = true)
    private void arsenal$tableLimit(int level, CallbackInfoReturnable<Integer> cir) {
        if (level > 4) {
            cir.setReturnValue(10000);
        }
    }
}
