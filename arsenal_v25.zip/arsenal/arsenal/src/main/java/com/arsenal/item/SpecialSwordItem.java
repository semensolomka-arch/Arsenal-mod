package com.arsenal.item;

import com.arsenal.NameDecor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;

/** Меч Infinity / меч Цербера: незеритовый меч с цветным названием и вечным переливом. */
public class SpecialSwordItem extends SwordItem {
    private final Formatting color;
    private final TextColor decor;

    public SpecialSwordItem(Settings settings, Formatting color) {
        super(ToolMaterials.NETHERITE, 3, -2.4F, settings);
        this.color = color;
        this.decor = null;
    }

    /** Меч с оформленным названием (мерцающие символы по краям), как у Stinger/Eternity. */
    public SpecialSwordItem(Settings settings, TextColor decor) {
        super(ToolMaterials.NETHERITE, 3, -2.4F, settings);
        this.color = null;
        this.decor = decor;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public Text getName(ItemStack stack) {
        if (decor != null) {
            return NameDecor.decorate(new TranslatableText(this.getTranslationKey(stack)), decor);
        }
        return new TranslatableText(this.getTranslationKey(stack)).formatted(color);
    }
}
