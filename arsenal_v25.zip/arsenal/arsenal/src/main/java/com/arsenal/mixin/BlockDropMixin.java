package com.arsenal.mixin;

import com.arsenal.tool.ToolEnchants;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Автоплавка, Магнетизм и Опытный: подменяют обычное выпадение предметов из сломанного блока. */
@Mixin(Block.class)
public abstract class BlockDropMixin {
    @Inject(method = "dropStacks(Lnet/minecraft/block/BlockState;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/entity/BlockEntity;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)V",
            at = @At("HEAD"), cancellable = true)
    private static void arsenal$toolDrops(BlockState state, World world, BlockPos pos, BlockEntity blockEntity,
                                          Entity entity, ItemStack stack, CallbackInfo ci) {
        if (ToolEnchants.handleDrops(state, world, pos, blockEntity, entity, stack)) {
            ci.cancel();
        }
    }
}
