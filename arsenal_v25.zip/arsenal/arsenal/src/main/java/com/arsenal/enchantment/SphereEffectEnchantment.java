package com.arsenal.enchantment;

import com.arsenal.sphere.EffectItem;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/**
 * Служебное зачарование: хранит уровень эффекта сферы/талисмана прямо на предмете
 * (и заодно показывается в подсказке, например "Скорость II").
 * Из стола, лута и торговли не берётся, подходит только предметам-сферам.
 */
public class SphereEffectEnchantment extends Enchantment {
    public SphereEffectEnchantment() {
        // тип null: книги с этим зачарованием не показываются во вкладках креатива
        super(Rarity.VERY_RARE, null, new EquipmentSlot[0]);
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public boolean isAcceptableItem(ItemStack stack) {
        return stack.getItem() instanceof EffectItem;
    }

    @Override
    public boolean isTreasure() {
        return true;
    }

    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }

    @Override
    public boolean isAvailableForRandomSelection() {
        return false;
    }
}
