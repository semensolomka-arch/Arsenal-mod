package com.arsenal.item;

import com.arsenal.Abilities;
import com.arsenal.GlintItem;
import com.arsenal.Lore;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Ком снега в руке: ПКМ - бросок. */
public class SnowClumpItem extends GlintItem {
    public SnowClumpItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            Abilities.useSnow((ServerPlayerEntity) user, stack);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public Text getName(ItemStack stack) {
        return Lore.gradientName(this.getTranslationKey(stack), 0x0DBFDE, 0x0ADAFF, false);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal.snow_ball.", 4, 0x00FFFF);
    }
}
