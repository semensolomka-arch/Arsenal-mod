package com.arsenal.enchantment;

import com.arsenal.Arsenal;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/**
 * Служебное зачарование: хранит на Артефакте один из эффектов Хранителя опыта.
 * Из стола, лута и торговли не берётся, подходит только Артефакту.
 */
public class ArtifactEffectEnchantment extends Enchantment {
    public ArtifactEffectEnchantment() {
        // тип null: книги с этим зачарованием не показываются во вкладках креатива
        super(Rarity.VERY_RARE, null, new EquipmentSlot[0]);
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean isAcceptableItem(ItemStack stack) {
        return stack.getItem() == Arsenal.ARTIFACT;
    }

    @Override
    public boolean isTreasure() {
        return true;
    }

    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }

    @Override
    public boolean isAvailableForRandomSelection() {
        return false;
    }
}
