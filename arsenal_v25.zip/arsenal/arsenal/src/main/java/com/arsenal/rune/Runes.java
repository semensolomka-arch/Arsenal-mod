package com.arsenal.rune;

import com.arsenal.Arsenal;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Логика рун. Вызывается, когда срабатывает тотем или талисман (см. LivingEntityMixin) и при входящем уроне. */
public final class Runes {
    public static final int ANVIL_COST = 10;

    private static final Map<UUID, Long> IMMORTAL_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> THORNS_UNTIL = new HashMap<>();
    /** Защита от бесконечного отражения, если шипы есть у обоих. */
    private static boolean reflecting = false;

    private Runes() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            IMMORTAL_UNTIL.clear();
            THORNS_UNTIL.clear();
        });
    }

    /** Руны можно вложить в обычный тотем и в любой талисман. */
    public static boolean canCarry(Item item) {
        return item == Items.TOTEM_OF_UNDYING || Arsenal.isTalisman(item);
    }

    public static boolean has(ItemStack stack, RuneType rune) {
        return rune.enchantment != null && EnchantmentHelper.getLevel(rune.enchantment, stack) > 0;
    }

    /** Бессмертие: идёт ли сейчас 3 секунды неуязвимости. */
    public static boolean isImmortal(LivingEntity entity) {
        Long until = IMMORTAL_UNTIL.get(entity.getUuid());
        return until != null && entity.world.getTime() < until;
    }

    /**
     * Сработал тотем или талисман.
     * @param runeStack копия сработавшего предмета (до того, как он потратился)
     * @param hand      рука, в которой он был (сюда же приходит новый тотем от "Последнего шанса")
     * @param rawDamage урон удара до брони, который сбил тотем (нужен Шипам)
     */
    public static void onTotem(LivingEntity self, ItemStack runeStack, Hand hand, DamageSource source, float rawDamage) {
        if (!(self instanceof ServerPlayerEntity) || runeStack == null || runeStack.isEmpty()) {
            return;
        }
        ServerPlayerEntity player = (ServerPlayerEntity) self;
        long now = player.world.getTime();

        if (has(runeStack, RuneType.IMMORTALITY)) {
            IMMORTAL_UNTIL.put(player.getUuid(), now + 20 * 3);
        }
        if (has(runeStack, RuneType.RESTORATION)) {
            player.setHealth(player.getMaxHealth());
        }
        if (has(runeStack, RuneType.RUN)) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 7, 3));       // Скорость IV, 7 с
        }
        if (has(runeStack, RuneType.SECOND_CHANCE)) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 7, 2));    // Сила III, 7 с
        }
        if (has(runeStack, RuneType.LEAP)) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 20 * 7, 2));  // Прыгучесть III, 7 с
        }
        if (has(runeStack, RuneType.SIGHT_LOSS)) {
            // тот, кто сбил тотем, слепнет
            Entity attacker = source.getAttacker();
            if (attacker instanceof LivingEntity && attacker != player) {
                ((LivingEntity) attacker).addStatusEffect(
                        new StatusEffectInstance(StatusEffects.BLINDNESS, 20 * 7, 2));              // Слепота III, 7 с
            }
        }
        if (has(runeStack, RuneType.THORNS)) {
            THORNS_UNTIL.put(player.getUuid(), now + 20 * 5);
            reflect(player, source, rawDamage); // отражаем и тот удар, который сбил тотем
        }
        if (has(runeStack, RuneType.LAST_CHANCE) && player.world.random.nextFloat() < 0.30F && hand != null) {
            ItemStack fresh = new ItemStack(Items.TOTEM_OF_UNDYING);
            if (player.getStackInHand(hand).isEmpty()) {
                player.setStackInHand(hand, fresh);
            } else {
                player.inventory.insertStack(fresh);
            }
            String text = player.world.random.nextBoolean() ? "Последний шанс..." : "Очередной шанс...";
            player.sendMessage(new LiteralText(text).formatted(Formatting.GREEN), true);
        }
    }

    /**
     * Шипы: пока они действуют, входящий урон отражается на нападающего.
     * Отражается "сырой" урон удара (до брони), а нападающий получает его через свою броню и защиту,
     * как если бы такой удар прилетел по нему.
     */
    public static void reflect(LivingEntity victim, DamageSource source, float rawAmount) {
        if (reflecting || rawAmount <= 0.0F) {
            return;
        }
        Long until = THORNS_UNTIL.get(victim.getUuid());
        if (until == null || victim.world.getTime() >= until) {
            return;
        }
        Entity attacker = source.getAttacker();
        if (!(attacker instanceof LivingEntity) || attacker == victim) {
            return;
        }
        reflecting = true;
        try {
            attacker.damage(DamageSource.thorns(victim), rawAmount);
        } finally {
            reflecting = false;
        }
    }
}
