package com.arsenal.mixin;

import com.arsenal.HealCooldown;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(StatusEffect.class)
public class StatusEffectMixin {
    /** Исцеление: после лечения 10 секунд повторно лечить игрока нельзя (кулдаун в HealCooldown). */
    @Inject(method = "applyInstantEffect", at = @At("HEAD"), cancellable = true)
    private void arsenal$healCooldown(Entity source, Entity attacker, LivingEntity target, int amplifier,
                                      double proximity, CallbackInfo ci) {
        if ((Object) this == StatusEffects.INSTANT_HEALTH && !target.isUndead() && !HealCooldown.tryHeal(target)) {
            ci.cancel();
        }
    }
}
