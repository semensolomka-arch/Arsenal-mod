package com.arsenal.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

/**
 * Непробиваемый: +5% шанс за каждый уровень на каждой части брони, что полученный урон уменьшится.
 * I: 5% за часть, урон -20% (4 части = 20%). II: 10% за часть, урон -30% (4 части = 40%).
 * Шансы складываются по частям, бросок один. Сама логика в LivingEntityMixin.
 */
public class ImpenetrableEnchantment extends Enchantment {
    /** Шанс за один уровень на одной части брони. */
    public static final float CHANCE_PER_LEVEL = 0.05F;

    /** На сколько уменьшается урон при срабатывании: I = 20%, II = 30%. */
    public static float damageReduction(int level) {
        return level >= 2 ? 0.30F : 0.20F;
    }

    public ImpenetrableEnchantment() {
        super(Rarity.VERY_RARE, EnchantmentTarget.ARMOR, new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET});
    }

    @Override
    public int getMaxLevel() {
        return 2;
    }

    // Из стола зачарований, лута и торговли не выпадает: только книги из креатива/команды и наковальня
    @Override
    public boolean isTreasure() {
        return true;
    }

    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }

    @Override
    public boolean isAvailableForRandomSelection() {
        return false;
    }
}
