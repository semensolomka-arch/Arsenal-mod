package com.arsenal.mixin;

import com.arsenal.artifact.ArtifactEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/** Помечаем момент, когда эффекты накладываются бросаемым зельем (нужно для "Справедливости"). */
@Mixin(PotionEntity.class)
public abstract class PotionEntityMixin {
    @Inject(method = "applySplashPotion", at = @At("HEAD"))
    private void arsenal$splashStart(List<StatusEffectInstance> effects, Entity entity, CallbackInfo ci) {
        ArtifactEffects.fromPotion = true;
    }

    @Inject(method = "applySplashPotion", at = @At("RETURN"))
    private void arsenal$splashEnd(List<StatusEffectInstance> effects, Entity entity, CallbackInfo ci) {
        ArtifactEffects.fromPotion = false;
    }
}
