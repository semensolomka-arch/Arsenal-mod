package com.arsenal.mixin;

import com.arsenal.artifact.ArtifactEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Смерть мобов: Телекинез (добыча только убийце 3 секунды). Игроков обрабатывает ArtifactPlayerDeathMixin. */
@Mixin(LivingEntity.class)
public abstract class ArtifactLivingDeathMixin {
    @Inject(method = "onDeath", at = @At("RETURN"))
    private void arsenal$artifactKill(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.world.isClient || self instanceof ServerPlayerEntity) {
            return;
        }
        ArtifactEffects.onKill(self, source);
    }
}
