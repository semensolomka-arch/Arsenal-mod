package com.arsenal.artifact;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;

/**
 * Десять эффектов "предметов Хранителя опыта". Каждый работает, пока предмет-эффект лежит у игрока
 * в инвентаре, либо пока в инвентаре лежит Артефакт с этим эффектом.
 */
public enum ArtifactEffect {
    HUNTER("hunter", "Охотник", false),
    ILLUMINATOR("illuminator", "Иллюминатор", false),
    SNOWMAN("snowman", "Снеговик", true),
    ENDERMAN("enderman", "Эндермен", true),
    ANTI_PHANTOM("anti_phantom", "АнтиФантом", false),
    TELEKINESIS("telekinesis", "Телекинез", false),
    GRAVITY("gravity", "Гравитация", false),
    BLAST_RESISTANCE("blast_resistance", "Взрывоустойчивость", false),
    VAMPIRISM("vampirism", "Вампиризм", false),
    JUSTICE("justice", "Справедливость", true);

    public final String id;
    public final String title;
    /** Блестит ли предмет-эффект как зачарованный. */
    public final boolean glint;

    /** Заполняется при регистрации. */
    public Item item;
    /** Служебное зачарование, которым эффект записывается на Артефакт. */
    public Enchantment enchantment;

    ArtifactEffect(String id, String title, boolean glint) {
        this.id = id;
        this.title = title;
        this.glint = glint;
    }

    public static ArtifactEffect byItem(Item item) {
        for (ArtifactEffect e : values()) {
            if (e.item == item) {
                return e;
            }
        }
        return null;
    }
}
