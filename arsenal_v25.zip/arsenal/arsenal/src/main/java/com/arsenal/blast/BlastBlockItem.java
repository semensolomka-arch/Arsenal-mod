package com.arsenal.blast;

import com.arsenal.Lore;
import net.minecraft.block.Block;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.List;

/** Предмет-блок взрывчатки с цветным названием и описанием. */
public class BlastBlockItem extends BlockItem {
    private final BlastKind kind;

    public BlastBlockItem(Block block, Settings settings, BlastKind kind) {
        super(block, settings);
        this.kind = kind;
    }

    @Override
    public Text getName(ItemStack stack) {
        return kind.displayName(this.getTranslationKey(stack));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal." + kind.id + ".", 6, kind.highlight);
    }
}
