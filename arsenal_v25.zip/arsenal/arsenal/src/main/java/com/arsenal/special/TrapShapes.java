package com.arsenal.special;

import com.arsenal.Abilities;
import com.arsenal.Arsenal;
import com.arsenal.TrapManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.registry.Registry;

/**
 * Постройки трапок (сделаны из схем Litematica):
 *  - TRAP: обычная трапка, коробка 5x5x5 из эндерняковых кирпичей;
 *  - AIR: взрывная трапка в воздухе, стеклянная клетка 7x7x7 (паутина и решётки внутри);
 *  - GROUND: взрывная трапка на земле, яма из земли, камня и обсидиана 8x5x9 (без крыши).
 * Слои идут снизу вверх, в слое строки по Z, символы по X; "." это воздух, остальные буквы это номер в palette.
 * Все блоки ставятся с запоминанием исходных (возвращаются через TRAP_LIFETIME) и пока стоят, их нельзя ломать.
 */
public final class TrapShapes {
    public static final class Shape {
        public final int sx, sy, sz;
        /** Какая клетка схемы совпадает с блоком игрока (где стоят его ноги). */
        final int cx, cy, cz;
        /** Воздух в этом блоке (minX, minY, minZ, maxX, maxY, maxZ включительно) очищается; воздух вне него не трогаем. */
        final int[] clearBox;
        final String[] palette;
        final String[][] layers;
        private BlockState[] states;

        Shape(int sx, int sy, int sz, int cx, int cy, int cz, int[] clearBox, String[] palette, String[][] layers) {
            this.sx = sx;
            this.sy = sy;
            this.sz = sz;
            this.cx = cx;
            this.cy = cy;
            this.cz = cz;
            this.clearBox = clearBox;
            this.palette = palette;
            this.layers = layers;
        }

        private BlockState state(int index) {
            if (states == null) {
                BlockState[] built = new BlockState[palette.length];
                for (int i = 0; i < built.length; i++) {
                    built[i] = parse(palette[i]);
                }
                states = built;
            }
            return states[index];
        }

        /** Угол схемы с наименьшими координатами для игрока в точке c. */
        public BlockPos minCorner(BlockPos c) {
            return c.add(-cx, -cy, -cz);
        }

        /** Габариты постройки в мире. */
        public Box bounds(BlockPos c) {
            BlockPos min = minCorner(c);
            return new Box(min.getX(), min.getY(), min.getZ(), min.getX() + sx, min.getY() + sy, min.getZ() + sz);
        }

        /** Строит постройку вокруг игрока. */
        public void build(ServerWorld world, BlockPos c) {
            BlockPos min = minCorner(c);
            BlockState air = Blocks.AIR.getDefaultState();
            for (int y = 0; y < sy; y++) {
                for (int z = 0; z < sz; z++) {
                    String row = layers[y][z];
                    for (int x = 0; x < sx; x++) {
                        char ch = row.charAt(x);
                        BlockPos pos = min.add(x, y, z);
                        if (ch == '.') {
                            boolean inside = x >= clearBox[0] && y >= clearBox[1] && z >= clearBox[2]
                                    && x <= clearBox[3] && y <= clearBox[4] && z <= clearBox[5];
                            if (inside) {
                                put(world, pos, air, null);
                            }
                        } else {
                            BlockState target = state(ch - 'a');
                            put(world, pos, target, target.getBlock());
                        }
                    }
                }
            }
        }
    }

    public static final Shape TRAP = new Shape(5, 5, 5, 2, 2, 2,
            new int[]{1,1,1,3,3,3},
            new String[]{"end_stone_bricks", "end_stone_brick_slab[type=bottom,waterlogged=false]", "end_stone_brick_slab[type=top,waterlogged=false]", "end_stone_brick_stairs[facing=west,half=top,shape=straight,waterlogged=false]"},
            new String[][]{
                    {"aaaaa", "aaaaa", "aaaaa", "aaaaa", "aaaaa"},
                    {"ababa", "b...b", "a...a", "b...b", "aaaaa"},
                    {"aaaaa", "a...a", "a...a", "a...a", "aaaaa"},
                    {"aaaaa", "c...a", "a...a", "a...d", "aaaba"},
                    {"aaaaa", "aaaaa", "aaaaa", "aaaaa", "aaaaa"},
            });

    public static final Shape AIR = new Shape(7, 7, 7, 3, 2, 3,
            new int[]{1,1,1,5,5,5},
            new String[]{"light_gray_stained_glass", "cobweb", "iron_bars[east=true,north=true,south=false,waterlogged=false,west=false]", "iron_bars[east=false,north=false,south=true,waterlogged=false,west=true]"},
            new String[][]{
                    {".......", ".a.....", "..aaa..", "..aaa..", "..aaaa.", "....aa.", "......."},
                    {".a.....", "abaaaa.", ".a...a.", ".a...a.", ".a...a.", ".aaaaa.", "......."},
                    {".aaaaaa", "a....ca", "a.....a", "a.....a", "a.....a", "ad...ba", "aaaaaaa"},
                    {".aaaaaa", "a....ca", "a.....a", "a.....a", "a.....a", "ad....a", "aaaaaaa"},
                    {".aaaaaa", "a.....a", "a.....a", "a.....a", "a.....a", "ad....a", "aaaaaaa"},
                    {".......", ".aaaaa.", ".a...a.", ".a...a.", ".a...a.", ".aaaaa.", "......."},
                    {".......", ".......", "..aaa..", "..aaa..", "..aaa..", ".......", "......."},
            });

    public static final Shape GROUND = new Shape(8, 5, 9, 3, 1, 4,
            new int[]{1,1,1,6,4,7},
            new String[]{"stone", "coarse_dirt", "cobblestone", "obsidian", "cobblestone_wall[east=low,north=tall,south=tall,up=true,waterlogged=false,west=none]", "cobblestone_wall[east=tall,north=low,south=low,up=false,waterlogged=false,west=tall]", "stone_bricks", "cobblestone_wall[east=none,north=tall,south=tall,up=false,waterlogged=false,west=none]", "cobweb", "cobblestone_wall[east=tall,north=none,south=tall,up=true,waterlogged=false,west=none]", "cobblestone_wall[east=tall,north=none,south=none,up=false,waterlogged=false,west=tall]", "cobblestone_wall[east=low,north=none,south=low,up=true,waterlogged=false,west=none]", "cobblestone_wall[east=none,north=low,south=low,up=false,waterlogged=false,west=none]", "cobblestone_wall[east=low,north=none,south=none,up=false,waterlogged=false,west=low]", "dirt", "grass_block[snowy=false]", "cobblestone_wall[east=none,north=low,south=none,up=true,waterlogged=false,west=low]"},
            new String[][]{
                    {"oooppaab", "baabaaaa", "aaddaaaa", "odbadaaa", "caaaaaaa", "aaaaaaab", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa"},
                    {"bbb..baa", "bccdaaab", "bc...acb", "cg...acb", "c....cbb", "ab.c.d.b", "ebdadabb", "abdaddab", "bbbfbbgb"},
                    {"bbbbbbaa", "bbq...bb", "bg.....b", "b......b", "b......b", "b......b", "h......b", "bi....ja", "bbbkbbg."},
                    {"bbabibbb", "bb....ab", "bi.....b", "b......b", "g......i", "g......b", "b......b", "b.....la", "bbbkbggb"},
                    {"bbbbbb.b", "bb.....b", "bb.....g", "b......b", "b......b", "b......b", "b......b", "m......b", "bbbnbbbb"},
            });

    private TrapShapes() {
    }

    /** Ставит блок, запоминая исходный (вернётся через TRAP_LIFETIME; пока стоит, ломать нельзя). */
    static void put(ServerWorld w, BlockPos pos, BlockState target, Block placed) {
        if (pos.getY() < 0 || pos.getY() > 255) {
            return;
        }
        BlockState cur = w.getBlockState(pos);
        if (cur.isOf(Arsenal.TRAP_BLOCK) || TrapManager.isProtected(pos)) {
            return;   // уже чья-то трапка
        }
        if (cur.isAir()) {
            if (target.isAir()) {
                return;
            }
        } else if (cur.getHardness(w, pos) < 0) {
            return;   // бедрок и т.п.
        }
        BlockEntity be = w.getBlockEntity(pos);
        if (be != null) {
            w.removeBlockEntity(pos);
        }
        TrapManager.add(w, pos, cur, be, Abilities.TRAP_LIFETIME, placed);
        w.setBlockState(pos, target, TrapManager.FLAGS);
    }

    /** "name[prop=value,...]" в состояние блока. */
    private static BlockState parse(String text) {
        int open = text.indexOf('[');
        String name = open < 0 ? text : text.substring(0, open);
        Block block = Registry.BLOCK.get(new Identifier(name));
        BlockState state = block.getDefaultState();
        if (open >= 0) {
            String props = text.substring(open + 1, text.length() - 1);
            for (String pair : props.split(",")) {
                int eq = pair.indexOf('=');
                Property<?> property = block.getStateManager().getProperty(pair.substring(0, eq));
                if (property != null) {
                    state = with(state, property, pair.substring(eq + 1));
                }
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState with(BlockState state, Property<T> property, String value) {
        return property.parse(value).map(v -> state.with(property, v)).orElse(state);
    }
}
