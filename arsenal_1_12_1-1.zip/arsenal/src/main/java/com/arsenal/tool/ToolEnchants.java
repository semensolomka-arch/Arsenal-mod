package com.arsenal.tool;

import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * Новые зачарования:
 *  Неразрушимость (кирка, мотыга, топор, лопата): когда остаётся 1 прочности, инструментом нельзя пользоваться.
 *  Опытный I-III (кирка): +10/20/30% опыта с руд.
 *  Дровосек I-III (топор): за один удар ломает до 32/64/128 связанных одинаковых блоков (дерево, ряд арбузов).
 *  Автоплавка (кирка, лопата): выпавшие предметы сразу переплавляются (как в печи).
 *  Оглушение (лук, арбалет): 5% шанс при попадании дать Замедление IV и Слепоту I на 10 секунд.
 *  Бур (кирка, лопата, топор): ломает область 3x3x1 (плоскость, в которую смотришь).
 *  Магнетизм (кирка, мотыга, топор): добытое сразу попадает в инвентарь.
 * Каждый сломанный блок тратит прочность инструмента, как обычно.
 */
public final class ToolEnchants {
    public static Enchantment INDESTRUCTIBLE;
    public static Enchantment EXPERIENCED;
    public static Enchantment LUMBERJACK;
    public static Enchantment AUTOSMELT;
    public static Enchantment STUNNING;
    public static Enchantment DRILL;
    public static Enchantment MAGNETISM;

    /** Шанс оглушения при попадании. */
    public static final float STUN_CHANCE = 0.05F;
    /** Сколько блоков ломает Дровосек по уровням (вместе с тем, по которому ударили). */
    public static final int[] LUMBERJACK_BLOCKS = {32, 64, 128};
    /** Прибавка опыта за уровень Опытного. */
    public static final double EXPERIENCED_BONUS_PER_LEVEL = 0.10;

    /** Пока true, дополнительные блоки (Дровосек, Бур) ломаются, и новые цепочки не запускаются. */
    private static boolean expanding;

    private static final Map<UUID, FaceMemo> FACES = new HashMap<>();
    private static final List<Pending> PENDING = new ArrayList<>();

    private ToolEnchants() {
    }

    private static final class FaceMemo {
        final BlockPos pos;
        final Direction face;

        FaceMemo(BlockPos pos, Direction face) {
            this.pos = pos;
            this.face = face;
        }
    }

    private static final class Pending {
        final ServerPlayerEntity player;
        final Item tool;
        /** Для Дровосека: ломаем только такой же блок. Для Бура null. */
        final Block block;
        final List<BlockPos> positions;

        Pending(ServerPlayerEntity player, Item tool, Block block, List<BlockPos> positions) {
            this.player = player;
            this.tool = tool;
            this.block = block;
            this.positions = positions;
        }
    }

    private static Enchantment reg(String id, Enchantment e) {
        return Registry.register(Registry.ENCHANTMENT, new Identifier("arsenal", id), e);
    }

    public static void init() {
        Predicate<Item> pickaxe = i -> i instanceof PickaxeItem;
        Predicate<Item> shovel = i -> i instanceof ShovelItem;
        Predicate<Item> axe = i -> i instanceof AxeItem;
        Predicate<Item> hoe = i -> i instanceof HoeItem;

        INDESTRUCTIBLE = reg("indestructible", new ToolEnchantment(Enchantment.Rarity.RARE, EnchantmentTarget.DIGGER,
                i -> pickaxe.test(i) || hoe.test(i) || axe.test(i) || shovel.test(i), 1, 1));
        EXPERIENCED = reg("experienced", new ToolEnchantment(Enchantment.Rarity.UNCOMMON, EnchantmentTarget.DIGGER,
                pickaxe, 3, 3));
        LUMBERJACK = reg("lumberjack", new ToolEnchantment(Enchantment.Rarity.UNCOMMON, EnchantmentTarget.DIGGER,
                axe, 3, 3));
        AUTOSMELT = reg("autosmelt", new ToolEnchantment(Enchantment.Rarity.RARE, EnchantmentTarget.DIGGER,
                i -> pickaxe.test(i) || shovel.test(i), 1, 1));
        STUNNING = reg("stunning", new ToolEnchantment(Enchantment.Rarity.RARE, EnchantmentTarget.BOW,
                i -> i instanceof BowItem || i instanceof CrossbowItem, 1, 0));
        DRILL = reg("drill", new ToolEnchantment(Enchantment.Rarity.RARE, EnchantmentTarget.DIGGER,
                i -> pickaxe.test(i) || shovel.test(i) || axe.test(i), 1, 1));
        MAGNETISM = reg("magnetism", new ToolEnchantment(Enchantment.Rarity.UNCOMMON, EnchantmentTarget.DIGGER,
                i -> pickaxe.test(i) || hoe.test(i) || axe.test(i), 1, 1));

        // --- Неразрушимость: с последней единицей прочности инструментом пользоваться нельзя ---
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (blocked(player.getStackInHand(hand), player)) {
                return ActionResult.FAIL;
            }
            if (!world.isClient) {
                FACES.put(player.getUuid(), new FaceMemo(pos.toImmutable(), direction));
            }
            return ActionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) ->
                blocked(player.getStackInHand(hand), player) ? ActionResult.FAIL : ActionResult.PASS);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                blocked(player.getStackInHand(hand), player) ? ActionResult.FAIL : ActionResult.PASS);
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !blocked(player.getMainHandStack(), player));

        // --- Дровосек и Бур: после обычного слома собираем соседние блоки ---
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (expanding || world.isClient || !(player instanceof ServerPlayerEntity)) {
                return;
            }
            ItemStack tool = player.getMainHandStack();
            if (tool.isEmpty()) {
                return;
            }
            ServerPlayerEntity sp = (ServerPlayerEntity) player;
            ServerWorld sw = (ServerWorld) world;

            int lj = EnchantmentHelper.getLevel(LUMBERJACK, tool);
            if (lj > 0 && tool.getMiningSpeedMultiplier(state) > 1.0F) {
                int limit = LUMBERJACK_BLOCKS[Math.min(lj, LUMBERJACK_BLOCKS.length) - 1] - 1;
                List<BlockPos> list = connected(sw, pos, state.getBlock(), limit);
                list.removeIf(p -> SpawnProtection.contains(sw, p) && !SpawnProtection.bypass(sp));
                if (!list.isEmpty()) {
                    PENDING.add(new Pending(sp, tool.getItem(), state.getBlock(), list));
                }
                return;
            }
            if (EnchantmentHelper.getLevel(DRILL, tool) > 0) {
                Direction.Axis axis;
                FaceMemo memo = FACES.get(sp.getUuid());
                if (memo != null && memo.pos.equals(pos)) {
                    axis = memo.face.getAxis();
                } else {
                    axis = Direction.getEntityFacingOrder(sp)[0].getAxis();
                }
                List<BlockPos> list = new ArrayList<>();
                for (int a = -1; a <= 1; a++) {
                    for (int b = -1; b <= 1; b++) {
                        if (a == 0 && b == 0) {
                            continue;
                        }
                        BlockPos p;
                        if (axis == Direction.Axis.X) {
                            p = pos.add(0, a, b);
                        } else if (axis == Direction.Axis.Y) {
                            p = pos.add(a, 0, b);
                        } else {
                            p = pos.add(a, b, 0);
                        }
                        if (SpawnProtection.contains(sw, p) && !SpawnProtection.bypass(sp)) {
                            continue;
                        }
                        if (drillable(sw, p, tool)) {
                            list.add(p);
                        }
                    }
                }
                if (!list.isEmpty()) {
                    PENDING.add(new Pending(sp, tool.getItem(), null, list));
                }
            }
        });

        // Сами дополнительные блоки ломаем в конце тика, когда основной уже полностью сломан
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (PENDING.isEmpty()) {
                return;
            }
            List<Pending> work = new ArrayList<>(PENDING);
            PENDING.clear();
            for (Pending p : work) {
                run(p);
            }
        });
    }

    private static void run(Pending p) {
        ServerPlayerEntity player = p.player;
        if (!player.isAlive()) {
            return;
        }
        ServerWorld world = player.getServerWorld();
        expanding = true;
        try {
            for (BlockPos pos : p.positions) {
                ItemStack tool = player.getMainHandStack();
                if (tool.isEmpty() || tool.getItem() != p.tool || blocked(tool, player)) {
                    break; // инструмент сломался или осталась последняя прочность
                }
                BlockState s = world.getBlockState(pos);
                if (s.isAir()) {
                    continue;
                }
                if (p.block != null) {
                    if (!s.isOf(p.block)) {
                        continue;
                    }
                } else if (!drillable(world, pos, tool)) {
                    continue;
                }
                player.interactionManager.tryBreakBlock(pos);
            }
        } finally {
            expanding = false;
        }
    }

    /** Бур ломает только то, что инструмент берёт быстрее руки, не бедрок и не блоки с хранилищем. */
    private static boolean drillable(ServerWorld world, BlockPos pos, ItemStack tool) {
        BlockState s = world.getBlockState(pos);
        return !s.isAir() && s.getHardness(world, pos) >= 0.0F && world.getBlockEntity(pos) == null
                && tool.getMiningSpeedMultiplier(s) > 1.0F;
    }

    /** Связанные (включая диагонали) такие же блоки, не больше limit штук, от ближних к дальним. */
    private static List<BlockPos> connected(ServerWorld world, BlockPos start, Block block, int limit) {
        List<BlockPos> result = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(start.toImmutable());
        queue.add(start.toImmutable());
        while (!queue.isEmpty() && result.size() < limit) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1 && result.size() < limit; dx++) {
                for (int dy = -1; dy <= 1 && result.size() < limit; dy++) {
                    for (int dz = -1; dz <= 1 && result.size() < limit; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        BlockPos n = cur.add(dx, dy, dz);
                        if (!seen.add(n)) {
                            continue;
                        }
                        if (world.getBlockState(n).isOf(block) && world.getBlockEntity(n) == null) {
                            result.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }
        return result;
    }

    /** Неразрушимость: true, если у инструмента осталась последняя единица прочности. */
    public static boolean blocked(ItemStack stack, PlayerEntity player) {
        if (stack.isEmpty() || player.isCreative() || !stack.isDamageable()) {
            return false;
        }
        if (EnchantmentHelper.getLevel(INDESTRUCTIBLE, stack) <= 0) {
            return false;
        }
        return stack.getMaxDamage() - stack.getDamage() <= 1;
    }

    /**
     * Вызывается из BlockDropMixin вместо ванильного выпадения предметов. Если у инструмента есть
     * Автоплавка, Магнетизм или Опытный, обрабатывает выпадение сам и возвращает true.
     */
    public static boolean handleDrops(BlockState state, World world, BlockPos pos, BlockEntity blockEntity,
                                      Entity entity, ItemStack tool) {
        if (!(world instanceof ServerWorld) || !(entity instanceof ServerPlayerEntity) || tool.isEmpty()) {
            return false;
        }
        int smelt = EnchantmentHelper.getLevel(AUTOSMELT, tool);
        int magnet = EnchantmentHelper.getLevel(MAGNETISM, tool);
        int exp = EnchantmentHelper.getLevel(EXPERIENCED, tool);
        if (smelt <= 0 && magnet <= 0 && exp <= 0) {
            return false;
        }
        ServerWorld sw = (ServerWorld) world;
        ServerPlayerEntity player = (ServerPlayerEntity) entity;

        for (ItemStack drop : Block.getDroppedStacks(state, sw, pos, blockEntity, entity, tool)) {
            ItemStack out = smelt > 0 ? smelt(sw, drop) : drop;
            if (magnet > 0) {
                player.inventory.offerOrDrop(sw, out);
            } else {
                Block.dropStack(sw, pos, out);
            }
        }

        Set<Integer> before = exp > 0 ? orbIds(sw, pos) : null;
        state.onStacksDropped(sw, pos, tool);
        if (before != null) {
            int sum = 0;
            for (ExperienceOrbEntity orb : nearbyOrbs(sw, pos)) {
                if (!before.contains(orb.getEntityId())) {
                    sum += orb.getExperienceAmount();
                }
            }
            double extra = sum * EXPERIENCED_BONUS_PER_LEVEL * exp;
            int whole = (int) extra;
            if (sw.random.nextDouble() < extra - whole) {
                whole++;
            }
            if (whole > 0) {
                sw.spawnEntity(new ExperienceOrbEntity(sw, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, whole));
            }
        }
        return true;
    }

    private static List<ExperienceOrbEntity> nearbyOrbs(ServerWorld world, BlockPos pos) {
        return world.getEntitiesByClass(ExperienceOrbEntity.class, new Box(pos).expand(3.0), e -> true);
    }

    private static Set<Integer> orbIds(ServerWorld world, BlockPos pos) {
        Set<Integer> ids = new HashSet<>();
        for (ExperienceOrbEntity orb : nearbyOrbs(world, pos)) {
            ids.add(orb.getEntityId());
        }
        return ids;
    }

    /** Переплавка как в печи: если у предмета есть рецепт плавки, получаем результат. */
    private static ItemStack smelt(ServerWorld world, ItemStack in) {
        Optional<SmeltingRecipe> recipe = world.getRecipeManager()
                .getFirstMatch(RecipeType.SMELTING, new SimpleInventory(in), world);
        if (!recipe.isPresent()) {
            return in;
        }
        ItemStack out = recipe.get().getOutput().copy();
        out.setCount(Math.min(out.getMaxCount(), out.getCount() * in.getCount()));
        return out;
    }
}
