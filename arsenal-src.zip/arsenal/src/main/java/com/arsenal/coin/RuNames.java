package com.arsenal.coin;

import net.minecraft.entity.Entity;

import java.util.HashMap;
import java.util.Map;

/** Названия мобов в винительном падеже («Вы убили овцу»). Для неизвестных мобов берётся имя, а если его нет, то id. */
final class RuNames {
    private static final Map<String, String> M = new HashMap<>();

    private static void p(String id, String ru) {
        M.put("minecraft:" + id, ru);
    }

    static {
        p("bat", "летучую мышь"); p("bee", "пчелу"); p("blaze", "ифрита"); p("cat", "кошку");
        p("cave_spider", "пещерного паука"); p("chicken", "курицу"); p("cod", "треску"); p("cow", "корову");
        p("creeper", "крипера"); p("dolphin", "дельфина"); p("donkey", "осла"); p("drowned", "утопленника");
        p("elder_guardian", "древнего стража"); p("ender_dragon", "эндер-дракона"); p("enderman", "эндермена");
        p("endermite", "эндермита"); p("evoker", "заклинателя"); p("fox", "лису"); p("ghast", "гаста");
        p("giant", "гиганта"); p("guardian", "стража"); p("hoglin", "хоглина"); p("horse", "лошадь");
        p("husk", "кадавра"); p("illusioner", "иллюзиониста"); p("iron_golem", "железного голема");
        p("llama", "ламу"); p("magma_cube", "магмового слизня"); p("mooshroom", "грибную корову");
        p("mule", "мула"); p("ocelot", "оцелота"); p("panda", "панду"); p("parrot", "попугая");
        p("phantom", "фантома"); p("pig", "свинью"); p("piglin", "пиглина"); p("piglin_brute", "брутального пиглина");
        p("pillager", "разбойника"); p("polar_bear", "белого медведя"); p("pufferfish", "иглобрюха");
        p("rabbit", "кролика"); p("ravager", "разорителя"); p("salmon", "лосося"); p("sheep", "овцу");
        p("shulker", "шалкера"); p("silverfish", "чешуйницу"); p("skeleton", "скелета");
        p("skeleton_horse", "скелета-лошадь"); p("slime", "слизня"); p("snow_golem", "снежного голема");
        p("spider", "паука"); p("squid", "кальмара"); p("stray", "зимогора"); p("strider", "лавоходца");
        p("trader_llama", "ламу торговца"); p("tropical_fish", "тропическую рыбку"); p("turtle", "черепаху");
        p("vex", "досаждателя"); p("villager", "жителя"); p("vindicator", "поборника");
        p("wandering_trader", "странствующего торговца"); p("witch", "ведьму"); p("wither", "иссушителя");
        p("wither_skeleton", "скелета-иссушителя"); p("wolf", "волка"); p("zoglin", "зоглина");
        p("zombie", "зомби"); p("zombie_horse", "лошадь-зомби"); p("zombie_villager", "зомби-жителя");
        p("zombified_piglin", "зомбифицированного пиглина");
    }

    private RuNames() {
    }

    static String accusative(String id, Entity e) {
        String ru = M.get(id);
        if (ru != null) {
            return ru;
        }
        if (e.hasCustomName()) {
            return e.getCustomName().getString();
        }
        return id.substring(id.indexOf(':') + 1).replace('_', ' ');
    }
}
