package com.arsenal.rune;

import com.arsenal.vi.VI;
import net.minecraft.util.Formatting;

/**
 * Руны для тотемов и талисманов. Руна лежит на тотеме служебным зачарованием и срабатывает вместе с ним.
 * Текстура предмета-руны это зачарованный краситель (dye), цвет надписи на тотеме совпадает с цветом красителя.
 * Несовместимых рун нет.
 */
public enum RuneType {
    IMMORTALITY("immortality", "Бессмертие", "orange_dye", Formatting.GOLD),
    RESTORATION("restoration", "Восстановление", "red_dye", Formatting.RED),
    THORNS("thorns", "Шипы", "pink_dye", Formatting.LIGHT_PURPLE),
    LAST_CHANCE("last_chance", "Последний шанс", "yellow_dye", Formatting.YELLOW),
    RUN("run", "Пора бежать", "blue_dye", Formatting.BLUE),
    SECOND_CHANCE("second_chance", "Второй шанс", "light_blue_dye", Formatting.AQUA),
    LEAP("leap", "Прыжки веры", "lime_dye", Formatting.GREEN),
    SIGHT_LOSS("sight_loss", "Потеря зрения", "white_dye", Formatting.WHITE);

    public final String id;
    public final String title;
    public final String dye;
    public final Formatting color;

    /** Заполняются при регистрации. */
    public VI vi;

    /** Ключ руны в данных предмета (ArsenalData). */
    public String key() {
        return "rune_" + id;
    }

    RuneType(String id, String title, String dye, Formatting color) {
        this.id = id;
        this.title = title;
        this.dye = dye;
        this.color = color;
    }
}
