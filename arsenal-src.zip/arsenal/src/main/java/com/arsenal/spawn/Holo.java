package com.arsenal.spawn;

import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.List;

/** Голограммы: невидимые стойки с именем. Стойка находится по тегу, создаётся при необходимости, текст обновляется на лету. */
public final class Holo {
    private Holo() {
    }

    /** Есть ли в мире игрок ближе dist блоков (голограммы вдали от людей не обновляем). */
    public static boolean anyoneNear(ServerWorld world, double x, double y, double z, double dist) {
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.squaredDistanceTo(x, y, z) <= dist * dist) {
                return true;
            }
        }
        return false;
    }

    public static void update(ServerWorld world, String tag, double x, double y, double z, Text text) {
        if (!world.isChunkLoaded(new BlockPos(x, y, z))) {
            return;
        }
        List<ArmorStandEntity> list = world.getEntitiesByClass(ArmorStandEntity.class,
                new Box(x - 1.0, y - 1.0, z - 1.0, x + 1.0, y + 1.0, z + 1.0), e -> e.getScoreboardTags().contains(tag));
        if (list.isEmpty()) {
            String dim = world.getRegistryKey().getValue().toString();
            try {
                world.getServer().getCommandManager().execute(world.getServer().getCommandSource().withSilent(),
                        "execute in " + dim + " run summon armor_stand " + x + " " + y + " " + z
                                + " {Invisible:1b,Marker:1b,NoGravity:1b,CustomNameVisible:1b,Tags:[\"" + tag + "\"],"
                                + "CustomName:'{\"text\":\".\"}'}");
            } catch (Exception ex) {
                System.err.println("[Arsenal] Голограмма не создалась: " + ex);
            }
            return;
        }
        for (int i = 1; i < list.size(); i++) {
            list.get(i).remove();
        }
        ArmorStandEntity stand = list.get(0);
        Text cur = stand.getCustomName();
        if (cur == null || !cur.getString().equals(text.getString())) {
            stand.setCustomName(text);
        }
    }
}
