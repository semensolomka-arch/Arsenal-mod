package com.arsenal.spawn;

import com.arsenal.event.CargoLoot;
import com.arsenal.item.UniversalKey;
import com.arsenal.vi.VI;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

/**
 * Хранилище на спавне (/warp unique): шалкер, который открывается универсальным ключом (в руке).
 * Ключ тратится, лут из таблицы "vault" файла config/arsenal_cargo.json появляется ВНУТРИ шалкера (окно 9x6, только брать).
 * Дальше {vault_expire_seconds} секунд (по умолчанию 300) хранилище принадлежит тому, кто его открыл:
 * только он может открывать его снова, уже без ключа и без нового лута, чтобы забрать остатки.
 * Рукой (без ключа) его не открыть. Через 5 минут остатки пропадают, и снова можно открыть только ключом.
 */
public final class UniqueVault {
    /** Смещение шалкера от центра зала. */
    public static final int DX = 22;
    public static final int DZ = -22;
    /** Сколько тиков хранилище принадлежит открывшему (настройка vault_expire_seconds). */
    public static int EXPIRE_TICKS = 20 * 60 * 5;

    private static final SimpleInventory INV = new SimpleInventory(54);
    private static UUID owner;
    private static String ownerName = "";
    /** Тик сервера, когда сессия кончается. */
    private static long sessionEnd;
    private static boolean dirty;
    private static MinecraftServer server;

    private UniqueVault() {
    }

    public static BlockPos pos() {
        return new BlockPos(SpawnManager.CX + DX, SpawnManager.FLOOR_Y + 1, SpawnManager.CZ + DZ);
    }

    /** Точка /warp unique: перед хранилищем, лицом к нему. */
    public static double[] warpPoint() {
        BlockPos p = pos();
        return new double[]{p.getX() + 0.5, SpawnManager.FLOOR_Y + 1.0, p.getZ() + 5.5, 180.0};
    }

    /** Строит постамент, шалкер и табличку (если их ещё нет), ставит голограммы. */
    public static void ensure(ServerWorld world) {
        BlockPos p = pos();
        if (world.getBlockState(p).getBlock() != Blocks.PURPLE_SHULKER_BOX
                || world.getBlockState(p.down()).getBlock() != Blocks.GOLD_BLOCK) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    world.setBlockState(p.add(dx, -1, dz), Blocks.GOLD_BLOCK.getDefaultState(), 18);
                    if (dx != 0 || dz != 0) {
                        world.setBlockState(p.add(dx, 0, dz), Blocks.AIR.getDefaultState(), 18);
                    }
                }
            }
            world.setBlockState(p, Blocks.PURPLE_SHULKER_BOX.getDefaultState(), 18);
            SpawnManager.sign(world, p.add(0, 0, 3), 0,
                    new LiteralText("[ ХРАНИЛИЩЕ ]").formatted(Formatting.GOLD, Formatting.BOLD),
                    new LiteralText("Открывается").formatted(Formatting.DARK_PURPLE),
                    new LiteralText("универсальным").formatted(Formatting.DARK_PURPLE),
                    new LiteralText("ключом").formatted(Formatting.DARK_PURPLE));
        }
        updateHolo(world, world.getServer().getTicks());
    }

    public static boolean isVault(net.minecraft.world.World world, BlockPos pos) {
        return pos.equals(pos()) && world.getBlockState(pos).getBlock() instanceof ShulkerBoxBlock;
    }

    /** Идёт сессия: кто-то открыл хранилище ключом, и 5 минут ещё не прошли. */
    private static boolean active(long now) {
        return owner != null && now < sessionEnd;
    }

    private static ItemStack findKey(PlayerEntity p) {
        for (ItemStack st : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            VI vi = VI.of(st);
            if (vi != null && UniversalKey.ID.equals(vi.id)) {
                return st;
            }
        }
        return null;
    }

    /** Окно хранилища: только брать, класть нельзя. */
    private static final class View implements Inventory {
        @Override
        public int size() {
            return INV.size();
        }

        @Override
        public boolean isEmpty() {
            return INV.isEmpty();
        }

        @Override
        public ItemStack getStack(int slot) {
            return INV.getStack(slot);
        }

        @Override
        public ItemStack removeStack(int slot, int amount) {
            return INV.removeStack(slot, amount);
        }

        @Override
        public ItemStack removeStack(int slot) {
            return INV.removeStack(slot);
        }

        @Override
        public void setStack(int slot, ItemStack stack) {
            INV.setStack(slot, stack);
        }

        @Override
        public void markDirty() {
            INV.markDirty();
        }

        @Override
        public boolean canPlayerUse(PlayerEntity player) {
            return true;
        }

        @Override
        public boolean isValid(int slot, ItemStack stack) {
            return false;
        }

        @Override
        public void clear() {
        }
    }

    private static void open(ServerPlayerEntity p) {
        final View view = new View();
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, pi, pl) -> GenericContainerScreenHandler.createGeneric9x6(id, pi, view),
                new LiteralText("Хранилище")));
    }

    private static ActionResult use(ServerPlayerEntity p) {
        long now = p.getServer().getTicks();
        if (active(now)) {
            if (!owner.equals(p.getUuid())) {
                long left = (sessionEnd - now + 19) / 20;
                p.sendMessage(new LiteralText("Хранилище открыл " + ownerName + ": лут только его, ещё " + left + " сек")
                        .formatted(Formatting.RED), true);
                return ActionResult.FAIL;
            }
            // хозяин забирает остатки: без ключа и без нового лута
            open(p);
            return ActionResult.SUCCESS;
        }
        // сессия кончилась (или её не было): остатков нет, нужен ключ
        if (owner != null) {
            endSession();
        }
        ItemStack key = findKey(p);
        if (key == null) {
            p.sendMessage(new LiteralText("Хранилище открывается только универсальным ключом").formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }
        key.decrement(1);
        // лут из config/arsenal_cargo.json, таблица "vault"; файл перечитывается при каждом открытии
        CargoLoot.load();
        INV.clear();
        CargoLoot.fill(INV, CargoLoot.rollFlat("vault"));
        owner = p.getUuid();
        ownerName = p.getGameProfile().getName();
        sessionEnd = now + EXPIRE_TICKS;
        dirty = true;
        p.sendMessage(new LiteralText("Хранилище открыто! У вас " + (EXPIRE_TICKS / 20)
                + " сек, чтобы забрать лут (повторно открывать можно без ключа)").formatted(Formatting.GOLD), false);
        open(p);
        return ActionResult.SUCCESS;
    }

    private static void endSession() {
        INV.clear();
        owner = null;
        ownerName = "";
        sessionEnd = 0;
        dirty = true;
    }

    // ---------------------------------------------------------------- сохранение (переживает перезапуск)

    private static Path file(MinecraftServer s) {
        return s.getSavePath(WorldSavePath.ROOT).resolve("arsenal_vault.json");
    }

    private static void load(MinecraftServer s) {
        server = s;
        INV.clear();
        owner = null;
        Path f = file(s);
        if (!Files.exists(f)) {
            return;
        }
        try {
            JsonElement root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8));
            if (!root.isJsonObject()) {
                return; // старый формат без сессии: остатки не восстанавливаем
            }
            JsonObject o = root.getAsJsonObject();
            long remaining = o.get("remaining").getAsLong();
            if (remaining > 0 && o.has("owner")) {
                owner = UUID.fromString(o.get("owner").getAsString());
                ownerName = o.get("name").getAsString();
                sessionEnd = s.getTicks() + remaining;
                for (JsonElement el : o.getAsJsonArray("items")) {
                    JsonObject it = el.getAsJsonObject();
                    ItemStack st = new ItemStack(Registry.ITEM.get(new Identifier(it.get("id").getAsString())),
                            it.get("count").getAsInt());
                    if (it.has("tag")) {
                        st.setTag(StringNbtReader.parse(it.get("tag").getAsString()));
                    }
                    int slot = it.get("slot").getAsInt();
                    if (slot >= 0 && slot < INV.size()) {
                        INV.setStack(slot, st);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать хранилище: " + e);
        }
        dirty = false;
    }

    private static void save() {
        if (server == null) {
            return;
        }
        JsonObject o = new JsonObject();
        long remaining = owner == null ? 0 : Math.max(0, sessionEnd - server.getTicks());
        o.addProperty("remaining", remaining);
        if (owner != null) {
            o.addProperty("owner", owner.toString());
            o.addProperty("name", ownerName);
        }
        JsonArray arr = new JsonArray();
        for (int i = 0; i < INV.size(); i++) {
            ItemStack st = INV.getStack(i);
            if (st.isEmpty()) {
                continue;
            }
            JsonObject it = new JsonObject();
            it.addProperty("slot", i);
            it.addProperty("id", Registry.ITEM.getId(st.getItem()).toString());
            it.addProperty("count", st.getCount());
            if (st.hasTag()) {
                it.addProperty("tag", st.getTag().toString());
            }
            arr.add(it);
        }
        o.add("items", arr);
        try {
            Files.write(file(server), o.toString().getBytes(StandardCharsets.UTF_8));
            dirty = false;
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось сохранить хранилище: " + e);
        }
    }

    // ---------------------------------------------------------------- голограммы и тик

    private static void updateHolo(ServerWorld w, long now) {
        BlockPos p = pos();
        String l2;
        Formatting c2;
        if (active(now)) {
            l2 = "Лут игрока " + ownerName + ": ещё " + ((sessionEnd - now + 19) / 20) + " сек";
            c2 = Formatting.RED;
        } else {
            l2 = "Открой универсальным ключом";
            c2 = Formatting.YELLOW;
        }
        double x = p.getX() + 0.5;
        double z = p.getZ() + 0.5;
        Holo.update(w, "arsenal_vault_h1", x, p.getY() + 1.9, z,
                new LiteralText("Хранилище").formatted(Formatting.GOLD, Formatting.BOLD));
        Holo.update(w, "arsenal_vault_h2", x, p.getY() + 1.6, z, new LiteralText(l2).formatted(c2));
    }

    private static void tick(MinecraftServer s) {
        long now = s.getTicks();
        if (dirty && now % 200 == 0) {
            save();
        }
        // через 5 минут остатки пропадают, хранилище снова открывается только ключом
        if (owner != null && now >= sessionEnd) {
            endSession();
        }
        if (now % 20 != 0) {
            return;
        }
        ServerWorld w = SpawnWorld.get(s);
        if (w == null) {
            return;
        }
        BlockPos p = pos();
        if (!Holo.anyoneNear(w, p.getX() + 0.5, p.getY(), p.getZ() + 0.5, 48)) {
            return;
        }
        updateHolo(w, now);
    }

    public static void init() {
        INV.addListener(i -> dirty = true);
        ServerLifecycleEvents.SERVER_STARTED.register(UniqueVault::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerTickEvents.END_SERVER_TICK.register(UniqueVault::tick);
        // раньше защиты зоны и запретов предметов мода (в выживании клик иначе перехватывается)
        com.arsenal.vi.Early.use(UseBlockCallback.EVENT, (player, world, hand, hit) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity) || player.isSpectator()) {
                return ActionResult.PASS;
            }
            if (!isVault(world, hit.getBlockPos())) {
                return ActionResult.PASS;
            }
            if (hand != Hand.MAIN_HAND) {
                return ActionResult.FAIL;
            }
            return use((ServerPlayerEntity) player);
        });
    }
}
