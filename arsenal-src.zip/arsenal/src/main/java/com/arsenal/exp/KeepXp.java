package com.arsenal.exp;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Опыт сохраняется после смерти (орбы не выпадают). Охотник забирает долю у убитого: эта доля вычитается.
 */
public final class KeepXp {
    private static final Map<UUID, Integer> KEPT = new HashMap<>();

    private KeepXp() {
    }

    private static java.nio.file.Path file() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("arsenal_keepxp.txt");
    }

    private static void save() {
        try {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<UUID, Integer> e : KEPT.entrySet()) {
                sb.append(e.getKey()).append('=').append(e.getValue()).append('\n');
            }
            java.nio.file.Files.write(file(), sb.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    private static void load() {
        try {
            if (!java.nio.file.Files.exists(file())) {
                return;
            }
            for (String line : java.nio.file.Files.readAllLines(file(), java.nio.charset.StandardCharsets.UTF_8)) {
                String[] kv = line.trim().split("=");
                if (kv.length == 2) {
                    KEPT.put(UUID.fromString(kv[0]), Integer.parseInt(kv[1]));
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void init() {
        load();
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (alive) {
                return;   // возвращение из Края: опыт ванильно остаётся
            }
            Integer kept = KEPT.remove(newPlayer.getUuid());
            if (kept != null && kept > 0) {
                ExpCommand.setTotalPoints(newPlayer, kept);
            }
            save();
        });
    }

    /** Перед смертью: запомнить весь опыт игрока. */
    public static void remember(ServerPlayerEntity player) {
        KEPT.put(player.getUuid(), ExpCommand.totalPoints(player));
        save();
    }

    /** Охотник забрал часть опыта убитого. */
    public static void reduce(UUID victim, int amount) {
        Integer v = KEPT.get(victim);
        if (v != null) {
            KEPT.put(victim, Math.max(0, v - amount));
            save();
        }
    }
}
