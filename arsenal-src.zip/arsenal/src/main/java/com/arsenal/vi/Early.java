package com.arsenal.vi;

import net.fabricmc.fabric.api.event.Event;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Регистрация обработчика клика по блоку раньше остальных (иначе защиты и запреты предметов мода его перехватывают).
 * В Fabric API 0.32.5 фаз ещё нет, поэтому обработчик вставляется в начало списка вручную.
 * Несколько "ранних" обработчиков идут между собой в порядке регистрации.
 * Если вставить не получилось, он регистрируется как обычный.
 */
public final class Early {
    private static int count;

    private Early() {
    }

    @SuppressWarnings("unchecked")
    public static <T> void use(Event<T> event, T cb) {
        try {
            Field handlersField = null;
            for (Class<?> c = event.getClass(); c != null && handlersField == null; c = c.getSuperclass()) {
                try {
                    handlersField = c.getDeclaredField("handlers");
                } catch (NoSuchFieldException ignored) {
                }
            }
            if (handlersField == null) {
                throw new NoSuchFieldException("handlers");
            }
            handlersField.setAccessible(true);
            synchronized (Early.class) {
                T[] old = (T[]) handlersField.get(event);
                T[] now = (T[]) Array.newInstance(old.getClass().getComponentType(), old.length + 1);
                int at = Math.min(count, old.length);
                System.arraycopy(old, 0, now, 0, at);
                now[at] = cb;
                System.arraycopy(old, at, now, at + 1, old.length - at);
                handlersField.set(event, now);
                count++;
            }
            Method update = null;
            for (Class<?> c = event.getClass(); c != null && update == null; c = c.getSuperclass()) {
                try {
                    update = c.getDeclaredMethod("update");
                } catch (NoSuchMethodException ignored) {
                }
            }
            if (update == null) {
                throw new NoSuchMethodException("update");
            }
            update.setAccessible(true);
            update.invoke(event);
        } catch (Throwable t) {
            System.err.println("[Arsenal] Early: не удалось поставить обработчик первым, обычная регистрация: " + t);
            event.register(cb);
        }
    }
}
