package com.arsenal.item;

import com.arsenal.Lore;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VI;
import net.fabricmc.fabric.api.loot.v1.FabricLootPoolBuilder;
import net.fabricmc.fabric.api.loot.v1.event.LootTableLoadingCallback;
import net.minecraft.item.Items;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetNbtLootFunction;
import net.minecraft.loot.ConstantLootTableRange;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

/**
 * Универсальный ключ (выглядит как отмычка): с шансом 5% лежит в ванильных сундуках и открывает хранилище на спавне
 * (/warp unique, см. UniqueVault).
 */
public final class UniversalKey {
    public static final String ID = "universal_key";
    /** Шанс найти ключ в одном сундуке. */
    public static final float CHANCE = 0.05F;
    public static VI VI_ITEM;

    private UniversalKey() {
    }

    public static void register() {
        VI_ITEM = VI.register(ID, Items.TRIPWIRE_HOOK)
                .glint(true)
                .name(s -> new LiteralText(Lang.get("item.arsenal.universal_key")).formatted(Formatting.GOLD))
                .lore(s -> Lore.lines("tooltip.arsenal.universal_key.", 7, 0xFFA500));
    }

    /** Добавляет ключ в лут ванильных сундуков (шанс CHANCE на сундук). Любая ошибка API только отключает выпадение. */
    public static void initLoot() {
        try {
            LootTableLoadingCallback.EVENT.register((resourceManager, lootManager, id, supplier, setter) -> {
                if (!"minecraft".equals(id.getNamespace()) || !id.getPath().startsWith("chests/")) {
                    return;
                }
                try {
                    supplier.withPool(FabricLootPoolBuilder.builder()
                            .rolls(ConstantLootTableRange.create(1))
                            .conditionally(RandomChanceLootCondition.builder(CHANCE))
                            .with(ItemEntry.builder(Items.TRIPWIRE_HOOK)
                                    .apply(SetNbtLootFunction.builder(VI_ITEM.stack().getTag().copy())))
                            .build());
                } catch (Throwable t) {
                    System.err.println("[Arsenal] Не удалось добавить ключ в " + id + ": " + t);
                }
            });
        } catch (Throwable t) {
            System.err.println("[Arsenal] Универсальный ключ в сундуках отключён: " + t);
        }
    }
}
