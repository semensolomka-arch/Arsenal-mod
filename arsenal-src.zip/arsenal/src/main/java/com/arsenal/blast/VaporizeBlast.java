package com.arsenal.blast;

import com.arsenal.TrapManager;
import com.arsenal.event.EventManager;
import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.inventory.Inventory;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;

import java.util.HashSet;
import java.util.Set;

/**
 * Динамит Б2: испаряет все блоки в ровном квадрате 25 на 25 (по умолчанию 12 вверх и 12 вниз) (и обсидиан, и жидкости, и всё прочее, кроме бедрока).
 * Блоки не выпадают, содержимое контейнеров исчезает, урона по игрокам нет.
 * Не трогает защищённые места: зону замка/спавна, груз, трапки и территорию приватов.
 */
public final class VaporizeBlast {
    /** Радиус цилиндра и его высота вверх и вниз от взрыва (настройки b2_radius, b2_up, b2_down). */
    public static int RADIUS = 12;
    public static int UP = 12;
    public static int DOWN = 12;
    private static final int[][] DIRS = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

    private VaporizeBlast() {
    }

    public static void explode(ServerWorld world, double x, double y, double z) {
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, x, y, z, 10, 5.0D, 3.0D, 5.0D, 0.0D);
        world.playSound(null, x, y, z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 10.0F, 0.6F);

        BlockPos center = new BlockPos(x, y, z);
        Set<BlockPos> removed = new HashSet<>();
        // идеально ровный квадрат (прямоугольный столб): вертикальные стенки, плоские дно и потолок, без неровностей как у обычного взрыва
        for (BlockPos pos : BlockPos.iterate(center.add(-RADIUS, -DOWN, -RADIUS), center.add(RADIUS, UP, RADIUS))) {
            if (pos.getY() < 0 || pos.getY() > 255) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (state.isAir() || state.isOf(Blocks.BEDROCK) || isProtected(world, pos)) {
                continue;
            }
            // содержимое сундуков и т.п. исчезает вместе с блоком, а не высыпается на землю
            BlockEntity be = world.getBlockEntity(pos);
            if (be instanceof Inventory) {
                ((Inventory) be).clear();
            }
            world.setBlockState(pos, Blocks.AIR.getDefaultState(), TrapManager.FLAGS);
            removed.add(pos.toImmutable());
        }

        // соседи пустоты: вода подтекает, песок и гравий падают
        for (BlockPos pos : removed) {
            for (int[] d : DIRS) {
                BlockPos n = pos.add(d[0], d[1], d[2]);
                if (removed.contains(n)) {
                    continue;
                }
                BlockState ns = world.getBlockState(n);
                FluidState fluid = ns.getFluidState();
                if (!fluid.isEmpty()) {
                    world.getFluidTickScheduler().schedule(n, fluid.getFluid(), fluid.getFluid().getTickRate(world));
                } else if (ns.getBlock() instanceof FallingBlock) {
                    world.getBlockTickScheduler().schedule(n, ns.getBlock(), 2);
                }
            }
        }
    }

    /** Места, которые взрывчатка не трогает. */
    static boolean isProtected(ServerWorld world, BlockPos pos) {
        return SpawnProtection.contains(world, pos) || TrapManager.isProtected(pos)
                || EventManager.inZone(world, pos)
                || PrivateManager.get(world, pos) != null || PrivateManager.isCovered(world, pos);
    }
}
