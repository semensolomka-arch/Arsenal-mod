package com.arsenal.blast;

import com.arsenal.tp.WorldLimit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.TntEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Optional;

/**
 * Снаряд ТНТ-пушки: ванильный TNT (клиент видит обычный горящий TNT), который летит строго по прямой без гравитации.
 * Взрывается о первое препятствие (блок с коллизией, игрок, граница мира; паутина и трава не мешают)
 * или после RANGE блоков. Сам взрыв как у заряженного ТНТ (kind == null: обычный TNT).
 */
public class CannonShell extends TntEntity {
    private final BlastKind kind;
    private final Vec3d dir;
    private final double speed;
    private final double range;
    private double traveled;
    private final boolean startedInside;

    public CannonShell(World world, double x, double y, double z, Vec3d dir, double speed, double range, BlastKind kind) {
        super(world, x, y, z, null);
        this.kind = kind;
        this.dir = dir.normalize();
        this.speed = speed;
        this.range = range;
        this.startedInside = WorldLimit.outside(x, z) <= 0.0;
        this.setNoGravity(true);
        this.setFuse(80);
        this.setVelocity(this.dir.multiply(speed));
    }

    @Override
    public void tick() {
        if (this.world.isClient) {
            return;
        }
        ServerWorld sw = (ServerWorld) this.world;
        Vec3d from = this.getPos();
        double step = Math.min(speed, range - traveled);
        Vec3d to = from.add(dir.multiply(step));
        Vec3d end = to;
        boolean hit = false;

        BlockPos toPos = new BlockPos(to);
        if (!sw.isChunkLoaded(toPos) || !sw.getWorldBorder().contains(toPos)
                || (startedInside && WorldLimit.outside(to.x, to.z) > 0.0)) {
            // граница мира или незагруженная область: взрываемся тут
            end = from;
            hit = true;
        } else {
            net.minecraft.util.hit.BlockHitResult bh = sw.raycast(new RaycastContext(from, to,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, this));
            if (bh.getType() != HitResult.Type.MISS) {
                end = bh.getPos().subtract(dir.multiply(0.05));
                hit = true;
            }
            double best = from.squaredDistanceTo(end);
            for (ServerPlayerEntity p : sw.getPlayers()) {
                if (p.isSpectator() || p.isDead() || p.squaredDistanceTo(from) > (speed + 6) * (speed + 6)) {
                    continue;
                }
                Box b = p.getBoundingBox().expand(0.3);
                if (b.contains(from)) {
                    end = from;
                    hit = true;
                    best = 0;
                    break;
                }
                Optional<Vec3d> o = b.raycast(from, end);
                if (o.isPresent()) {
                    double d = from.squaredDistanceTo(o.get());
                    if (d <= best) {
                        best = d;
                        end = o.get();
                        hit = true;
                    }
                }
            }
        }

        traveled += from.distanceTo(end);
        this.updatePosition(end.x, end.y, end.z);
        if (hit || traveled >= range - 1.0E-6) {
            this.remove();
            explode(sw, end);
            return;
        }
        this.setVelocity(dir.multiply(speed));
        sw.getChunkManager().sendToNearbyPlayers(this, new EntityVelocityUpdateS2CPacket(this));
    }

    private void explode(ServerWorld sw, Vec3d at) {
        if (kind == null) {
            sw.createExplosion(this, at.x, at.y, at.z, 4.0F, net.minecraft.world.explosion.Explosion.DestructionType.BREAK);
        } else {
            BlastUtil.explode(sw, this, at.x, at.y, at.z, kind);
        }
    }
}
