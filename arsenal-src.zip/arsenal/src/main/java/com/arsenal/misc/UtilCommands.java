package com.arsenal.misc;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Бытовые команды: /invsee, /ec, /anvil (/anvill), /craft, /fix, /fix all, /smithingtable, /near, /heal, /feed.
 * Кулдауны хранятся в памяти (после перезапуска сервера сбрасываются), настраиваются в /arsenal settings.
 */
public final class UtilCommands {
    private UtilCommands() {
    }

    /** Кулдауны в миллисекундах (менются настройками). */
    public static long FIX_CD = 600_000L;
    public static long FIX_ALL_CD = 1_200_000L;
    public static long HEAL_CD = 60_000L;
    public static long FEED_CD = 60_000L;
    public static int NEAR_RADIUS = 100;

    private static final Map<UUID, Long> FIX = new HashMap<>();
    private static final Map<UUID, Long> FIX_ALL = new HashMap<>();
    private static final Map<UUID, Long> HEAL = new HashMap<>();
    private static final Map<UUID, Long> FEED = new HashMap<>();

    public static void init() {
        CommandRegistrationCallback.EVENT.register((d, dedicated) -> {
            d.register(CommandManager.literal("craft").executes(c -> craft(c.getSource())));
            d.register(anvilCmd("anvil"));
            d.register(anvilCmd("anvill"));
            d.register(CommandManager.literal("smithingtable").executes(c -> smith(c.getSource())));
            d.register(CommandManager.literal("near").executes(c -> near(c.getSource())));
            d.register(CommandManager.literal("heal").executes(c -> heal(c.getSource(), true)));
            d.register(CommandManager.literal("feed").executes(c -> heal(c.getSource(), false)));
            d.register(CommandManager.literal("fix")
                    .executes(c -> fix(c.getSource(), false))
                    .then(CommandManager.literal("all").executes(c -> fix(c.getSource(), true))));
            d.register(CommandManager.literal("ec")
                    .executes(c -> ec(c.getSource(), null))
                    .then(CommandManager.argument("ник", StringArgumentType.word())
                            .requires(s -> s.hasPermissionLevel(2))
                            .executes(c -> ec(c.getSource(), StringArgumentType.getString(c, "ник")))));
            d.register(CommandManager.literal("invsee")
                    .requires(s -> s.hasPermissionLevel(2))
                    .then(CommandManager.argument("ник", StringArgumentType.word())
                            .executes(c -> invsee(c.getSource(), StringArgumentType.getString(c, "ник")))));
        });
    }

    private static LiteralArgumentBuilder<ServerCommandSource> anvilCmd(String name) {
        return CommandManager.literal(name).executes(c -> anvil(c.getSource()));
    }

    private static ServerPlayerEntity player(ServerCommandSource src) {
        try {
            return src.getPlayer();
        } catch (Exception e) {
            src.sendFeedback(new LiteralText("Только для игроков"), false);
            return null;
        }
    }

    private static void say(ServerPlayerEntity p, String msg, Formatting f) {
        p.sendMessage(new LiteralText(msg).formatted(f), false);
    }

    /** true, если кулдаун ещё идёт (и пишет игроку, сколько осталось). */
    private static boolean onCooldown(Map<UUID, Long> map, ServerPlayerEntity p, long cdMs) {
        Long until = map.get(p.getUuid());
        long now = System.currentTimeMillis();
        if (until != null && until > now) {
            long s = (until - now + 999) / 1000;
            String t = s >= 60 ? (s / 60) + " мин " + (s % 60) + " сек" : s + " сек";
            say(p, "Подождите ещё " + t, Formatting.RED);
            return true;
        }
        return false;
    }

    private static void startCooldown(Map<UUID, Long> map, ServerPlayerEntity p, long cdMs) {
        if (cdMs > 0) {
            map.put(p.getUuid(), System.currentTimeMillis() + cdMs);
        }
    }

    // ---------------- окна ----------------

    private static int craft(ServerCommandSource src) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, pi, pl) -> new CraftingScreenHandler(id, pi, ScreenHandlerContext.create(pl.world, pl.getBlockPos())) {
                    @Override
                    public boolean canUse(PlayerEntity player) {
                        return true;
                    }
                },
                new TranslatableText("container.crafting")));
        return 1;
    }

    private static int anvil(ServerCommandSource src) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, pi, pl) -> new AnvilScreenHandler(id, pi, ScreenHandlerContext.create(pl.world, pl.getBlockPos())) {
                    @Override
                    public boolean canUse(PlayerEntity player) {
                        return true;
                    }
                },
                new TranslatableText("container.repair")));
        return 1;
    }

    private static int ec(ServerCommandSource src, String nick) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        ServerPlayerEntity target = p;
        if (nick != null) {
            target = src.getMinecraftServer().getPlayerManager().getPlayer(nick);
            if (target == null) {
                say(p, "Игрок " + nick + " не в сети", Formatting.RED);
                return 0;
            }
        }
        final Inventory inv = target.getEnderChestInventory();
        if (target == p) {
            p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                    (id, pi, pl) -> GenericContainerScreenHandler.createGeneric9x3(id, pi, inv),
                    new TranslatableText("container.enderchest")));
            return 1;
        }
        // чужой эндерсундук: только просмотр
        final Inventory ro = new Inventory() {
            @Override
            public int size() {
                return inv.size();
            }

            @Override
            public boolean isEmpty() {
                return inv.isEmpty();
            }

            @Override
            public ItemStack getStack(int slot) {
                return inv.getStack(slot);
            }

            @Override
            public ItemStack removeStack(int slot, int amount) {
                return ItemStack.EMPTY;
            }

            @Override
            public ItemStack removeStack(int slot) {
                return ItemStack.EMPTY;
            }

            @Override
            public void setStack(int slot, ItemStack stack) {
            }

            @Override
            public void markDirty() {
            }

            @Override
            public boolean canPlayerUse(PlayerEntity player) {
                return true;
            }

            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }

            @Override
            public void clear() {
            }
        };
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, pi, pl) -> new GenericContainerScreenHandler(ScreenHandlerType.GENERIC_9X3, id, pi, ro, 3) {
                    @Override
                    public ItemStack onSlotClick(int slotIndex, int clickData, net.minecraft.screen.slot.SlotActionType actionType, PlayerEntity player) {
                        if (slotIndex < 27 || actionType == net.minecraft.screen.slot.SlotActionType.PICKUP_ALL
                                || actionType == net.minecraft.screen.slot.SlotActionType.QUICK_CRAFT) {
                            return ItemStack.EMPTY;
                        }
                        return super.onSlotClick(slotIndex, clickData, actionType, player);
                    }

                    @Override
                    public ItemStack transferSlot(PlayerEntity player, int index) {
                        return ItemStack.EMPTY;
                    }
                },
                new LiteralText("Эндерсундук: " + target.getGameProfile().getName())));
        return 1;
    }

    private static int invsee(ServerCommandSource src, String nick) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        ServerPlayerEntity target = src.getMinecraftServer().getPlayerManager().getPlayer(nick);
        if (target == null) {
            say(p, "Игрок " + nick + " не в сети", Formatting.RED);
            return 0;
        }
        if (target == p) {
            say(p, "Это ваш собственный инвентарь (откройте его клавишей E)", Formatting.RED);
            return 0;
        }
        final InvView view = new InvView(target.inventory);
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, pi, pl) -> new GenericContainerScreenHandler(ScreenHandlerType.GENERIC_9X5, id, pi, view, 5) {
                    @Override
                    public ItemStack onSlotClick(int slotIndex, int clickData, net.minecraft.screen.slot.SlotActionType actionType, PlayerEntity player) {
                        if (slotIndex < 45 || actionType == net.minecraft.screen.slot.SlotActionType.PICKUP_ALL
                                || actionType == net.minecraft.screen.slot.SlotActionType.QUICK_CRAFT) {
                            return ItemStack.EMPTY;
                        }
                        return super.onSlotClick(slotIndex, clickData, actionType, player);
                    }

                    @Override
                    public ItemStack transferSlot(PlayerEntity player, int index) {
                        return ItemStack.EMPTY;
                    }
                },
                new LiteralText("Инвентарь: " + target.getGameProfile().getName())));
        return 1;
    }

    /** Окно 9x5: 27 слотов рюкзака, хотбар, броня (шлем..ботинки), левая рука. Только просмотр, менять нельзя. */
    private static final class InvView implements Inventory {
        private final PlayerInventory inv;

        InvView(PlayerInventory inv) {
            this.inv = inv;
        }

        private static int map(int k) {
            if (k < 27) {
                return 9 + k;
            }
            if (k < 36) {
                return k - 27;
            }
            if (k < 40) {
                return 39 - (k - 36);
            }
            if (k == 40) {
                return 40;
            }
            return -1;
        }

        @Override
        public int size() {
            return 45;
        }

        @Override
        public boolean isEmpty() {
            return inv.isEmpty();
        }

        @Override
        public ItemStack getStack(int slot) {
            int m = map(slot);
            return m < 0 ? ItemStack.EMPTY : inv.getStack(m);
        }

        @Override
        public ItemStack removeStack(int slot, int amount) {
            int m = map(slot);
            return m < 0 ? ItemStack.EMPTY : inv.removeStack(m, amount);
        }

        @Override
        public ItemStack removeStack(int slot) {
            int m = map(slot);
            return m < 0 ? ItemStack.EMPTY : inv.removeStack(m);
        }

        @Override
        public void setStack(int slot, ItemStack stack) {
            int m = map(slot);
            if (m >= 0) {
                inv.setStack(m, stack);
            }
        }

        @Override
        public void markDirty() {
            inv.markDirty();
        }

        @Override
        public boolean canPlayerUse(PlayerEntity player) {
            return true;
        }

        @Override
        public boolean isValid(int slot, ItemStack stack) {
            return false;
        }

        @Override
        public void clear() {
        }
    }

    // ---------------- /fix ----------------

    private static boolean repairable(ItemStack s) {
        if (s.isEmpty() || !s.isDamageable() || s.getDamage() <= 0) {
            return false;
        }
        Item it = s.getItem();
        return !(it instanceof ArmorItem) && !(it instanceof ElytraItem);
    }

    private static int fix(ServerCommandSource src, boolean all) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        Map<UUID, Long> map = all ? FIX_ALL : FIX;
        long cd = all ? FIX_ALL_CD : FIX_CD;
        if (onCooldown(map, p, cd)) {
            return 0;
        }
        int n = 0;
        if (all) {
            for (ItemStack s : p.inventory.main) {
                if (repairable(s)) {
                    s.setDamage(0);
                    n++;
                }
            }
            ItemStack off = p.getOffHandStack();
            if (repairable(off)) {
                off.setDamage(0);
                n++;
            }
        } else {
            ItemStack s = p.getMainHandStack();
            if (s.isEmpty() || !s.isDamageable()) {
                say(p, "Возьмите в руку предмет, который можно починить", Formatting.RED);
                return 0;
            }
            if (s.getItem() instanceof ArmorItem || s.getItem() instanceof ElytraItem) {
                say(p, "Броню чинить нельзя", Formatting.RED);
                return 0;
            }
            if (s.getDamage() <= 0) {
                say(p, "Предмет и так целый", Formatting.YELLOW);
                return 0;
            }
            s.setDamage(0);
            n = 1;
        }
        if (n == 0) {
            say(p, "Нечего чинить", Formatting.YELLOW);
            return 0;
        }
        startCooldown(map, p, cd);
        p.inventory.markDirty();
        say(p, all ? "Починено предметов: " + n : "Предмет починен", Formatting.GREEN);
        return 1;
    }

    // ---------------- /smithingtable ----------------

    private static Item netherite(Item it) {
        if (it == Items.DIAMOND_SWORD) return Items.NETHERITE_SWORD;
        if (it == Items.DIAMOND_PICKAXE) return Items.NETHERITE_PICKAXE;
        if (it == Items.DIAMOND_AXE) return Items.NETHERITE_AXE;
        if (it == Items.DIAMOND_SHOVEL) return Items.NETHERITE_SHOVEL;
        if (it == Items.DIAMOND_HOE) return Items.NETHERITE_HOE;
        if (it == Items.DIAMOND_HELMET) return Items.NETHERITE_HELMET;
        if (it == Items.DIAMOND_CHESTPLATE) return Items.NETHERITE_CHESTPLATE;
        if (it == Items.DIAMOND_LEGGINGS) return Items.NETHERITE_LEGGINGS;
        if (it == Items.DIAMOND_BOOTS) return Items.NETHERITE_BOOTS;
        return null;
    }

    private static int smith(ServerCommandSource src) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        ItemStack s = p.getMainHandStack();
        Item to = netherite(s.getItem());
        if (to == null) {
            say(p, "Возьмите в руку алмазный предмет (меч, инструмент или броню)", Formatting.RED);
            return 0;
        }
        NbtCompound tag = s.getTag();
        if (tag != null && tag.contains("ArsenalId")) {
            say(p, "Предметы Arsenal улучшать нельзя", Formatting.RED);
            return 0;
        }
        ItemStack ns = new ItemStack(to, s.getCount());
        if (tag != null) {
            ns.setTag(tag.copy());
        }
        p.setStackInHand(net.minecraft.util.Hand.MAIN_HAND, ns);
        p.inventory.markDirty();
        say(p, "Предмет улучшен до незерита", Formatting.GREEN);
        return 1;
    }

    // ---------------- /near ----------------

    private static int near(ServerCommandSource src) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        List<ServerPlayerEntity> list = new ArrayList<>();
        for (ServerPlayerEntity o : src.getMinecraftServer().getPlayerManager().getPlayerList()) {
            if (o == p || o.world != p.world || o.isSpectator() || o.isInvisible()) {
                continue;
            }
            if (o.distanceTo(p) <= NEAR_RADIUS) {
                list.add(o);
            }
        }
        if (list.isEmpty()) {
            say(p, "окружающие игроки: никого нет", Formatting.YELLOW);
            return 1;
        }
        list.sort(Comparator.comparingDouble(o -> o.distanceTo(p)));
        StringBuilder sb = new StringBuilder("окружающие игроки: ");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            ServerPlayerEntity o = list.get(i);
            sb.append(o.getGameProfile().getName()).append('(').append(Math.round(o.distanceTo(p))).append("м)");
        }
        say(p, sb.toString(), Formatting.YELLOW);
        return 1;
    }

    // ---------------- /heal, /feed ----------------

    private static int heal(ServerCommandSource src, boolean withHp) {
        ServerPlayerEntity p = player(src);
        if (p == null) {
            return 0;
        }
        Map<UUID, Long> map = withHp ? HEAL : FEED;
        long cd = withHp ? HEAL_CD : FEED_CD;
        if (onCooldown(map, p, cd)) {
            return 0;
        }
        p.getHungerManager().add(40, 1.0F);
        if (withHp) {
            p.setHealth(p.getMaxHealth());
        }
        startCooldown(map, p, cd);
        say(p, withHp ? "Здоровье и голод восстановлены" : "Голод восстановлен", Formatting.GREEN);
        return 1;
    }
}
