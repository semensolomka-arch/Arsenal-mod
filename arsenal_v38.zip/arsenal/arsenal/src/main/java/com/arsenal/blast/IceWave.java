package com.arsenal.blast;

import com.arsenal.TrapManager;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Ледяная волна: вода рядом со взрывом на 10 секунд становится льдом, потом возвращается как была. */
public final class IceWave {
    public static final int RADIUS = 7;
    public static final int TICKS = 20 * 10;

    private static final List<Entry> ENTRIES = new ArrayList<>();

    private static final class Entry {
        final ServerWorld world;
        final BlockPos pos;
        final BlockState original;
        int ticks;

        Entry(ServerWorld world, BlockPos pos, BlockState original, int ticks) {
            this.world = world;
            this.pos = pos;
            this.original = original;
            this.ticks = ticks;
        }
    }

    private IceWave() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
        // при остановке сервера лёд сразу возвращаем в воду, чтобы он не остался навсегда
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (Entry e : ENTRIES) {
                restore(e);
            }
            ENTRIES.clear();
        });
    }

    public static void freeze(ServerWorld world, double x, double y, double z) {
        BlockPos center = new BlockPos(x, y, z);
        double r2 = (double) RADIUS * RADIUS;
        boolean any = false;
        for (BlockPos pos : BlockPos.iterate(center.add(-RADIUS, -RADIUS, -RADIUS), center.add(RADIUS, RADIUS, RADIUS))) {
            if (pos.getSquaredDistance(x, y, z, true) > r2) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (!state.isOf(Blocks.WATER) || VaporizeBlast.isProtected(world, pos)) {
                continue;
            }
            world.setBlockState(pos, Blocks.ICE.getDefaultState(), TrapManager.FLAGS);
            ENTRIES.add(new Entry(world, pos.toImmutable(), state, TICKS));
            any = true;
        }
        if (any) {
            world.playSound(null, x, y, z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 2.0F, 1.2F);
        }
    }

    private static void tick() {
        if (ENTRIES.isEmpty()) {
            return;
        }
        Iterator<Entry> it = ENTRIES.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (--e.ticks > 0) {
                continue;
            }
            if (!e.world.getChunkManager().isChunkLoaded(e.pos.getX() >> 4, e.pos.getZ() >> 4)) {
                e.ticks = 20;   // чанк выгружен: попробуем через секунду
                continue;
            }
            restore(e);
            it.remove();
        }
    }

    private static void restore(Entry e) {
        // возвращаем воду, только если лёд на месте (его могли сломать)
        if (e.world.getBlockState(e.pos).isOf(Blocks.ICE)) {
            e.world.setBlockState(e.pos, e.original, 3);
        }
    }
}
