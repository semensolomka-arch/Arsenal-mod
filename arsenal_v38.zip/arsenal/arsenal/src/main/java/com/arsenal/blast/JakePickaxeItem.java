package com.arsenal.blast;

import com.arsenal.Lore;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Language;
import net.minecraft.world.World;

import java.util.List;

/**
 * Золотая кирка Джейка: сломанный ею спавнер выпадает с мобом внутри (шанс 100%),
 * после чего кирка ломается. Выглядит как золотая кирка с зачарованием "Спавнер I".
 */
public class JakePickaxeItem extends PickaxeItem {
    public static final int COLOR = 0xFF8C00;

    public JakePickaxeItem(Settings settings) {
        super(ToolMaterials.GOLD, 1, -2.8F, settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(this.getTranslationKey(stack))
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(COLOR)).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Language lang = Language.getInstance();
        tooltip.add(new LiteralText(lang.get("tooltip.arsenal.jake_pickaxe.enchant")).formatted(Formatting.GRAY));
        tooltip.add(new LiteralText(""));
        tooltip.add(new LiteralText(lang.get("tooltip.arsenal.jake_pickaxe.header")).formatted(Formatting.DARK_GRAY));
        for (int i = 1; i <= 4; i++) {
            String key = "tooltip.arsenal.jake_pickaxe." + i;
            if (lang.hasTranslation(key)) {
                tooltip.add(Lore.parse(lang.get(key), COLOR));
            }
        }
    }

    public static void init() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || !state.isOf(Blocks.SPAWNER)) {
                return;
            }
            ItemStack tool = player.getMainHandStack();
            if (!(tool.getItem() instanceof JakePickaxeItem)) {
                return;
            }
            String mobId = null;
            NbtCompound spawnData = null;
            if (blockEntity instanceof MobSpawnerBlockEntity) {
                NbtCompound full = blockEntity.writeNbt(new NbtCompound());
                if (full.contains("SpawnData", 10)) {
                    NbtCompound data = full.getCompound("SpawnData");
                    String id = data.getString("id");
                    if (!id.isEmpty()) {
                        mobId = id;
                        spawnData = data.copy();
                    }
                }
            }
            // моб сохраняется всегда; у пустого спавнера выпадает такой же пустой
            ItemStack drop = mobId == null ? new ItemStack(Items.SPAWNER) : SpawnerUtil.makeSpawner(mobId, spawnData);
            Block.dropStack(world, pos, drop);
            if (mobId != null && world instanceof ServerWorld) {
                StealerBlast.playMobSound((ServerWorld) world, mobId, pos);
            }
            // кирка забирает только один спавнер и ломается
            if (!player.isCreative()) {
                player.sendToolBreakStatus(Hand.MAIN_HAND);
                tool.decrement(1);
            }
        });
    }
}
