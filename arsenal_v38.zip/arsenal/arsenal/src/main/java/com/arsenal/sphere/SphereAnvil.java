package com.arsenal.sphere;

import com.arsenal.Arsenal;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Свои рецепты наковальни:
 *  - две обычные/эпические/легендарные сферы -> одна сфера (эффекты складываются);
 *    результат должен быть эпической (2 очка, 30 ур.) или легендарной (3-4 очка, 30 ур.);
 *    мифическую в наковальне получить нельзя;
 *  - сфера + тотем бессмертия -> талисман того же вида (обычный/эпический/легендарный/Stinger/Eternity), всегда 30 ур.
 */
public final class SphereAnvil {
    public static final int EPIC_COST = 30;
    public static final int LEGENDARY_COST = 30;
    public static final int TALISMAN_COST = 30;
    public static final int MAX_EFFECT_LEVEL_IN_ANVIL = 3;
    public static final int MAX_POINTS_IN_ANVIL = 4;

    public static class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private SphereAnvil() {
    }

    private static boolean isMergeable(Item item) {
        return item == Arsenal.SPHERE_COMMON || item == Arsenal.SPHERE_EPIC || item == Arsenal.SPHERE_LEGENDARY;
    }

    private static boolean canMakeTalisman(Item item) {
        return isMergeable(item) || item == Arsenal.SPHERE_STINGER || item == Arsenal.SPHERE_ETERNITY;
    }

    /** null = это не наш рецепт, остаётся обычное поведение наковальни. */
    public static Result compute(ItemStack left, ItemStack right) {
        Item l = left.getItem();
        Item r = right.getItem();

        if (r == Items.TOTEM_OF_UNDYING && canMakeTalisman(l)) {
            return talisman(left);
        }
        if (l == Items.TOTEM_OF_UNDYING && canMakeTalisman(r)) {
            return talisman(right);
        }
        if (isMergeable(l) && isMergeable(r)) {
            return merge(left, right);
        }
        return null;
    }

    /** Каждая сфера даёт талисман своего вида; уровни эффектов переносятся. */
    private static Result talisman(ItemStack sphere) {
        Item item = sphere.getItem();
        if (item == Arsenal.SPHERE_ETERNITY) {
            return new Result(new ItemStack(Arsenal.TALISMAN_ETERNITY), TALISMAN_COST);
        }
        if (item == Arsenal.SPHERE_STINGER) {
            return new Result(new ItemStack(Arsenal.TALISMAN_STINGER), TALISMAN_COST);
        }
        Item target = item == Arsenal.SPHERE_COMMON ? Arsenal.TALISMAN_COMMON
                : item == Arsenal.SPHERE_EPIC ? Arsenal.TALISMAN
                : Arsenal.TALISMAN_LEGENDARY;
        int[] levels = ((EffectItem) item).effects(sphere);
        return new Result(Spheres.stack(target, levels), TALISMAN_COST);
    }

    private static Result merge(ItemStack a, ItemStack b) {
        int[] la = ((EffectItem) a.getItem()).effects(a);
        int[] lb = ((EffectItem) b.getItem()).effects(b);
        int[] sum = new int[SphereEffect.COUNT];
        for (int i = 0; i < sum.length; i++) {
            sum[i] = la[i] + lb[i];
            if (sum[i] > MAX_EFFECT_LEVEL_IN_ANVIL) {
                return null;
            }
        }
        int points = Spheres.points(sum);
        if (points > MAX_POINTS_IN_ANVIL) {
            return null; // дальше только мифические и особые, их в наковальне не сделать
        }
        if (points == 2) {
            return new Result(Spheres.stack(Arsenal.SPHERE_EPIC, sum), EPIC_COST);
        }
        if (points >= 3) {
            return new Result(Spheres.stack(Arsenal.SPHERE_LEGENDARY, sum), LEGENDARY_COST);
        }
        return null;
    }
}
