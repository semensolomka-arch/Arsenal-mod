package com.arsenal.artifact;

import com.arsenal.Arsenal;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Логика всех эффектов Артефакта. Вызывается из миксинов. */
public final class ArtifactEffects {
    /** true, пока эффект накладывается броском зелья (для "Справедливости"). */
    public static boolean fromPotion = false;

    /** Настраиваются в Settings: шансы в процентах, длительности в тиках, уровень эффекта минус 1. */
    public static int ILLUMINATOR_CHANCE = 5;
    public static int ILLUMINATOR_TICKS = 20 * 15;
    public static int SNOWMAN_CHANCE = 5;
    public static int SNOWMAN_TICKS = 20 * 5;
    public static int SNOWMAN_AMP = 0;
    public static int VAMPIRISM_CHANCE = 2;
    public static int VAMPIRISM_TICKS = 20 * 5;
    public static int VAMPIRISM_AMP = 1;
    public static int ENDERMAN_CHANCE = 50;
    public static int TELEKINESIS_TICKS = 20 * 3;
    public static int HUNTER_PERCENT = 50;

    private static final Map<String, Long> LAST_NOTIFY = new HashMap<>();
    private static final List<Pending> PENDING = new ArrayList<>();

    private static class Pending {
        final ItemEntity item;
        final long until;

        Pending(ItemEntity item, long until) {
            this.item = item;
            this.until = until;
        }
    }

    private ArtifactEffects() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ArtifactEffects::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            PENDING.clear();
            LAST_NOTIFY.clear();
        });
    }

    /** Телекинез: через 3 секунды добыча снова доступна всем. */
    private static void tick(MinecraftServer server) {
        if (PENDING.isEmpty()) {
            return;
        }
        Iterator<Pending> it = PENDING.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (p.item.world.getTime() >= p.until) {
                p.item.setOwner(null);
                it.remove();
            }
        }
    }

    /** Артефакт со всеми эффектами сразу (для креативной вкладки). */
    public static ItemStack fullArtifact() {
        ItemStack stack = new ItemStack(Arsenal.ARTIFACT);
        for (ArtifactEffect effect : ArtifactEffect.values()) {
            stack.addEnchantment(effect.enchantment, 1);
        }
        return stack;
    }

    /** Есть ли у игрока эффект: сам предмет-эффект или Артефакт с ним в инвентаре. */
    public static boolean has(PlayerEntity player, ArtifactEffect effect) {
        for (int i = 0; i < player.inventory.size(); i++) {
            ItemStack stack = player.inventory.getStack(i);
            if (stack.isEmpty()) {
                continue;
            }
            Item item = stack.getItem();
            if (item == effect.item) {
                return true;
            }
            if (item == Arsenal.ARTIFACT && effect.enchantment != null
                    && EnchantmentHelper.getLevel(effect.enchantment, stack) > 0) {
                return true;
            }
        }
        return false;
    }

    /** "Только что сработал эффект «...»" над хотбаром (не чаще раза в секунду на эффект). */
    public static void notifyTriggered(ServerPlayerEntity player, ArtifactEffect effect) {
        long now = player.world.getTime();
        String key = player.getUuid() + ":" + effect.id;
        Long last = LAST_NOTIFY.get(key);
        if (last != null && now - last < 20) {
            return;
        }
        LAST_NOTIFY.put(key, now);
        player.sendMessage(new LiteralText("Только что сработал эффект «" + effect.title + "»")
                .formatted(Formatting.GREEN), true);
    }

    /** Удар игрока по существу: Иллюминатор, Снеговик, Вампиризм. */
    public static void onMeleeHit(ServerPlayerEntity attacker, LivingEntity victim) {
        Random random = attacker.world.random;

        if (has(attacker, ArtifactEffect.ILLUMINATOR) && random.nextFloat() * 100.0F < ILLUMINATOR_CHANCE) {
            victim.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, ILLUMINATOR_TICKS, 4));
            notifyTriggered(attacker, ArtifactEffect.ILLUMINATOR);
        }
        if (has(attacker, ArtifactEffect.SNOWMAN) && random.nextFloat() * 100.0F < SNOWMAN_CHANCE) {
            victim.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, SNOWMAN_TICKS, SNOWMAN_AMP));
            notifyTriggered(attacker, ArtifactEffect.SNOWMAN);
        }
        if (has(attacker, ArtifactEffect.VAMPIRISM) && random.nextFloat() * 100.0F < VAMPIRISM_CHANCE) {
            attacker.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, VAMPIRISM_TICKS, VAMPIRISM_AMP));
            notifyTriggered(attacker, ArtifactEffect.VAMPIRISM);
        }
    }

    /** Убийство: Телекинез и Охотник. Вызывается после того, как добыча уже выпала. */
    public static void onKill(LivingEntity victim, DamageSource source) {
        Entity attacker = source.getAttacker();
        if (!(attacker instanceof ServerPlayerEntity) || attacker == victim) {
            return;
        }
        ServerPlayerEntity killer = (ServerPlayerEntity) attacker;

        if (has(killer, ArtifactEffect.TELEKINESIS)) {
            long now = victim.world.getTime();
            boolean any = false;
            for (ItemEntity item : victim.world.getEntitiesByClass(ItemEntity.class,
                    victim.getBoundingBox().expand(0.5), e -> true)) {
                item.setOwner(killer.getUuid());
                PENDING.add(new Pending(item, now + TELEKINESIS_TICKS));
                any = true;
            }
            if (any) {
                notifyTriggered(killer, ArtifactEffect.TELEKINESIS);
            }
        }

        if (victim instanceof PlayerEntity && has(killer, ArtifactEffect.HUNTER)) {
            int take = totalExperience((PlayerEntity) victim) * HUNTER_PERCENT / 100;
            if (take > 0) {
                killer.addExperience(take);
                notifyTriggered(killer, ArtifactEffect.HUNTER);
            }
        }
    }

    /** Весь опыт игрока в очках (по уровню и полоске). */
    private static int totalExperience(PlayerEntity player) {
        int level = player.experienceLevel;
        int base;
        if (level <= 16) {
            base = level * level + 6 * level;
        } else if (level <= 31) {
            base = (int) (2.5 * level * level - 40.5 * level + 360);
        } else {
            base = (int) (4.5 * level * level - 162.5 * level + 2220);
        }
        return base + (int) (player.experienceProgress * player.getNextLevelExperience());
    }

    /** Дебаффы, которые "Справедливость" не пускает от бросаемых зелий. */
    public static boolean isDebuff(StatusEffect effect) {
        return effect == StatusEffects.JUMP_BOOST
                || effect == StatusEffects.SLOWNESS
                || effect == StatusEffects.BLINDNESS
                || effect == StatusEffects.WEAKNESS
                || effect == StatusEffects.POISON
                || effect == StatusEffects.WITHER
                || effect == StatusEffects.MINING_FATIGUE;
    }
}
