package com.arsenal;

import com.arsenal.entity.SnowClumpEntity;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.SlabType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

/**
 * Вся логика предметов.
 * Работает двумя способами:
 *  - из руки: ПКМ с самим предметом (Item.use вызывает useXxx(player, stackВРуке));
 *  - по бинду: предмет лежит в инвентаре, в руке оружие (useXxxBound).
 */
public class Abilities {
    // --- настройки ---
    public static final int TRAP_COOLDOWN = 20 * 40;      // кд трапки
    public static final int TRAP_LIFETIME = 20 * 15;      // сколько стоит клетка
    public static final int SNOW_COOLDOWN = 20 * 30;      // кд кома снега
    public static final int STUN_COOLDOWN = 20 * 30;      // кд стана
    public static final int STUN_PEARL_BAN = 20 * 30;     // запрет жемчуга эндера
    public static final int STUN_SLOW_TICKS = 20 * 10;    // замедление I
    public static final double STUN_HALF_SIZE = 15.0;     // зона 30x30x30
    public static final int TRAP_GAP_DY = 0;              // высота "окошка" в стенках: 0 = центральный блок стены

    /** Что считается оружием. Добавь сюда другие классы, если нужно. */
    public static boolean isWeapon(ItemStack stack) {
        Item i = stack.getItem();
        return i instanceof SwordItem || i instanceof AxeItem || i instanceof TridentItem;
    }

    public static ItemStack find(PlayerEntity p, Item item) {
        for (int i = 0; i < p.inventory.size(); i++) {
            ItemStack s = p.inventory.getStack(i);
            if (!s.isEmpty() && s.getItem() == item) {
                return s;
            }
        }
        return ItemStack.EMPTY;
    }

    /** В руке оружие и предмет есть в инвентаре (кд не учитывается). */
    public static boolean holdsWeaponAndHas(PlayerEntity p, Item item) {
        return !p.isSpectator() && isWeapon(p.getMainHandStack()) && !find(p, item).isEmpty();
    }

    /** То же, но ещё и кулдаун закончился. */
    public static boolean canUse(PlayerEntity p, Item item) {
        return holdsWeaponAndHas(p, item) && !p.getItemCooldownManager().isCoolingDown(item);
    }

    /**
     * Можно ли сейчас поставить трапку правой кнопкой (по бинду, с оружием в руке).
     * Если во второй руке еда, щит и т.п., трапка не срабатывает. В главной руке должен быть меч или топор (не трезубец).
     */
    public static boolean canUseTrapByRmb(PlayerEntity p) {
        // только с мечом или топором: с трезубцем ПКМ натягивает бросок и трапку не ставит
        Item held = p.getMainHandStack().getItem();
        if (!(held instanceof SwordItem || held instanceof AxeItem)) return false;
        Item trap = find(p, Arsenal.TRAP).isEmpty() ? Arsenal.EXPLOSIVE_TRAP : Arsenal.TRAP;
        if (!canUse(p, trap)) return false;
        ItemStack off = p.getOffHandStack();
        return off.isEmpty() || off.getUseAction() == UseAction.NONE;
    }

    private static void consume(PlayerEntity p, ItemStack stack) {
        if (!p.isCreative()) {
            stack.decrement(1);
        }
    }

    // ---------- Ком снега ----------
    public static void useSnowBound(ServerPlayerEntity p) {
        if (!canUse(p, Arsenal.SNOW_BALL)) return;
        useSnow(p, find(p, Arsenal.SNOW_BALL));
    }

    public static void useSnow(ServerPlayerEntity p, ItemStack source) {
        World world = p.world;

        world.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_SNOWBALL_THROW,
                SoundCategory.PLAYERS, 0.5F, 0.4F / (world.random.nextFloat() * 0.4F + 0.8F));

        SnowClumpEntity clump = new SnowClumpEntity(world, p);
        clump.setItem(new ItemStack(Arsenal.SNOW_BALL));
        clump.setProperties(p, p.pitch, p.yaw, 0.0F, 1.5F, 1.0F);
        world.spawnEntity(clump);

        p.getItemCooldownManager().set(Arsenal.SNOW_BALL, SNOW_COOLDOWN);
        consume(p, source);
    }

    // ---------- Стан ----------
    public static void useStunBound(ServerPlayerEntity p) {
        if (!canUse(p, Arsenal.STUN)) return;
        useStun(p, find(p, Arsenal.STUN));
    }

    public static void useStun(ServerPlayerEntity user, ItemStack source) {
        ServerWorld world = user.getServerWorld();

        Box box = new Box(
                user.getX() - STUN_HALF_SIZE, user.getY() - STUN_HALF_SIZE, user.getZ() - STUN_HALF_SIZE,
                user.getX() + STUN_HALF_SIZE, user.getY() + STUN_HALF_SIZE, user.getZ() + STUN_HALF_SIZE);

        // жемчуг эндера блокируется только внутри этой зоны и только пока она активна (StunZones)
        StunZones.add(world, box, STUN_PEARL_BAN);

        for (PlayerEntity p : world.getEntitiesByClass(PlayerEntity.class, box, e -> e.isAlive() && !e.isSpectator())) {
            if (p != user) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, STUN_SLOW_TICKS, 0));
            }
        }

        world.playSound(null, user.getX(), user.getY(), user.getZ(),
                SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 1.0F, 1.0F);
        world.spawnParticles(ParticleTypes.CLOUD, user.getX(), user.getY() + 1.0, user.getZ(), 40, 1.5, 0.5, 1.5, 0.1);

        user.getItemCooldownManager().set(Arsenal.STUN, STUN_COOLDOWN);
        consume(user, source);
    }

    // ---------- Трапка ----------
    public static boolean useTrapBound(ServerPlayerEntity p) {
        if (!canUseTrapByRmb(p)) return false;
        ItemStack normal = find(p, Arsenal.TRAP);
        if (!normal.isEmpty()) {
            useTrap(p, normal);
        } else {
            com.arsenal.special.Specials.useExplosiveTrap(p, find(p, Arsenal.EXPLOSIVE_TRAP));
        }
        return true;
    }

    /**
     * Трапка: коробка 5x5x5 из эндерняковых кирпичей вокруг игрока (схема TrapShapes.TRAP).
     * Блоки на её месте запоминаются и через TRAP_LIFETIME тиков возвращаются как были (с содержимым сундуков).
     * Пока клетка стоит, её блоки нельзя ломать. Бедрок и прочее неломаемое не трогаем.
     */
    public static void useTrap(ServerPlayerEntity p, ItemStack source) {
        if (SpawnProtection.contains(p.getServerWorld(), p.getBlockPos()) && !SpawnProtection.bypass(p)) {
            SpawnProtection.deny(p, "В зоне замка нельзя ставить трапки");
            return;
        }
        ServerWorld world = p.getServerWorld();
        BlockPos center = p.getBlockPos();

        if (com.arsenal.priv.PrivateManager.intersects(world, com.arsenal.special.TrapShapes.TRAP.bounds(center))) {
            SpawnProtection.deny(p, "В привате нельзя использовать трапки");
            return;
        }
        // коробка 5x5x5 из эндерняковых кирпичей вокруг игрока (схема в TrapShapes.TRAP)
        com.arsenal.special.TrapShapes.TRAP.build(world, center);

        world.playSound(null, p.getX(), p.getY(), p.getZ(),
                SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 4.0F, 0.8F);

        p.getItemCooldownManager().set(Arsenal.TRAP, TRAP_COOLDOWN);
        p.getItemCooldownManager().set(Arsenal.EXPLOSIVE_TRAP, TRAP_COOLDOWN); // общий кд с взрывной трапкой
        consume(p, source);
    }
}
