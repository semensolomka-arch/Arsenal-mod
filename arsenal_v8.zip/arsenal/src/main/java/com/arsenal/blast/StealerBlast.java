package com.arsenal.blast;

import com.arsenal.TrapManager;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/**
 * Взрыв стиллера: выглядит и звучит как взрыв TNT, но не наносит урона и не ломает блоки.
 * Забирает ровно один спавнер рядом (ближайший). С шансом выпадает спавнер с тем же мобом, иначе спавнер свиньи.
 */
public final class StealerBlast {
    /** Радиус поиска спавнера вокруг взрыва, блоков. */
    private static final int RADIUS = 3;
    private static final String PIG = "minecraft:pig";

    private StealerBlast() {
    }

    public static void explode(ServerWorld world, double x, double y, double z, BlastKind kind) {
        // вид и звук обычного взрыва, но без урона и разрушения
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, x, y, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        world.playSound(null, x, y, z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0F,
                (1.0F + (world.random.nextFloat() - world.random.nextFloat()) * 0.2F) * 0.7F);

        BlockPos spawnerPos = findSpawner(world, x, y, z);
        if (spawnerPos == null) {
            return;
        }
        BlockEntity be = world.getBlockEntity(spawnerPos);
        String mobId = PIG;
        NbtCompound spawnData = null;
        if (be instanceof MobSpawnerBlockEntity) {
            NbtCompound full = be.writeNbt(new NbtCompound());
            if (full.contains("SpawnData", 10)) {
                spawnData = full.getCompound("SpawnData").copy();
                String id = spawnData.getString("id");
                if (!id.isEmpty()) {
                    mobId = id;
                }
            }
        }

        boolean kept = world.random.nextDouble() < kind.keepChance;
        if (!kept) {
            mobId = PIG;
            spawnData = null;
        }
        if (spawnData == null) {
            spawnData = new NbtCompound();
            spawnData.putString("id", mobId);
        }

        world.removeBlock(spawnerPos, false);
        Block.dropStack(world, spawnerPos, makeSpawner(mobId, spawnData));
        playMobSound(world, mobId, spawnerPos);
    }

    /** Ближайший к взрыву спавнер в радиусе (с учётом защищённых зон). */
    private static BlockPos findSpawner(ServerWorld world, double x, double y, double z) {
        BlockPos center = new BlockPos(x, y, z);
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.iterate(center.add(-RADIUS, -RADIUS, -RADIUS), center.add(RADIUS, RADIUS, RADIUS))) {
            BlockState state = world.getBlockState(pos);
            if (!state.isOf(Blocks.SPAWNER)) {
                continue;
            }
            if (SpawnProtection.contains(world, pos) || TrapManager.isProtected(pos)) {
                continue;
            }
            double dist = pos.getSquaredDistance(x - 0.5D, y - 0.5D, z - 0.5D, false);
            if (dist < bestDist) {
                bestDist = dist;
                best = pos.toImmutable();
            }
        }
        return best;
    }

    /** Предмет-спавнер с мобом. Содержимое одинаковое для одного моба, поэтому такие спавнеры стакаются. */
    private static ItemStack makeSpawner(String mobId, NbtCompound spawnData) {
        ItemStack stack = new ItemStack(Items.SPAWNER);
        NbtCompound blockEntityTag = new NbtCompound();
        blockEntityTag.put("SpawnData", spawnData);
        stack.putSubTag("BlockEntityTag", blockEntityTag);

        Identifier id = Identifier.tryParse(mobId);
        EntityType<?> type = id == null ? EntityType.PIG : EntityType.get(mobId).orElse(EntityType.PIG);
        Text name = new TranslatableText("name.arsenal.spawner", new TranslatableText(type.getTranslationKey()))
                .setStyle(Style.EMPTY.withItalic(false));
        stack.getOrCreateSubTag("display").putString("Name", Text.Serializer.toJson(name));
        return stack;
    }

    /** Звук моба (его обычный звук), как будто он выпал из спавнера. */
    private static void playMobSound(ServerWorld world, String mobId, BlockPos pos) {
        EntityType<?> type = EntityType.get(mobId).orElse(EntityType.PIG);
        Entity entity = type.create(world);
        if (entity instanceof MobEntity) {
            entity.setPosition(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            ((MobEntity) entity).playAmbientSound();
        }
    }
}
