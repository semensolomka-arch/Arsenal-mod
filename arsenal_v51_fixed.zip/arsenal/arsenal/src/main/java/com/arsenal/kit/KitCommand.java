package com.arsenal.kit;

import com.arsenal.Arsenal;
import com.arsenal.NameDecor;
import com.arsenal.sphere.EffectItem;
import com.arsenal.tool.ToolEnchants;
import net.minecraft.enchantment.Enchantment;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ToolItem;
import net.minecraft.item.TridentItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import static net.minecraft.enchantment.Enchantments.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * /kit stinger, eternity, infinity, dragon, kraken, wither, ghast, mustang, griefer, start: выдают набор вещей. Если в инвентаре не хватает места,
 * не выдаётся ничего, а в чат пишется, что нет места.
 */
public final class KitCommand {
    private KitCommand() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("kit")
                        .then(CommandManager.literal("stinger").executes(ctx -> giveStinger(ctx.getSource())))
                        .then(CommandManager.literal("eternity").executes(ctx -> giveEternity(ctx.getSource())))
                        .then(CommandManager.literal("infinity").executes(ctx -> giveInfinity(ctx.getSource())))
                        .then(CommandManager.literal("dragon").executes(ctx -> run(ctx.getSource(), "DRAGON", dragonKit())))
                        .then(CommandManager.literal("kraken").executes(ctx -> run(ctx.getSource(), "KRAKEN", krakenKit())))
                        .then(CommandManager.literal("wither").executes(ctx -> run(ctx.getSource(), "WITHER", witherKit())))
                        .then(CommandManager.literal("ghast").executes(ctx -> run(ctx.getSource(), "GHAST", ghastKit())))
                        .then(CommandManager.literal("mustang").executes(ctx -> run(ctx.getSource(), "MUSTANG", mustangKit())))
                        .then(CommandManager.literal("griefer").executes(ctx -> run(ctx.getSource(), "GRIEFER", grieferKit())))
                        .then(CommandManager.literal("start").executes(ctx -> run(ctx.getSource(), "START", startKit())))));
    }

    private static int run(ServerCommandSource source, String name, List<ItemStack> kit) throws CommandSyntaxException {
        give(source.getPlayer(), name, kit);
        return 1;
    }

    private static int giveStinger(ServerCommandSource source) throws CommandSyntaxException {
        give(source.getPlayer(), "STINGER", stingerKit());
        return 1;
    }

    private static int giveEternity(ServerCommandSource source) throws CommandSyntaxException {
        give(source.getPlayer(), "ETERNITY", eternityKit());
        return 1;
    }

    private static int giveInfinity(ServerCommandSource source) throws CommandSyntaxException {
        give(source.getPlayer(), "INFINITY", infinityKit());
        return 1;
    }

    // ---------------- наборы ----------------

    /** Вся броня, оружие, инструменты, сферы и талисманы из всех китов (для вкладки креатива). */
    public static List<ItemStack> allGear() {
        List<ItemStack> out = new ArrayList<>();
        List<List<ItemStack>> kits = Arrays.asList(stingerKit(), eternityKit(), infinityKit(), dragonKit(), krakenKit(),
                witherKit(), ghastKit(), mustangKit(), grieferKit(), startKit(), sunKit());
        for (List<ItemStack> kit : kits) {
            for (ItemStack s : kit) {
                Item i = s.getItem();
                if (i instanceof ArmorItem || i instanceof ToolItem || i instanceof BowItem || i instanceof CrossbowItem
                        || i instanceof TridentItem || i instanceof EffectItem) {
                    out.add(s);
                }
            }
        }
        return out;
    }

    private static List<ItemStack> stingerKit() {
        Look l = STINGER;
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(Arsenal.stingerArmor()));
        kit.add(Arsenal.stingerSword());
        kit.add(Arsenal.stingerTrident());
        kit.add(gear(Items.CROSSBOW, l, "Арбалет STINGER", MULTISHOT, 1, PIERCING, 4, QUICK_CHARGE, 3, UNBREAKING, 3,
                ToolEnchants.STUNNING, 1));
        kit.add(gear(Items.BOW, l, "Лук STINGER", FLAME, 1, INFINITY, 1, POWER, 4, PUNCH, 2, UNBREAKING, 3,
                ToolEnchants.STUNNING, 1));
        kit.add(gear(Items.NETHERITE_PICKAXE, l, "Кирка STINGER", EFFICIENCY, 8, FORTUNE, 4, MENDING, 1, UNBREAKING, 4,
                ToolEnchants.INDESTRUCTIBLE, 1, ToolEnchants.AUTOSMELT, 1, ToolEnchants.EXPERIENCED, 3, ToolEnchants.DRILL, 1));
        kit.add(gear(Items.NETHERITE_SHOVEL, l, "Лопата STINGER", EFFICIENCY, 5, FORTUNE, 4, MENDING, 1, UNBREAKING, 4,
                ToolEnchants.DRILL, 1, ToolEnchants.INDESTRUCTIBLE, 1));
        kit.add(gear(Items.NETHERITE_AXE, l, "Топор STINGER", EFFICIENCY, 6, FORTUNE, 4, MENDING, 1, UNBREAKING, 4,
                ToolEnchants.LUMBERJACK, 2));
        kit.add(new ItemStack(Arsenal.TALISMAN_STINGER));
        add(kit, new ItemStack(Items.ENDER_PEARL), 16);
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 32);
        add(kit, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 4);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 5 * 64);
        add(kit, new ItemStack(Items.TOTEM_OF_UNDYING), 3);
        add(kit, tipped(Potions.STRONG_HARMING), 32);
        add(kit, tipped(Potions.POISON), 8);
        add(kit, tipped(Potions.WEAKNESS), 8);
        add(kit, new ItemStack(Items.ARROW), 64);
        add(kit, drink(Potions.LONG_INVISIBILITY), POTIONS);
        add(kit, drink(Potions.LONG_FIRE_RESISTANCE), POTIONS);
        add(kit, new ItemStack(Arsenal.SPEED_III_3M), POTIONS);
        add(kit, new ItemStack(Items.OBSIDIAN), 16);
        add(kit, new ItemStack(Items.TNT), 8);
        add(kit, new ItemStack(Items.END_CRYSTAL), 16);
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 48);
        add(kit, new ItemStack(Items.CHORUS_FRUIT), 48);
        return kit;
    }

    /** Фул незерит: все защиты III, Прочность III, Починка, Невесомость II; шлем: Подводное дыхание III + Подводник, ботинки: Подводная ходьба III. */
    private static List<ItemStack> dragonKit() {
        Look l = DRAGON;
        List<ItemStack> kit = new ArrayList<>();
        ItemStack[] armor = armor(NETHERITE, l, "DRAGON", PROTECTION, 3, BLAST_PROTECTION, 3, FIRE_PROTECTION, 3,
                PROJECTILE_PROTECTION, 3, UNBREAKING, 3);
        armor[3].addEnchantment(FEATHER_FALLING, 2);
        for (ItemStack piece : armor) {
            piece.addEnchantment(MENDING, 1);              // Починка, как на броне Infinity
        }
        armor[0].addEnchantment(RESPIRATION, 3);           // Подводное дыхание
        armor[0].addEnchantment(AQUA_AFFINITY, 1);         // Подводник
        armor[3].addEnchantment(DEPTH_STRIDER, 3);         // Подводная ходьба
        kit.addAll(Arrays.asList(armor));
        kit.add(gear(Items.NETHERITE_SWORD, l, "Меч DRAGON", SHARPNESS, 5, LOOTING, 5, UNBREAKING, 3, FIRE_ASPECT, 2,
                BANE_OF_ARTHROPODS, 7, SMITE, 7, MENDING, 1, SWEEPING, 3));
        kit.add(gear(Items.TRIDENT, l, "Трезубец DRAGON", UNBREAKING, 2, LOYALTY, 2, Arsenal.HOMING, 1, LOOTING, 1,
                IMPALING, 2));
        kit.add(gear(Items.BOW, l, "Лук DRAGON", UNBREAKING, 3, PUNCH, 2, POWER, 3, INFINITY, 1, FLAME, 1));
        kit.add(gear(Items.CROSSBOW, l, "Арбалет DRAGON", MULTISHOT, 1, PIERCING, 3, QUICK_CHARGE, 3, UNBREAKING, 3));
        kit.add(gear(Items.NETHERITE_PICKAXE, l, "Кирка DRAGON", EFFICIENCY, 6, FORTUNE, 3, UNBREAKING, 4,
                ToolEnchants.EXPERIENCED, 2, ToolEnchants.AUTOSMELT, 1));
        kit.add(gear(Items.NETHERITE_AXE, l, "Топор DRAGON", EFFICIENCY, 5, UNBREAKING, 3, FORTUNE, 3, MENDING, 1,
                ToolEnchants.LUMBERJACK, 1));
        kit.add(gear(Items.NETHERITE_SHOVEL, l, "Лопата DRAGON", FORTUNE, 3, EFFICIENCY, 5, MENDING, 1, UNBREAKING, 3));
        add(kit, new ItemStack(Items.ENDER_PEARL), 16);
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 16);
        add(kit, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 4);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 4 * 64);
        add(kit, new ItemStack(Items.ARROW), 64);
        add(kit, tipped(Potions.STRONG_HARMING), 32);
        add(kit, drink(Potions.LONG_INVISIBILITY), POTIONS);
        add(kit, drink(Potions.LONG_FIRE_RESISTANCE), POTIONS);
        add(kit, new ItemStack(Arsenal.SPEED_III_3M), POTIONS);
        add(kit, new ItemStack(Items.CHORUS_FRUIT), 32);
        add(kit, new ItemStack(Items.TOTEM_OF_UNDYING), 1);
        kit.add(new ItemStack(Arsenal.TALISMAN_DRAGON));
        return kit;
    }

    private static List<ItemStack> krakenKit() {
        Look l = KRAKEN;
        List<ItemStack> kit = new ArrayList<>();
        ItemStack[] armor = armor(DIAMOND, l, "KRAKEN", PROTECTION, 3, BLAST_PROTECTION, 2, FIRE_PROTECTION, 2,
                PROJECTILE_PROTECTION, 2, UNBREAKING, 2);
        armor[0].addEnchantment(RESPIRATION, 3);
        armor[0].addEnchantment(AQUA_AFFINITY, 1);
        armor[3].addEnchantment(DEPTH_STRIDER, 3);
        armor[3].addEnchantment(FEATHER_FALLING, 1);
        armor[3].addEnchantment(SOUL_SPEED, 3);
        kit.addAll(Arrays.asList(armor));
        kit.add(gear(Items.DIAMOND_AXE, l, "Топор KRAKEN", EFFICIENCY, 4, UNBREAKING, 3, FORTUNE, 3, MENDING, 1));
        kit.add(gear(Items.DIAMOND_SHOVEL, l, "Лопата KRAKEN", EFFICIENCY, 4, UNBREAKING, 3, FORTUNE, 3, MENDING, 1));
        kit.add(gear(Items.DIAMOND_PICKAXE, l, "Кирка KRAKEN", EFFICIENCY, 6, UNBREAKING, 4, ToolEnchants.EXPERIENCED, 2,
                ToolEnchants.AUTOSMELT, 1, MENDING, 1, FORTUNE, 3));
        kit.add(gear(Items.DIAMOND_SWORD, l, "Меч KRAKEN", SHARPNESS, 4, FIRE_ASPECT, 2, LOOTING, 5, BANE_OF_ARTHROPODS, 7,
                SMITE, 7, UNBREAKING, 3, MENDING, 1, SWEEPING, 3));
        kit.add(gear(Items.TRIDENT, l, "Трезубец KRAKEN", UNBREAKING, 1, LOYALTY, 1, IMPALING, 1));
        kit.add(gear(Items.BOW, l, "Лук KRAKEN", POWER, 3, PUNCH, 2, UNBREAKING, 3));
        add(kit, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 1);
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 8);
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 32);
        add(kit, new ItemStack(Items.ENDER_PEARL), 12);
        add(kit, drink(Potions.LONG_FIRE_RESISTANCE), POTIONS);
        add(kit, drink(Potions.LONG_INVISIBILITY), POTIONS);
        add(kit, new ItemStack(Items.ARROW), 32);
        add(kit, new ItemStack(Items.CHORUS_FRUIT), 24);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 3 * 64);
        return kit;
    }

    private static List<ItemStack> witherKit() {
        Look l = WITHER;
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(armor(DIAMOND, l, "WITHER", PROTECTION, 2, UNBREAKING, 2)));
        kit.add(gear(Items.TRIDENT, l, "Трезубец WITHER", UNBREAKING, 1));
        kit.add(gear(Items.DIAMOND_SWORD, l, "Меч WITHER", SHARPNESS, 3, FIRE_ASPECT, 1, UNBREAKING, 2, LOOTING, 3,
                SWEEPING, 2));
        kit.add(gear(Items.BOW, l, "Лук WITHER", POWER, 2, UNBREAKING, 2, PUNCH, 1));
        kit.add(gear(Items.DIAMOND_PICKAXE, l, "Кирка WITHER", EFFICIENCY, 4, FORTUNE, 2, UNBREAKING, 3));
        kit.add(gear(Items.DIAMOND_AXE, l, "Топор WITHER", EFFICIENCY, 4, FORTUNE, 2, UNBREAKING, 3));
        kit.add(gear(Items.DIAMOND_SHOVEL, l, "Лопата WITHER", EFFICIENCY, 4, FORTUNE, 2, UNBREAKING, 3));
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 8);
        add(kit, new ItemStack(Items.CHORUS_FRUIT), 16);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 48);
        add(kit, new ItemStack(Items.ENDER_PEARL), 8);
        add(kit, drink(Potions.LONG_INVISIBILITY), POTIONS);
        add(kit, drink(Potions.LONG_FIRE_RESISTANCE), POTIONS);
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 16);
        add(kit, new ItemStack(Items.ARROW), 32);
        return kit;
    }

    private static List<ItemStack> ghastKit() {
        Look l = GHAST;
        List<ItemStack> kit = new ArrayList<>();
        // шлем и штаны железные (защита 2), нагрудник и ботинки алмазные (защита 1)
        kit.add(gear(Items.IRON_HELMET, l, "Шлем GHAST", PROTECTION, 2, UNBREAKING, 2));
        kit.add(gear(Items.DIAMOND_CHESTPLATE, l, "Нагрудник GHAST", PROTECTION, 1, UNBREAKING, 1));
        kit.add(gear(Items.IRON_LEGGINGS, l, "Поножи GHAST", PROTECTION, 2, UNBREAKING, 2));
        kit.add(gear(Items.DIAMOND_BOOTS, l, "Ботинки GHAST", PROTECTION, 1, UNBREAKING, 1));
        kit.add(gear(Items.IRON_SWORD, l, "Меч GHAST", SHARPNESS, 3, LOOTING, 2, UNBREAKING, 3));
        kit.add(gear(Items.BOW, l, "Лук GHAST", POWER, 1, UNBREAKING, 1));
        kit.add(gear(Items.DIAMOND_PICKAXE, l, "Кирка GHAST", EFFICIENCY, 3, FORTUNE, 2, UNBREAKING, 2));
        kit.add(gear(Items.DIAMOND_AXE, l, "Топор GHAST", EFFICIENCY, 3, FORTUNE, 2, UNBREAKING, 2));
        kit.add(gear(Items.DIAMOND_SHOVEL, l, "Лопата GHAST", EFFICIENCY, 3, FORTUNE, 2, UNBREAKING, 2));
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 3);
        add(kit, new ItemStack(Items.ENDER_PEARL), 2);
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 8);
        add(kit, new ItemStack(Items.CHORUS_FRUIT), 8);
        add(kit, new ItemStack(Items.ARROW), 24);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 32);
        return kit;
    }

    private static List<ItemStack> mustangKit() {
        Look l = MUSTANG;
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(armor(IRON, l, "MUSTANG", PROTECTION, 2, UNBREAKING, 2)));
        kit.add(gear(Items.IRON_SWORD, l, "Меч MUSTANG", SHARPNESS, 2, UNBREAKING, 2, LOOTING, 1));
        kit.add(gear(Items.IRON_PICKAXE, l, "Кирка MUSTANG", EFFICIENCY, 3, UNBREAKING, 1, FORTUNE, 2));
        kit.add(gear(Items.BOW, l, "Лук MUSTANG", POWER, 1));
        kit.add(gear(Items.IRON_AXE, l, "Топор MUSTANG", EFFICIENCY, 3, UNBREAKING, 1, FORTUNE, 2));
        kit.add(gear(Items.IRON_SHOVEL, l, "Лопата MUSTANG", EFFICIENCY, 3, UNBREAKING, 1, FORTUNE, 2));
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 1);
        add(kit, new ItemStack(Items.ARROW), 10);
        add(kit, new ItemStack(Items.COOKED_PORKCHOP), 8);
        return kit;
    }

    private static List<ItemStack> grieferKit() {
        Look l = GRIEFER;
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(armor(CHAIN, l, "GRIEFER", PROTECTION, 1, UNBREAKING, 1)));
        kit.add(gear(Items.IRON_SWORD, l, "Меч GRIEFER", SHARPNESS, 1, UNBREAKING, 1));
        kit.add(gear(Items.IRON_PICKAXE, l, "Кирка GRIEFER", UNBREAKING, 1, EFFICIENCY, 1));
        kit.add(gear(Items.BOW, l, "Лук GRIEFER"));
        kit.add(gear(Items.IRON_AXE, l, "Топор GRIEFER", UNBREAKING, 1, EFFICIENCY, 1));
        kit.add(gear(Items.IRON_SHOVEL, l, "Лопата GRIEFER", EFFICIENCY, 1, UNBREAKING, 1));
        add(kit, new ItemStack(Items.OAK_LOG), 32);
        add(kit, new ItemStack(Items.COOKED_PORKCHOP), 8);
        add(kit, new ItemStack(Items.ARROW), 4);
        return kit;
    }

    /** Стартовый набор: обычные названия, как в ванили. */
    private static List<ItemStack> startKit() {
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(armor(CHAIN, null, null, UNBREAKING, 1)));
        kit.add(gear(Items.STONE_SWORD, null, null, UNBREAKING, 1));
        kit.add(gear(Items.STONE_AXE, null, null, UNBREAKING, 1));
        kit.add(gear(Items.STONE_PICKAXE, null, null, UNBREAKING, 1));
        add(kit, new ItemStack(Items.COOKED_PORKCHOP), 8);
        return kit;
    }

    private static List<ItemStack> eternityKit() {
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(Arsenal.eternityArmor()));
        kit.add(Arsenal.eternitySword());
        kit.add(Arsenal.eternityTrident());
        kit.add(new ItemStack(Arsenal.TALISMAN_ETERNITY));
        add(kit, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 64);  // стак чарок
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 64);           // стак золотой моркови
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 64);            // стак золотых яблок
        add(kit, drink(Potions.STRONG_HEALING), 64);                // стак обычного исцеления 2
        add(kit, new ItemStack(Items.ENDER_PEARL), 4 * 16);         // 4 стака жемчуга
        add(kit, new ItemStack(Arsenal.STRENGTH_III_6M), 64);       // стак силок 3 на 6 минут
        add(kit, new ItemStack(Items.TOTEM_OF_UNDYING), 3);
        addStack(kit, Arsenal.TRAP);
        addStack(kit, Arsenal.SNOW_BALL);
        addStack(kit, Arsenal.STUN);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 6 * 64);
        return kit;
    }

    /** Как Eternity, но броня/меч/талисман Infinity и вдвое больше трапок, комов снега и станов (по 2 стака). */
    private static List<ItemStack> infinityKit() {
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(Arsenal.infinityArmor()));
        kit.add(Arsenal.infinitySword());
        kit.add(Arsenal.infinityTrident());
        kit.add(new ItemStack(Arsenal.TALISMAN_INFINITY));
        add(kit, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 64);
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 64);
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 64);
        add(kit, drink(Potions.STRONG_HEALING), 64);
        add(kit, new ItemStack(Items.ENDER_PEARL), 4 * 16);
        add(kit, new ItemStack(Arsenal.STRENGTH_III_6M), 64);
        add(kit, new ItemStack(Items.TOTEM_OF_UNDYING), 3);
        add(kit, new ItemStack(Arsenal.TRAP), 2 * Arsenal.TRAP.getMaxCount());
        add(kit, new ItemStack(Arsenal.SNOW_BALL), 2 * Arsenal.SNOW_BALL.getMaxCount());
        add(kit, new ItemStack(Arsenal.STUN), 2 * Arsenal.STUN.getMaxCount());
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 6 * 64);
        return kit;
    }

    /** Шлем и ботинки солнца (ботинки пока только в креативе, в лут они не входят). */
    private static List<ItemStack> sunKit() {
        return new ArrayList<>(Arrays.asList(com.arsenal.item.SunGear.helmet(), com.arsenal.item.SunGear.boots()));
    }

    /** Вещь из кита для лута грузов: kit = wither/kraken/dragon/stinger/eternity, part = helmet, chestplate, leggings, boots, sword, trident, bow, crossbow, pickaxe, axe, shovel. */
    public static ItemStack lootGear(String kit, String part) {
        List<ItemStack> list;
        switch (kit) {
            case "wither": list = witherKit(); break;
            case "kraken": list = krakenKit(); break;
            case "dragon": list = dragonKit(); break;
            case "stinger": list = stingerKit(); break;
            case "eternity": list = eternityKit(); break;
            case "infinity": list = infinityKit(); break;
            case "sun": list = sunKit(); break;
            default: return null;
        }
        for (ItemStack s : list) {
            if (isPart(s.getItem(), part)) {
                return s.copy();
            }
        }
        return null;
    }

    private static boolean isPart(Item i, String part) {
        switch (part) {
            case "helmet": return i instanceof ArmorItem && ((ArmorItem) i).getSlotType() == EquipmentSlot.HEAD;
            case "chestplate": return i instanceof ArmorItem && ((ArmorItem) i).getSlotType() == EquipmentSlot.CHEST;
            case "leggings": return i instanceof ArmorItem && ((ArmorItem) i).getSlotType() == EquipmentSlot.LEGS;
            case "boots": return i instanceof ArmorItem && ((ArmorItem) i).getSlotType() == EquipmentSlot.FEET;
            case "sword": return i instanceof SwordItem;
            case "trident": return i instanceof TridentItem;
            case "bow": return i instanceof BowItem;
            case "crossbow": return i instanceof CrossbowItem;
            case "pickaxe": return i instanceof PickaxeItem;
            case "axe": return i instanceof AxeItem;
            case "shovel": return i instanceof ShovelItem;
            default: return false;
        }
    }

    // ---------------- помощники ----------------

    /** Сколько штук каждого зелья (Невидимость, Огнестойкость, Скорость III) в китах. */
    private static final int POTIONS = 1;

    private static final String[] ARMOR_RU = {"Шлем", "Нагрудник", "Поножи", "Ботинки"};
    private static final Item[] NETHERITE = {Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS};
    private static final Item[] DIAMOND = {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS};
    private static final Item[] IRON = {Items.IRON_HELMET, Items.IRON_CHESTPLATE,
            Items.IRON_LEGGINGS, Items.IRON_BOOTS};
    private static final Item[] CHAIN = {Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE,
            Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS};

    /** Как называть предметы кита: цвет и мерцающие символы по краям (или без них). */
    private static final class Look {
        final TextColor color;
        final boolean symbols;

        Look(TextColor color, boolean symbols) {
            this.color = color;
            this.symbols = symbols;
        }

        MutableText name(String title) {
            MutableText base = new LiteralText(title);
            return symbols ? NameDecor.decorate(base, color) : NameDecor.plain(base, color);
        }
    }

    private static final Look STINGER = new Look(NameDecor.LIGHT_RED, true);
    private static final Look DRAGON = new Look(TextColor.fromRgb(0xA020F0), false);   // фиолетовый
    private static final Look KRAKEN = new Look(TextColor.fromRgb(0x33CC33), false);   // зелёный, темнее Infinity
    private static final Look WITHER = new Look(TextColor.fromRgb(0xFF6A38), false);   // красно-оранжевый
    private static final Look GHAST = new Look(TextColor.fromRgb(0x66CCFF), false);    // голубой
    private static final Look MUSTANG = new Look(TextColor.fromRgb(0xFFE033), false);  // жёлтый
    private static final Look GRIEFER = new Look(TextColor.fromRgb(0xFFD6E0), false);  // очень светло-розовый

    /**
     * Предмет с зачарованиями. ench: пары (зачарование, уровень). look == null: обычное название.
     */
    private static ItemStack gear(Item item, Look look, String title, Object... ench) {
        ItemStack s = new ItemStack(item);
        for (int i = 0; i + 1 < ench.length; i += 2) {
            s.addEnchantment((Enchantment) ench[i], (Integer) ench[i + 1]);
        }
        if (look != null) {
            s.setCustomName(look.name(title));
        }
        return s;
    }

    /** Четыре части брони с одинаковыми зачарованиями. */
    private static ItemStack[] armor(Item[] pieces, Look look, String kitName, Object... ench) {
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            result[i] = gear(pieces[i], look, ARMOR_RU[i] + " " + kitName, ench);
        }
        return result;
    }

    /** Стрела с эффектом. */
    private static ItemStack tipped(Potion potion) {
        return PotionUtil.setPotion(new ItemStack(Items.TIPPED_ARROW), potion);
    }

    /** Обычное (пьяное) зелье. */
    private static ItemStack drink(Potion potion) {
        return PotionUtil.setPotion(new ItemStack(Items.POTION), potion);
    }

    /** Один полный стак предмета. */
    private static void addStack(List<ItemStack> kit, Item item) {
        add(kit, new ItemStack(item), item.getMaxCount());
    }

    /** Добавляет total штук, раскладывая по стакам. */
    private static void add(List<ItemStack> kit, ItemStack template, int total) {
        int max = Math.max(1, template.getMaxCount());
        int left = total;
        while (left > 0) {
            ItemStack part = template.copy();
            part.setCount(Math.min(max, left));
            kit.add(part);
            left -= part.getCount();
        }
    }

    private static void give(ServerPlayerEntity player, String name, List<ItemStack> kit) {
        int free = 0;
        for (ItemStack stack : player.inventory.main) {
            if (stack.isEmpty()) {
                free++;
            }
        }
        if (free < kit.size()) {
            player.sendMessage(new LiteralText("Нет места в инвентаре: для набора нужно " + kit.size()
                    + " свободных слотов, свободно " + free + ".").formatted(Formatting.RED), false);
            return;
        }
        for (ItemStack stack : kit) {
            player.inventory.insertStack(stack);
        }
        player.sendMessage(new LiteralText("Набор " + name + " выдан.").formatted(Formatting.GREEN), false);
    }
}
