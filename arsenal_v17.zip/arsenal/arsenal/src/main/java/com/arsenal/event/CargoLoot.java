package com.arsenal.event;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Лут грузов: config/arsenal_cargo.json (создаётся сам из настроек по умолчанию). */
public final class CargoLoot {
    private static final Random RNG = new Random();
    private static JsonObject root;

    private CargoLoot() {
    }

    public static void load() {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("arsenal_cargo.json");
            if (!Files.exists(file)) {
                try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json")) {
                    Files.copy(in, file);
                }
            }
            root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_cargo.json: " + ex);
            root = null;
        }
    }

    public static float blastPower(float fallback) {
        if (root != null && root.has("explosiveBlastPower")) {
            return root.get("explosiveBlastPower").getAsFloat();
        }
        return fallback;
    }

    /** Лут для 4 шалкеров груза данного вида ("peace" или "explosive"). */
    public static List<List<ItemStack>> roll(String table, int shulkers) {
        List<List<ItemStack>> result = new ArrayList<>();
        for (int i = 0; i < shulkers; i++) {
            result.add(new ArrayList<>());
        }
        if (root == null) {
            load();
        }
        if (root == null || !root.has("loot") || !root.getAsJsonObject("loot").has(table)) {
            return result;
        }
        JsonObject t = root.getAsJsonObject("loot").getAsJsonObject(table);
        JsonArray entries = t.getAsJsonArray("entries");
        int rollsMin = 4;
        int rollsMax = 6;
        if (t.has("rolls")) {
            JsonArray r = t.getAsJsonArray("rolls");
            rollsMin = r.get(0).getAsInt();
            rollsMax = r.get(1).getAsInt();
        }
        Map<Integer, Integer> used = new HashMap<>();
        for (int s = 0; s < shulkers; s++) {
            int rolls = rollsMin + RNG.nextInt(Math.max(1, rollsMax - rollsMin + 1));
            for (int i = 0; i < rolls; i++) {
                for (int attempt = 0; attempt < 12; attempt++) {
                    int index = pick(entries);
                    if (index < 0) {
                        break;
                    }
                    JsonObject e = entries.get(index).getAsJsonObject();
                    int limit = e.has("limit") ? e.get("limit").getAsInt() : 0;
                    int u = used.getOrDefault(index, 0);
                    if (limit > 0 && u >= limit) {
                        continue;
                    }
                    ItemStack stack = make(e);
                    if (stack == null || stack.isEmpty()) {
                        continue;
                    }
                    used.put(index, u + 1);
                    result.get(s).add(stack);
                    break;
                }
            }
        }
        return result;
    }

    private static int pick(JsonArray entries) {
        int total = 0;
        for (JsonElement el : entries) {
            JsonObject e = el.getAsJsonObject();
            total += Math.max(0, e.has("weight") ? e.get("weight").getAsInt() : 10);
        }
        if (total <= 0) {
            return -1;
        }
        int r = RNG.nextInt(total);
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            r -= Math.max(0, e.has("weight") ? e.get("weight").getAsInt() : 10);
            if (r < 0) {
                return i;
            }
        }
        return -1;
    }

    private static ItemStack make(JsonObject e) {
        Item item = Registry.ITEM.getOrEmpty(new Identifier(e.get("item").getAsString())).orElse(null);
        if (item == null) {
            return null;
        }
        if (e.has("enchantment")) {
            Enchantment ench = Registry.ENCHANTMENT.getOrEmpty(new Identifier(e.get("enchantment").getAsString())).orElse(null);
            if (ench == null) {
                return null;
            }
            JsonArray levels = e.getAsJsonArray("levels");
            int level = levels.get(RNG.nextInt(levels.size())).getAsInt();
            return EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ench, level));
        }
        int min = e.has("min") ? e.get("min").getAsInt() : 1;
        int max = e.has("max") ? e.get("max").getAsInt() : min;
        int count = min + RNG.nextInt(Math.max(1, max - min + 1));
        ItemStack stack = new ItemStack(item, Math.max(1, Math.min(count, item.getMaxCount())));
        if (e.has("potion")) {
            Potion potion = Registry.POTION.getOrEmpty(new Identifier(e.get("potion").getAsString())).orElse(null);
            if (potion != null) {
                PotionUtil.setPotion(stack, potion);
            }
        }
        return stack;
    }

    /** Раскладывает предметы по слотам шалкера в случайном порядке. */
    public static void fill(net.minecraft.inventory.Inventory inv, List<ItemStack> stacks) {
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inv.size(); i++) {
            slots.add(i);
        }
        Collections.shuffle(slots, RNG);
        for (int i = 0; i < stacks.size() && i < slots.size(); i++) {
            inv.setStack(slots.get(i), stacks.get(i));
        }
    }
}
