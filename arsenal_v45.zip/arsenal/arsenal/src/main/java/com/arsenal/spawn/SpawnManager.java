package com.arsenal.spawn;

import com.arsenal.tp.TeleportManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.HorseBaseEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Box;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Спавн сервера: закрытый зал со стеклянной крышей далеко от обычного мира (он строится сам при первом
 * использовании). Сюда ведёт /spawn (с ожиданием 3 секунды, как любая телепортация) и сюда возрождаются
 * после смерти те, у кого нет кровати. В зале все ходят со своими вещами.
 *
 * В зале есть яма с порталом Края: прыгаешь в неё и попадаешь на обычный /rtp. Рядом табличка.
 * Эта же яма доступна по /warp rtp. Ломать и строить в зале нельзя (см. SpawnProtection).
 * Телепортация в обычный мир возможна любой командой телепорта или через яму.
 */
public final class SpawnManager {
    public static final int CX = -29_000_000;
    public static final int CZ = 29_000_000;
    public static final int FLOOR_Y = 100;
    /** Радиус зала: 29 на 29 блоков. */
    public static final int R = 14;
    private static final int HEIGHT = 8;
    /** Смещение центра ямы от центра зала (на север). */
    private static final int PIT_DZ = -9;
    /** Сколько блоков вокруг зала тоже защищено от строительства. */
    private static final int MARGIN = 10;

    public static final double SPAWN_X = CX + 0.5;
    public static final double SPAWN_Y = FLOOR_Y + 1.0;
    public static final double SPAWN_Z = CZ + 0.5;
    public static final float SPAWN_YAW = 180.0F;

    /** Точка /warp rtp: перед ямой, лицом к ней. */
    public static final double WARP_X = CX + 0.5;
    public static final double WARP_Y = FLOOR_Y + 1.0;
    public static final double WARP_Z = CZ - 3.5;
    public static final float WARP_YAW = 180.0F;

    private static final Map<UUID, Long> LAST_PORTAL = new HashMap<>();

    private SpawnManager() {
    }

    public static void init() {
        // возрождение после смерти не у кровати: на спавн
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (alive) {
                return;
            }
            BlockPos bed = newPlayer.getSpawnPointPosition();
            if (bed != null && newPlayer.squaredDistanceTo(bed.getX() + 0.5, bed.getY(), bed.getZ() + 0.5) < 100.0) {
                return;
            }
            ServerWorld overworld = newPlayer.getServer().getOverworld();
            ensureBuilt(overworld);
            newPlayer.teleport(overworld, SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_YAW, 0.0F);
            newPlayer.fallDistance = 0.0F;
        });

        // мобы на спавне не появляются и не задерживаются, вредные эффекты с игроков снимаются
        ServerTickEvents.END_SERVER_TICK.register(SpawnManager::onTick);

        // яйца призыва на спавне не работают
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!(stack.getItem() instanceof SpawnEggItem) || SpawnProtection.bypass(player)) {
                return ActionResult.PASS;
            }
            if (contains(world, hit.getBlockPos()) || contains(world, hit.getBlockPos().offset(hit.getSide()))) {
                if (!world.isClient) {
                    SpawnProtection.deny((ServerPlayerEntity) player, "На спавне нельзя призывать мобов");
                }
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    private static int tick;

    private static void onTick(MinecraftServer server) {
        tick++;
        if (tick % 10 != 0) {
            return;
        }
        ServerWorld ow = server.getOverworld();
        Box zone = new Box(CX - R - MARGIN, 0, CZ - R - MARGIN, CX + R + MARGIN, 256, CZ + R + MARGIN);
        // getEntitiesByClass не загружает чанки: если там никого нет, ничего и не происходит
        for (MobEntity mob : ow.getEntitiesByClass(MobEntity.class, zone, e -> !isPet(e))) {
            mob.remove();
        }
        for (ServerPlayerEntity p : new ArrayList<>(ow.getPlayers())) {
            if (!near(p)) {
                continue;
            }
            List<StatusEffect> bad = new ArrayList<>();
            for (StatusEffectInstance effect : p.getStatusEffects()) {
                if (effect.getEffectType().getType() == StatusEffectType.HARMFUL) {
                    bad.add(effect.getEffectType());
                }
            }
            for (StatusEffect effect : bad) {
                p.removeStatusEffect(effect);
            }
        }
    }

    /** Прирученные питомцы игроков не трогаем: иначе они бы гибли, если прибегут за хозяином. */
    private static boolean isPet(MobEntity e) {
        return (e instanceof TameableEntity && ((TameableEntity) e).isTamed())
                || (e instanceof HorseBaseEntity && ((HorseBaseEntity) e).isTame());
    }

    // ------------------------------------------------------------------ зона

    /** Зал и 10 блоков вокруг него: тут нельзя ломать и строить. */
    public static boolean contains(World world, BlockPos pos) {
        return world.getRegistryKey() == World.OVERWORLD
                && Math.abs(pos.getX() - CX) <= R + MARGIN
                && Math.abs(pos.getZ() - CZ) <= R + MARGIN;
    }

    /** Пересекается ли куб привата (сторона 2*half+1 вокруг блока) с зоной спавна. */
    public static boolean overlaps(World world, BlockPos center, int half) {
        return world.getRegistryKey() == World.OVERWORLD
                && center.getX() + half >= CX - R - MARGIN && center.getX() - half <= CX + R + MARGIN
                && center.getZ() + half >= CZ - R - MARGIN && center.getZ() - half <= CZ + R + MARGIN;
    }

    /** Рядом со спавном (для отмены урона от границы мира, спавн лежит за ней). */
    public static boolean near(Entity e) {
        return e.world.getRegistryKey() == World.OVERWORLD
                && Math.abs(e.getX() - CX) < R + 40
                && Math.abs(e.getZ() - CZ) < R + 40;
    }

    /** Игрок оказался внутри портала в яме (вызывается из EndPortalBlockMixin). */
    public static void portal(ServerPlayerEntity p) {
        long now = p.world.getTime();
        Long last = LAST_PORTAL.get(p.getUuid());
        if (last != null && now - last < 60) {
            return;
        }
        LAST_PORTAL.put(p.getUuid(), now);
        TeleportManager.portalRtp(p);
    }

    // ------------------------------------------------------------------ постройка

    public static void ensureBuilt(ServerWorld world) {
        if (world.getBlockState(new BlockPos(CX, FLOOR_Y, CZ)).getBlock() == Blocks.GOLD_BLOCK
                && world.getBlockState(new BlockPos(CX, FLOOR_Y - 2, CZ + PIT_DZ)).getBlock() == Blocks.END_PORTAL
                && world.getBlockState(new BlockPos(CX, FLOOR_Y + HEIGHT, CZ)).getBlock() == Blocks.GLASS) {
            return;
        }
        build(world);
    }

    private static void set(ServerWorld world, int x, int y, int z, Block block) {
        world.setBlockState(new BlockPos(x, y, z), block.getDefaultState());
    }

    private static boolean inPit(int dx, int dz) {
        return Math.abs(dx) <= 3 && dz >= PIT_DZ - 3 && dz <= PIT_DZ + 3;
    }

    private static Block floorBlock(int dx, int dz, int d) {
        if (d <= 1) {
            return Blocks.GOLD_BLOCK;
        }
        if (d == 2) {
            return Blocks.CHISELED_QUARTZ_BLOCK;
        }
        boolean lampX = Math.abs(dx) == 7 || dx == 0;
        boolean lampZ = Math.abs(dz) == 7 || dz == 0;
        if (lampX && lampZ && !inPit(dx, dz)) {
            return Blocks.SEA_LANTERN;
        }
        if (d >= R - 1) {
            return Blocks.POLISHED_BLACKSTONE_BRICKS;
        }
        return ((dx + dz) & 1) == 0 ? Blocks.SMOOTH_QUARTZ : Blocks.POLISHED_ANDESITE;
    }

    private static void build(ServerWorld world) {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                int x = CX + dx;
                int z = CZ + dz;
                int d = Math.max(Math.abs(dx), Math.abs(dz));
                set(world, x, FLOOR_Y, z, floorBlock(dx, dz, d));
                for (int rel = 1; rel < HEIGHT; rel++) {
                    int y = FLOOR_Y + rel;
                    if (d < R) {
                        set(world, x, y, z, Blocks.AIR);
                        continue;
                    }
                    int along = Math.abs(dx) == R ? dz : dx;
                    Block wall;
                    if (along % 7 == 0) {
                        wall = Blocks.QUARTZ_PILLAR;
                    } else if (rel <= 2 || rel >= 6) {
                        wall = Blocks.QUARTZ_BRICKS;
                    } else {
                        wall = Blocks.GLASS;
                    }
                    set(world, x, y, z, wall);
                }
                set(world, x, FLOOR_Y + HEIGHT, z, d == R ? Blocks.QUARTZ_BLOCK : Blocks.GLASS);
            }
        }
        buildPit(world);
        buildSign(world);
    }

    /** Яма 5 на 5, три блока вглубь: на дне портал Края, вокруг обсидиан. */
    private static void buildPit(ServerWorld world) {
        int pz = CZ + PIT_DZ;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int x = CX + dx;
                int z = pz + dz;
                if (Math.max(Math.abs(dx), Math.abs(dz)) == 3) {
                    set(world, x, FLOOR_Y, z, ((dx + dz) & 1) == 0 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
                    set(world, x, FLOOR_Y - 1, z, Blocks.OBSIDIAN);
                    set(world, x, FLOOR_Y - 2, z, Blocks.OBSIDIAN);
                    set(world, x, FLOOR_Y - 3, z, Blocks.OBSIDIAN);
                } else {
                    set(world, x, FLOOR_Y, z, Blocks.AIR);
                    set(world, x, FLOOR_Y - 1, z, Blocks.AIR);
                    set(world, x, FLOOR_Y - 2, z, Blocks.END_PORTAL);
                    set(world, x, FLOOR_Y - 3, z, Blocks.OBSIDIAN);
                }
            }
        }
    }

    private static String json(Text text) {
        return Text.Serializer.toJson(text);
    }

    /** Табличка перед ямой, текстом к залу. */
    private static void buildSign(ServerWorld world) {
        BlockPos pos = new BlockPos(CX, FLOOR_Y + 1, CZ - 5);
        world.setBlockState(pos, Blocks.OAK_SIGN.getDefaultState().with(Properties.ROTATION, 0));
        BlockEntity be = world.getBlockEntity(pos);
        if (be == null) {
            return;
        }
        NbtCompound tag = be.writeNbt(new NbtCompound());
        tag.putString("Text1", json(new LiteralText("[ RTP ]").formatted(Formatting.GOLD, Formatting.BOLD)));
        tag.putString("Text2", json(new LiteralText("Рандомная").formatted(Formatting.DARK_PURPLE, Formatting.BOLD)));
        tag.putString("Text3", json(new LiteralText("телепортация").formatted(Formatting.DARK_PURPLE)));
        tag.putString("Text4", json(new LiteralText("прыгай в яму").formatted(Formatting.DARK_GRAY)));
        tag.putString("Color", "black");
        BlockState state = world.getBlockState(pos);
        be.fromTag(state, tag);
        be.markDirty();
        world.updateListeners(pos, state, state, 3);
    }
}
