package com.arsenal.castle;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;
import java.util.zip.GZIPInputStream;

/**
 * Один раз при создании мира ставит замок по центру на 0,0, выравнивает под него основание
 * и переносит туда спавн. Данные замка лежат в ресурсе /castle/castle.bin (сделан из zamok.schem).
 * Чтобы построить замок ещё раз, удали файл arsenal_castle_placed.txt из папки мира.
 */
public final class CastleBuilder {
    private static final String MARKER = "arsenal_castle_placed.txt";
    /** 2 = отправить клиентам, 16 = без обновления соседей (состояния блоков остаются как в схеме). */
    private static final int FLAGS = 2 | 16;

    private CastleBuilder() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(CastleBuilder::onServerStarted);
    }

    private static void onServerStarted(MinecraftServer server) {
        Path marker = server.getSavePath(WorldSavePath.ROOT).resolve(MARKER);
        if (Files.exists(marker)) {
            return;
        }
        try {
            build(server);
            Files.write(marker, "ok".getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось построить замок: " + e);
            e.printStackTrace();
        }
    }

    // ---------------- данные ----------------

    private static class Data {
        int w, h, l;
        int spawnX, spawnY, spawnZ;
        String[] palette;
        int[] runIndex;
        int[] runLength;
        int[] beX, beY, beZ;
        String[] beState;
    }

    private static Data load() throws IOException {
        InputStream resource = CastleBuilder.class.getResourceAsStream("/castle/castle.bin");
        if (resource == null) {
            throw new IOException("нет файла castle.bin в моде");
        }
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(resource)))) {
            byte[] magic = new byte[4];
            in.readFully(magic);
            if (!"ARSC".equals(new String(magic, StandardCharsets.US_ASCII))) {
                throw new IOException("неверный формат castle.bin");
            }
            Data d = new Data();
            d.w = in.readInt();
            d.h = in.readInt();
            d.l = in.readInt();
            d.spawnX = in.readInt();
            d.spawnY = in.readInt();
            d.spawnZ = in.readInt();
            d.palette = new String[in.readInt()];
            for (int i = 0; i < d.palette.length; i++) {
                d.palette[i] = readString(in);
            }
            int runs = in.readInt();
            d.runIndex = new int[runs];
            d.runLength = new int[runs];
            for (int i = 0; i < runs; i++) {
                d.runIndex[i] = readVarInt(in);
                d.runLength[i] = readVarInt(in);
            }
            int entities = in.readInt();
            d.beX = new int[entities];
            d.beY = new int[entities];
            d.beZ = new int[entities];
            d.beState = new String[entities];
            for (int i = 0; i < entities; i++) {
                d.beX[i] = in.readInt();
                d.beY[i] = in.readInt();
                d.beZ[i] = in.readInt();
                d.beState[i] = readString(in);
            }
            return d;
        }
    }

    private static String readString(DataInputStream in) throws IOException {
        byte[] bytes = new byte[in.readInt()];
        in.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int value = 0;
        int shift = 0;
        while (true) {
            int b = in.readUnsignedByte();
            value |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) {
                return value;
            }
            shift += 7;
        }
    }

    // ---------------- блоки ----------------

    private static BlockState parseState(String text) {
        String name = text;
        String props = null;
        int bracket = text.indexOf('[');
        if (bracket >= 0) {
            name = text.substring(0, bracket);
            props = text.substring(bracket + 1, text.length() - 1);
        }
        Block block = Registry.BLOCK.get(new Identifier(name));
        BlockState state = block.getDefaultState();
        if (props != null && !props.isEmpty()) {
            for (String pair : props.split(",")) {
                int eq = pair.indexOf('=');
                if (eq < 0) {
                    continue;
                }
                Property<?> property = block.getStateManager().getProperty(pair.substring(0, eq));
                if (property != null) {
                    state = withProperty(state, property, pair.substring(eq + 1));
                }
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withProperty(BlockState state, Property<T> property, String value) {
        Optional<T> parsed = property.parse(value);
        return parsed.isPresent() ? state.with(property, parsed.get()) : state;
    }

    // ---------------- постройка ----------------

    private static void build(MinecraftServer server) throws IOException {
        Data d = load();
        ServerWorld world = server.getOverworld();
        int minX = CastleConstants.MIN_X;
        int minZ = CastleConstants.MIN_Z;

        // подгружаем (и при необходимости генерируем) все чанки под замком
        for (int cx = minX >> 4; cx <= (minX + d.w - 1) >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= (minZ + d.l - 1) >> 4; cz++) {
                world.getChunk(cx, cz);
            }
        }

        // высота земли: медиана по сетке точек (деревья не считаем)
        int[] heights = new int[9];
        int n = 0;
        for (int gx = 0; gx < 3; gx++) {
            for (int gz = 0; gz < 3; gz++) {
                int x = minX + 10 + gx * (d.w - 21) / 2;
                int z = minZ + 10 + gz * (d.l - 21) / 2;
                heights[n++] = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            }
        }
        Arrays.sort(heights);
        int groundTop = heights[4] - 1; // верхний блок земли
        int baseY = groundTop - CastleConstants.SURFACE_LAYER;
        baseY = Math.max(5, Math.min(baseY, 256 - d.h));

        // блоки схемы (воздух тоже ставится, поэтому всё лишнее в объёме замка сносится)
        BlockState[] states = new BlockState[d.palette.length];
        for (int i = 0; i < states.length; i++) {
            states[i] = parseState(d.palette[i]);
        }
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int index = 0;
        int layer = d.l * d.w;
        for (int r = 0; r < d.runIndex.length; r++) {
            BlockState state = states[d.runIndex[r]];
            for (int k = 0; k < d.runLength[r]; k++) {
                int y = index / layer;
                int rest = index % layer;
                int z = rest / d.w;
                int x = rest % d.w;
                pos.set(minX + x, baseY + y, minZ + z);
                world.setBlockState(pos, state, FLAGS);
                index++;
            }
        }

        // основание: если под замком пустота, вода или лава, заполняем камнем
        BlockState stone = Blocks.STONE.getDefaultState();
        for (int x = 0; x < d.w; x++) {
            for (int z = 0; z < d.l; z++) {
                for (int y = baseY - 1; y >= Math.max(1, baseY - 40); y--) {
                    pos.set(minX + x, y, minZ + z);
                    BlockState current = world.getBlockState(pos);
                    if (current.isAir() || !current.getFluidState().isEmpty() || current.getMaterial().isReplaceable()) {
                        world.setBlockState(pos, stone, FLAGS);
                    } else {
                        break;
                    }
                }
            }
        }

        // бочки, воронки, таблички, костры и т.п. (с содержимым) ставим командой setblock
        ServerCommandSource source = server.getCommandSource().withSilent();
        for (int i = 0; i < d.beState.length; i++) {
            String command = "setblock " + (minX + d.beX[i]) + " " + (baseY + d.beY[i]) + " " + (minZ + d.beZ[i])
                    + " " + d.beState[i] + " replace";
            server.getCommandManager().execute(source, command);
        }

        // спавн на открытой площадке у замка, точно в этой точке
        BlockPos spawn = new BlockPos(minX + d.spawnX, baseY + d.spawnY, minZ + d.spawnZ);
        world.setSpawnPos(spawn, 0.0F);
        server.getGameRules().get(GameRules.SPAWN_RADIUS).set(0, server);

        System.out.println("[Arsenal] Замок построен: основание на высоте " + baseY + ", спавн " + spawn.getX() + " "
                + spawn.getY() + " " + spawn.getZ());
    }
}
