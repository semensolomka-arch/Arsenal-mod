package com.arsenal.mixin;

import com.arsenal.Abilities;
import com.arsenal.Arsenal;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехватывает Q и F ДО ванильной обработки.
 * Если в руке оружие и в инвентаре есть нужный предмет, нажатие "съедается"
 * (оружие не выбрасывается, руки не меняются) и серверу уходит пакет.
 * Если предмета нет, всё работает как в ванили.
 */
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void arsenal$handleKeys(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient) (Object) this;
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.currentScreen != null || player.isSpectator()) {
            return;
        }

        // Q (выброс) -> стан
        if (Abilities.holdsWeaponAndHas(player, Arsenal.STUN)) {
            boolean pressed = false;
            while (mc.options.keyDrop.wasPressed()) {
                pressed = true;
            }
            if (pressed && Abilities.canUse(player, Arsenal.STUN)) {
                ClientPlayNetworking.send(Arsenal.USE_STUN, PacketByteBufs.empty());
            }
        }

        // F (смена рук) -> ком снега
        if (Abilities.holdsWeaponAndHas(player, Arsenal.SNOW_BALL)) {
            boolean pressed = false;
            while (mc.options.keySwapHands.wasPressed()) {
                pressed = true;
            }
            if (pressed && Abilities.canUse(player, Arsenal.SNOW_BALL)) {
                ClientPlayNetworking.send(Arsenal.USE_SNOW, PacketByteBufs.empty());
            }
        }
    }
}
