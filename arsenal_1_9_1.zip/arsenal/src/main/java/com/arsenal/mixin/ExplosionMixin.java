package com.arsenal.mixin;

import com.arsenal.protection.SpawnProtection;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Взрывы не разрушают блоки в зоне замка. */
@Mixin(Explosion.class)
public abstract class ExplosionMixin {
    @Shadow
    @Final
    private World world;

    @Inject(method = "affectWorld", at = @At("HEAD"))
    private void arsenal$protectSpawn(boolean particles, CallbackInfo ci) {
        ((Explosion) (Object) this).getAffectedBlocks().removeIf(pos -> SpawnProtection.contains(world, pos));
    }
}
