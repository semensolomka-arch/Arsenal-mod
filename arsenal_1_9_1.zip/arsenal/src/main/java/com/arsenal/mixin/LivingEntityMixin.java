package com.arsenal.mixin;

import com.arsenal.Arsenal;
import com.arsenal.WeaponEffects;
import com.arsenal.enchantment.ImpenetrableEnchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * "Непробиваемый": после того как посчитаны броня и зачарования защиты,
 * с шансом (20% за каждую часть брони) срезаем ещё 20% урона. Бросок один на удар.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** Урон, с которым пришёл последний удар (до брони), нужен Разрушителю. */
    @Unique
    private float arsenal$rawDamage;

    @Inject(method = "damage", at = @At("HEAD"))
    private void arsenal$rememberDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        arsenal$rawDamage = amount;
    }

    // Убираем отдачу (отбрасывание), если атака была произведена мечом Цербера, Инфинити, Eternity или Stinger
    @Inject(method = "takeKnockback", at = @At("HEAD"), cancellable = true)
    private void arsenal$noKnockback(float strength, double x, double z, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        LivingEntity attacker = self.getAttacker();
        if (attacker != null) {
            ItemStack mainHand = attacker.getMainHandStack();
            if (!mainHand.isEmpty() && (mainHand.getItem() == Arsenal.CERBERUS_SWORD || mainHand.getItem() == Arsenal.INFINITY_SWORD
                    || mainHand.getItem() == Arsenal.ETERNITY_SWORD || mainHand.getItem() == Arsenal.STINGER_SWORD)) {
                ci.cancel();
            }
        }
    }

    // Два имени, потому что в разных сборках маппингов этот метод называется по-разному.
    @Inject(method = {"modifyAppliedDamage", "applyEnchantmentsToDamage"}, at = @At("RETURN"), cancellable = true)
    private void arsenal$damage(DamageSource source, float amount, CallbackInfoReturnable<Float> cir) {
        float result = cir.getReturnValue();
        if (result <= 0.0F || source.isUnblockable()) {
            return;
        }

        LivingEntity self = (LivingEntity) (Object) this;

        // "Непробиваемый"
        int levels = 0;
        for (ItemStack stack : self.getArmorItems()) {
            levels += EnchantmentHelper.getLevel(Arsenal.IMPENETRABLE, stack);
        }
        if (levels > 0) {
            float chance = Math.min(1.0F, levels * ImpenetrableEnchantment.CHANCE_PER_LEVEL);
            if (self.world.random.nextFloat() < chance) {
                result *= 1.0F - ImpenetrableEnchantment.DAMAGE_REDUCTION;
            }
        }

        // "Критический" и "Разрушитель" (меч и топор в руке атакующего)
        ItemStack weapon = WeaponEffects.meleeWeapon(source);
        if (!weapon.isEmpty()) {
            result = WeaponEffects.applyCritical(self, weapon, result, self.world.random);
            WeaponEffects.applyDestroyer(self, weapon, arsenal$rawDamage, self.world.random);
        }

        cir.setReturnValue(result);
    }

    /**
     * Талисман в любой руке (правой или левой) спасает от смерти как тотем бессмертия (и пропадает).
     * Эффекты сфер и талисманов при этом даются только из левой руки (см. SphereEffects).
     * Срабатывает, только если ванильный тотем не сработал.
     */
    @Inject(method = "tryUseTotem", at = @At("RETURN"), cancellable = true)
    private void arsenal$talisman(DamageSource source, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() || source.isOutOfWorld()) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof PlayerEntity)) {
            return;
        }
        ItemStack talisman = ItemStack.EMPTY;
        for (Hand hand : Hand.values()) {
            ItemStack stack = self.getStackInHand(hand);
            if (Arsenal.isTalisman(stack.getItem())) {
                talisman = stack;
                break;
            }
        }
        if (talisman.isEmpty()) {
            return;
        }
        talisman.decrement(1);
        self.setHealth(1.0F);
        self.clearStatusEffects();
        self.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 900, 1));
        self.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 100, 1));
        self.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 800, 0));
        self.world.sendEntityStatus(self, (byte) 35); // анимация тотема
        cir.setReturnValue(true);
    }
}
