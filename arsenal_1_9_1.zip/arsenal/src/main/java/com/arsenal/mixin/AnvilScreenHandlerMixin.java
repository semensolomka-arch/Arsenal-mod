package com.arsenal.mixin;

import com.arsenal.artifact.ArtifactAnvil;
import com.arsenal.sphere.SphereAnvil;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.Property;
import net.minecraft.screen.ScreenHandler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Подставляет свой результат в наковальню:
 *  - сферы: сфера + сфера (50/60 ур.) и сфера + тотем = талисман (60 ур.), см. SphereAnvil;
 *  - Артефакт + предмет-эффект Хранителя опыта (10 ур.), см. ArtifactAnvil.
 */
@Mixin(AnvilScreenHandler.class)
public abstract class AnvilScreenHandlerMixin {
    @Shadow
    @Final
    private Property levelCost;

    @Shadow
    private int repairItemUsage;

    @Inject(method = "updateResult", at = @At("RETURN"))
    private void arsenal$customRecipes(CallbackInfo ci) {
        ScreenHandler self = (ScreenHandler) (Object) this;
        ItemStack left = self.getSlot(0).getStack();
        ItemStack right = self.getSlot(1).getStack();
        if (left.isEmpty() || right.isEmpty()) {
            return;
        }

        ItemStack output = null;
        int cost = 0;

        SphereAnvil.Result sphere = SphereAnvil.compute(left, right);
        if (sphere != null) {
            output = sphere.stack;
            cost = sphere.cost;
        } else {
            ArtifactAnvil.Result artifact = ArtifactAnvil.compute(left, right);
            if (artifact != null) {
                output = artifact.stack;
                cost = artifact.cost;
            }
        }
        if (output == null) {
            return;
        }

        self.getSlot(2).setStack(output);
        levelCost.set(cost);
        repairItemUsage = 0;
    }
}
