package com.arsenal;

import com.arsenal.artifact.ArtifactEffect;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;

/** Uses Minecraft's own potion bottle and overlay textures, tinted like vanilla potions. */
public class ArsenalClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Vanilla potion overlay colors: swiftness blue, strength red.
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0x7CAFC6 : -1,
                Arsenal.SPEED_III_6M, Arsenal.SPEED_III_3M);
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0x932423 : -1,
                Arsenal.STRENGTH_III_6M, Arsenal.STRENGTH_III_3M);
        // Справедливость: как ванильное зелье исцеления
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0xF82423 : -1,
                ArtifactEffect.JUSTICE.item);
    }
}
