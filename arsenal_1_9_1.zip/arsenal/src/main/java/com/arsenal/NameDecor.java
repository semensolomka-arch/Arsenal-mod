package com.arsenal;

import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

/**
 * Оформление названий особых предметов (Stinger / Eternity / Infinity / Цербер):
 * постоянно меняющийся символ в начале, название цветом, такой же символ в конце.
 * Пример: [символ]Меч Цербера[символ] (без пробелов).
 */
public final class NameDecor {
    /** Сколько "мерцающих" символов с каждой стороны. */
    private static final String SYMBOL = "A";

    public static final TextColor LIGHT_RED = TextColor.fromFormatting(Formatting.RED);
    public static final TextColor DARK_RED = TextColor.fromFormatting(Formatting.DARK_RED);
    public static final TextColor DARK_PINK = TextColor.fromRgb(0xD81B60);
    public static final TextColor LIME = TextColor.fromFormatting(Formatting.GREEN);

    private NameDecor() {
    }

    public static MutableText decorate(MutableText base, TextColor color) {
        Style plain = Style.EMPTY.withColor(color);
        MutableText result = new LiteralText("").setStyle(Style.EMPTY.withItalic(false));
        result.append(new LiteralText(SYMBOL).setStyle(plain).formatted(Formatting.OBFUSCATED));
        result.append(base.setStyle(plain));
        result.append(new LiteralText(SYMBOL).setStyle(plain).formatted(Formatting.OBFUSCATED));
        return result;
    }
}
