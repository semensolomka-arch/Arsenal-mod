package com.arsenal;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Помнит, какие блоки (и содержимое сундуков и т.п.) были до трапки, и возвращает их по таймеру. */
public class TrapManager {
    /** 2 = отправить клиентам, 16 = без обновления соседей (чтобы факелы и т.п. не отваливались). */
    public static final int FLAGS = 2 | 16;

    private static final List<Entry> ENTRIES = new ArrayList<>();

    private static class Entry {
        final ServerWorld world;
        final BlockPos pos;
        final BlockState original;
        final BlockEntity blockEntity; // сундук/печка/табличка и т.п. вместе с содержимым, может быть null
        int ticks;

        Entry(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, int ticks) {
            this.world = world;
            this.pos = pos;
            this.original = original;
            this.blockEntity = blockEntity;
            this.ticks = ticks;
        }
    }

    public static void add(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, int ticks) {
        ENTRIES.add(new Entry(world, pos.toImmutable(), original, blockEntity, ticks));
    }

    /** Возвращает исходный блок сразу, даже если там кто-то стоит. */
    private static void restore(Entry e) {
        BlockState cur = e.world.getBlockState(e.pos);
        // возвращаем, только если там наша плита, пустота или жидкость/что-то заменяемое
        boolean ours = cur.isOf(Arsenal.TRAP_BLOCK) || cur.isAir() || cur.getMaterial().isReplaceable();
        if (!ours) {
            return;
        }
        e.world.setBlockState(e.pos, e.original, FLAGS);
        if (e.blockEntity != null) {
            // ставим обратно тот же самый блок-сущность, со всем содержимым
            e.blockEntity.cancelRemoval();
            e.world.setBlockEntity(e.pos, e.blockEntity);
            e.blockEntity.markDirty();
        }
    }

    public static void tick() {
        Iterator<Entry> it = ENTRIES.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (--e.ticks <= 0) {
                restore(e);
                it.remove();
            }
        }
    }

    /** При остановке сервера всё возвращаем сразу. */
    public static void clearAll() {
        for (Entry e : ENTRIES) {
            restore(e);
        }
        ENTRIES.clear();
    }
}
