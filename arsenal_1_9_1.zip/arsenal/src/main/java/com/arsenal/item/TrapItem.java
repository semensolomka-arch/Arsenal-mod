package com.arsenal.item;

import com.arsenal.Abilities;
import com.arsenal.GlintItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Трапка в руке: ПКМ - клетка вокруг игрока. */
public class TrapItem extends GlintItem {
    public TrapItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            Abilities.useTrap((ServerPlayerEntity) user, stack);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
