package com.arsenal.item;

import com.arsenal.Abilities;
import com.arsenal.GlintItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Ком снега в руке: ПКМ - бросок. */
public class SnowClumpItem extends GlintItem {
    public SnowClumpItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            Abilities.useSnow((ServerPlayerEntity) user, stack);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
