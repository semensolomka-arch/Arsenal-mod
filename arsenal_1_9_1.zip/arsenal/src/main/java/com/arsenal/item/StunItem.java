package com.arsenal.item;

import com.arsenal.Abilities;
import com.arsenal.GlintItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Стан в руке: ПКМ - оглушение в зоне. */
public class StunItem extends GlintItem {
    public StunItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            Abilities.useStun((ServerPlayerEntity) user, stack);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
