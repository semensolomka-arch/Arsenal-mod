package com.arsenal.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

/**
 * Непробиваемый: за каждую часть брони с этим зачарованием +20% шанс, что полученный урон уменьшится на 20%.
 * Шансы складываются по частям (3 части = 60%), бросок один. Сама логика в LivingEntityMixin.
 */
public class ImpenetrableEnchantment extends Enchantment {
    /** Шанс за один уровень на одной части брони. */
    public static final float CHANCE_PER_LEVEL = 0.20F;
    /** На сколько уменьшается урон при срабатывании. */
    public static final float DAMAGE_REDUCTION = 0.20F;

    public ImpenetrableEnchantment() {
        super(Rarity.VERY_RARE, EnchantmentTarget.ARMOR, new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET});
    }

    @Override
    public int getMaxLevel() {
        return 1; // пока только I
    }

    // Из стола зачарований, лута и торговли не выпадает: только книги из креатива/команды и наковальня
    @Override
    public boolean isTreasure() {
        return true;
    }

    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }

    @Override
    public boolean isAvailableForRandomSelection() {
        return false;
    }
}
