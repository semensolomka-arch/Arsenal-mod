package com.arsenal.special;

import com.arsenal.Abilities;
import com.arsenal.Arsenal;
import com.arsenal.StunZones;
import com.arsenal.TrapManager;
import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Три особых предмета из шалкеров:
 *  - Взрывная трапка: постройка вокруг игрока (в воздухе стеклянная клетка, на земле яма из земли и обсидиана), стан-зона, урон всем рядом, кроме активатора;
 *  - Взрывная штучка: взрыв под ногами подбрасывает на 5 блоков (на 7, если в воздухе);
 *  - Светильник Джейка: свечение игрокам рядом и тыква на голову тем, у кого нет шлема.
 * Все числа ниже можно менять.
 */
public final class Specials {
    // --- взрывная трапка ---
    public static final int TRAP_LIFETIME = Abilities.TRAP_LIFETIME;   // 15 секунд
    public static final int TRAP_COOLDOWN = Abilities.TRAP_COOLDOWN;   // общий с обычной трапкой
    public static final float TRAP_DAMAGE = 10.0F;                     // половина ХП, броня уменьшает
    public static final int TRAP_ZONE_MARGIN = 4;                      // стан-зона и урон: от стен ещё на 4 блока

    // --- взрывная штучка ---
    public static final float CHARM_POWER = 5.0F;                      // убивает голого игрока с 3 блоков
    public static final double CHARM_LAUNCH_GROUND = 0.91;             // подброс примерно на 5 блоков
    public static final double CHARM_LAUNCH_AIR = 1.099;               // примерно на 7 блоков
    public static final int CHARM_COOLDOWN = 20 * 60;

    // --- светильник Джейка ---
    public static final double JAKE_RADIUS = 15.0;
    public static final int JAKE_GLOW_TICKS = 20 * 10;
    public static final int JAKE_PUMPKIN_TICKS = 20 * 15;
    public static final int JAKE_COOLDOWN = 20 * 30;
    private static final String JAKE_TAG = "ArsenalJakeUntil";

    private Specials() {
    }

    public static void init() {
        // блоки взрывной трапки не ломаются, пока она стоит
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !(TrapManager.isProtected(pos) && !player.isCreative()));
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) ->
                TrapManager.isProtected(pos) && !player.isCreative() ? ActionResult.FAIL : ActionResult.PASS);

        // раз в секунду: у тыквы Джейка через 15 секунд пропадает несъёмность (сама тыква остаётся)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) {
                return;
            }
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                ItemStack head = p.getEquippedStack(EquipmentSlot.HEAD);
                if (head.isEmpty() || !head.hasTag() || !head.getTag().contains(JAKE_TAG)) {
                    continue;
                }
                if (p.world.getTime() >= head.getTag().getLong(JAKE_TAG)) {
                    EnchantmentHelper.set(new LinkedHashMap<>(), head);
                    head.getTag().remove(JAKE_TAG);
                }
            }
        });
    }

    // =====================================================================
    // Взрывная трапка
    // =====================================================================

    public static boolean useExplosiveTrap(ServerPlayerEntity p, ItemStack source) {
        ServerWorld world = p.getServerWorld();
        BlockPos c = p.getBlockPos();
        if (SpawnProtection.contains(world, c) && !SpawnProtection.bypass(p)) {
            SpawnProtection.deny(p, "В зоне замка нельзя ставить трапки");
            return false;
        }
        // в воздухе: стеклянная клетка, на земле: яма из земли и обсидиана
        TrapShapes.Shape shape = p.isOnGround() ? TrapShapes.GROUND : TrapShapes.AIR;
        shape.build(world, c);

        // стан-зона: сама постройка и 4 блока от неё; по тем же границам взрыв бьёт всех, кроме активатора
        Box zone = shape.bounds(c).expand(TRAP_ZONE_MARGIN);
        StunZones.add(world, zone, TRAP_LIFETIME);

        List<LivingEntity> victims = world.getEntitiesByClass(LivingEntity.class, zone,
                e -> e != p && e.isAlive() && !e.isSpectator() && !(e instanceof ArmorStandEntity));
        for (LivingEntity e : victims) {
            e.damage(DamageSource.explosion((LivingEntity) p), TRAP_DAMAGE);
        }

        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.getX() + 0.5, c.getY() + 1.0, c.getZ() + 0.5, 1, 0, 0, 0, 0);
        world.playSound(null, c, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 4.0F, 0.8F);

        p.getItemCooldownManager().set(Arsenal.TRAP, TRAP_COOLDOWN);
        p.getItemCooldownManager().set(Arsenal.EXPLOSIVE_TRAP, TRAP_COOLDOWN);
        if (!p.isCreative()) {
            source.decrement(1);
        }
        return true;
    }

    // =====================================================================
    // Взрывная штучка
    // =====================================================================

    public static boolean useBlastCharm(ServerPlayerEntity p, ItemStack source) {
        ServerWorld world = p.getServerWorld();
        boolean airborne = !p.isOnGround();
        // взрыв бьёт всех рядом, включая активатора; блоки не ломает
        world.createExplosion(null, p.getX(), p.getY() + 0.1, p.getZ(), CHARM_POWER, Explosion.DestructionType.NONE);
        if (p.isAlive()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, airborne ? CHARM_LAUNCH_AIR : CHARM_LAUNCH_GROUND, v.z);
            p.velocityModified = true;
        }
        p.getItemCooldownManager().set(Arsenal.BLAST_CHARM, CHARM_COOLDOWN);
        if (!p.isCreative()) {
            source.decrement(1);
        }
        return true;
    }

    // =====================================================================
    // Светильник Джейка
    // =====================================================================

    public static boolean useJakeLantern(ServerPlayerEntity p, ItemStack source) {
        ServerWorld world = p.getServerWorld();
        List<PlayerEntity> targets = world.getEntitiesByClass(PlayerEntity.class, p.getBoundingBox().expand(JAKE_RADIUS),
                e -> e != p && !e.isSpectator() && e.squaredDistanceTo(p) <= JAKE_RADIUS * JAKE_RADIUS);
        for (PlayerEntity t : targets) {
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, JAKE_GLOW_TICKS, 0));
            if (t.getEquippedStack(EquipmentSlot.HEAD).isEmpty()) {
                ItemStack pumpkin = new ItemStack(Items.CARVED_PUMPKIN);
                pumpkin.addEnchantment(Enchantments.BINDING_CURSE, 1);
                pumpkin.getOrCreateTag().putLong(JAKE_TAG, world.getTime() + JAKE_PUMPKIN_TICKS);
                t.equipStack(EquipmentSlot.HEAD, pumpkin);
            }
        }
        world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0F, 1.5F);
        p.getItemCooldownManager().set(Arsenal.JAKE_LANTERN, JAKE_COOLDOWN);
        if (!p.isCreative()) {
            source.decrement(1);
        }
        return true;
    }
}
