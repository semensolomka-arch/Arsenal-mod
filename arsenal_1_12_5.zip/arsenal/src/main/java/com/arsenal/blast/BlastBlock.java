package com.arsenal.blast;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

/** Блок взрывчатки: поджигается как TNT (огниво, огненный шар, редстоун, горящая стрела, соседний взрыв). */
public class BlastBlock extends Block {
    public final BlastKind kind;

    public BlastBlock(Settings settings, BlastKind kind) {
        super(settings);
        this.kind = kind;
    }

    /** Зажигает взрывчатку на месте блока (сам блок убирает вызывающий). chain: короткий запал от соседнего взрыва. */
    public void prime(World world, BlockPos pos, LivingEntity igniter, boolean chain) {
        if (world.isClient) {
            return;
        }
        BlastEntity entity = new BlastEntity(world, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, igniter, kind);
        if (chain) {
            int fuse = kind.fuseTicks;
            entity.setFuse(world.random.nextInt(Math.max(1, fuse / 4)) + fuse / 8);
        }
        world.spawnEntity(entity);
        world.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
    }

    @Override
    public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        if (!oldState.isOf(state.getBlock()) && world.isReceivingRedstonePower(pos)) {
            prime(world, pos, null, false);
            world.removeBlock(pos, false);
        }
    }

    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        if (world.isReceivingRedstonePower(pos)) {
            prime(world, pos, null, false);
            world.removeBlock(pos, false);
        }
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack stack = player.getStackInHand(hand);
        boolean flint = stack.isOf(Items.FLINT_AND_STEEL);
        if (!flint && !stack.isOf(Items.FIRE_CHARGE)) {
            return super.onUse(state, world, pos, player, hand, hit);
        }
        prime(world, pos, player, false);
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), 11);
        if (!player.isCreative()) {
            if (flint) {
                stack.damage(1, player, p -> p.sendToolBreakStatus(hand));
            } else {
                stack.decrement(1);
            }
        }
        return ActionResult.success(world.isClient);
    }

    @Override
    public void onProjectileHit(World world, BlockState state, BlockHitResult hit, ProjectileEntity projectile) {
        if (!world.isClient && projectile.isOnFire()) {
            Entity owner = projectile.getOwner();
            BlockPos pos = hit.getBlockPos();
            prime(world, pos, owner instanceof LivingEntity ? (LivingEntity) owner : null, false);
            world.removeBlock(pos, false);
        }
    }

    @Override
    public void onDestroyedByExplosion(World world, BlockPos pos, Explosion explosion) {
        prime(world, pos, explosion == null ? null : explosion.getCausingEntity(), true);
    }

    @Override
    public boolean shouldDropItemsOnExplosion(Explosion explosion) {
        return false;
    }
}
