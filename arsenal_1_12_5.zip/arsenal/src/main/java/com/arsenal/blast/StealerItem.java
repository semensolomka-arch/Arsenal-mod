package com.arsenal.blast;

import com.arsenal.Lore;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

/**
 * Стиллер: ПКМ по спавнеру забирает его. Урона не наносит.
 * Шанс сохранить моба (50% у обычного, 75% у надёжного). Если моб не сохранился, выпадает спавнер свиньи.
 * Тратится при использовании (в творческом нет).
 */
public class StealerItem extends Item {
    private final double chance;
    private final int nameColor;
    private final String key;

    public StealerItem(Settings settings, double chance, int nameColor, String key) {
        super(settings);
        this.chance = chance;
        this.nameColor = nameColor;
        this.key = key;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        BlockState state = world.getBlockState(pos);
        if (!state.isOf(Blocks.SPAWNER)) {
            return ActionResult.PASS;
        }
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        PlayerEntity player = context.getPlayer();
        if (SpawnProtection.contains(world, pos) && (player == null || !SpawnProtection.bypass(player))) {
            if (player instanceof ServerPlayerEntity) {
                SpawnProtection.deny((ServerPlayerEntity) player, "В зоне замка нельзя забирать спавнеры");
            }
            return ActionResult.FAIL;
        }
        BlockEntity be = world.getBlockEntity(pos);
        if (!(be instanceof MobSpawnerBlockEntity)) {
            return ActionResult.PASS;
        }

        // забранный спавнер: с мобом (шанс) или обычный спавнер свиньи (в ванили спавнер без данных = свинья)
        ItemStack spawner = new ItemStack(Items.SPAWNER);
        boolean kept = world.random.nextDouble() < chance;
        if (kept) {
            NbtCompound tag = be.toTag(new NbtCompound());
            tag.remove("x");
            tag.remove("y");
            tag.remove("z");
            spawner.putSubTag("BlockEntityTag", tag);
        }

        world.removeBlock(pos, false);
        Block.dropStack(world, pos, spawner);
        world.playSound(null, pos, SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.BLOCKS, 1.0F, 0.8F);

        if (player != null) {
            if (player instanceof ServerPlayerEntity) {
                ((ServerPlayerEntity) player).sendMessage(kept
                        ? new LiteralText("Спавнер забран вместе с мобом!").formatted(Formatting.GREEN)
                        : new LiteralText("Моб не сохранился: выпал спавнер свиньи.").formatted(Formatting.YELLOW), true);
            }
            if (!player.isCreative()) {
                context.getStack().decrement(1);
            }
        }
        return ActionResult.SUCCESS;
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(this.getTranslationKey(stack))
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(nameColor)).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal." + key + ".", 6, nameColor);
    }
}
