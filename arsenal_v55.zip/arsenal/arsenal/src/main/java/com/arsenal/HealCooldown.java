package com.arsenal;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.PotionUtil;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Кулдаун на эффект Исцеления: после того как игрока вылечило (бросаемое, питьевое зелье, стрела),
 * следующие 10 секунд Исцеление на него не действует. Регенерация и яблоки не затрагиваются.
 *
 * Кулдаун показывается в панели над хотбаром (action bar): когда игрок лечится, когда лечение
 * заблокировано, и пока держит в руке зелье исцеления. Значок-кулдаун на самом предмете сделать нельзя,
 * потому что он общий для всех бросаемых зелий и блокировал бы их все.
 */
public final class HealCooldown {
    public static int TICKS = 20 * 10;

    private static final Map<UUID, Long> UNTIL = new HashMap<>();

    private HealCooldown() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(HealCooldown::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> UNTIL.clear());
    }

    /** Сбрасывает кулдаун Исцеления (например, при входе в /hub). */
    public static void reset(UUID id) {
        UNTIL.remove(id);
    }

    /** Сколько тиков осталось до конца кулдауна (0, если его нет). */
    public static int remainingTicks(LivingEntity target) {
        Long until = UNTIL.get(target.getUuid());
        if (until == null) {
            return 0;
        }
        return (int) Math.max(0, until - target.world.getTime());
    }

    /** true - лечить можно (и кулдаун запускается), false - кулдаун ещё идёт. */
    public static boolean tryHeal(LivingEntity target) {
        if (!(target instanceof PlayerEntity)) {
            return true;
        }
        long now = target.world.getTime();
        Long until = UNTIL.get(target.getUuid());
        if (until != null && now < until) {
            notify(target, "Исцеление заблокировано: кулдаун ещё " + seconds((int) (until - now)) + " с", Formatting.RED);
            return false;
        }
        if (UNTIL.size() > 256) {
            Iterator<Map.Entry<UUID, Long>> it = UNTIL.entrySet().iterator();
            while (it.hasNext()) {
                if (it.next().getValue() <= now) {
                    it.remove();
                }
            }
        }
        UNTIL.put(target.getUuid(), now + TICKS);
        notify(target, "Исцеление: кулдаун " + seconds(TICKS) + " с", Formatting.YELLOW);
        return true;
    }

    private static int seconds(int ticks) {
        return (ticks + 19) / 20;
    }

    private static void notify(LivingEntity target, String text, Formatting color) {
        if (target instanceof ServerPlayerEntity) {
            ((ServerPlayerEntity) target).sendMessage(new LiteralText(text).formatted(color), true);
        }
    }

    // Пока в руке зелье исцеления и кулдаун идёт, показываем оставшееся время
    private static void tick(MinecraftServer server) {
        if (UNTIL.isEmpty() || server.getTicks() % 5 != 0) {
            return;
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            int remaining = remainingTicks(player);
            if (remaining > 0 && holdsHealingPotion(player)) {
                player.sendMessage(new LiteralText("Исцеление: кулдаун " + seconds(remaining) + " с")
                        .formatted(Formatting.YELLOW), true);
            }
        }
    }

    private static boolean holdsHealingPotion(PlayerEntity player) {
        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getStackInHand(hand);
            Item item = stack.getItem();
            if (item == Items.POTION || item == Items.SPLASH_POTION || item == Items.LINGERING_POTION) {
                for (StatusEffectInstance effect : PotionUtil.getPotionEffects(stack)) {
                    if (effect.getEffectType() == StatusEffects.INSTANT_HEALTH) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
