package com.arsenal.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Кнопка настройки в Mod Menu: открывает главный экран настроек (лут, пресеты, общие настройки). */
public class ArsenalModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ArsenalConfigScreen::new;
    }
}
