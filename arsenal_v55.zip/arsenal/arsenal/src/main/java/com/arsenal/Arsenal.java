package com.arsenal;

import com.arsenal.artifact.ArtifactEffect;
import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.enchantment.ArtifactEffectEnchantment;
import com.arsenal.enchantment.RuneEnchantment;
import com.arsenal.enchantment.HomingEnchantment;
import com.arsenal.enchantment.ImpenetrableEnchantment;
import com.arsenal.expkeeper.ExpKeeper;
import com.arsenal.enchantment.MeleeEnchantment;
import com.arsenal.enchantment.SphereEffectEnchantment;
import com.arsenal.sphere.EffectItem;
import com.arsenal.sphere.SphereEffect;
import com.arsenal.sphere.SphereEffects;
import com.arsenal.sphere.Spheres;
import com.arsenal.item.ArtifactItem;
import com.arsenal.castle.CastleBuilder;
import com.arsenal.exp.ExpBottleItem;
import com.arsenal.exp.ExpCommand;
import com.arsenal.kit.KitCommand;
import com.arsenal.special.Specials;
import com.arsenal.special.UseItem;
import com.arsenal.tool.Filters;
import com.arsenal.shulker.ShulkerEvent;
import com.arsenal.tool.ToolEnchants;
import com.arsenal.rune.RuneType;
import com.arsenal.rune.Runes;
import com.arsenal.bind.Binds;
import com.arsenal.blast.Blasts;
import com.arsenal.protection.SpawnProtection;
import com.arsenal.item.ExpBubbleItem;
import com.arsenal.item.RuneItem;
import com.arsenal.item.KeeperItem;
import com.arsenal.item.SnowClumpItem;
import com.arsenal.item.SpecialSwordItem;
import com.arsenal.item.StunItem;
import com.arsenal.item.TrapItem;
import com.arsenal.item.ArsenalPotionItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.block.SlabBlock;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Rarity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.text.TextColor;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.registry.Registry;

public class Arsenal implements ModInitializer {
    public static final String MODID = "arsenal";

    // сетевые пакеты "клиент -> сервер" (нажатия F и Q)
    public static final Identifier USE_SNOW = new Identifier(MODID, "use_snow");
    public static final Identifier USE_STUN = new Identifier(MODID, "use_stun");

    public static Item TRAP;
    public static Item STUN;
    public static Item SNOW_BALL;
    public static Item EXP_BUBBLE;
    public static Item ARTIFACT;

    // Только четыре пользовательских зелья III уровня: скорость/сила на 6 и 3 минуты.
    public static ArsenalPotionItem SPEED_III_6M, SPEED_III_3M;
    public static ArsenalPotionItem STRENGTH_III_6M, STRENGTH_III_3M;
    public static com.arsenal.item.WinnerPotionItem WINNER_POTION;
    public static Block TRAP_BLOCK;
    public static Enchantment IMPENETRABLE;
    public static Enchantment HOMING;
    public static Enchantment CRITICAL;
    public static Enchantment DESTROYER;
    public static ItemGroup GROUP;
    /** Вкладка с вещами из китов: броня, оружие, инструменты, сферы и талисманы. */
    public static ItemGroup GEAR_GROUP;

    // Сферы и талисманы
    public static Item SPHERE_COMMON;
    public static Item SPHERE_EPIC;
    public static Item SPHERE_LEGENDARY;
    public static Item SPHERE_MYTHIC;
    public static Item SPHERE_FLASH;
    public static Item SPHERE_CERBERUS;
    public static Item SPHERE_STINGER;
    public static Item SPHERE_ETERNITY;
    public static Item TALISMAN_COMMON;
    public static Item TALISMAN;            // эпический
    public static Item TALISMAN_LEGENDARY;
    public static Item TALISMAN_STINGER;
    public static Item TALISMAN_ETERNITY;
    public static Item TALISMAN_INFINITY;
    public static Item TALISMAN_DRAGON;
    public static Item EXPLOSIVE_TRAP;
    public static Item BLAST_CHARM;
    public static Item JAKE_LANTERN;
    public static Item JAKE_PICKAXE;
    public static Item EXP_BOTTLE_15;
    public static Item EXP_BOTTLE_30;
    public static Item EXP_BOTTLE_50;

    // Мечи (только креатив)
    public static Item INFINITY_SWORD;
    public static Item CERBERUS_SWORD;
    public static Item ETERNITY_SWORD;
    public static Item STINGER_SWORD;

    @Override
    public void onInitialize() {
        // Общие настройки (цифры): config/arsenal_settings.json, применяются при запуске мира
        Settings.init();

        // Неломаемая плита для клетки (как бедрок: не ломается, не взрывается, не двигается поршнями)
        TRAP_BLOCK = Registry.register(Registry.BLOCK, new Identifier(MODID, "trap_slab"),
                new SlabBlock(AbstractBlock.Settings.of(Material.STONE).strength(-1.0F, 3600000.0F).dropsNothing()));

        // Зачарование "Непробиваемый"
        IMPENETRABLE = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "impenetrable"),
                new ImpenetrableEnchantment());

        // Зачарование "Самонаводка" (трезубец), уровни I-IV
        HOMING = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "homing"), new HomingEnchantment());

        // Неразрушимость, Опытный, Дровосек, Автоплавка, Оглушение, Бур, Магнетизм
        ToolEnchants.init();

        // Критический и Разрушитель (меч и топор). Максимум II: Разрушитель III есть только на мече Цербера
        CRITICAL = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "critical"), new MeleeEnchantment(2));
        DESTROYER = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "destroyer"), new MeleeEnchantment(2));

        // Служебные зачарования для хранения уровней эффектов сфер
        for (SphereEffect effect : SphereEffect.values()) {
            effect.enchantment = Registry.register(Registry.ENCHANTMENT,
                    new Identifier(MODID, "sphere_" + effect.id), new SphereEffectEnchantment());
        }

        // Служебные зачарования для хранения эффектов Хранителя опыта на Артефакте
        for (ArtifactEffect effect : ArtifactEffect.values()) {
            effect.enchantment = Registry.register(Registry.ENCHANTMENT,
                    new Identifier(MODID, "artifact_" + effect.id), new ArtifactEffectEnchantment());
        }

        // Служебные зачарования для рун на тотемах и талисманах
        for (RuneType rune : RuneType.values()) {
            rune.enchantment = Registry.register(Registry.ENCHANTMENT,
                    new Identifier(MODID, "rune_" + rune.id), new RuneEnchantment(rune));
        }

        // Своя вкладка в креативе: предметы мода и книги
        GROUP = FabricItemGroupBuilder.create(new Identifier(MODID, "main"))
                .icon(() -> new ItemStack(TRAP))
                .appendItems(stacks -> {
                    stacks.add(new ItemStack(TRAP));
                    stacks.add(new ItemStack(STUN));
                    stacks.add(new ItemStack(SNOW_BALL));
                    stacks.add(new ItemStack(JAKE_PICKAXE));
                    Blasts.addCreativeStacks(stacks);
                    com.arsenal.priv.Privates.addCreativeStacks(stacks);
                    stacks.add(new ItemStack(EXP_BUBBLE));
                    stacks.add(new ItemStack(ARTIFACT));
                    stacks.add(ArtifactEffects.fullArtifact());
                    for (ArtifactEffect effect : ArtifactEffect.values()) {
                        stacks.add(new ItemStack(effect.item));
                    }
                    for (RuneType rune : RuneType.values()) {
                        stacks.add(new ItemStack(rune.item));
                    }
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(IMPENETRABLE, 1)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(IMPENETRABLE, 2)));
                    for (int lvl = 1; lvl <= 4; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(HOMING, lvl)));
                    }
                    for (int lvl = 1; lvl <= 10; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.EFFICIENCY, lvl)));
                    }
                    for (int lvl = 4; lvl <= 5; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.FORTUNE, lvl)));
                    }
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.INDESTRUCTIBLE, 1)));
                    for (int lvl = 1; lvl <= 3; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.EXPERIENCED, lvl)));
                    }
                    for (int lvl = 1; lvl <= 3; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.LUMBERJACK, lvl)));
                    }
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.AUTOSMELT, 1)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.STUNNING, 1)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.DRILL, 1)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.MAGNETISM, 1)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ToolEnchants.FILTER, 1)));
                    for (int lvl = 1; lvl <= 5; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.PROTECTION, lvl)));
                    }
                    for (int lvl = 1; lvl <= 5; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.UNBREAKING, lvl)));
                    }
                    for (int lvl = 1; lvl <= 2; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(CRITICAL, lvl)));
                    }
                    for (int lvl = 1; lvl <= 2; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(DESTROYER, lvl)));
                    }
                    for (int lvl = 1; lvl <= 5; lvl++) {
                        stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.LOOTING, lvl)));
                    }
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.SHARPNESS, 7)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.SMITE, 7)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.BANE_OF_ARTHROPODS, 7)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.FIRE_PROTECTION, 5)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.BLAST_PROTECTION, 5)));
                    stacks.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(Enchantments.PROJECTILE_PROTECTION, 5)));
                    stacks.add(infinitySword());
                    stacks.add(cerberusSword());
                    stacks.add(eternitySword());
                    stacks.add(stingerSword());
                    addArmorSets(stacks);
                    Spheres.addCreativeStacks(stacks);
                    stacks.add(new ItemStack(SPEED_III_6M));
                    stacks.add(new ItemStack(SPEED_III_3M));
                    stacks.add(new ItemStack(STRENGTH_III_6M));
                    stacks.add(new ItemStack(STRENGTH_III_3M));
                    stacks.add(new ItemStack(WINNER_POTION));
                    stacks.add(com.arsenal.item.SunGear.helmet());
                    stacks.add(com.arsenal.item.SunGear.boots());
                    stacks.add(com.arsenal.item.SunGear.armorElytra());
                    stacks.add(com.arsenal.item.SunGear.unbreakableElytra());
                })
                .build();

        GEAR_GROUP = FabricItemGroupBuilder.create(new Identifier(MODID, "gear"))
                .icon(() -> new ItemStack(Items.NETHERITE_CHESTPLATE))
                .appendItems(stacks -> {
                    stacks.addAll(KitCommand.allGear());
                    Spheres.addCreativeStacks(stacks);
                })
                .build();

        TRAP = Registry.register(Registry.ITEM, new Identifier(MODID, "trap"),
                new TrapItem(new Item.Settings().group(GROUP).maxCount(64)));
        STUN = Registry.register(Registry.ITEM, new Identifier(MODID, "stun"),
                new StunItem(new Item.Settings().group(GROUP).maxCount(64)));
        SNOW_BALL = Registry.register(Registry.ITEM, new Identifier(MODID, "snow_ball"),
                new SnowClumpItem(new Item.Settings().group(GROUP).maxCount(64)));
        EXP_BUBBLE = reg("exp_bubble",
                new ExpBubbleItem(new Item.Settings().group(GROUP).maxCount(64).rarity(Rarity.UNCOMMON)));

        // Артефакт и предметы-эффекты Хранителя опыта
        ARTIFACT = reg("artifact", new ArtifactItem(new Item.Settings().group(GROUP).maxCount(1)));
        for (ArtifactEffect effect : ArtifactEffect.values()) {
            effect.item = reg("keeper_" + effect.id,
                    new KeeperItem(new Item.Settings().group(GROUP).maxCount(1), effect));
        }

        // Руны для тотемов и талисманов
        for (RuneType rune : RuneType.values()) {
            rune.item = reg("rune_" + rune.id,
                    new RuneItem(new Item.Settings().group(GROUP).maxCount(1), rune));
        }

        Item.Settings potionSettings = new Item.Settings().group(GROUP).maxCount(64);
        SPEED_III_6M = potion("speed_3_6m", false, 3, 7200, potionSettings);
        SPEED_III_3M = potion("speed_3_3m", false, 3, 3600, potionSettings);
        STRENGTH_III_6M = potion("strength_3_6m", true, 3, 7200, potionSettings);
        STRENGTH_III_3M = potion("strength_3_3m", true, 3, 3600, potionSettings);
        WINNER_POTION = (com.arsenal.item.WinnerPotionItem) reg("winner_potion",
                new com.arsenal.item.WinnerPotionItem(new Item.Settings().group(GROUP).maxCount(64)));

        // Мечи без группы: в креативе они лежат только готовыми, с чарами (см. appendItems выше)
        INFINITY_SWORD = reg("infinity_sword",
                new SpecialSwordItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof(), NameDecor.LIME));
        CERBERUS_SWORD = reg("cerberus_sword",
                new SpecialSwordItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof(), NameDecor.DARK_RED));
        ETERNITY_SWORD = reg("eternity_sword",
                new SpecialSwordItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof(), NameDecor.DARK_PINK));
        STINGER_SWORD = reg("stinger_sword",
                new SpecialSwordItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof(), NameDecor.LIGHT_RED));

        // Сферы: порядок уровней = скорость, урон, броня, скорость атаки, макс. здоровье
        SPHERE_COMMON = reg("sphere_common", new EffectItem(sphereSettings(), Formatting.GRAY, null));
        SPHERE_EPIC = reg("sphere_epic", new EffectItem(sphereSettings(), Formatting.DARK_PURPLE, null));
        SPHERE_LEGENDARY = reg("sphere_legendary", new EffectItem(sphereSettings(), Formatting.BLUE, null));
        SPHERE_MYTHIC = reg("sphere_mythic", new EffectItem(sphereSettings(), Formatting.RED, null));
        SPHERE_FLASH = reg("sphere_flash", new EffectItem(sphereSettings(), Formatting.AQUA, Spheres.v(3, 0, 1, 0, 0)));
        SPHERE_CERBERUS = reg("sphere_cerberus", new EffectItem(sphereSettings(), Formatting.DARK_GRAY, Spheres.v(0, 5, 0, 1, 0)));
        SPHERE_STINGER = reg("sphere_stinger", new EffectItem(sphereSettings(), Formatting.BLUE, Spheres.v(1, 2, 2, 0, 0), NameDecor.LIGHT_RED));
        SPHERE_ETERNITY = reg("sphere_eternity", new EffectItem(sphereSettings(), Formatting.BLUE, Spheres.v(2, 2, 2, 0, 0), NameDecor.DARK_PINK));
        TALISMAN_COMMON = reg("talisman_common", new EffectItem(sphereSettings(), Formatting.GRAY, null));
        TALISMAN = reg("talisman", new EffectItem(sphereSettings(), Formatting.DARK_PURPLE, null));
        TALISMAN_LEGENDARY = reg("talisman_legendary", new EffectItem(sphereSettings(), Formatting.BLUE, null));
        TALISMAN_STINGER = reg("talisman_stinger", new EffectItem(sphereSettings(), Formatting.BLUE, Spheres.v(1, 2, 2, 0, 0), NameDecor.LIGHT_RED));
        TALISMAN_ETERNITY = reg("talisman_eternity", new EffectItem(sphereSettings(), Formatting.BLUE, Spheres.v(2, 2, 2, 0, 0), NameDecor.DARK_PINK));
        // Талисман Dragon: +10% скорости и +1 урон из левой руки, спасает от смерти как остальные талисманы
        TALISMAN_DRAGON = reg("talisman_dragon", new EffectItem(sphereSettings(), Formatting.DARK_PURPLE,
                Spheres.v(0, 0, 0, 0, 0), null, new double[]{0.10, 1.0, 0.0, 0.0, 0.0}));
        // Предметы из шалкеров: взрывная трапка, взрывная штучка, светильник Джейка
        EXPLOSIVE_TRAP = reg("explosive_trap", new UseItem(new Item.Settings().group(GROUP).maxCount(64),
                Specials::useExplosiveTrap, false, "tooltip.arsenal.explosive_trap",
                6, 0x5F769F, 0x5F769F, 0x7E9ED2));
        BLAST_CHARM = reg("blast_charm", new UseItem(new Item.Settings().group(GROUP).maxCount(64),
                Specials::useBlastCharm, true, "tooltip.arsenal.blast_charm",
                6, 0xFF5705, 0xFF7707, 0xFF5905));
        JAKE_LANTERN = reg("jake_lantern", new UseItem(new Item.Settings().group(GROUP).maxCount(64),
                Specials::useJakeLantern, true, "tooltip.arsenal.jake_lantern",
                7, 0xFFD700, 0xD4BA08, 0xFCDD0A));

        // Золотая кирка Джейка: ломает один спавнер, сохраняя моба, и сама ломается
        JAKE_PICKAXE = reg("jake_pickaxe", new com.arsenal.blast.JakePickaxeItem(new Item.Settings().group(GROUP)));

        // Бутыльки опыта на 15, 30 и 50 уровней (ПКМ в руке)
        EXP_BOTTLE_15 = reg("exp_bottle_15", new ExpBottleItem(new Item.Settings().group(GROUP), 15, 0x55FF55));
        EXP_BOTTLE_30 = reg("exp_bottle_30", new ExpBottleItem(new Item.Settings().group(GROUP), 30, 0xFFFF55));
        EXP_BOTTLE_50 = reg("exp_bottle_50", new ExpBottleItem(new Item.Settings().group(GROUP), 50, 0xFF6A38));
        TALISMAN_INFINITY = reg("talisman_infinity", new EffectItem(sphereSettings(), Formatting.GOLD, Spheres.v(2, 2, 2, 0, 2), NameDecor.LIME));

        // Взрывчатое вещество, динамит А/Б, C4, разрывная волна, стиллеры
        Blasts.init(GROUP);
        com.arsenal.priv.Privates.init(GROUP);
        com.arsenal.priv.Privates.initEvents();
        com.arsenal.anvil.UnbreakableAnvilBlock.init(GROUP);
        com.arsenal.pvp.FireworkRule.init();

        // Запрет ломать плиты трапки (в том числе в креативе)
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) ->
                world.getBlockState(pos).isOf(TRAP_BLOCK) ? ActionResult.FAIL : ActionResult.PASS);

        // --- Бинды на ПКМ (/binds): оружие в руке, предмет лежит в инвентаре ---
        // ПКМ по блоку
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || !Binds.keyAvailable(player, Binds.Key.USE)
                    || Binds.boundTo(player, Binds.Key.USE).isEmpty()) {
                return ActionResult.PASS;
            }

            // Сначала обычное взаимодействие с блоком (сундук, дверь, кнопка...).
            // На шифте, как и в ванили, взаимодействие с блоком пропускается.
            if (!player.isSneaking()) {
                ActionResult result = world.getBlockState(hit.getBlockPos()).onUse(world, player, hand, hit);
                if (result.isAccepted()) {
                    return result;
                }
            }

            if (world.isClient) {
                // реальную работу и сообщения делает сервер; клиент только угадывает, сработает ли предмет
                return Binds.pickReady(player, Binds.Key.USE) != null ? ActionResult.SUCCESS : ActionResult.PASS;
            }
            return Binds.trigger((ServerPlayerEntity) player, Binds.Key.USE) ? ActionResult.SUCCESS : ActionResult.PASS;
        });

        // ПКМ в пустоту (или по мобу/игроку)
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack held = player.getStackInHand(hand);
            if (hand != Hand.MAIN_HAND || !Binds.keyAvailable(player, Binds.Key.USE)
                    || Binds.boundTo(player, Binds.Key.USE).isEmpty()) {
                return TypedActionResult.pass(held);
            }
            if (world.isClient) {
                return Binds.pickReady(player, Binds.Key.USE) != null
                        ? TypedActionResult.success(held)
                        : TypedActionResult.pass(held);
            }
            return Binds.trigger((ServerPlayerEntity) player, Binds.Key.USE)
                    ? TypedActionResult.success(held)
                    : TypedActionResult.pass(held);
        });

        // F и Q обрабатывает клиент (см. MinecraftClientMixin) и присылает пакет, его принимает Binds.init()
        Binds.init();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            TrapManager.tick();
            SphereEffects.tick(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> TrapManager.clearAll());

        // /expkeeper: эффекты за опыт на 24 часа
        ExpKeeper.init();
        StunZones.init();
        HealCooldown.init();
        TurtleCooldown.init();
        ArtifactEffects.init();
        Runes.init();
        KitCommand.init();
        SpawnProtection.init();
        ShulkerEvent.init();
        com.arsenal.blast.SpawnerUtil.init();
        com.arsenal.blast.JakePickaxeItem.init();
        com.arsenal.blast.IceWave.init();
        Filters.init();
        ExpCommand.init();
        Specials.init();
        com.arsenal.combat.Combat.init();
        com.arsenal.pvp.PvpManager.init();
        com.arsenal.event.EventManager.init();
        com.arsenal.tp.TeleportManager.init();
        com.arsenal.hub.HubManager.init();
        com.arsenal.spawn.SpawnManager.init();
        com.arsenal.priv.PrivateCommand.init();
        CastleBuilder.init();
    }

    /** Талисманы спасают от смерти (из правой или левой руки), как тотем бессмертия, и пропадают. */
    public static boolean isTalisman(Item item) {
        return item == TALISMAN_COMMON || item == TALISMAN || item == TALISMAN_LEGENDARY
                || item == TALISMAN_STINGER || item == TALISMAN_ETERNITY || item == TALISMAN_INFINITY
                || item == TALISMAN_DRAGON;
    }

    /** Меч Infinity: острота 8, Критический II, Разрушитель II + все топ-чары для меча. */
    public static ItemStack infinitySword() {
        ItemStack s = new ItemStack(INFINITY_SWORD);
        s.addEnchantment(Enchantments.SHARPNESS, 8);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(DESTROYER, 2);
        return topSword(s);
    }

    /** Меч Eternity: как Infinity, но острота 7 (Небесная кара 7, Бич 7, Разрушитель II, Критический II и т.д.). Без отдачи. */
    public static ItemStack eternitySword() {
        ItemStack s = new ItemStack(ETERNITY_SWORD);
        s.addEnchantment(Enchantments.SHARPNESS, 7);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(DESTROYER, 2);
        return topSword(s);
    }

    /** Меч Stinger: острота 6, Небесная кара 7, Бич 7, Критический II, без Разрушителя, Прочность 4, Добыча 5, Разящий клинок 3, Заговор огня 2, Починка. */
    public static ItemStack stingerSword() {
        ItemStack s = new ItemStack(STINGER_SWORD);
        s.addEnchantment(Enchantments.SHARPNESS, 6);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(CRITICAL, 2);
        s.addEnchantment(Enchantments.LOOTING, 5);
        s.addEnchantment(Enchantments.UNBREAKING, 4);
        s.addEnchantment(Enchantments.SWEEPING, 3);       // Разящий клинок, как на мече Dragon
        s.addEnchantment(Enchantments.FIRE_ASPECT, 2);    // Заговор огня, как на мече Dragon
        s.addEnchantment(Enchantments.MENDING, 1);        // Починка, как на мече Dragon
        return s;
    }

    /**
     * Броня Eternity (незерит): все защиты V, Прочность V, Починка, Непробиваемый на всех частях.
     * Броня Stinger (алмаз): все защиты IV, Прочность IV, Починка, Непробиваемый только на нагруднике и поножах.
     */
    private static void addArmorSets(java.util.List<ItemStack> out) {
        out.addAll(java.util.Arrays.asList(infinityArmor()));
        out.addAll(java.util.Arrays.asList(eternityArmor()));
        out.addAll(java.util.Arrays.asList(stingerArmor()));
    }

    private static final String[] ARMOR_NAMES = {"Шлем", "Нагрудник", "Поножи", "Ботинки"};

    private static Item[] netheriteArmor() {
        return new Item[]{Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS};
    }

    /** Броня Eternity (незерит): все защиты V, Прочность V, Починка, Непробиваемый на всех частях. */
    public static ItemStack[] eternityArmor() {
        Item[] items = netheriteArmor();
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            result[i] = armorPiece(items[i], ARMOR_NAMES[i] + " ETERNITY", NameDecor.DARK_PINK, 5, 5, 1);
        }
        addUtilityEnchants(result);
        return result;
    }

    // ---------------- трезубцы для китов ----------------

    /** Трезубец Stinger: Прочность III, Починка, Самонаводка II, Добыча III, Пронзатель III, Верность II. */
    public static ItemStack stingerTrident() {
        ItemStack s = new ItemStack(Items.TRIDENT);
        s.addEnchantment(Enchantments.UNBREAKING, 3);
        s.addEnchantment(Enchantments.MENDING, 1);
        s.addEnchantment(HOMING, 2);
        s.addEnchantment(Enchantments.LOOTING, 3);
        s.addEnchantment(Enchantments.IMPALING, 3);
        s.addEnchantment(Enchantments.LOYALTY, 2);
        s.setCustomName(NameDecor.decorate(new LiteralText("Трезубец STINGER"), NameDecor.LIGHT_RED));
        return s;
    }

    /** Трезубец Eternity: Прочность IV, Самонаводка III, Пронзатель IV, Добыча IV, Починка, Верность III. */
    public static ItemStack eternityTrident() {
        ItemStack s = new ItemStack(Items.TRIDENT);
        s.addEnchantment(Enchantments.UNBREAKING, 4);
        s.addEnchantment(HOMING, 3);
        s.addEnchantment(Enchantments.IMPALING, 4);
        s.addEnchantment(Enchantments.LOOTING, 4);
        s.addEnchantment(Enchantments.MENDING, 1);
        s.addEnchantment(Enchantments.LOYALTY, 3);
        s.setCustomName(NameDecor.decorate(new LiteralText("Трезубец ETERNITY"), NameDecor.DARK_PINK));
        return s;
    }

    /** Трезубец Infinity: Самонаводка IV, Добыча V, Прочность V, Починка, Пронзатель V, Верность III. */
    public static ItemStack infinityTrident() {
        ItemStack s = new ItemStack(Items.TRIDENT);
        s.addEnchantment(HOMING, 4);
        s.addEnchantment(Enchantments.LOOTING, 5);
        s.addEnchantment(Enchantments.UNBREAKING, 5);
        s.addEnchantment(Enchantments.MENDING, 1);
        s.addEnchantment(Enchantments.IMPALING, 5);
        s.addEnchantment(Enchantments.LOYALTY, 3);
        s.setCustomName(NameDecor.decorate(new LiteralText("Трезубец INFINITY"), NameDecor.LIME));
        return s;
    }

    /** Броня Infinity (незерит): как Eternity (защиты V, Прочность V, Починка), но Непробиваемый II на всех частях. */
    public static ItemStack[] infinityArmor() {
        Item[] items = netheriteArmor();
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            result[i] = armorPiece(items[i], ARMOR_NAMES[i] + " INFINITY", NameDecor.LIME, 5, 5, 2);
        }
        addUtilityEnchants(result);
        return result;
    }

    /** Броня Stinger (незерит): все защиты IV, Прочность IV, Починка, Непробиваемый на нагруднике и поножах. */
    public static ItemStack[] stingerArmor() {
        Item[] items = netheriteArmor();
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            int impenetrable = (i == 1 || i == 2) ? 1 : 0;
            result[i] = armorPiece(items[i], ARMOR_NAMES[i] + " STINGER", NameDecor.LIGHT_RED, 4, 4, impenetrable);
        }
        addUtilityEnchants(result);
        return result;
    }

    /**
     * Шлем: Подводное дыхание III + Подводник. Ботинки: Скорость души III + Подводная ходьба III + Невесомость IV
     * (максимальные ванильные уровни).
     */
    private static void addUtilityEnchants(ItemStack[] armor) {
        armor[0].addEnchantment(Enchantments.RESPIRATION, 3);
        armor[0].addEnchantment(Enchantments.AQUA_AFFINITY, 1);
        armor[3].addEnchantment(Enchantments.SOUL_SPEED, 3);
        armor[3].addEnchantment(Enchantments.DEPTH_STRIDER, 3);
        armor[3].addEnchantment(Enchantments.FEATHER_FALLING, 4);
    }

    private static ItemStack armorPiece(Item item, String name, TextColor color, int protection, int unbreaking,
                                        int impenetrable) {
        ItemStack s = new ItemStack(item);
        s.addEnchantment(Enchantments.PROTECTION, protection);
        s.addEnchantment(Enchantments.FIRE_PROTECTION, protection);
        s.addEnchantment(Enchantments.BLAST_PROTECTION, protection);
        s.addEnchantment(Enchantments.PROJECTILE_PROTECTION, protection);
        s.addEnchantment(Enchantments.UNBREAKING, unbreaking);
        s.addEnchantment(Enchantments.MENDING, 1);
        if (impenetrable > 0) {
            s.addEnchantment(IMPENETRABLE, impenetrable);
        }
        s.setCustomName(NameDecor.decorate(new LiteralText(name), color));
        return s;
    }

    /** Меч Цербера: острота 9, Критический II, Разрушитель III (только на нём) + все топ-чары для меча. */
    private static ItemStack cerberusSword() {
        ItemStack s = new ItemStack(CERBERUS_SWORD);
        s.addEnchantment(Enchantments.SHARPNESS, 9);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(DESTROYER, 3);
        return topSword(s);
    }

    private static ItemStack topSword(ItemStack s) {
        s.addEnchantment(CRITICAL, 2);
        s.addEnchantment(Enchantments.LOOTING, 5);
        s.addEnchantment(Enchantments.FIRE_ASPECT, 2);
        s.addEnchantment(Enchantments.SWEEPING, 3);
        s.addEnchantment(Enchantments.UNBREAKING, 5);
        s.addEnchantment(Enchantments.MENDING, 1);
        return s;
    }

    private static Item reg(String id, Item item) {
        return Registry.register(Registry.ITEM, new Identifier(MODID, id), item);
    }

    private static ArsenalPotionItem potion(String id, boolean strength, int level, int duration, Item.Settings settings) {
        return (ArsenalPotionItem) reg(id, new ArsenalPotionItem(strength, level, duration, settings));
    }

    private static Item.Settings sphereSettings() {
        return new Item.Settings().group(GROUP).maxCount(1);
    }
}
