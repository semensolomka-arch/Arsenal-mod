package com.arsenal.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

import java.util.List;

/**
 * Зелье победителя: Сила III, Скорость III и Невидимость на 8 минут, Спешка II на 1:30, Регенерация II и Сопротивление II
 * на 30 секунд и мгновенное Исцеление II. После питья откат 5 минут (на все такие зелья сразу).
 */
public class WinnerPotionItem extends Item {
    public static int COOLDOWN_TICKS = 20 * 60 * 5;

    public WinnerPotionItem(Settings settings) {
        super(settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(getTranslationKey(stack)).setStyle(Style.EMPTY.withColor(Formatting.AQUA).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(new LiteralText(""));
        tooltip.add(new LiteralText("Эффекты:").setStyle(Style.EMPTY.withColor(Formatting.GRAY).withItalic(false)));
        String[] lines = {"Сила III (8:00)", "Скорость III (8:00)", "Невидимость (8:00)", "Спешка II (1:30)",
                "Регенерация II (0:30)", "Сопротивление II (0:30)", "Исцеление II"};
        for (String line : lines) {
            tooltip.add(new LiteralText("- " + line).setStyle(Style.EMPTY.withColor(Formatting.AQUA).withItalic(false)));
        }
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 32;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient) {
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 60 * 8, 2, false, true, true));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 60 * 8, 2, false, true, true));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 20 * 60 * 8, 0, false, true, true));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 20 * 90, 1, false, true, true));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 20 * 30, 1, false, true, true));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 30, 1, false, true, true));
            // мгновенное лечение проходит через общий кулдаун исцеления (StatusEffectMixin)
            StatusEffects.INSTANT_HEALTH.applyInstantEffect(user, user, user, 1, 1.0D);
        }
        if (user instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) user;
            player.getItemCooldownManager().set(this, COOLDOWN_TICKS);
            if (player.abilities.creativeMode) {
                return stack;
            }
        }
        stack.decrement(1);
        return stack.isEmpty() ? ItemStack.EMPTY : stack;
    }
}
