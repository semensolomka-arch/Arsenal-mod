package com.arsenal.mixin;

import com.arsenal.sync.PlayerSync;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** После телепорта в другой мир заново отправляем клиенту опыт, эффекты, здоровье и инвентарь. */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerTeleportMixin {
    @Unique
    private boolean arsenal$crossWorld;

    @Inject(method = "teleport(Lnet/minecraft/server/world/ServerWorld;DDDFF)V", at = @At("HEAD"))
    private void arsenal$beforeTeleport(ServerWorld target, double x, double y, double z, float yaw, float pitch, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;
        arsenal$crossWorld = self.getServerWorld() != target;
    }

    @Inject(method = "teleport(Lnet/minecraft/server/world/ServerWorld;DDDFF)V", at = @At("TAIL"))
    private void arsenal$afterTeleport(ServerWorld target, double x, double y, double z, float yaw, float pitch, CallbackInfo ci) {
        if (arsenal$crossWorld) {
            arsenal$crossWorld = false;
            PlayerSync.full((ServerPlayerEntity) (Object) this);
        }
    }
}
