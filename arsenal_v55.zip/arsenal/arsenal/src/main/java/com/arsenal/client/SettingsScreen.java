package com.arsenal.client;

import com.arsenal.Settings;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Общие настройки мода: кулдауны, длительности, интервалы (config/arsenal_settings.json). */
public class SettingsScreen extends Screen {
    private final Screen parent;
    /** Текущие значения (в том числе с других страниц). */
    private final Map<String, Integer> values = new LinkedHashMap<>();
    private final List<TextFieldWidget> fields = new ArrayList<>();
    private final List<Settings.Def> shown = new ArrayList<>();
    private int page;

    public SettingsScreen(Screen parent) {
        super(new LiteralText("Arsenal: общие настройки"));
        this.parent = parent;
        Settings.load();
        for (Settings.Def d : Settings.defs()) {
            values.put(d.key, Settings.get(d.key));
        }
    }

    private int perPage() {
        return Math.max(3, Math.min(14, (this.height - 90) / 22));
    }

    @Override
    protected void init() {
        fields.clear();
        shown.clear();
        int left = (this.width - 340) / 2;
        List<Settings.Def> defs = Settings.defs();
        int per = perPage();
        int pages = Math.max(1, (defs.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= defs.size()) {
                break;
            }
            Settings.Def d = defs.get(idx);
            TextFieldWidget f = new TextFieldWidget(this.textRenderer, left + 240, 28 + i * 22, 50, 20, new LiteralText(d.key));
            f.setMaxLength(7);
            f.setTextPredicate(s -> s.matches("\\d*"));
            f.setText(String.valueOf(values.get(d.key)));
            this.addButton(f);
            fields.add(f);
            shown.add(d);
        }

        int py = this.height - 52;
        this.addButton(new ButtonWidget(left, py, 24, 20, new LiteralText("<"), b -> {
            commit();
            page--;
            this.init(this.client, this.width, this.height);
        }));
        this.addButton(new ButtonWidget(left + 316, py, 24, 20, new LiteralText(">"), b -> {
            commit();
            page++;
            this.init(this.client, this.width, this.height);
        }));

        int by = this.height - 28;
        this.addButton(new ButtonWidget(left, by, 100, 20, new LiteralText("По умолчанию"), b -> {
            for (Settings.Def d : Settings.defs()) {
                values.put(d.key, d.def);
            }
            this.init(this.client, this.width, this.height);
        }));
        this.addButton(new ButtonWidget(left + 104, by, 130, 20, new LiteralText("Сохранить"), b -> {
            commit();
            // сразу применяем, только если мир запущен у нас (одиночка или свой мир)
            boolean hosting = this.client.getServer() != null;
            Settings.save(values, hosting);
            if (hosting) {
                Settings.broadcast(this.client.getServer());   // игроки в твоём мире увидят новые цифры в описаниях
            }
            this.client.openScreen(parent);
        }));
        this.addButton(new ButtonWidget(left + 238, by, 102, 20, new LiteralText("Отмена"),
                b -> this.client.openScreen(parent)));
    }

    private void commit() {
        for (int i = 0; i < fields.size(); i++) {
            Settings.Def d = shown.get(i);
            String t = fields.get(i).getText();
            if (!t.isEmpty()) {
                try {
                    values.put(d.key, Math.max(d.min, Math.min(d.max, Integer.parseInt(t))));
                } catch (NumberFormatException ex) {
                    // оставляем прежнее значение
                }
            }
        }
    }

    @Override
    public void tick() {
        for (TextFieldWidget f : fields) {
            f.tick();
        }
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        int left = (this.width - 340) / 2;
        drawCenteredText(matrices, this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
        for (int i = 0; i < shown.size(); i++) {
            Settings.Def d = shown.get(i);
            int y = 28 + i * 22 + 6;
            this.textRenderer.drawWithShadow(matrices, this.textRenderer.trimToWidth(d.label, 232), left, y, 0xFFFFFF);
            this.textRenderer.drawWithShadow(matrices, d.unit, left + 296, y, 0xAAAAAA);
        }
        int per = perPage();
        int pages = Math.max(1, (Settings.defs().size() + per - 1) / per);
        drawCenteredText(matrices, this.textRenderer, new LiteralText("Страница " + (page + 1) + " / " + pages),
                this.width / 2, this.height - 46, 0xAAAAAA);
        drawCenteredText(matrices, this.textRenderer,
                new LiteralText("Применяется при запуске мира; в своём мире сразу после «Сохранить» (описания предметов тоже)."),
                this.width / 2, this.height - 64, 0x888888);
        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        this.client.openScreen(parent);
    }
}
