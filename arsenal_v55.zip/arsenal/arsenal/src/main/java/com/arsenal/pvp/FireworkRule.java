package com.arsenal.pvp;

import com.arsenal.combat.Combat;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.TypedActionResult;

/** Фейерверки (в том числе для полёта на элитрах) нельзя использовать в бою и в схватках /pvp. */
public final class FireworkRule {
    private FireworkRule() {
    }

    public static void init() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (stack.getItem() == Items.FIREWORK_ROCKET && blocked(player)) {
                warn(player, world.isClient);
                return TypedActionResult.fail(stack);
            }
            return TypedActionResult.pass(stack);
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (player.getStackInHand(hand).getItem() == Items.FIREWORK_ROCKET && blocked(player)) {
                warn(player, world.isClient);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    private static boolean blocked(PlayerEntity player) {
        return player instanceof ServerPlayerEntity
                ? Combat.isInCombat((ServerPlayerEntity) player) || PvpManager.inFight((ServerPlayerEntity) player)
                : false;
    }

    private static void warn(PlayerEntity player, boolean client) {
        if (!client && player instanceof ServerPlayerEntity) {
            ((ServerPlayerEntity) player).sendMessage(
                    new LiteralText("В бою нельзя использовать фейерверки").formatted(Formatting.RED), true);
        }
    }
}
