package com.arsenal.spawn;

import com.arsenal.Arsenal;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.WorldGenerationProgressListener;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.World;
import net.minecraft.world.level.storage.LevelStorage;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

/**
 * Отдельное измерение arsenal:spawn для спавна. Мир создаётся при запуске сервера прямо в игре (датапак не нужен и
 * подходит для уже существующего мира), файлы лежат в папке мира dimensions/arsenal/spawn. У него свой рельеф-генератор
 * как у обычного мира, своя граница мира и своё время суток, поэтому спавн не мешает обычному миру.
 *
 * Если создать измерение не удалось (другая версия игры и т. п.), всё работает как раньше: спавн строится в обычном
 * мире далеко от центра, а в консоль пишется причина.
 */
public final class SpawnWorld {
    /** Ключ строится через реестр измерений minecraft:dimension (так же, как у обычных миров). */
    public static final RegistryKey<World> KEY = RegistryKey.of(
            RegistryKey.<World>ofRegistry(new Identifier("dimension")), new Identifier(Arsenal.MODID, "spawn"));

    private static RegistryKey<World> active = World.OVERWORLD;

    private SpawnWorld() {
    }

    /** Ключ мира спавна: arsenal:spawn или обычный мир, если измерение создать не вышло. */
    public static RegistryKey<World> key() {
        return active;
    }

    public static ServerWorld get(MinecraftServer server) {
        ServerWorld w = server.getWorld(active);
        return w != null ? w : server.getOverworld();
    }

    @SuppressWarnings("unchecked")
    public static void create(MinecraftServer server) {
        if (server.getWorld(KEY) != null) {
            active = KEY;
            return;
        }
        try {
            ServerWorld overworld = server.getOverworld();
            ServerWorld donor = server.getWorld(World.NETHER);
            if (donor == null) {
                donor = server.getWorld(World.END);
            }
            if (donor == null) {
                throw new IllegalStateException("нет мира-образца для свойств");
            }

            Map<RegistryKey<World>, ServerWorld> worlds = null;
            LevelStorage.Session session = null;
            for (Field f : MinecraftServer.class.getDeclaredFields()) {
                f.setAccessible(true);
                if (f.getType() == Map.class) {
                    Object v = f.get(server);
                    if (v instanceof Map && !((Map<?, ?>) v).isEmpty()
                            && ((Map<?, ?>) v).values().iterator().next() instanceof ServerWorld) {
                        worlds = (Map<RegistryKey<World>, ServerWorld>) v;
                    }
                } else if (f.getType() == LevelStorage.Session.class) {
                    session = (LevelStorage.Session) f.get(server);
                }
            }
            if (worlds == null || session == null) {
                throw new IllegalStateException("не найдены список миров или хранилище мира");
            }

            Object props = donor.getLevelProperties();
            Object generator = overworld.getChunkManager().getChunkGenerator();
            Object dimensionType = overworld.getDimension();
            Object listener = Proxy.newProxyInstance(SpawnWorld.class.getClassLoader(),
                    new Class<?>[]{WorldGenerationProgressListener.class}, (proxy, method, args) -> {
                        switch (method.getName()) {
                            case "hashCode":
                                return System.identityHashCode(proxy);
                            case "equals":
                                return proxy == args[0];
                            case "toString":
                                return "NoopProgressListener";
                            default:
                                return null;
                        }
                    });

            Constructor<?> ctor = null;
            for (Constructor<?> c : ServerWorld.class.getDeclaredConstructors()) {
                if (c.getParameterCount() >= 10) {
                    ctor = c;
                }
            }
            if (ctor == null) {
                throw new IllegalStateException("не найден конструктор мира");
            }
            ctor.setAccessible(true);
            Class<?>[] types = ctor.getParameterTypes();
            Object[] args = new Object[types.length];
            for (int i = 0; i < types.length; i++) {
                Class<?> t = types[i];
                if (t == MinecraftServer.class) {
                    args[i] = server;
                } else if (t == Executor.class) {
                    args[i] = Util.getMainWorkerExecutor();
                } else if (t == LevelStorage.Session.class) {
                    args[i] = session;
                } else if (t == RegistryKey.class) {
                    args[i] = KEY;
                } else if (t == WorldGenerationProgressListener.class) {
                    args[i] = listener;
                } else if (t == boolean.class) {
                    args[i] = Boolean.FALSE;
                } else if (t == long.class) {
                    args[i] = overworld.getSeed();
                } else if (t == List.class) {
                    args[i] = Collections.emptyList();
                } else if (t.isInstance(props)) {
                    args[i] = props;
                } else if (t.isInstance(dimensionType)) {
                    args[i] = dimensionType;
                } else if (t.isInstance(generator)) {
                    args[i] = generator;
                }
                if (args[i] == null) {
                    throw new IllegalStateException("не удалось подобрать аргумент конструктора мира: " + t.getName());
                }
            }
            ServerWorld world = (ServerWorld) ctor.newInstance(args);
            worlds.put(KEY, world);
            active = KEY;
            System.out.println("[Arsenal] создано измерение спавна " + KEY.getValue());
        } catch (Throwable t) {
            active = World.OVERWORLD;
            System.err.println("[Arsenal] не удалось создать измерение спавна, спавн будет в обычном мире: " + t);
            t.printStackTrace();
        }
    }
}
