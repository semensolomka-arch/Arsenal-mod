package com.arsenal.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Пресеты лута: сохраняют целиком оба файла лута (грузы и шалкеры) под именем в config/arsenal_loot_presets/.
 * «Загрузить» кладёт пресет в экран лута (дальше «Сохранить» там), «Удалить» стирает файл пресета.
 */
public class PresetScreen extends Screen {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final int PER_PAGE = 5;

    private final LootConfigScreen loot;
    private final List<String> names = new ArrayList<>();
    private TextFieldWidget nameField;
    private String nameText = "";
    private int page;
    private String message = "";
    private int messageColor = 0xAAAAAA;

    public PresetScreen(LootConfigScreen loot) {
        super(new LiteralText("Arsenal: пресеты лута"));
        this.loot = loot;
    }

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_loot_presets");
    }

    private void scan() {
        names.clear();
        try {
            Path d = dir();
            if (Files.isDirectory(d)) {
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(d, "*.json")) {
                    for (Path p : ds) {
                        String n = p.getFileName().toString();
                        names.add(n.substring(0, n.length() - 5));
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Пресеты: не прочитать папку: " + ex);
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
    }

    private static String clean(String s) {
        return s.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    @Override
    protected void init() {
        scan();
        int left = (this.width - 340) / 2;
        int pages = Math.max(1, (names.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= names.size()) {
                break;
            }
            final String name = names.get(idx);
            int y = 40 + i * 24;
            this.addButton(new ButtonWidget(left + 200, y, 80, 20, new LiteralText("Загрузить"), b -> load(name)));
            this.addButton(new ButtonWidget(left + 284, y, 56, 20, new LiteralText("Удалить"), b -> {
                try {
                    Files.deleteIfExists(dir().resolve(name + ".json"));
                    message = "Пресет удалён: " + name;
                    messageColor = 0xFFAA00;
                } catch (Exception ex) {
                    message = "Не удалось удалить: " + ex.getMessage();
                    messageColor = 0xFF5555;
                }
                this.init(this.client, this.width, this.height);
            }));
        }

        int py = 40 + PER_PAGE * 24;
        this.addButton(new ButtonWidget(left, py, 24, 20, new LiteralText("<"), b -> {
            page--;
            this.init(this.client, this.width, this.height);
        }));
        this.addButton(new ButtonWidget(left + 316, py, 24, 20, new LiteralText(">"), b -> {
            page++;
            this.init(this.client, this.width, this.height);
        }));

        int by = this.height - 52;
        nameField = new TextFieldWidget(this.textRenderer, left, by, 200, 20, new LiteralText("имя"));
        nameField.setMaxLength(40);
        nameField.setText(nameText);
        this.addButton(nameField);
        this.addButton(new ButtonWidget(left + 204, by, 136, 20, new LiteralText("Сохранить как пресет"), b -> saveCurrent()));
        this.addButton(new ButtonWidget(left, this.height - 28, 340, 20, new LiteralText("Назад"),
                b -> this.client.openScreen(loot)));
    }

    private void saveCurrent() {
        String name = clean(nameField.getText());
        nameText = nameField.getText();
        if (name.isEmpty()) {
            message = "Введи имя пресета";
            messageColor = 0xFF5555;
            return;
        }
        try {
            Files.createDirectories(dir());
            Files.write(dir().resolve(name + ".json"), GSON.toJson(loot.snapshot()).getBytes(StandardCharsets.UTF_8));
            message = "Пресет сохранён: " + name;
            messageColor = 0x55FF55;
            nameText = "";
        } catch (Exception ex) {
            message = "Не удалось сохранить: " + ex.getMessage();
            messageColor = 0xFF5555;
        }
        this.init(this.client, this.width, this.height);
    }

    private void load(String name) {
        try {
            String text = new String(Files.readAllBytes(dir().resolve(name + ".json")), StandardCharsets.UTF_8);
            loot.applyPreset(new JsonParser().parse(text).getAsJsonObject(), name);
            this.client.openScreen(loot);
        } catch (Exception ex) {
            message = "Не удалось загрузить: " + ex.getMessage();
            messageColor = 0xFF5555;
        }
    }

    @Override
    public void tick() {
        if (nameField != null) {
            nameField.tick();
        }
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        int left = (this.width - 340) / 2;
        drawCenteredText(matrices, this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
        if (names.isEmpty()) {
            drawCenteredText(matrices, this.textRenderer, new LiteralText("Пресетов пока нет. Введи имя внизу и сохрани текущий лут."),
                    this.width / 2, 60, 0x888888);
        }
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= names.size()) {
                break;
            }
            this.textRenderer.drawWithShadow(matrices, this.textRenderer.trimToWidth(names.get(idx), 192), left, 40 + i * 24 + 6, 0xFFFFFF);
        }
        int pages = Math.max(1, (names.size() + PER_PAGE - 1) / PER_PAGE);
        drawCenteredText(matrices, this.textRenderer, new LiteralText((page + 1) + " / " + pages),
                this.width / 2, 40 + PER_PAGE * 24 + 6, 0xAAAAAA);
        if (!message.isEmpty()) {
            drawCenteredText(matrices, this.textRenderer, new LiteralText(message), this.width / 2, this.height - 68, messageColor);
        }
        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        this.client.openScreen(loot);
    }
}
