package com.arsenal.pvp;

import com.arsenal.combat.Combat;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.MessageType;
import net.minecraft.network.packet.s2c.play.WorldBorderS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * /pvp: поиск противника, список доступных игр, поединок и смертельная схватка.
 *
 * Поединок: оба телепортируются на далёкие координаты (в пределах 30 блоков друг от друга),
 * получают 30 секунд режима боя и 10 секунд свечения.
 * Смертельная схватка: телепорт очень далеко, арена 150x150, режим боя и свечение постоянно продлеваются,
 * выйти за арену нельзя (жемчуг: урон и возврат). Победитель 1 минуту лутает, затем возвращается на своё место.
 */
public final class PvpManager {
    public enum Kind {
        DUEL("Поединок", "Поединок"),
        DEADLY("Смертельная схватка", "Смертельная схватка");

        public final String title;
        public final String chatName;

        Kind(String title, String chatName) {
            this.title = title;
            this.chatName = chatName;
        }
    }

    /** Размер арены смертельной схватки (сторона квадрата). */
    public static final int ARENA = 150;
    public static int LOOT_TICKS = 20 * 60;
    /** Через сколько тиков схватки начинает сужаться граница (30 минут). */
    public static int SHRINK_AFTER = 20 * 60 * 30;
    private static final double MIN_HALF = 10.0;
    private static final int BACK_TICKS = 60;
    private static final int ESCAPE_DAMAGE_DISTANCE = 6;
    private static final Random RANDOM = new Random();

    private static final class Origin {
        RegistryKey<World> world;
        double x, y, z;
        float yaw, pitch;

        static Origin of(ServerPlayerEntity p) {
            Origin o = new Origin();
            o.world = p.getServerWorld().getRegistryKey();
            o.x = p.getX();
            o.y = p.getY();
            o.z = p.getZ();
            o.yaw = p.yaw;
            o.pitch = p.pitch;
            return o;
        }
    }

    private static final class Fight {
        Kind kind;
        UUID a, b;
        String nameA, nameB;
        ServerPlayerEntity ea, eb;
        Origin oa, ob;
        ServerWorld world;
        double cx, cz;
        int age;
        UUID winner;
        double[] spawnA, spawnB;
        int backLeft;
        UUID backBy;
        double[] backAt;
        float backHealth;
        double half = ARENA / 2.0;
        int lootLeft;
        final Map<UUID, double[]> last = new HashMap<>();

        ServerPlayerEntity entity(UUID id) {
            return id.equals(a) ? ea : eb;
        }
    }

    private static final Map<UUID, Kind> SEARCH = new LinkedHashMap<>();
    private static final List<Fight> FIGHTS = new ArrayList<>();
    private static final Map<UUID, Origin> PENDING = new HashMap<>();

    private PvpManager() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(PvpStats::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            PvpStats.save();
            SEARCH.clear();
            FIGHTS.clear();
            PENDING.clear();
        });
        ServerTickEvents.END_SERVER_TICK.register(PvpManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> SEARCH.remove(handler.player.getUuid()));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            Origin origin = PENDING.remove(handler.player.getUuid());
            if (origin != null) {
                ServerPlayerEntity p = handler.player;
                server.execute(() -> teleportTo(server, p, origin));
            }
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("pvp")
                        .executes(ctx -> {
                            PvpMenu.openSearch(ctx.getSource().getPlayer());
                            return 1;
                        })
                        .then(CommandManager.literal("list").executes(ctx -> {
                            PvpMenu.openList(ctx.getSource().getPlayer());
                            return 1;
                        }))
                        .then(CommandManager.literal("wipe")
                                .requires(s -> s.hasPermissionLevel(2))
                                .executes(ctx -> {
                                    PvpStats.wipe();
                                    ctx.getSource().sendFeedback(new LiteralText("Статистика за вайп сброшена"), true);
                                    return 1;
                                }))));
    }

    // ---------------------------------------------------------------- поиск

    public static boolean busy(ServerPlayerEntity p) {
        for (Fight f : FIGHTS) {
            if (f.a.equals(p.getUuid()) || f.b.equals(p.getUuid())) {
                return true;
            }
        }
        return false;
    }

    public static Kind searching(UUID id) {
        return SEARCH.get(id);
    }

    /** Копия списка ищущих (порядок поиска). */
    public static Map<UUID, Kind> searchers() {
        return new LinkedHashMap<>(SEARCH);
    }

    public static void startSearch(ServerPlayerEntity p, Kind kind) {
        if (busy(p)) {
            p.sendMessage(new LiteralText("Вы уже участвуете в схватке").formatted(Formatting.RED), false);
            return;
        }
        if (Combat.isInCombat(p)) {
            p.sendMessage(new LiteralText("В режиме боя нельзя искать противника").formatted(Formatting.RED), false);
            return;
        }
        if (SEARCH.containsKey(p.getUuid())) {
            p.sendMessage(new LiteralText("Вы уже ищете противника. Сначала отмените поиск красной кнопкой").formatted(Formatting.RED), false);
            return;
        }
        SEARCH.put(p.getUuid(), kind);
        String name = p.getGameProfile().getName();
        MutableText msg = new LiteralText("Игрок ").formatted(Formatting.GRAY);
        msg.append(new LiteralText(name).formatted(Formatting.GOLD));
        msg.append(new LiteralText(" жаждет игры в «").formatted(Formatting.GRAY));
        msg.append(new LiteralText(kind.chatName).formatted(kind == Kind.DUEL ? Formatting.GREEN : Formatting.LIGHT_PURPLE));
        msg.append(new LiteralText(kind == Kind.DUEL ? "»! Кто готов скрестить свой меч? " : "»! Кто готов к битве насмерть? ").formatted(Formatting.GRAY));
        msg.append(new LiteralText("(/pvp list)").styled(s -> s.withColor(Formatting.AQUA)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/pvp list"))));
        p.getServer().getPlayerManager().broadcastChatMessage(msg, MessageType.SYSTEM, p.getUuid());
    }

    public static void cancelSearch(ServerPlayerEntity p) {
        if (SEARCH.remove(p.getUuid()) != null) {
            p.sendMessage(new LiteralText("Поиск противника отменён").formatted(Formatting.RED), false);
        } else {
            p.sendMessage(new LiteralText("Вы сейчас не ищете противника").formatted(Formatting.GRAY), false);
        }
    }

    // ---------------------------------------------------------------- старт схватки

    /** accepter выбрал в списке игрока target. */
    public static void accept(ServerPlayerEntity accepter, UUID targetId, Kind expected) {
        MinecraftServer server = accepter.getServer();
        Kind kind = SEARCH.get(targetId);
        ServerPlayerEntity target = server.getPlayerManager().getPlayer(targetId);
        if (kind == null || kind != expected || target == null || target.isDead()) {
            accepter.sendMessage(new LiteralText("Этот игрок больше не ищет противника").formatted(Formatting.RED), false);
            return;
        }
        if (target == accepter) {
            accepter.sendMessage(new LiteralText("Нельзя начать схватку с самим собой").formatted(Formatting.RED), false);
            return;
        }
        if (busy(accepter) || Combat.isInCombat(accepter) || accepter.isDead()) {
            accepter.sendMessage(new LiteralText("Сейчас вы не можете начать схватку").formatted(Formatting.RED), false);
            return;
        }
        if (busy(target) || Combat.isInCombat(target)) {
            accepter.sendMessage(new LiteralText("Этот игрок сейчас в бою").formatted(Formatting.RED), false);
            return;
        }
        ServerWorld arena = server.getOverworld();
        double[] spots = findArena(arena, kind);
        if (spots == null) {
            accepter.sendMessage(new LiteralText("Не удалось найти место для арены, попробуйте ещё раз").formatted(Formatting.RED), false);
            return;
        }

        SEARCH.remove(accepter.getUuid());
        SEARCH.remove(targetId);

        Fight f = new Fight();
        f.kind = kind;
        f.a = accepter.getUuid();
        f.b = targetId;
        f.nameA = accepter.getGameProfile().getName();
        f.nameB = target.getGameProfile().getName();
        f.ea = accepter;
        f.eb = target;
        f.oa = Origin.of(accepter);
        f.ob = Origin.of(target);
        f.world = arena;
        f.spawnA = new double[]{spots[0] + 0.5, spots[1], spots[2] + 0.5};
        f.spawnB = new double[]{spots[3] + 0.5, spots[4], spots[5] + 0.5};
        f.cx = spots[6];
        f.cz = spots[7];
        FIGHTS.add(f);

        // spots: x1,y1,z1, x2,y2,z2
        accepter.stopRiding();
        target.stopRiding();
        accepter.teleport(arena, spots[0] + 0.5, spots[1], spots[2] + 0.5, -90.0F, 0.0F);
        target.teleport(arena, spots[3] + 0.5, spots[4], spots[5] + 0.5, 90.0F, 0.0F);
        f.last.put(f.a, f.spawnA);
        f.last.put(f.b, f.spawnB);

        if (kind == Kind.DEADLY) {
            sendBorder(accepter, f);
            sendBorder(target, f);
            glow(accepter);
            glow(target);
        } else {
            accepter.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 20 * 10, 0, false, false));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 20 * 10, 0, false, false));
        }
        Combat.tag(accepter, target);

        MutableText msg = new LiteralText("Начинается «" + kind.chatName + "»: ").formatted(kind == Kind.DUEL ? Formatting.GREEN : Formatting.LIGHT_PURPLE);
        msg.append(new LiteralText(f.nameA).formatted(Formatting.GOLD));
        msg.append(new LiteralText(" против ").formatted(Formatting.GRAY));
        msg.append(new LiteralText(f.nameB).formatted(Formatting.GOLD));
        server.getPlayerManager().broadcastChatMessage(msg, MessageType.SYSTEM, accepter.getUuid());

        String hint = kind == Kind.DUEL
                ? "Вы телепортированы на соперника. Победитель получит вещи проигравшего."
                : "Вы на арене " + ARENA + "x" + ARENA + ". Уйти нельзя, пока не умрёт один из вас.";
        accepter.sendMessage(new LiteralText(hint).formatted(Formatting.AQUA), false);
        target.sendMessage(new LiteralText(hint).formatted(Formatting.AQUA), false);
    }

    /**
     * Ищет место (суша, не вода). Возвращает x1,y1,z1,x2,y2,z2,cx,cz или null.
     * Поединок: далеко, но игроки в 20 блоках друг от друга. Смертельная схватка: ещё дальше, по краям арены.
     */
    private static double[] findArena(ServerWorld world, Kind kind) {
        double limit = world.getWorldBorder().getSize() / 2.0 - 400.0;
        double min = kind == Kind.DUEL ? 3000 : 8000;
        double max = kind == Kind.DUEL ? 8000 : 15000;
        if (max > limit) {
            max = Math.max(limit, 100);
        }
        if (min > max * 0.5) {
            min = max * 0.5;
        }
        double half = kind == Kind.DUEL ? 10 : 40;
        for (int attempt = 0; attempt < 150; attempt++) {
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double dist = min + RANDOM.nextDouble() * (max - min);
            int cx = (int) Math.round(Math.cos(angle) * dist);
            int cz = (int) Math.round(Math.sin(angle) * dist);
            int x1 = (int) Math.round(cx - half);
            int x2 = (int) Math.round(cx + half);
            int y1 = groundY(world, x1, cz);
            int y2 = groundY(world, x2, cz);
            if (y1 < 0 || y2 < 0) {
                continue;
            }
            return new double[]{x1, y1, cz, x2, y2, cz, cx, cz};
        }
        return null;
    }

    /** Высота, на которой можно стоять (над твёрдым блоком, не над жидкостью), или -1. */
    private static int groundY(ServerWorld world, int x, int z) {
        world.getChunk(x >> 4, z >> 4);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y < 5 || y > 250) {
            return -1;
        }
        BlockPos below = new BlockPos(x, y - 1, z);
        if (world.getBlockState(below).isAir() || !world.getBlockState(below).getFluidState().isEmpty()) {
            return -1;
        }
        if (!world.getFluidState(new BlockPos(x, y, z)).isEmpty()) {
            return -1;
        }
        return y;
    }

    // ---------------------------------------------------------------- тик

    private static void tick(MinecraftServer server) {
        if (!SEARCH.isEmpty() && server.getTicks() % 20 == 0) {
            Iterator<UUID> it = SEARCH.keySet().iterator();
            while (it.hasNext()) {
                ServerPlayerEntity p = server.getPlayerManager().getPlayer(it.next());
                if (p == null || p.isDead()) {
                    it.remove();
                }
            }
        }
        if (FIGHTS.isEmpty()) {
            return;
        }
        for (Fight f : new ArrayList<>(FIGHTS)) {
            tickFight(server, f);
        }
    }

    private static boolean alive(MinecraftServer server, UUID id, ServerPlayerEntity expected) {
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
        return p != null && p == expected && !p.isDead();
    }

    private static void tickFight(MinecraftServer server, Fight f) {
        boolean aliveA = alive(server, f.a, f.ea);
        boolean aliveB = alive(server, f.b, f.eb);

        if (f.winner == null) {
            if (!aliveA && !aliveB) {
                end(server, f, false);
                return;
            }
            if (!aliveA) {
                win(server, f, f.b, f.a);
                return;
            }
            if (!aliveB) {
                win(server, f, f.a, f.b);
                return;
            }
            if (f.backLeft > 0) {
                ServerPlayerEntity runner = f.entity(f.backBy);
                ServerPlayerEntity other = f.entity(f.backBy.equals(f.a) ? f.b : f.a);
                float hp = runner.getHealth() + runner.getAbsorptionAmount();
                double moved = Math.abs(runner.getX() - f.backAt[0]) + Math.abs(runner.getZ() - f.backAt[2]);
                if (hp < f.backHealth - 0.01F || moved > 0.5 || Combat.isInCombat(runner)) {
                    f.backLeft = 0;
                    runner.sendMessage(new LiteralText("Запрос на телепортацию отменен").formatted(Formatting.RED), false);
                } else {
                    f.backHealth = Math.max(f.backHealth, hp);
                    f.backLeft--;
                    if (f.backLeft % 20 == 0 && f.backLeft > 0) {
                        runner.sendMessage(new LiteralText("Телепортация через " + (f.backLeft / 20) + " с. Не двигайтесь").formatted(Formatting.YELLOW), true);
                    }
                    if (f.backLeft == 0) {
                        coward(server, f, f.backBy);
                        return;
                    }
                    return;
                }
            }
            f.age++;
            if (f.age == 5 || f.age == 40) {
                verifyArrival(f, f.ea, true);
                verifyArrival(f, f.eb, false);
            }
            if (f.kind == Kind.DEADLY) {
                if (f.age % 20 == 0) {
                    Combat.tag(f.ea, f.eb);
                    glow(f.ea);
                    glow(f.eb);
                }
                if (f.age >= SHRINK_AFTER && f.age % 20 == 0 && f.half > MIN_HALF) {
                    if (f.half == ARENA / 2.0) {
                        String m = "Прошло 30 минут: граница арены начала сужаться!";
                        f.ea.sendMessage(new LiteralText(m).formatted(Formatting.RED), false);
                        f.eb.sendMessage(new LiteralText(m).formatted(Formatting.RED), false);
                    }
                    f.half = Math.max(MIN_HALF, f.half - 0.25);
                    sendBorder(f.ea, f);
                    sendBorder(f.eb, f);
                }
                keepInside(f, f.ea, true);
                keepInside(f, f.eb, true);
                expelOutsiders(server, f);
                if (f.age % 10 == 0) {
                    clearMobs(f);
                }
            }
            return;
        }

        // идёт время на лут
        boolean winnerAlive = f.winner.equals(f.a) ? aliveA : aliveB;
        if (!winnerAlive && server.getPlayerManager().getPlayer(f.winner) != null) {
            // победитель погиб (или возродился) во время лута
            end(server, f, false);
            return;
        }
        f.lootLeft--;
        if (winnerAlive) {
            ServerPlayerEntity w = f.entity(f.winner);
            if (f.kind == Kind.DEADLY) {
                keepInside(f, w, false);
            }
            if (f.lootLeft % 20 == 0) {
                w.sendMessage(new LiteralText("Соберите вещи проигравшего. Возврат через " + (f.lootLeft / 20) + " с")
                        .formatted(Formatting.GREEN), true);
            }
        }
        if (f.lootLeft <= 0) {
            end(server, f, true);
        }
    }

    private static void win(MinecraftServer server, Fight f, UUID winner, UUID loser) {
        f.winner = winner;
        f.lootLeft = LOOT_TICKS;
        String wn = winner.equals(f.a) ? f.nameA : f.nameB;
        String ln = winner.equals(f.a) ? f.nameB : f.nameA;
        PvpStats.win(winner, wn);
        PvpStats.loss(loser, ln);

        ServerPlayerEntity w = server.getPlayerManager().getPlayer(winner);
        if (w != null) {
            w.removeStatusEffect(StatusEffects.GLOWING);
            Combat.clear(w);
            w.sendMessage(new LiteralText("Победа! У вас есть минута, чтобы забрать вещи проигравшего, затем вы вернётесь назад.")
                    .formatted(Formatting.GREEN), false);
        }
        MutableText msg = new LiteralText("Игрок ").formatted(Formatting.GRAY);
        msg.append(new LiteralText(wn).formatted(Formatting.GOLD));
        msg.append(new LiteralText(" одержал победу над игроком ").formatted(Formatting.GRAY));
        msg.append(new LiteralText(ln).formatted(Formatting.GOLD));
        msg.append(new LiteralText(" в «" + f.kind.chatName + "»! Поздравляем!").formatted(Formatting.GRAY));
        server.getPlayerManager().broadcastChatMessage(msg, MessageType.SYSTEM, winner);
    }

    /** Завершает схватку; если returnPlayers, живых возвращает на место, где схватка была выбрана. */
    private static void end(MinecraftServer server, Fight f, boolean returnPlayers) {
        end(server, f, returnPlayers, null);
    }

    /** skip: игрок, которого не возвращаем на прежнее место (он сам телепортируется куда хотел). */
    private static void end(MinecraftServer server, Fight f, boolean returnPlayers, UUID skip) {
        FIGHTS.remove(f);
        for (UUID id : new UUID[]{f.a, f.b}) {
            Origin origin = id.equals(f.a) ? f.oa : f.ob;
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
            if (p == null) {
                if (returnPlayers && (f.winner == null || f.winner.equals(id))) {
                    PENDING.put(id, origin);
                }
                continue;
            }
            if (p != f.entity(id) || p.isDead()) {
                continue;
            }
            p.removeStatusEffect(StatusEffects.GLOWING);
            p.setInvulnerable(false);
            Combat.clear(p);
            if (returnPlayers && !id.equals(skip)) {
                teleportTo(server, p, origin);
            } else if (returnPlayers || f.kind == Kind.DEADLY) {
                restoreBorder(p);
            }
        }
    }

    private static void teleportTo(MinecraftServer server, ServerPlayerEntity p, Origin o) {
        ServerWorld w = server.getWorld(o.world);
        if (w == null) {
            w = server.getOverworld();
        }
        p.stopRiding();
        p.teleport(w, o.x, o.y, o.z, o.yaw, o.pitch);
        restoreBorder(p);
        p.sendMessage(new LiteralText("Вы возвращены на прежнее место").formatted(Formatting.GREEN), false);
    }

    // ---------------------------------------------------------------- арена

    private static void keepInside(Fight f, ServerPlayerEntity p, boolean damage) {
        double half = f.half;
        boolean sameWorld = p.getServerWorld() == f.world;
        boolean inside = sameWorld && Math.abs(p.getX() - f.cx) <= half && Math.abs(p.getZ() - f.cz) <= half;
        double[] last = f.last.get(p.getUuid());
        if (inside) {
            f.last.put(p.getUuid(), new double[]{p.getX(), p.getY(), p.getZ()});
            return;
        }
        boolean jump = !sameWorld || last == null
                || Math.abs(p.getX() - last[0]) + Math.abs(p.getZ() - last[2]) > ESCAPE_DAMAGE_DISTANCE;
        if (jump) {
            if (damage) {
                p.damage(DamageSource.MAGIC, 6.0F);
                p.sendMessage(new LiteralText("Убежать из смертельной схватки нельзя!").formatted(Formatting.RED), false);
            }
            if (p.isDead()) {
                return;
            }
            double[] to = last != null ? last : new double[]{f.cx, f.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) f.cx, (int) f.cz), f.cz};
            p.teleport(f.world, to[0], to[1], to[2], p.yaw, p.pitch);
        } else {
            double nx = Math.max(f.cx - half + 0.5, Math.min(f.cx + half - 0.5, p.getX()));
            double nz = Math.max(f.cz - half + 0.5, Math.min(f.cz + half - 0.5, p.getZ()));
            p.teleport(f.world, nx, p.getY(), nz, p.yaw, p.pitch);
        }
    }

    /** Если игрок после телепорта не оказался у арены, телепортируем ещё раз (и пишем в консоль). */
    private static void verifyArrival(Fight f, ServerPlayerEntity p, boolean first) {
        double[] want = p.getUuid().equals(f.a) ? f.spawnA : f.spawnB;
        if (want == null) {
            return;
        }
        boolean ok = p.getServerWorld() == f.world
                && Math.abs(p.getX() - f.cx) < 100 && Math.abs(p.getZ() - f.cz) < 100;
        if (!ok) {
            System.err.println("[Arsenal] PvP: " + p.getGameProfile().getName() + " не попал на арену, повторный телепорт");
            p.stopRiding();
            p.teleport(f.world, want[0], want[1], want[2], p.yaw, p.pitch);
        }
    }

    /** Игрок сбежал из поединка командой /back: ему поражение, сопернику победа, оба возвращаются назад. */
    private static void coward(MinecraftServer server, Fight f, UUID runner) {
        coward(server, f, runner, false);
    }

    private static void coward(MinecraftServer server, Fight f, UUID runner, boolean keepRunner) {
        UUID other = runner.equals(f.a) ? f.b : f.a;
        String rn = runner.equals(f.a) ? f.nameA : f.nameB;
        String on = runner.equals(f.a) ? f.nameB : f.nameA;
        PvpStats.win(other, on);
        PvpStats.loss(runner, rn);
        MutableText msg = new LiteralText("Игрок ").formatted(Formatting.GRAY);
        msg.append(new LiteralText(rn).formatted(Formatting.RED));
        msg.append(new LiteralText(" струсил перед игроком ").formatted(Formatting.GRAY));
        msg.append(new LiteralText(on).formatted(Formatting.RED));
        msg.append(new LiteralText(" в схватке один на один!").formatted(Formatting.GRAY));
        server.getPlayerManager().broadcastChatMessage(msg, MessageType.SYSTEM, other);
        end(server, f, true, keepRunner ? runner : null);
    }

    private static void freeze(Fight f, ServerPlayerEntity p, double[] at) {
        if (Math.abs(p.getX() - at[0]) > 0.2 || Math.abs(p.getZ() - at[2]) > 0.2 || Math.abs(p.getY() - at[1]) > 1.0) {
            p.teleport(f.world, at[0], at[1], at[2], p.yaw, p.pitch);
        }
    }

    /** На арене смертельной схватки мобы не должны жить. */
    private static void clearMobs(Fight f) {
        net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(
                f.cx - f.half - 8, 0, f.cz - f.half - 8, f.cx + f.half + 8, 256, f.cz + f.half + 8);
        for (net.minecraft.entity.mob.MobEntity mob : f.world.getEntitiesByClass(net.minecraft.entity.mob.MobEntity.class, box, e -> true)) {
            mob.remove();
        }
    }

    public static boolean inFight(ServerPlayerEntity p) {
        for (Fight f : FIGHTS) {
            if (f.winner == null && (f.a.equals(p.getUuid()) || f.b.equals(p.getUuid()))) {
                return true;
            }
        }
        return false;
    }

    public static boolean inDeathFight(ServerPlayerEntity p) {
        for (Fight f : FIGHTS) {
            if (f.kind != Kind.DUEL && f.winner == null && (f.a.equals(p.getUuid()) || f.b.equals(p.getUuid()))) {
                return true;
            }
        }
        return false;
    }

    /** Из смертельной схватки телепортироваться нельзя (команда прерывается). В поединке можно: это побег, см. surrenderDuel. */
    public static boolean teleportBlocked(ServerPlayerEntity p) {
        if (inDeathFight(p)) {
            p.sendMessage(new LiteralText("Из смертельной схватки телепортироваться нельзя").formatted(Formatting.RED), false);
            return true;
        }
        return false;
    }

    /**
     * Игрок в поединке всё-таки телепортируется (команда выполнена, 3 секунды простоял): ему поражение, сопернику победа,
     * сообщение в чат, соперника возвращает на место до поединка, а сам беглец идёт туда, куда телепортируется.
     * Возвращает true, если это был побег из поединка.
     */
    public static boolean surrenderDuel(MinecraftServer server, ServerPlayerEntity p) {
        for (Fight f : FIGHTS) {
            if (f.kind == Kind.DUEL && f.winner == null && (f.a.equals(p.getUuid()) || f.b.equals(p.getUuid()))) {
                coward(server, f, p.getUuid(), true);
                return true;
            }
        }
        return false;
    }

    /** Посторонним на арене делать нечего: выбрасываем за её край. */
    private static void expelOutsiders(MinecraftServer server, Fight f) {
        for (ServerPlayerEntity o : server.getPlayerManager().getPlayerList()) {
            if (o.getUuid().equals(f.a) || o.getUuid().equals(f.b) || o.isSpectator() || o.getServerWorld() != f.world) {
                continue;
            }
            double dx = o.getX() - f.cx;
            double dz = o.getZ() - f.cz;
            double margin = f.half + 4.0;
            if (Math.abs(dx) > margin || Math.abs(dz) > margin) {
                continue;
            }
            double nx = o.getX();
            double nz = o.getZ();
            double out = f.half + 12.0;
            if (Math.abs(dx) >= Math.abs(dz)) {
                nx = f.cx + (dx >= 0 ? out : -out);
            } else {
                nz = f.cz + (dz >= 0 ? out : -out);
            }
            int ny = f.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) nx, (int) nz);
            o.stopRiding();
            o.teleport(f.world, nx, ny, nz, o.yaw, o.pitch);
            o.sendMessage(new LiteralText("Здесь идёт смертельная схватка, вход запрещён").formatted(Formatting.RED), false);
        }
    }

    private static void glow(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100, 0, false, false));
    }

    /** Граница арены видна только участникам (на клиенте), настоящая граница мира не меняется. */
    private static void sendBorder(ServerPlayerEntity p, Fight f) {
        WorldBorder border = new WorldBorder();
        border.setCenter(f.cx, f.cz);
        border.setSize(f.half * 2.0);
        p.networkHandler.sendPacket(new WorldBorderS2CPacket(border, WorldBorderS2CPacket.Type.INITIALIZE));
    }

    private static void restoreBorder(ServerPlayerEntity p) {
        p.networkHandler.sendPacket(new WorldBorderS2CPacket(p.getServerWorld().getWorldBorder(), WorldBorderS2CPacket.Type.INITIALIZE));
    }

    private static void broadcast(MinecraftServer server, ServerPlayerEntity from, MutableText text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, from.getUuid());
    }
}
