package com.arsenal.anvil;

import com.arsenal.Lore;
import net.minecraft.block.Block;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.List;

/** Предмет нерушимой наковальни с описанием «Особенности». */
public class UnbreakableAnvilItem extends BlockItem {
    public UnbreakableAnvilItem(Block block, Settings settings) {
        super(block, settings);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal.unbreakable_anvil.", 4, 0xFFFFFF);
    }
}
