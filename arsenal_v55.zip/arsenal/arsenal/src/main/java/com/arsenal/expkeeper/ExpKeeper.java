package com.arsenal.expkeeper;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * /expkeeper: меню, где за уровни опыта покупаются эффекты на 24 часа.
 *  - эффекты хранятся в файле мира (arsenal_expkeeper.json), срок идёт по реальному времени;
 *  - каждый тик эффекты возвращаются игроку, поэтому они не пропадают после смерти, тотема и молока;
 *  - в творческом режиме покупка бесплатная и без проверки опыта;
 *  - /expkeeper reset убирает все свои эффекты Хранителя.
 */
public final class ExpKeeper {
    public static long DURATION_MS = 24L * 60L * 60L * 1000L;

    /** Слот с информацией об опыте и слоты зелий (средний ряд). */
    private static final int INFO_SLOT = 4;
    private static final int[] PERK_SLOTS = {11, 12, 13, 14, 15};

    public enum Perk {
        RESISTANCE("resistance", "Сопротивление I", StatusEffects.RESISTANCE, 0, 175, Formatting.GRAY, Potions.TURTLE_MASTER),
        REGENERATION("regeneration", "Регенерация I", StatusEffects.REGENERATION, 0, 175, Formatting.LIGHT_PURPLE, Potions.REGENERATION),
        SPEED("speed", "Скорость III", StatusEffects.SPEED, 2, 150, Formatting.AQUA, Potions.SWIFTNESS),
        FIRE_RESISTANCE("fire_resistance", "Огнестойкость", StatusEffects.FIRE_RESISTANCE, 0, 110, Formatting.GOLD, Potions.FIRE_RESISTANCE),
        HEALTH_BOOST("health_boost", "Прилив здоровья I", StatusEffects.HEALTH_BOOST, 0, 200, Formatting.RED, Potions.HEALING);

        public final String id;
        public final String title;
        public final StatusEffect effect;
        public final int amplifier;   // уровень - 1
        public final int price;       // в уровнях опыта
        public final Formatting color;
        public final Potion icon;

        Perk(String id, String title, StatusEffect effect, int amplifier, int price, Formatting color, Potion icon) {
            this.id = id;
            this.title = title;
            this.effect = effect;
            this.amplifier = amplifier;
            this.price = price;
            this.color = color;
            this.icon = icon;
        }

        static Perk byId(String id) {
            for (Perk p : values()) {
                if (p.id.equals(id)) {
                    return p;
                }
            }
            return null;
        }
    }

    /** uuid игрока -> (id эффекта -> время окончания в мс). */
    private static final Map<UUID, Map<String, Long>> DATA = new HashMap<>();
    private static final Type FILE_TYPE = new TypeToken<Map<String, Map<String, Long>>>() {
    }.getType();
    private static MinecraftServer server;

    private ExpKeeper() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("expkeeper")
                        .executes(ctx -> {
                            open(ctx.getSource().getPlayer());
                            return 1;
                        })
                        .then(CommandManager.literal("reset")
                                .executes(ctx -> {
                                    reset(ctx.getSource().getPlayer());
                                    return 1;
                                }))));

        ServerLifecycleEvents.SERVER_STARTED.register(ExpKeeper::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerTickEvents.END_SERVER_TICK.register(ExpKeeper::tick);
    }

    // ---------------- меню ----------------

    private static void open(ServerPlayerEntity player) {
        SimpleInventory inventory = new SimpleInventory(27);
        fillMenu(player, inventory);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new KeeperScreenHandler(syncId, playerInventory, inventory),
                new LiteralText("Хранитель опыта")));
    }

    private static void fillMenu(ServerPlayerEntity player, SimpleInventory inventory) {
        for (int i = 0; i < inventory.size(); i++) {
            inventory.setStack(i, ItemStack.EMPTY);
        }
        inventory.setStack(INFO_SLOT, infoStack(player));
        Perk[] perks = Perk.values();
        for (int i = 0; i < perks.length; i++) {
            inventory.setStack(PERK_SLOTS[i], perkStack(player, perks[i]));
        }
    }

    private static ItemStack infoStack(ServerPlayerEntity player) {
        ItemStack stack = new ItemStack(Items.EXPERIENCE_BOTTLE);
        MutableText name;
        if (player.isCreative()) {
            name = new LiteralText("Творческий режим: всё бесплатно").formatted(Formatting.GREEN);
        } else {
            name = new LiteralText("Ваш опыт: " + player.experienceLevel + " ур.").formatted(Formatting.GREEN);
        }
        name.append(new LiteralText("  (эффекты на 24 часа)").formatted(Formatting.GRAY));
        stack.setCustomName(name.styled(style -> style.withItalic(false)));
        return stack;
    }

    private static ItemStack perkStack(ServerPlayerEntity player, Perk perk) {
        ItemStack stack = PotionUtil.setPotion(new ItemStack(Items.POTION), perk.icon);
        // прячем ванильные строки эффекта у зелья-иконки
        stack.addHideFlag(ItemStack.TooltipSection.ADDITIONAL);

        MutableText name = new LiteralText(perk.title).formatted(perk.color);
        long left = leftMs(player, perk);
        if (left > 0) {
            name.append(new LiteralText("  активно: " + formatLeft(left)).formatted(Formatting.GREEN));
        } else if (player.isCreative()) {
            name.append(new LiteralText("  бесплатно").formatted(Formatting.GREEN));
        } else {
            Formatting priceColor = player.experienceLevel >= perk.price ? Formatting.GREEN : Formatting.RED;
            name.append(new LiteralText("  " + perk.price + " ур.").formatted(priceColor));
        }
        stack.setCustomName(name.styled(style -> style.withItalic(false)));
        return stack;
    }

    static void onMenuClick(ServerPlayerEntity player, int slot, SimpleInventory menu) {
        Perk[] perks = Perk.values();
        for (int i = 0; i < perks.length; i++) {
            if (PERK_SLOTS[i] == slot) {
                buy(player, perks[i]);
                fillMenu(player, menu);
                return;
            }
        }
    }

    // ---------------- покупка и сброс ----------------

    private static void buy(ServerPlayerEntity player, Perk perk) {
        long left = leftMs(player, perk);
        if (left > 0) {
            player.sendMessage(new LiteralText(perk.title + " уже активен, осталось " + formatLeft(left) + ".")
                    .formatted(Formatting.YELLOW), false);
            sound(player, SoundEvents.ENTITY_VILLAGER_NO);
            return;
        }
        if (!player.isCreative()) {
            if (player.experienceLevel < perk.price) {
                player.sendMessage(new LiteralText("Не хватает опыта: нужно " + perk.price + " ур., у вас "
                        + player.experienceLevel + ".").formatted(Formatting.RED), false);
                sound(player, SoundEvents.ENTITY_VILLAGER_NO);
                return;
            }
            player.addExperienceLevels(-perk.price);
        }

        DATA.computeIfAbsent(player.getUuid(), k -> new HashMap<>())
                .put(perk.id, System.currentTimeMillis() + DURATION_MS);
        save();
        maintain(player);

        player.sendMessage(new LiteralText("Куплено: " + perk.title + " на 24 часа.").formatted(Formatting.GREEN), false);
        sound(player, SoundEvents.ENTITY_PLAYER_LEVELUP);
    }

    private static void reset(ServerPlayerEntity player) {
        DATA.remove(player.getUuid());
        save();
        for (Perk perk : Perk.values()) {
            player.removeStatusEffect(perk.effect);
        }
        player.sendMessage(new LiteralText("Все эффекты Хранителя опыта сброшены.").formatted(Formatting.YELLOW), false);
    }

    private static long leftMs(ServerPlayerEntity player, Perk perk) {
        Map<String, Long> mine = DATA.get(player.getUuid());
        if (mine == null) {
            return 0;
        }
        Long expires = mine.get(perk.id);
        return expires == null ? 0 : Math.max(0, expires - System.currentTimeMillis());
    }

    private static void sound(ServerPlayerEntity player, SoundEvent event) {
        player.world.playSound(null, player.getX(), player.getY(), player.getZ(),
                event, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    private static String formatLeft(long ms) {
        long minutes = ms / 60000L;
        return (minutes / 60) + " ч " + (minutes % 60) + " мин";
    }

    // ---------------- поддержание эффектов ----------------

    private static void tick(MinecraftServer s) {
        boolean changed = false;
        for (ServerPlayerEntity player : s.getPlayerManager().getPlayerList()) {
            if (maintain(player)) {
                changed = true;
            }
        }
        if (changed) {
            save();
        }
    }

    /** Возвращает игроку эффекты, которые должны у него быть. true, если какие-то эффекты истекли. */
    private static boolean maintain(ServerPlayerEntity player) {
        Map<String, Long> mine = DATA.get(player.getUuid());
        if (mine == null || mine.isEmpty()) {
            return false;
        }
        boolean changed = false;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<String, Long>> it = mine.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> entry = it.next();
            Perk perk = Perk.byId(entry.getKey());
            long left = entry.getValue() - now;
            if (perk == null || left <= 0) {
                it.remove();
                changed = true;
                continue;
            }
            int ticks = (int) Math.min(left / 50L, 1_800_000L);
            StatusEffectInstance current = player.getStatusEffect(perk.effect);
            // длительность в эффекте не должна жить дольше реального срока (например, после оффлайна)
            if (current != null && current.getAmplifier() >= perk.amplifier && current.getDuration() > ticks + 40) {
                player.removeStatusEffect(perk.effect);
                current = null;
            }
            if (current == null || current.getAmplifier() < perk.amplifier) {
                player.addStatusEffect(new StatusEffectInstance(perk.effect, ticks, perk.amplifier, false, false, true));
            }
        }
        return changed;
    }

    // ---------------- сохранение ----------------

    private static Path file(MinecraftServer s) {
        return s.getSavePath(WorldSavePath.ROOT).resolve("arsenal_expkeeper.json");
    }

    private static void load(MinecraftServer s) {
        server = s;
        DATA.clear();
        Path path = file(s);
        if (!Files.exists(path)) {
            return;
        }
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            Map<String, Map<String, Long>> raw = new Gson().fromJson(reader, FILE_TYPE);
            if (raw != null) {
                for (Map.Entry<String, Map<String, Long>> e : raw.entrySet()) {
                    DATA.put(UUID.fromString(e.getKey()), new HashMap<>(e.getValue()));
                }
            }
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать данные Хранителя опыта: " + e);
        }
    }

    private static void save() {
        if (server == null) {
            return;
        }
        Map<String, Map<String, Long>> raw = new HashMap<>();
        for (Map.Entry<UUID, Map<String, Long>> e : DATA.entrySet()) {
            if (!e.getValue().isEmpty()) {
                raw.put(e.getKey().toString(), e.getValue());
            }
        }
        try {
            Files.write(file(server), new Gson().toJson(raw, FILE_TYPE).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("[Arsenal] Не удалось сохранить данные Хранителя опыта: " + e);
        }
    }
}
