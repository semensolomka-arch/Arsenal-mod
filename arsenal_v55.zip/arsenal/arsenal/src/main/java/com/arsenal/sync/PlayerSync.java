package com.arsenal.sync;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.network.packet.s2c.play.EntityStatusEffectS2CPacket;
import net.minecraft.network.packet.s2c.play.ExperienceBarUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Полная пересылка клиенту того, что он теряет при смене мира: опыт, здоровье и голод, эффекты и инвентарь.
 * Без этого после телепорта в другое измерение (спавн, арена /pvp) пропадал опыт и значки эффектов,
 * а инвентарь мог разойтись с сервером.
 */
public final class PlayerSync {
    private PlayerSync() {
    }

    public static void full(ServerPlayerEntity p) {
        if (p.networkHandler == null) {
            return;
        }
        p.networkHandler.sendPacket(new ExperienceBarUpdateS2CPacket(p.experienceProgress, p.totalExperience, p.experienceLevel));
        p.networkHandler.sendPacket(new HealthUpdateS2CPacket(p.getHealth(), p.getHungerManager().getFoodLevel(),
                p.getHungerManager().getSaturationLevel()));
        for (StatusEffectInstance effect : p.getStatusEffects()) {
            p.networkHandler.sendPacket(new EntityStatusEffectS2CPacket(p.getEntityId(), effect));
        }
        p.networkHandler.sendPacket(new InventoryS2CPacket(p.playerScreenHandler.syncId, p.playerScreenHandler.getStacks()));
    }
}
