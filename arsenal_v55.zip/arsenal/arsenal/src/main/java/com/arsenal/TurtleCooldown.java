package com.arsenal;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Кулдаун на зелья Черепашьей мощи (выпить, бросить, туманное облако): после того как эффект наложился на игрока,
 * следующие 5 минут Черепашья мощь на него не действует. Работает так же, как {@link HealCooldown}.
 * Стрелы с зельем не затрагиваются.
 */
public final class TurtleCooldown {
    public static int TICKS = 20 * 60 * 5;

    /** true, пока внутри выпитого / брошенного / туманного зелья Черепашьей мощи накладываются его эффекты. */
    public static boolean active = false;

    private static final Map<UUID, Long> UNTIL = new HashMap<>();
    private static final Map<UUID, Long> STARTED = new HashMap<>();

    private TurtleCooldown() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(TurtleCooldown::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            UNTIL.clear();
            STARTED.clear();
        });
    }

    public static boolean isTurtle(Potion potion) {
        return potion == Potions.TURTLE_MASTER || potion == Potions.LONG_TURTLE_MASTER
                || potion == Potions.STRONG_TURTLE_MASTER;
    }

    public static boolean isTurtle(ItemStack stack) {
        return isTurtle(PotionUtil.getPotion(stack));
    }

    /** Сбрасывает кулдаун Черепашьей мощи (например, при входе в /hub). */
    public static void reset(UUID id) {
        UNTIL.remove(id);
        STARTED.remove(id);
    }

    /** Сколько тиков осталось до конца кулдауна (0, если его нет). */
    public static int remainingTicks(LivingEntity target) {
        Long until = UNTIL.get(target.getUuid());
        if (until == null) {
            return 0;
        }
        return (int) Math.max(0, until - target.world.getTime());
    }

    /**
     * true - эффекты Черепашьей мощи накладывать можно. Первое наложение запускает кулдаун; второй эффект зелья
     * (оно даёт Замедление и Сопротивление) приходит в тот же тик и тоже проходит.
     */
    public static boolean tryApply(LivingEntity target) {
        if (!(target instanceof PlayerEntity)) {
            return true;
        }
        long now = target.world.getTime();
        UUID id = target.getUuid();
        Long until = UNTIL.get(id);
        if (until != null && now < until) {
            Long started = STARTED.get(id);
            if (started != null && started == now) {
                return true;
            }
            notify(target, "Черепашья мощь: кулдаун ещё " + seconds((int) (until - now)), Formatting.RED);
            return false;
        }
        if (UNTIL.size() > 256) {
            Iterator<Map.Entry<UUID, Long>> it = UNTIL.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Long> e = it.next();
                if (e.getValue() <= now) {
                    STARTED.remove(e.getKey());
                    it.remove();
                }
            }
        }
        UNTIL.put(id, now + TICKS);
        STARTED.put(id, now);
        notify(target, "Черепашья мощь: кулдаун " + seconds(TICKS), Formatting.YELLOW);
        return true;
    }

    /** Можно ли сейчас выпить зелье (кулдауна нет). Само питьё кулдаун не запускает, это делает tryApply. */
    public static boolean canDrink(LivingEntity target) {
        return !(target instanceof PlayerEntity) || remainingTicks(target) <= 0;
    }

    public static void notifyBlocked(LivingEntity target) {
        notify(target, "Черепашья мощь: кулдаун ещё " + seconds(remainingTicks(target)), Formatting.RED);
    }

    private static String seconds(int ticks) {
        int total = (ticks + 19) / 20;
        return (total / 60) + ":" + (total % 60 < 10 ? "0" : "") + (total % 60);
    }

    private static void notify(LivingEntity target, String text, Formatting color) {
        if (target instanceof ServerPlayerEntity) {
            ((ServerPlayerEntity) target).sendMessage(new LiteralText(text).formatted(color), true);
        }
    }

    // Пока в руке зелье Черепашьей мощи и кулдаун идёт, показываем оставшееся время
    private static void tick(MinecraftServer server) {
        if (UNTIL.isEmpty() || server.getTicks() % 5 != 0) {
            return;
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            int remaining = remainingTicks(player);
            if (remaining > 0 && holdsTurtlePotion(player)) {
                player.sendMessage(new LiteralText("Черепашья мощь: кулдаун " + seconds(remaining))
                        .formatted(Formatting.YELLOW), true);
            }
        }
    }

    private static boolean holdsTurtlePotion(PlayerEntity player) {
        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getStackInHand(hand);
            if ((stack.getItem() == Items.POTION || stack.getItem() == Items.SPLASH_POTION
                    || stack.getItem() == Items.LINGERING_POTION) && isTurtle(stack)) {
                return true;
            }
        }
        return false;
    }
}
