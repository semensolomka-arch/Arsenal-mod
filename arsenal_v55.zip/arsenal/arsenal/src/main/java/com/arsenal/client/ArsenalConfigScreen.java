package com.arsenal.client;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

/** Главный экран настроек Arsenal в Mod Menu. */
public class ArsenalConfigScreen extends Screen {
    private final Screen parent;

    public ArsenalConfigScreen(Screen parent) {
        super(new LiteralText("Arsenal"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = this.height / 2 - 40;
        this.addButton(new ButtonWidget(x, y, 200, 20, new LiteralText("Лут грузов и шалкеров"),
                b -> this.client.openScreen(new LootConfigScreen(this))));
        this.addButton(new ButtonWidget(x, y + 26, 200, 20, new LiteralText("Общие настройки (цифры)"),
                b -> this.client.openScreen(new SettingsScreen(this))));
        this.addButton(new ButtonWidget(x, y + 62, 200, 20, new LiteralText("Назад"),
                b -> this.client.openScreen(parent)));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        drawCenteredText(matrices, this.textRenderer, this.title, this.width / 2, this.height / 2 - 70, 0xFFFFFF);
        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        this.client.openScreen(parent);
    }
}
