package com.example.armorhud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import me.shedaniel.clothconfig2.gui.entries.SelectionListEntry;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class ArmorHudConfig {

    public enum Mode implements SelectionListEntry.Translatable {
        PERCENT("Проценты"),
        DURABILITY("Прочность (ед.)");

        private final String label;

        Mode(String label) {
            this.label = label;
        }

        @Override
        public String getKey() {
            return label;
        }
    }

    // Чужая броня (игроки и мобы, только если надета полная броня)
    public static boolean showOthers = true;
    public static Mode othersMode = Mode.PERCENT;

    // Своя броня (в углу HUD)
    public static boolean showSelf = true;
    public static Mode selfMode = Mode.PERCENT;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static class Data {
        boolean showOthers = true;
        Mode othersMode = Mode.PERCENT;
        boolean showSelf = true;
        Mode selfMode = Mode.PERCENT;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("armorhud.json");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        try {
            String json = new String(Files.readAllBytes(f), StandardCharsets.UTF_8);
            Data d = GSON.fromJson(json, Data.class);
            if (d == null) return;
            showOthers = d.showOthers;
            showSelf = d.showSelf;
            if (d.othersMode != null) othersMode = d.othersMode;
            if (d.selfMode != null) selfMode = d.selfMode;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        Data d = new Data();
        d.showOthers = showOthers;
        d.othersMode = othersMode;
        d.showSelf = showSelf;
        d.selfMode = selfMode;
        try {
            Files.write(file(), GSON.toJson(d).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
