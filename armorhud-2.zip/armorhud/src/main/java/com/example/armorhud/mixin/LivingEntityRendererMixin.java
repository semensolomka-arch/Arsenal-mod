package com.example.armorhud.mixin;

import com.example.armorhud.ArmorHudConfig;
import com.example.armorhud.ArmorText;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import net.minecraft.util.math.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(
        method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("TAIL")
    )
    private void armorhud$drawDurability(LivingEntity entity, float yaw, float tickDelta,
                                         MatrixStack matrices, VertexConsumerProvider vcp,
                                         int light, CallbackInfo ci) {
        if (!ArmorHudConfig.showOthers) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (entity == mc.player || entity instanceof ArmorStandEntity || !entity.isAlive()) return;
        if (mc.options.hudHidden) return;
        if (entity.squaredDistanceTo(mc.gameRenderer.getCamera().getPos()) > 32 * 32) return;

        // Только если надета ПОЛНАЯ броня (все 4 слота) - то, что и так видно на модели
        MutableText text = new LiteralText("");
        int count = 0;
        for (ItemStack stack : entity.getArmorItems()) {
            if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem) || !stack.isDamageable()) return;
            if (count++ > 0) text.append(new LiteralText(" | ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xAAAAAA))));
            text.append(ArmorText.format(stack, ArmorHudConfig.othersMode));
        }
        if (count != 4) return;

        TextRenderer tr = mc.textRenderer;
        matrices.push();
        matrices.translate(0.0, entity.getHeight() + 0.75, 0.0);
        matrices.multiply(mc.getEntityRenderDispatcher().getRotation());
        matrices.scale(-0.025F, -0.025F, 0.025F);
        Matrix4f matrix = matrices.peek().getModel();
        float x = -tr.getWidth(text) / 2.0F;
        int bg = (int) (mc.options.getTextBackgroundOpacity(0.25F) * 255.0F) << 24;
        // seeThrough = false -> текст не виден сквозь стены
        tr.draw(text, x, 0, 0xFFFFFFFF, false, matrix, vcp, false, bg, light);
        matrices.pop();
    }
}
