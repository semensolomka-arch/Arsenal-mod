package com.example.armorhud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArmorHudClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ArmorHudConfig.load();
        HudRenderCallback.EVENT.register(ArmorHudClient::renderSelf);
    }

    private static void renderSelf(MatrixStack matrices, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ArmorHudConfig.showSelf || mc.player == null || mc.options.hudHidden) return;

        // getArmorItems() идёт от ботинок к шлему - разворачиваем, чтобы шлем был сверху
        List<ItemStack> stacks = new ArrayList<>();
        for (ItemStack s : mc.player.getArmorItems()) {
            if (!s.isEmpty() && s.isDamageable()) stacks.add(s);
        }
        if (stacks.isEmpty()) return;
        Collections.reverse(stacks);

        List<MutableText> texts = new ArrayList<>();
        int maxW = 0;
        for (ItemStack s : stacks) {
            MutableText t = ArmorText.format(s, ArmorHudConfig.selfMode);
            texts.add(t);
            maxW = Math.max(maxW, mc.textRenderer.getWidth(t));
        }

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Блок слева от хотбара (хотбар: 182 px по центру), нижняя строка на уровне слотов хотбара
        int blockW = 20 + maxW;
        int x = sw / 2 - 91 - 6 - blockW;
        int n = stacks.size();

        for (int i = 0; i < n; i++) {
            int y = sh - 19 - 18 * (n - 1 - i);
            mc.getItemRenderer().renderGuiItemIcon(stacks.get(i), x, y);
            mc.textRenderer.drawWithShadow(matrices, texts.get(i), x + 20, y + 4, 0xFFFFFF);
        }
    }
}
