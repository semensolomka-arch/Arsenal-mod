package com.example.armorhud;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.LiteralText;

public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ModMenuIntegration::createScreen;
    }

    private static Screen createScreen(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(new LiteralText("Armor Durability HUD"))
                .setSavingRunnable(ArmorHudConfig::save);

        ConfigEntryBuilder eb = builder.entryBuilder();

        ConfigCategory others = builder.getOrCreateCategory(new LiteralText("Чужая броня"));
        others.addEntry(eb.startBooleanToggle(new LiteralText("Показывать броню у игроков и мобов"), ArmorHudConfig.showOthers)
                .setDefaultValue(true)
                .setTooltip(new LiteralText("Показывается только если надета полная броня (4 части)"))
                .setSaveConsumer(v -> ArmorHudConfig.showOthers = v)
                .build());
        others.addEntry(eb.startEnumSelector(new LiteralText("Формат"), ArmorHudConfig.Mode.class, ArmorHudConfig.othersMode)
                .setDefaultValue(ArmorHudConfig.Mode.PERCENT)
                .setSaveConsumer(v -> ArmorHudConfig.othersMode = v)
                .build());

        ConfigCategory self = builder.getOrCreateCategory(new LiteralText("Своя броня"));
        self.addEntry(eb.startBooleanToggle(new LiteralText("Показывать свою броню на экране"), ArmorHudConfig.showSelf)
                .setDefaultValue(true)
                .setSaveConsumer(v -> ArmorHudConfig.showSelf = v)
                .build());
        self.addEntry(eb.startEnumSelector(new LiteralText("Формат"), ArmorHudConfig.Mode.class, ArmorHudConfig.selfMode)
                .setDefaultValue(ArmorHudConfig.Mode.PERCENT)
                .setSaveConsumer(v -> ArmorHudConfig.selfMode = v)
                .build());

        return builder.build();
    }
}
