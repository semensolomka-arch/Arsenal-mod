package com.example.armorhud;

import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;

public class ArmorText {

    public static MutableText format(ItemStack stack, ArmorHudConfig.Mode mode) {
        int max = stack.getMaxDamage();
        int left = Math.max(0, max - stack.getDamage());
        String str;
        if (mode == ArmorHudConfig.Mode.PERCENT) {
            str = Math.round(left * 100f / max) + "%";
        } else {
            str = left + "/" + max;
        }
        float ratio = Math.max(0f, Math.min(1f, left / (float) max));
        int rgb = java.awt.Color.HSBtoRGB(ratio / 3f, 1f, 1f) & 0xFFFFFF;
        return new LiteralText(str).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb)));
    }
}
