package com.arsenal.priv;

import com.arsenal.Lore;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/** Предмет привата. С Shift (кроме уникального) ставится обычный блок, а не приват. */
public class PrivateBlockItem extends BlockItem {
    public static final String DURABILITY_TAG = "PrivateDurability";
    public final PrivateType type;

    public PrivateBlockItem(Block block, Settings settings, PrivateType type) {
        super(block, settings);
        this.type = type;
    }

    /** Прочность из предмета (нет тега значит полная). */
    public static int durabilityOf(ItemStack stack, PrivateType type) {
        NbtCompound tag = stack.getTag();
        if (tag != null && tag.contains(DURABILITY_TAG, 3)) {
            return Math.max(1, Math.min(type.durability, tag.getInt(DURABILITY_TAG)));
        }
        return type.durability;
    }

    /** Предмет привата с заданной прочностью (полная прочность хранится без тега, чтобы стакались). */
    public static ItemStack stackWith(PrivateType type, int durability) {
        ItemStack stack = new ItemStack(type.item);
        if (durability < type.durability) {
            stack.getOrCreateTag().putInt(DURABILITY_TAG, durability);
        }
        return stack;
    }

    @Override
    protected BlockState getPlacementState(ItemPlacementContext context) {
        PlayerEntity player = context.getPlayer();
        if (type.canBePlainBlock() && player != null && player.isSneaking()) {
            BlockState plain = type.vanillaBlock().getDefaultState();
            return this.canPlace(context, plain) ? plain : null;
        }
        return super.getPlacementState(context);
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(this.getTranslationKey(stack))
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(type.color)).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal." + type.id + ".", 6, type.color);
        if (type.durability > 1) {
            tooltip.add(new LiteralText("Прочность: ").formatted(Formatting.GRAY)
                    .append(new LiteralText(durabilityOf(stack, type) + "/" + type.durability).formatted(Formatting.WHITE))
                    .styled(s -> s.withItalic(false)));
        }
    }
}
