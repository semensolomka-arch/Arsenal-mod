package com.arsenal.priv;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/** Виды приватов: размер территории (куб), прочность (сколько взрывов выдерживает), стойкость к взрыву и цвет названия. */
public enum PrivateType {
    IRON("private_iron", 5, 1, 6.0F, 0xD8D8D8),
    GOLD("private_gold", 7, 1, 6.0F, 0xFFD700),
    DIAMOND("private_diamond", 11, 1, 6.0F, 0x55FFFF),
    EMERALD("private_emerald", 21, 1, 3.0F, 0x55FF55),
    /** 2 прочности: C4 надо взорвать рядом дважды. */
    NETHERITE("private_netherite", 31, 2, 12.0F, 0xB48CFF),
    /** Отдельный предмет из креатива, 4 прочности, при Shift ставится тоже как приват. */
    UNIQUE("private_unique", 31, 4, 12.0F, 0xFF55FF);

    public final String id;
    public final int size;
    /** Сколько блоков от центра до края (для 5 это 2, для 31 это 15). */
    public final int half;
    public final int durability;
    public final float resistance;
    public final int color;

    /** Заполняется при регистрации. */
    public Block block;
    public Item item;

    PrivateType(String id, int size, int durability, float resistance, int color) {
        this.id = id;
        this.size = size;
        this.half = size / 2;
        this.durability = durability;
        this.resistance = resistance;
        this.color = color;
    }

    public String translationKey() {
        return "block.arsenal." + id;
    }

    /** Обычный блок, который ставится при установке с Shift. */
    public Block vanillaBlock() {
        switch (this) {
            case IRON:
                return Blocks.IRON_BLOCK;
            case GOLD:
                return Blocks.GOLD_BLOCK;
            case DIAMOND:
                return Blocks.DIAMOND_BLOCK;
            case EMERALD:
                return Blocks.EMERALD_ORE;
            case NETHERITE:
                return Blocks.NETHERITE_BLOCK;
            default:
                return Blocks.ANCIENT_DEBRIS;
        }
    }

    /** Что падает, если ломать приват с Shift (изумрудная руда даёт изумруд). */
    public Item shiftDrop() {
        switch (this) {
            case IRON:
                return Items.IRON_BLOCK;
            case GOLD:
                return Items.GOLD_BLOCK;
            case DIAMOND:
                return Items.DIAMOND_BLOCK;
            case EMERALD:
                return Items.EMERALD;
            case NETHERITE:
                return Items.NETHERITE_BLOCK;
            default:
                return Items.ANCIENT_DEBRIS;
        }
    }

    public boolean canBePlainBlock() {
        return this != UNIQUE;
    }
}
