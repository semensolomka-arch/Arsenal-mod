package com.arsenal.priv;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Список поставленных приватов (по измерениям), проверки территории и надписи над приватами.
 * Хранится в папке мира: arsenal_privates.json.
 */
public final class PrivateManager {
    public static final class Entry {
        public final String dim;
        public final BlockPos pos;
        public final UUID owner;
        public final String ownerName;
        public final PrivateType type;
        public int durability;

        Entry(String dim, BlockPos pos, UUID owner, String ownerName, PrivateType type, int durability) {
            this.dim = dim;
            this.pos = pos;
            this.owner = owner;
            this.ownerName = ownerName;
            this.type = type;
            this.durability = durability;
        }

        public boolean covers(BlockPos p) {
            return Math.abs(p.getX() - pos.getX()) <= type.half
                    && Math.abs(p.getY() - pos.getY()) <= type.half
                    && Math.abs(p.getZ() - pos.getZ()) <= type.half;
        }

        public String key() {
            return dim + "|" + pos.asLong();
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<String, Map<Long, Entry>> BY_DIM = new HashMap<>();
    private static Path file;

    private PrivateManager() {
    }

    private static String dim(World world) {
        return world.getRegistryKey().getValue().toString();
    }

    private static Map<Long, Entry> map(String dim) {
        return BY_DIM.computeIfAbsent(dim, d -> new HashMap<>());
    }

    // ---------- запросы ----------

    public static Entry get(World world, BlockPos pos) {
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        return m == null ? null : m.get(pos.asLong());
    }

    public static List<Entry> all(World world) {
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        return m == null ? new ArrayList<>() : new ArrayList<>(m.values());
    }

    /** Все приваты, чья территория накрывает точку. */
    public static List<Entry> regionsAt(World world, BlockPos pos) {
        List<Entry> list = new ArrayList<>();
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        if (m != null) {
            for (Entry e : m.values()) {
                if (e.covers(pos)) {
                    list.add(e);
                }
            }
        }
        return list;
    }

    /** Блок лежит на территории какого-нибудь привата. */
    public static boolean isCovered(World world, BlockPos pos) {
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        if (m == null) {
            return false;
        }
        for (Entry e : m.values()) {
            if (e.covers(pos)) {
                return true;
            }
        }
        return false;
    }

    /** Чужой для игрока приват, накрывающий точку (или null). */
    public static Entry foreignAt(World world, BlockPos pos, PlayerEntity player) {
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        if (m == null) {
            return null;
        }
        for (Entry e : m.values()) {
            if (e.covers(pos) && !e.owner.equals(player.getUuid())) {
                return e;
            }
        }
        return null;
    }

    /** Задевает ли прямоугольник хоть одну территорию (для трапок). */
    public static boolean intersects(World world, Box box) {
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        if (m == null) {
            return false;
        }
        for (Entry e : m.values()) {
            double r = e.type.half;
            if (box.maxX > e.pos.getX() - r && box.minX < e.pos.getX() + r + 1
                    && box.maxY > e.pos.getY() - r && box.minY < e.pos.getY() + r + 1
                    && box.maxZ > e.pos.getZ() - r && box.minZ < e.pos.getZ() + r + 1) {
                return true;
            }
        }
        return false;
    }

    /** Пересекается ли территория нового привата с чужим приватом. */
    public static Entry overlapForeign(World world, BlockPos center, PrivateType type, PlayerEntity player) {
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        if (m == null) {
            return null;
        }
        for (Entry e : m.values()) {
            if (e.owner.equals(player.getUuid())) {
                continue;
            }
            int reach = e.type.half + type.half;
            if (Math.abs(center.getX() - e.pos.getX()) <= reach
                    && Math.abs(center.getY() - e.pos.getY()) <= reach
                    && Math.abs(center.getZ() - e.pos.getZ()) <= reach) {
                return e;
            }
        }
        return null;
    }

    // ---------- изменения ----------

    public static void add(ServerWorld world, BlockPos pos, UUID owner, String ownerName, PrivateType type, int durability) {
        String d = dim(world);
        Entry e = new Entry(d, pos.toImmutable(), owner, ownerName, type, durability);
        map(d).put(pos.asLong(), e);
        save();
        relabel(world, e);
    }

    /** Убирает приват (блок уже заменён) и его надписи. */
    public static void remove(World world, BlockPos pos) {
        if (world.isClient) {
            return;
        }
        Map<Long, Entry> m = BY_DIM.get(dim(world));
        if (m == null) {
            return;
        }
        Entry e = m.remove(pos.asLong());
        if (e != null) {
            killLabels((ServerWorld) world, e);
            save();
        }
    }

    public static void setDurability(ServerWorld world, Entry e, int durability) {
        e.durability = durability;
        save();
        relabel(world, e);
    }

    // ---------- надписи над приватом ----------

    private static String tag(Entry e) {
        return "arsenal_p_" + e.pos.getX() + "_" + e.pos.getY() + "_" + e.pos.getZ();
    }

    private static void run(ServerWorld world, String command) {
        MinecraftServer server = world.getServer();
        server.getCommandManager().execute(server.getCommandSource().withWorld(world).withSilent(), command);
    }

    private static void killLabels(ServerWorld world, Entry e) {
        run(world, "kill @e[type=minecraft:armor_stand,tag=" + tag(e) + "]");
    }

    /** Три строки над блоком: вид и размер, владелец, прочность. */
    public static void relabel(ServerWorld world, Entry e) {
        killLabels(world, e);
        List<Text> lines = new ArrayList<>();
        MutableText title = new TranslatableText(e.type.translationKey())
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(e.type.color)).withBold(true));
        title.append(new LiteralText(" " + e.type.size + "×" + e.type.size).formatted(Formatting.GRAY));
        lines.add(title);
        lines.add(new LiteralText("Владелец: ").formatted(Formatting.GRAY)
                .append(new LiteralText(e.ownerName).formatted(Formatting.AQUA)));
        Formatting dur = e.durability >= e.type.durability ? Formatting.GREEN
                : e.durability <= 1 ? Formatting.RED : Formatting.YELLOW;
        lines.add(new LiteralText("Прочность: ").formatted(Formatting.GRAY)
                .append(new LiteralText(e.durability + "/" + e.type.durability).formatted(dur)));

        double x = e.pos.getX() + 0.5D;
        double z = e.pos.getZ() + 0.5D;
        for (int i = 0; i < lines.size(); i++) {
            double y = e.pos.getY() + 1.0D + 0.28D * (lines.size() - 1 - i);
            String json = Text.Serializer.toJson(lines.get(i)).replace("\\", "\\\\").replace("'", "\\'");
            run(world, String.format(Locale.ROOT,
                    "summon minecraft:armor_stand %.2f %.2f %.2f {Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,"
                            + "CustomNameVisible:1b,Tags:[\"arsenal_private\",\"%s\"],CustomName:'%s'}",
                    x, y, z, tag(e), json));
        }
    }

    // ---------- сохранение ----------

    public static void load(MinecraftServer server) {
        BY_DIM.clear();
        file = server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_privates.json");
        try {
            if (!Files.exists(file)) {
                return;
            }
            JsonArray array = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement el : array) {
                JsonObject o = el.getAsJsonObject();
                PrivateType type = PrivateType.valueOf(o.get("type").getAsString());
                String d = o.get("dim").getAsString();
                BlockPos pos = new BlockPos(o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt());
                Entry e = new Entry(d, pos, UUID.fromString(o.get("owner").getAsString()),
                        o.get("ownerName").getAsString(), type, o.get("durability").getAsInt());
                map(d).put(pos.asLong(), e);
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать arsenal_privates.json: " + ex);
        }
    }

    public static void save() {
        if (file == null) {
            return;
        }
        try {
            JsonArray array = new JsonArray();
            for (Map<Long, Entry> m : BY_DIM.values()) {
                for (Entry e : m.values()) {
                    JsonObject o = new JsonObject();
                    o.addProperty("dim", e.dim);
                    o.addProperty("x", e.pos.getX());
                    o.addProperty("y", e.pos.getY());
                    o.addProperty("z", e.pos.getZ());
                    o.addProperty("owner", e.owner.toString());
                    o.addProperty("ownerName", e.ownerName);
                    o.addProperty("type", e.type.name());
                    o.addProperty("durability", e.durability);
                    array.add(o);
                }
            }
            Files.write(file, GSON.toJson(array).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось сохранить arsenal_privates.json: " + ex);
        }
    }

    public static void clear() {
        BY_DIM.clear();
        file = null;
    }
}
