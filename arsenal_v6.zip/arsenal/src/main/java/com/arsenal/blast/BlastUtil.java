package com.arsenal.blast;

import com.arsenal.TrapManager;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.explosion.Explosion;

import java.util.HashSet;
import java.util.Set;

/** Взрывы динамита, C4 и разрывной волны. */
public final class BlastUtil {
    private BlastUtil() {
    }

    public static void explode(ServerWorld world, Entity source, double x, double y, double z, BlastKind kind) {
        if (kind.mode == BlastKind.Mode.STEALER) {
            StealerBlast.explode(world, x, y, z, kind);
            return;
        }
        if (kind.mode == BlastKind.Mode.VANILLA) {
            // обычный взрыв, просто другой силы (зону замка защищает ExplosionMixin)
            world.createExplosion(source, x, y, z, kind.power, Explosion.DestructionType.BREAK);
            return;
        }

        // Урон, отброс, звук и частицы как у обычного взрыва, но без разрушения блоков
        world.createExplosion(source, x, y, z, kind.power, Explosion.DestructionType.NONE);

        boolean wave = kind.mode == BlastKind.Mode.WAVE;
        float obsidian = wave ? BlastKind.WAVE_OBSIDIAN_RESISTANCE : BlastKind.C4_OBSIDIAN_RESISTANCE;
        Set<BlockPos> blocks = collect(world, x, y, z, kind.power, wave, obsidian);

        for (BlockPos pos : blocks) {
            if (SpawnProtection.contains(world, pos) || TrapManager.isProtected(pos)) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (state.isAir() || state.getBlock() instanceof FluidBlock || state.getHardness(world, pos) < 0) {
                continue;   // воздух, вода, бедрок и прочее неломаемое
            }
            Block block = state.getBlock();
            if (block instanceof com.arsenal.priv.PrivateBlock) {
                com.arsenal.priv.Privates.explosionHit(world, pos);   // минус прочность, на нуле приват разрушается
                continue;
            }
            if (com.arsenal.priv.Privates.EXPLOSION_PROOF_REGION && com.arsenal.priv.PrivateManager.isCovered(world, pos)) {
                continue;   // территория привата не страдает
            }
            if (block instanceof TntBlock) {
                TntBlock.primeTnt(world, pos);      // цепная реакция
                world.removeBlock(pos, false);
                continue;
            }
            if (block instanceof BlastBlock) {
                ((BlastBlock) block).prime(world, pos, null, true);
                world.removeBlock(pos, false);
                continue;
            }
            // как в ванили: предмет выпадает не всегда
            world.breakBlock(pos, world.random.nextFloat() < 1.0F / kind.power);
        }
    }

    /**
     * Те же лучи, что у ванильного взрыва, только с поправками:
     * вода не гасит взрыв (разрывная волна) и обсидиан считается менее прочным.
     */
    private static Set<BlockPos> collect(ServerWorld world, double x, double y, double z, float power,
                                         boolean ignoreFluid, float obsidianResistance) {
        Set<BlockPos> set = new HashSet<>();
        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                for (int l = 0; l < 16; l++) {
                    if (j != 0 && j != 15 && k != 0 && k != 15 && l != 0 && l != 15) {
                        continue;
                    }
                    double dx = j / 15.0 * 2.0 - 1.0;
                    double dy = k / 15.0 * 2.0 - 1.0;
                    double dz = l / 15.0 * 2.0 - 1.0;
                    double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    dx /= len;
                    dy /= len;
                    dz /= len;
                    float strength = power * (0.7F + world.random.nextFloat() * 0.6F);
                    double px = x;
                    double py = y;
                    double pz = z;
                    for (; strength > 0.0F; strength -= 0.22500001F) {
                        BlockPos pos = new BlockPos(px, py, pz);
                        if (pos.getY() < 0 || pos.getY() > 255) {
                            break;
                        }
                        BlockState state = world.getBlockState(pos);
                        FluidState fluid = world.getFluidState(pos);
                        if (!state.isAir() || !fluid.isEmpty()) {
                            float resistance = resistanceOf(state, fluid, ignoreFluid, obsidianResistance);
                            strength -= (resistance + 0.3F) * 0.3F;
                        }
                        if (strength > 0.0F) {
                            set.add(pos);
                        }
                        px += dx * 0.30000001192092896D;
                        py += dy * 0.30000001192092896D;
                        pz += dz * 0.30000001192092896D;
                    }
                }
            }
        }
        return set;
    }

    private static float resistanceOf(BlockState state, FluidState fluid, boolean ignoreFluid, float obsidianResistance) {
        Block block = state.getBlock();
        if (block instanceof FluidBlock) {
            return ignoreFluid ? 0.0F : block.getBlastResistance();
        }
        float resistance = block.getBlastResistance();
        if (!ignoreFluid) {
            resistance = Math.max(resistance, fluid.getBlastResistance());
        }
        if (state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.CRYING_OBSIDIAN)) {
            resistance = Math.min(resistance, obsidianResistance);
        }
        return resistance;
    }
}
