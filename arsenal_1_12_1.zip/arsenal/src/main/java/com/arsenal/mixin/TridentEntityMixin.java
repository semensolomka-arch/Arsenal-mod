package com.arsenal.mixin;

import com.arsenal.Arsenal;
import com.arsenal.enchantment.HomingEnchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Трезубец:
 *  1) самонаводка I-IV: трезубец медленнее и падает сильнее; через 1 с после броска берёт цель, ближайшую
 *     к прицелу (по углу к направлению броска) в пределах конуса уровня, и доворачивает к ней с ограниченной
 *     скоростью; каждый довернутый градус тратит запас (15 / 45 / 90 / 180); дальность 20 / 40 / 60 / 80 блоков;
 *  2) трезубец с самонаводкой не попадает по тому, кто его бросил (пролетает насквозь);
 *  3) урон растёт с расстоянием, которое пролетел трезубец (у любого трезубца, с самонаводкой или без).
 */
@Mixin(TridentEntity.class)
public abstract class TridentEntityMixin extends PersistentProjectileEntity {
    @Shadow
    private ItemStack tridentStack;

    @Shadow
    private boolean dealtDamage;

    /** Точка, где трезубец появился (начало полёта). */
    @Unique
    private Vec3d arsenal$origin;

    /** Направление в момент броска (прицел), от него считается угол захвата. */
    @Unique
    private Vec3d arsenal$launchDir;

    @Unique
    private LivingEntity arsenal$target;

    /** Уровень самонаводки (0 = нет), читается один раз в первом тике. */
    @Unique
    private int arsenal$level;

    /** Сколько градусов поворота ещё осталось. */
    @Unique
    private double arsenal$budget;

    /** Тиков в полёте (для задержки включения). */
    @Unique
    private int arsenal$ticks;

    protected TridentEntityMixin(EntityType<? extends PersistentProjectileEntity> type, World world) {
        super(type, world);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void arsenal$homing(CallbackInfo ci) {
        if (this.world.isClient) {
            return;
        }
        if (arsenal$origin == null) {
            arsenal$origin = this.getPos();
            Vec3d v = this.getVelocity();
            if (v.lengthSquared() > 1.0E-6) {
                arsenal$launchDir = v.normalize();
            }
            int level = EnchantmentHelper.getLevel(Arsenal.HOMING, this.tridentStack);
            if (level > 0) {
                arsenal$level = Math.min(level, HomingEnchantment.CONE_DEGREES.length);
                arsenal$budget = HomingEnchantment.CONE_DEGREES[arsenal$level - 1];
                // трезубец с самонаводкой летит медленнее
                this.setVelocity(v.multiply(HomingEnchantment.SPEED_MULTIPLIER));
                this.velocityModified = true;
            }
        }
        if (arsenal$level <= 0 || this.inGround || this.dealtDamage || this.isNoClip() || arsenal$launchDir == null) {
            return;
        }
        arsenal$ticks++;

        // падает сильнее обычного; скорость шлём клиентам каждый тик (у клиента трезубец не знает про наши чары)
        if (!this.hasNoGravity()) {
            this.setVelocity(this.getVelocity().add(0.0, -HomingEnchantment.EXTRA_GRAVITY, 0.0));
        }
        this.velocityModified = true;

        // самонаводка включается через секунду после броска
        if (arsenal$ticks <= HomingEnchantment.HOMING_DELAY_TICKS) {
            return;
        }
        // запас поворота кончился: самонаводка выключена до конца полёта
        if (arsenal$budget <= 1.0E-3) {
            arsenal$target = null;
            return;
        }
        double cone = HomingEnchantment.CONE_DEGREES[arsenal$level - 1];
        double maxDistance = HomingEnchantment.MAX_HOMING_DISTANCE[arsenal$level - 1];

        // дальше лимита уровня от точки броска самонаводка отключается
        Vec3d pos = this.getPos();
        double flown = pos.distanceTo(arsenal$origin);
        if (flown > maxDistance) {
            arsenal$target = null;
            return;
        }

        Vec3d velocity = this.getVelocity();
        double speed = velocity.length();
        if (speed < 1.0E-4) {
            return;
        }
        Vec3d cur = velocity.normalize();

        // держим захваченную цель, пока она жива; иначе берём ближайшую к прицелу
        if (arsenal$target != null && (!arsenal$target.isAlive() || arsenal$target.world != this.world)) {
            arsenal$target = null;
        }
        if (arsenal$target == null) {
            arsenal$target = arsenal$findTarget(this.getOwner(), pos, cur, cone, maxDistance - flown);
        }
        if (arsenal$target == null) {
            return;
        }

        Vec3d aim = arsenal$center(arsenal$target).subtract(pos);
        if (aim.lengthSquared() < 1.0E-6) {
            return;
        }
        Vec3d want = aim.normalize();
        // доворот: не быстрее TURN_RATE за тик и не больше оставшегося запаса; гравитацию никто не компенсирует
        double needed = arsenal$angle(cur, want);
        double turn = Math.min(Math.min(needed, HomingEnchantment.TURN_RATE_DEGREES), arsenal$budget);
        if (turn > 1.0E-4) {
            Vec3d nd = arsenal$rotateToward(cur, want, Math.toRadians(turn));
            this.setVelocity(nd.multiply(speed));
            arsenal$budget -= turn;
        }
    }

    /** Трезубец с самонаводкой не бьёт того, кто его бросил: пролетает насквозь. */
    @Inject(method = "onEntityHit", at = @At("HEAD"), cancellable = true)
    private void arsenal$passThroughOwner(EntityHitResult hit, CallbackInfo ci) {
        if (hit.getEntity() == this.getOwner() && EnchantmentHelper.getLevel(Arsenal.HOMING, this.tridentStack) > 0) {
            ci.cancel();
        }
    }

    /** Цель, ближайшая к прицелу (минимальный угол к направлению броска) в конусе и в пределах оставшейся дальности. */
    @Unique
    private LivingEntity arsenal$findTarget(Entity owner, Vec3d pos, Vec3d cur, double cone, double range) {
        if (range <= 0.0) {
            return null;
        }
        List<LivingEntity> list = this.world.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(range),
                e -> e != owner && e.isAlive() && !e.isSpectator() && !(e instanceof ArmorStandEntity)
                        && !(e instanceof PlayerEntity && ((PlayerEntity) e).isCreative())
                        && !(owner != null && e.isTeammate(owner)));
        LivingEntity best = null;
        double bestAngle = Double.MAX_VALUE;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            Vec3d to = arsenal$center(e).subtract(pos);
            double dist = to.length();
            if (dist < 1.0E-6 || dist > range) {
                continue;
            }
            double angle = arsenal$angle(arsenal$launchDir, to.multiply(1.0 / dist));
            if (angle > cone + 1.0E-3) {
                continue;
            }
            // дотянуться запаса поворота должно хватить
            if (arsenal$angle(cur, to.multiply(1.0 / dist)) > arsenal$budget + 1.0E-3) {
                continue;
            }
            // при равном угле берём ближайшего
            if (angle > bestAngle || (angle == bestAngle && dist >= bestDist)) {
                continue;
            }
            if (!e.canSee(this)) { // цель за стеной не захватываем
                continue;
            }
            best = e;
            bestAngle = angle;
            bestDist = dist;
        }
        return best;
    }

    @Unique
    private static Vec3d arsenal$center(Entity e) {
        return e.getPos().add(0.0, e.getHeight() * 0.5, 0.0);
    }

    /** Поворачивает единичный вектор cur к единичному want не больше чем на maxRad радиан. */
    @Unique
    private static Vec3d arsenal$rotateToward(Vec3d cur, Vec3d want, double maxRad) {
        double angle = Math.acos(MathHelper.clamp(cur.dotProduct(want), -1.0, 1.0));
        if (angle <= maxRad) {
            return want;
        }
        Vec3d axis = cur.crossProduct(want);
        if (axis.lengthSquared() < 1.0E-8) { // цель строго позади: ось любая, перпендикулярная движению
            axis = cur.crossProduct(new Vec3d(0.0, 1.0, 0.0));
            if (axis.lengthSquared() < 1.0E-8) {
                axis = new Vec3d(1.0, 0.0, 0.0);
            }
        }
        axis = axis.normalize();
        return cur.multiply(Math.cos(maxRad)).add(axis.crossProduct(cur).multiply(Math.sin(maxRad))).normalize();
    }

    /** Угол между двумя единичными векторами, градусы. */
    @Unique
    private static double arsenal$angle(Vec3d a, Vec3d b) {
        return Math.toDegrees(Math.acos(MathHelper.clamp(a.dotProduct(b), -1.0, 1.0)));
    }

    /** Урон трезубца растёт с пролетевшим расстоянием (по прямой от точки броска). */
    @ModifyArg(method = "onEntityHit", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"), index = 1)
    private float arsenal$distanceDamage(float damage) {
        if (arsenal$origin == null) {
            return damage;
        }
        double distance = this.getPos().distanceTo(arsenal$origin);
        return damage + (float) (distance * HomingEnchantment.DAMAGE_PER_BLOCK);
    }
}
