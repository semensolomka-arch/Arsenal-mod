package com.arsenal.special;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Предмет с действием по ПКМ в руке (взрывная трапка, взрывная штучка, светильник Джейка). */
public class UseItem extends Item {
    public interface Action {
        /** Возвращает true, если предмет сработал (тогда он тратится внутри Action). */
        boolean run(ServerPlayerEntity player, ItemStack stack);
    }

    private final Action action;
    private final boolean glint;
    private final String tooltipKey;

    public UseItem(Settings settings, Action action, boolean glint, String tooltipKey) {
        super(settings);
        this.action = action;
        this.glint = glint;
        this.tooltipKey = tooltipKey;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return glint;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient || !(user instanceof ServerPlayerEntity)) {
            return TypedActionResult.success(stack, world.isClient());
        }
        boolean ok = action.run((ServerPlayerEntity) user, stack);
        return ok ? TypedActionResult.success(stack) : TypedActionResult.fail(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(new TranslatableText(tooltipKey).formatted(Formatting.GRAY));
    }
}
