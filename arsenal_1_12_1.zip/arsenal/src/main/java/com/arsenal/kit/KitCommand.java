package com.arsenal.kit;

import com.arsenal.Arsenal;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * /kit stinger и /kit eternity: выдают набор вещей. Если в инвентаре не хватает места,
 * не выдаётся ничего, а в чат пишется, что нет места.
 */
public final class KitCommand {
    private KitCommand() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("kit")
                        .then(CommandManager.literal("stinger").executes(ctx -> giveStinger(ctx.getSource())))
                        .then(CommandManager.literal("eternity").executes(ctx -> giveEternity(ctx.getSource())))));
    }

    private static int giveStinger(ServerCommandSource source) throws CommandSyntaxException {
        give(source.getPlayer(), "STINGER", stingerKit());
        return 1;
    }

    private static int giveEternity(ServerCommandSource source) throws CommandSyntaxException {
        give(source.getPlayer(), "ETERNITY", eternityKit());
        return 1;
    }

    // ---------------- наборы ----------------

    private static List<ItemStack> stingerKit() {
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(Arsenal.stingerArmor()));
        kit.add(Arsenal.stingerSword());
        kit.add(new ItemStack(Arsenal.TALISMAN_STINGER));
        add(kit, drink(Potions.STRONG_HEALING), 32);           // пол стака обычного исцеления II
        add(kit, new ItemStack(Arsenal.STRENGTH_III_6M), 12);  // 12 силок на 6 минут
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 64);      // стак золотой моркови
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 32);       // 32 золотых яблока
        add(kit, new ItemStack(Items.ENDER_PEARL), 2 * 16);    // 2 стака жемчуга
        add(kit, new ItemStack(Items.TOTEM_OF_UNDYING), 1);
        addStack(kit, Arsenal.TRAP);
        addStack(kit, Arsenal.SNOW_BALL);
        addStack(kit, Arsenal.STUN);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 4 * 64);
        return kit;
    }

    private static List<ItemStack> eternityKit() {
        List<ItemStack> kit = new ArrayList<>();
        kit.addAll(Arrays.asList(Arsenal.eternityArmor()));
        kit.add(Arsenal.eternitySword());
        kit.add(new ItemStack(Arsenal.TALISMAN_ETERNITY));
        add(kit, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 64);  // стак чарок
        add(kit, new ItemStack(Items.GOLDEN_CARROT), 64);           // стак золотой моркови
        add(kit, new ItemStack(Items.GOLDEN_APPLE), 64);            // стак золотых яблок
        add(kit, drink(Potions.STRONG_HEALING), 64);                // стак обычного исцеления 2
        add(kit, new ItemStack(Items.ENDER_PEARL), 4 * 16);         // 4 стака жемчуга
        add(kit, new ItemStack(Arsenal.STRENGTH_III_6M), 64);       // стак силок 3 на 6 минут
        add(kit, new ItemStack(Items.TOTEM_OF_UNDYING), 3);
        addStack(kit, Arsenal.TRAP);
        addStack(kit, Arsenal.SNOW_BALL);
        addStack(kit, Arsenal.STUN);
        add(kit, new ItemStack(Items.EXPERIENCE_BOTTLE), 6 * 64);
        return kit;
    }

    // ---------------- помощники ----------------

    /** Обычное (пьяное) зелье. */
    private static ItemStack drink(Potion potion) {
        return PotionUtil.setPotion(new ItemStack(Items.POTION), potion);
    }

    /** Один полный стак предмета. */
    private static void addStack(List<ItemStack> kit, Item item) {
        add(kit, new ItemStack(item), item.getMaxCount());
    }

    /** Добавляет total штук, раскладывая по стакам. */
    private static void add(List<ItemStack> kit, ItemStack template, int total) {
        int max = Math.max(1, template.getMaxCount());
        int left = total;
        while (left > 0) {
            ItemStack part = template.copy();
            part.setCount(Math.min(max, left));
            kit.add(part);
            left -= part.getCount();
        }
    }

    private static void give(ServerPlayerEntity player, String name, List<ItemStack> kit) {
        int free = 0;
        for (ItemStack stack : player.inventory.main) {
            if (stack.isEmpty()) {
                free++;
            }
        }
        if (free < kit.size()) {
            player.sendMessage(new LiteralText("Нет места в инвентаре: для набора нужно " + kit.size()
                    + " свободных слотов, свободно " + free + ".").formatted(Formatting.RED), false);
            return;
        }
        for (ItemStack stack : kit) {
            player.inventory.insertStack(stack);
        }
        player.sendMessage(new LiteralText("Набор " + name + " выдан.").formatted(Formatting.GREEN), false);
    }
}
