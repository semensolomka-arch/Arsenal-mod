package com.arsenal.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

/**
 * Самонаводка (только трезубец), уровни I-IV. Сама логика в TridentEntityMixin.
 *  - Трезубец с самонаводкой летит медленнее (x0.6) и падает сильнее (+20% гравитации).
 *  - Самонаводка включается через секунду после броска.
 *  - Цель: ближайшая к прицелу (минимальный угол к направлению броска) в конусе уровня: 15 / 45 / 90 / 180 градусов.
 *  - Эти же градусы это общий запас поворота: каждый довернутый градус тратится, кончился запас: самонаводка выключилась.
 *  - Скорость поворота ограничена (TURN_RATE_DEGREES за тик).
 *  - Цель позади бросающего может взять только IV. Свой трезубец с самонаводкой бросающего не бьёт, пролетает насквозь.
 *  - Дальность: самонаводка отключается на расстоянии от точки броска: I 20, II 40, III 60, IV 80 блоков.
 * Из стола зачарований можно получить только I или II (на книгу или трезубец), III и IV: наковальня и киты.
 * Все числа ниже можно менять здесь.
 */
public class HomingEnchantment extends Enchantment {
    /** Угол захвата и общий запас поворота по уровням, градусы (индекс = уровень - 1). */
    public static final double[] CONE_DEGREES = {15.0, 45.0, 90.0, 180.0};
    /** Дальше этого расстояния от точки броска самонаводка отключается, по уровням, блоков. */
    public static final double[] MAX_HOMING_DISTANCE = {20.0, 40.0, 60.0, 80.0};
    /** Сколько градусов за тик трезубец может довернуть к цели. */
    public static final double TURN_RATE_DEGREES = 25.0;
    /** Через сколько тиков после броска включается самонаводка (20 = 1 секунда). */
    public static final int HOMING_DELAY_TICKS = 5;
    /** Скорость трезубца с самонаводкой относительно обычной (0.6 = на 40% медленнее). */
    public static final double SPEED_MULTIPLIER = 0.6;
    /** Дополнительное падение за тик (у трезубца гравитация 0.05, +20% = 0.01). */
    public static final double EXTRA_GRAVITY = 0.04;
    /**
     * Прибавка урона за каждый пролетевший блок (по прямой от точки броска).
     * 73/60: на 60 блоках урон 8 + 73 = 81 до брони (по расчёту это чуть больше половины ХП
     * через полный незерит с Защитой V на всех частях и Сопротивлением I).
     */
    public static final double DAMAGE_PER_BLOCK = 73.0 / 60.0;

    public HomingEnchantment() {
        super(Rarity.UNCOMMON, EnchantmentTarget.TRIDENT, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
    }

    @Override
    public int getMaxLevel() {
        return 4;
    }

    // Стол зачарований: I на низких уровнях стола, II на высоких. III и IV стол выдать не может.
    @Override
    public int getMinPower(int level) {
        if (level == 1) {
            return 1;
        }
        if (level == 2) {
            return 20;
        }
        return 10000;
    }

    @Override
    public int getMaxPower(int level) {
        return level <= 2 ? getMinPower(level) + 30 : 10050;
    }

    // В торговле книгами с жителями не появляется
    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
}
