package com.arsenal.hub;

import com.arsenal.combat.Combat;
import com.arsenal.pvp.PvpManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /hub: игрок «выходит» из мира, не выходя с сервера. Его телепортирует в закрытую комнату на краю мира,
 * настоящий инвентарь сохраняется в файл, в руках остаётся только компас «Вернуться к игре».
 * В комнате игрок бессмертен (режим приключения, урон не проходит), голод не падает.
 * ПКМ по компасу или повторное /hub возвращает его на то место, где он написал /hub, и отдаёт вещи.
 * Состояние пишется в config/arsenal_hub_state.json, поэтому вещи не пропадают при перезапуске сервера.
 */
public final class HubManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final String COMPASS_TAG = "ArsenalHubCompass";

    // Комната на самом краю мира (почти 29 миллионов блоков от центра): туда никто не доберётся и ничего не видно.
    // Пол на y=100, потолок на y=105, внутри 4 блока высоты, радиус 5
    private static final int CX = 29_000_000;
    private static final int CZ = 29_000_000;
    private static final int FLOOR_Y = 100;
    private static final int CEIL_Y = 105;
    private static final int RADIUS = 5;
    private static final double HUB_X = CX + 0.5;
    private static final double HUB_Y = FLOOR_Y + 1.0;
    private static final double HUB_Z = CZ + 0.5;

    private static final class Saved {
        String dim;
        double x, y, z;
        float yaw, pitch;
        String mode = "survival";
        JsonArray items = new JsonArray();
    }

    private static final Map<UUID, Saved> SAVED = new HashMap<>();
    private static int tick;

    private HubManager() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> load());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());
        ServerTickEvents.END_SERVER_TICK.register(HubManager::onTick);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            if (!SAVED.containsKey(p.getUuid())) {
                return;
            }
            if (inHub(p)) {
                p.setInvulnerable(true);
            } else {
                finish(p, false);
            }
        });

        // умер в хабе (например от /kill): вещи всё равно возвращаются
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (SAVED.containsKey(newPlayer.getUuid())) {
                finish(newPlayer, false);
            }
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("hub").executes(ctx -> toggle(ctx.getSource().getPlayer()))));

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack held = player.getStackInHand(hand);
            if (hand != Hand.MAIN_HAND || !isCompass(held)) {
                return TypedActionResult.pass(held);
            }
            if (!world.isClient && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity p = (ServerPlayerEntity) player;
                if (SAVED.containsKey(p.getUuid())) {
                    finish(p, true);
                } else {
                    // компас остался у игрока не в хабе (например выпал): убираем
                    held.setCount(0);
                }
            }
            return TypedActionResult.success(held);
        });
    }

    /** Игрок сейчас в хабе: его нельзя выбирать целью телепортов и поединков. */
    public static boolean isActive(UUID id) {
        return SAVED.containsKey(id);
    }

    // ------------------------------------------------------------------ команда

    private static int toggle(ServerPlayerEntity p) {
        if (SAVED.containsKey(p.getUuid())) {
            finish(p, true);
            return 1;
        }
        if (Combat.isInCombat(p)) {
            say(p, "В режиме боя в хаб нельзя", Formatting.RED);
            return 0;
        }
        if (PvpManager.busy(p)) {
            say(p, "Во время схватки в хаб нельзя", Formatting.RED);
            return 0;
        }
        enter(p);
        return 1;
    }

    private static void enter(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        ServerWorld overworld = server.getOverworld();
        buildRoom(overworld);

        Saved s = new Saved();
        s.dim = p.getServerWorld().getRegistryKey().getValue().toString();
        s.x = p.getX();
        s.y = p.getY();
        s.z = p.getZ();
        s.yaw = p.yaw;
        s.pitch = p.pitch;
        s.mode = p.interactionManager.getGameMode().getName();
        s.items = takeItems(p);
        SAVED.put(p.getUuid(), s);
        save();
        // поиск соперника отменяется: из хаба в поединок идти нельзя
        if (PvpManager.searching(p.getUuid()) != null) {
            PvpManager.cancelSearch(p);
        }

        p.closeHandledScreen();
        p.stopRiding();
        p.inventory.clear();
        ItemStack compass = new ItemStack(Items.COMPASS);
        compass.getOrCreateTag().putBoolean(COMPASS_TAG, true);
        compass.setCustomName(new LiteralText("Вернуться к игре")
                .setStyle(Style.EMPTY.withItalic(false).withColor(Formatting.GREEN)));
        p.inventory.setStack(4, compass);
        p.inventory.selectedSlot = 4;

        p.setInvulnerable(true);
        p.extinguish();
        p.setGameMode(GameMode.ADVENTURE);
        p.teleport(overworld, HUB_X, HUB_Y, HUB_Z, 0.0F, 0.0F);
        p.fallDistance = 0.0F;
        overworld.playSound(null, HUB_X, HUB_Y, HUB_Z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        say(p, "Вы в хабе: урон не проходит, можно стоять сколько угодно. Вернуться: компас или /hub", Formatting.GREEN);
    }

    /**
     * Возвращает игроку вещи и режим игры. Если back=true, телепортирует на прежнее место,
     * иначе оставляет там, где он сейчас (смерть, выход из хаба другим способом).
     */
    private static void finish(ServerPlayerEntity p, boolean back) {
        Saved s = SAVED.remove(p.getUuid());
        if (s == null) {
            return;
        }
        p.closeHandledScreen();
        p.inventory.clear();
        restoreItems(p, s.items);
        p.setInvulnerable(false);
        p.setGameMode(GameMode.byName(s.mode));
        if (back) {
            MinecraftServer server = p.getServer();
            ServerWorld target = null;
            for (ServerWorld w : server.getWorlds()) {
                if (w.getRegistryKey().getValue().toString().equals(s.dim)) {
                    target = w;
                }
            }
            p.stopRiding();
            if (target == null) {
                ServerWorld ow = server.getOverworld();
                BlockPos spawn = ow.getSpawnPos();
                p.teleport(ow, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, 0.0F, 0.0F);
            } else {
                p.teleport(target, s.x, s.y, s.z, s.yaw, s.pitch);
            }
            p.fallDistance = 0.0F;
            p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(),
                    SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
        save();
        say(p, "Вы вернулись в игру", Formatting.GREEN);
    }

    // ------------------------------------------------------------------ тик

    private static void onTick(MinecraftServer server) {
        tick++;
        if (tick % 20 != 0 || SAVED.isEmpty()) {
            return;
        }
        for (UUID id : new ArrayList<>(SAVED.keySet())) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
            if (p == null) {
                continue;
            }
            if (!inHub(p)) {
                // ушёл из комнаты другой командой: бессмертие и режим приключения больше не нужны
                finish(p, false);
                continue;
            }
            p.setInvulnerable(true);
            p.getHungerManager().setFoodLevel(20);
            p.extinguish();
        }
    }

    private static boolean inHub(ServerPlayerEntity p) {
        return p.getServerWorld().getRegistryKey() == World.OVERWORLD
                && Math.abs(p.getX() - CX) < RADIUS + 2
                && Math.abs(p.getZ() - CZ) < RADIUS + 2
                && p.getY() > FLOOR_Y - 2
                && p.getY() < CEIL_Y + 2;
    }

    private static boolean isCompass(ItemStack stack) {
        return !stack.isEmpty() && stack.hasTag() && stack.getTag().getBoolean(COMPASS_TAG);
    }

    // ------------------------------------------------------------------ комната

    private static void buildRoom(ServerWorld world) {
        Block floorMark = world.getBlockState(new BlockPos(CX, FLOOR_Y, CZ)).getBlock();
        Block ceilMark = world.getBlockState(new BlockPos(CX, CEIL_Y, CZ)).getBlock();
        Block wallMark = world.getBlockState(new BlockPos(CX + RADIUS, FLOOR_Y + 1, CZ)).getBlock();
        if (floorMark == Blocks.SMOOTH_QUARTZ && ceilMark == Blocks.SMOOTH_QUARTZ && wallMark == Blocks.QUARTZ_BRICKS) {
            return;
        }
        for (int x = CX - RADIUS; x <= CX + RADIUS; x++) {
            for (int z = CZ - RADIUS; z <= CZ + RADIUS; z++) {
                for (int y = FLOOR_Y; y <= CEIL_Y; y++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    boolean edge = Math.abs(x - CX) == RADIUS || Math.abs(z - CZ) == RADIUS;
                    Block block;
                    if (y == FLOOR_Y || y == CEIL_Y) {
                        boolean lamp = Math.abs(x - CX) == 3 && Math.abs(z - CZ) == 3;
                        block = lamp ? Blocks.SEA_LANTERN : Blocks.SMOOTH_QUARTZ;
                    } else if (edge) {
                        block = Blocks.QUARTZ_BRICKS;
                    } else {
                        block = Blocks.AIR;
                    }
                    world.setBlockState(pos, block.getDefaultState());
                }
            }
        }
        // отметки для проверки «комната на месте»
        world.setBlockState(new BlockPos(CX, FLOOR_Y, CZ), Blocks.SMOOTH_QUARTZ.getDefaultState());
        world.setBlockState(new BlockPos(CX, CEIL_Y, CZ), Blocks.SMOOTH_QUARTZ.getDefaultState());
    }

    // ------------------------------------------------------------------ вещи

    private static JsonArray takeItems(ServerPlayerEntity p) {
        JsonArray arr = new JsonArray();
        pack(arr, "main", p.inventory.main);
        pack(arr, "armor", p.inventory.armor);
        pack(arr, "off", p.inventory.offHand);
        return arr;
    }

    private static void pack(JsonArray arr, String part, List<ItemStack> list) {
        for (int i = 0; i < list.size(); i++) {
            ItemStack s = list.get(i);
            if (s.isEmpty()) {
                continue;
            }
            JsonObject o = new JsonObject();
            o.addProperty("part", part);
            o.addProperty("slot", i);
            o.addProperty("id", Registry.ITEM.getId(s.getItem()).toString());
            o.addProperty("count", s.getCount());
            if (s.hasTag()) {
                o.addProperty("tag", s.getTag().toString());
            }
            arr.add(o);
        }
    }

    private static void restoreItems(ServerPlayerEntity p, JsonArray items) {
        for (JsonElement el : items) {
            JsonObject o = el.getAsJsonObject();
            Item item = Registry.ITEM.getOrEmpty(new Identifier(o.get("id").getAsString())).orElse(null);
            if (item == null) {
                continue;
            }
            ItemStack stack = new ItemStack(item, o.get("count").getAsInt());
            if (o.has("tag")) {
                try {
                    stack.setTag(StringNbtReader.parse(o.get("tag").getAsString()));
                } catch (Exception ignored) {
                    // предмет вернётся без тега, лучше так, чем потерять совсем
                }
            }
            int slot = o.get("slot").getAsInt();
            String part = o.get("part").getAsString();
            if (part.equals("main") && slot >= 0 && slot < p.inventory.main.size()) {
                p.inventory.main.set(slot, stack);
            } else if (part.equals("armor") && slot >= 0 && slot < p.inventory.armor.size()) {
                p.inventory.armor.set(slot, stack);
            } else if (part.equals("off") && slot >= 0 && slot < p.inventory.offHand.size()) {
                p.inventory.offHand.set(slot, stack);
            } else {
                p.inventory.offerOrDrop(p.world, stack);
            }
        }
    }

    // ------------------------------------------------------------------ файл состояния

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_hub_state.json");
    }

    private static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, Saved> en : SAVED.entrySet()) {
                Saved s = en.getValue();
                JsonObject o = new JsonObject();
                o.addProperty("dim", s.dim);
                o.addProperty("x", s.x);
                o.addProperty("y", s.y);
                o.addProperty("z", s.z);
                o.addProperty("yaw", s.yaw);
                o.addProperty("pitch", s.pitch);
                o.addProperty("mode", s.mode);
                o.add("items", s.items);
                root.add(en.getKey().toString(), o);
            }
            Files.write(file(), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            System.err.println("[Arsenal] не удалось сохранить состояние хаба: " + e);
        }
    }

    private static void load() {
        SAVED.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> en : root.entrySet()) {
                JsonObject o = en.getValue().getAsJsonObject();
                Saved s = new Saved();
                s.dim = o.get("dim").getAsString();
                s.x = o.get("x").getAsDouble();
                s.y = o.get("y").getAsDouble();
                s.z = o.get("z").getAsDouble();
                s.yaw = o.get("yaw").getAsFloat();
                s.pitch = o.get("pitch").getAsFloat();
                s.mode = o.get("mode").getAsString();
                s.items = o.getAsJsonArray("items");
                SAVED.put(UUID.fromString(en.getKey()), s);
            }
        } catch (Exception e) {
            System.err.println("[Arsenal] не удалось прочитать состояние хаба: " + e);
        }
    }

    private static void say(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(new LiteralText(text).formatted(color), false);
    }
}
