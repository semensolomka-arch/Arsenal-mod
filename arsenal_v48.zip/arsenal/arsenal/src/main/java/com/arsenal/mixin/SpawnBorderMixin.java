package com.arsenal.mixin;

import com.arsenal.spawn.SpawnManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Спавн это безопасная зона: игроки там не получают никакого урона (ни от игроков, ни от эффектов, ни от границы мира,
 * которая лежит ближе спавна). Исключение: команда /kill и пустота (OUT_OF_WORLD).
 */
@Mixin(LivingEntity.class)
public abstract class SpawnBorderMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void arsenal$spawnIsSafe(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        if (self instanceof PlayerEntity && source != DamageSource.OUT_OF_WORLD && SpawnManager.near(self)) {
            cir.setReturnValue(false);
        }
    }
}
