package com.arsenal.mixin;

import com.arsenal.spawn.SpawnManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.EndPortalBlock;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Портал в яме на спавне не ведёт в Энд, а отправляет игрока на /rtp. Настоящие порталы Края работают как обычно. */
@Mixin(EndPortalBlock.class)
public abstract class EndPortalBlockMixin {
    @Inject(method = "onEntityCollision", at = @At("HEAD"), cancellable = true)
    private void arsenal$spawnPortal(BlockState state, World world, BlockPos pos, Entity entity, CallbackInfo ci) {
        if (!SpawnManager.contains(world, pos)) {
            return;
        }
        if (!world.isClient && entity instanceof ServerPlayerEntity) {
            SpawnManager.portal((ServerPlayerEntity) entity);
        }
        ci.cancel();
    }
}
