package com.arsenal.spawn;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Две автошахты на спавне, каждая 15 на 15 блоков и 15 вглубь. Шахта 1 это Обычный мир, шахта 2 каждый раз
 * случайно Ад (незерняк) или Энд (эндерняк). Обновляются раз в 15 минут, но со сдвигом: первая через 5 минут
 * после первого запуска, вторая через 10, дальше каждая со своим шагом 15 минут, поэтому одновременно они не обновляются.
 *
 * Каждое обновление случайно выбирает уровень шахты: обычная, эпическая или легендарная (меньше шлака, больше ценных
 * руд). В легендарной шахте Обычного мира спрятано 2-3 залежи (позолоченный блэкстоун) с взрывчатым веществом, больше
 * нигде оно не встречается. Над шахтами висит табличка из невидимых
 * стоек с названием, временем до обновления и следующей шахтой.
 *
 * Блоки шахты можно ломать (на остальном спавне нельзя), в том числе Буром. Из фиолетовой керамики падает жемчуг Края,
 * из пурпурных блоков плод хоруса. Само обновление выполняется, когда на спавне есть игроки или кто-то телепортируется в шахту.
 */
public final class MineManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final long PERIOD_MS = 15L * 60L * 1000L;
    private static final Random RANDOM = new Random();

    /** Центры шахт относительно центра зала. */
    private static final int[] MINE_DX = {-10, 10};
    private static final int MINE_DZ = 17;
    /** Шахта внутри: от -7 до 7 по x и z, 15 слоёв вглубь от уровня пола. */
    private static final int HALF = 7;
    private static final int DEPTH = 15;

    public enum Realm {
        OVERWORLD("Обычный мир", Formatting.GREEN),
        NETHER("Ад", Formatting.RED),
        END("Энд", Formatting.LIGHT_PURPLE);

        final String title;
        final Formatting color;

        Realm(String title, Formatting color) {
            this.title = title;
            this.color = color;
        }
    }

    public enum Tier {
        COMMON("Обычная", Formatting.WHITE, 70),
        EPIC("Эпическая", Formatting.DARK_PURPLE, 25),
        LEGENDARY("Легендарная", Formatting.GOLD, 5);

        final String title;
        final Formatting color;
        final int weight;

        Tier(String title, Formatting color, int weight) {
            this.title = title;
            this.color = color;
            this.weight = weight;
        }
    }

    private static final class Mine {
        final int id;
        final int cx;
        final int cz;
        Realm realm;
        Tier tier;
        Realm nextRealm;
        Tier nextTier;
        long nextRefresh;
        /** Блоки шахты устарели или ещё не построены. */
        boolean dirty = true;

        Mine(int id, int cx, int cz) {
            this.id = id;
            this.cx = cx;
            this.cz = cz;
        }
    }

    private static final Mine[] MINES = {
            new Mine(1, SpawnManager.CX + MINE_DX[0], SpawnManager.CZ + MINE_DZ),
            new Mine(2, SpawnManager.CX + MINE_DX[1], SpawnManager.CZ + MINE_DZ)
    };

    private static final class Entry {
        final Block block;
        final int weight;

        Entry(Block block, int weight) {
            this.block = block;
            this.weight = weight;
        }
    }

    /** Залежь взрывчатого вещества: при добыче даёт предмет «взрывчатое вещество» (сам блок не падает). */
    private static final Block DEPOSIT = Blocks.GILDED_BLACKSTONE;

    private static int tick;

    private MineManager() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> load());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());
        ServerTickEvents.END_SERVER_TICK.register(MineManager::onTick);

        // особые дропы: фиолетовая керамика даёт жемчуг Края, пурпурные блоки дают плод хоруса
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || player.isCreative() || !isInterior(world, pos)) {
                return true;
            }
            Block b = state.getBlock();
            ItemStack drop;
            if (b == Blocks.PURPLE_TERRACOTTA) {
                drop = new ItemStack(Items.ENDER_PEARL, 1);
            } else if (b == Blocks.PURPUR_BLOCK) {
                drop = new ItemStack(Items.CHORUS_FRUIT, 1 + RANDOM.nextInt(2));
            } else if (b == DEPOSIT) {
                drop = new ItemStack(com.arsenal.blast.Blasts.EXPLOSIVE_SUBSTANCE, 1);
            } else {
                return true;
            }
            world.breakBlock(pos, false);
            Block.dropStack(world, pos, drop);
            ItemStack tool = player.getMainHandStack();
            if (!tool.isEmpty() && player instanceof ServerPlayerEntity) {
                tool.damage(1, (ServerPlayerEntity) player, p -> p.sendToolBreakStatus(Hand.MAIN_HAND));
            }
            return false;
        });
    }

    // ------------------------------------------------------------------ геометрия

    /** Блок внутри любой из шахт (их можно ломать). */
    public static boolean isInterior(World world, BlockPos pos) {
        if (world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        int y = pos.getY();
        if (y > SpawnManager.FLOOR_Y || y <= SpawnManager.FLOOR_Y - DEPTH) {
            return false;
        }
        for (Mine m : MINES) {
            if (Math.abs(pos.getX() - m.cx) <= HALF && Math.abs(pos.getZ() - m.cz) <= HALF) {
                return true;
            }
        }
        return false;
    }

    public static int centerX(int mineId) {
        return MINES[mineId - 1].cx;
    }

    public static int centerZ(int mineId) {
        return MINES[mineId - 1].cz;
    }

    /** Центры шахт относительно центра зала нужны постройке стенок. */
    public static int mineDx(int mineId) {
        return MINE_DX[mineId - 1];
    }

    public static int mineDz() {
        return MINE_DZ;
    }

    /** Зал перестроен: блоки шахт нужно набрать заново. */
    public static void invalidate() {
        for (Mine m : MINES) {
            m.dirty = true;
        }
    }

    // ------------------------------------------------------------------ расписание

    private static Tier rollTier() {
        int total = 0;
        for (Tier t : Tier.values()) {
            total += t.weight;
        }
        int r = RANDOM.nextInt(total);
        for (Tier t : Tier.values()) {
            r -= t.weight;
            if (r < 0) {
                return t;
            }
        }
        return Tier.COMMON;
    }

    private static Realm rollRealm(Mine m) {
        if (m.id == 1) {
            return Realm.OVERWORLD;
        }
        return RANDOM.nextBoolean() ? Realm.NETHER : Realm.END;
    }

    private static void rollNext(Mine m) {
        m.nextRealm = rollRealm(m);
        m.nextTier = rollTier();
    }

    private static void advance(Mine m, long now) {
        m.realm = m.nextRealm;
        m.tier = m.nextTier;
        rollNext(m);
        while (m.nextRefresh <= now) {
            m.nextRefresh += PERIOD_MS;
        }
        m.dirty = true;
    }

    private static void fresh(long now) {
        for (Mine m : MINES) {
            m.realm = rollRealm(m);
            m.tier = rollTier();
            rollNext(m);
            m.dirty = true;
        }
        // сдвиг: первая шахта обновится через 5 минут, вторая через 10
        MINES[0].nextRefresh = now + 5L * 60L * 1000L;
        MINES[1].nextRefresh = now + 10L * 60L * 1000L;
    }

    // ------------------------------------------------------------------ тик

    private static void onTick(MinecraftServer server) {
        tick++;
        if (tick % 20 != 0) {
            return;
        }
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Mine m : MINES) {
            if (m.realm == null) {
                fresh(now);
                changed = true;
                break;
            }
            if (now >= m.nextRefresh) {
                advance(m, now);
                changed = true;
            }
        }
        ServerWorld ow = server.getOverworld();
        boolean anyone = false;
        for (ServerPlayerEntity p : ow.getPlayers()) {
            if (SpawnManager.near(p)) {
                anyone = true;
                break;
            }
        }
        if (anyone) {
            for (Mine m : MINES) {
                if (m.dirty) {
                    regenerate(ow, m);
                    changed = true;
                }
                updateHolograms(ow, m, now);
            }
        }
        if (changed) {
            save();
        }
    }

    /** Перед телепортом в шахту: если блоки устарели, обновить сейчас. */
    public static void ensureFresh(ServerWorld ow, int mineId) {
        Mine m = MINES[mineId - 1];
        if (m.realm == null) {
            fresh(System.currentTimeMillis());
        }
        if (m.dirty) {
            regenerate(ow, m);
            save();
        }
    }

    // ------------------------------------------------------------------ постройка шахты

    private static Entry[] table(Realm realm, Tier tier) {
        switch (realm) {
            case NETHER:
                switch (tier) {
                    case LEGENDARY:
                        return new Entry[]{e(Blocks.NETHERRACK, 200), e(Blocks.NETHER_BRICKS, 100),
                                e(Blocks.NETHER_GOLD_ORE, 360), e(Blocks.NETHER_QUARTZ_ORE, 340)};
                    case EPIC:
                        return new Entry[]{e(Blocks.NETHERRACK, 380), e(Blocks.NETHER_BRICKS, 120),
                                e(Blocks.NETHER_GOLD_ORE, 260), e(Blocks.NETHER_QUARTZ_ORE, 240)};
                    default:
                        return new Entry[]{e(Blocks.NETHERRACK, 600), e(Blocks.NETHER_BRICKS, 120),
                                e(Blocks.NETHER_GOLD_ORE, 160), e(Blocks.NETHER_QUARTZ_ORE, 120)};
                }
            case END:
                switch (tier) {
                    case LEGENDARY:
                        return new Entry[]{e(Blocks.END_STONE, 220), e(Blocks.OBSIDIAN, 160),
                                e(Blocks.PURPUR_BLOCK, 310), e(Blocks.PURPLE_TERRACOTTA, 310)};
                    case EPIC:
                        return new Entry[]{e(Blocks.END_STONE, 400), e(Blocks.OBSIDIAN, 120),
                                e(Blocks.PURPUR_BLOCK, 240), e(Blocks.PURPLE_TERRACOTTA, 240)};
                    default:
                        return new Entry[]{e(Blocks.END_STONE, 600), e(Blocks.OBSIDIAN, 80),
                                e(Blocks.PURPUR_BLOCK, 160), e(Blocks.PURPLE_TERRACOTTA, 160)};
                }
            default:
                switch (tier) {
                    case LEGENDARY:
                        return new Entry[]{e(Blocks.STONE, 130), e(Blocks.COAL_ORE, 60), e(Blocks.IRON_ORE, 180),
                                e(Blocks.GOLD_ORE, 150), e(Blocks.REDSTONE_ORE, 100), e(Blocks.LAPIS_ORE, 100),
                                e(Blocks.DIAMOND_ORE, 180), e(Blocks.EMERALD_ORE, 100)};
                    case EPIC:
                        return new Entry[]{e(Blocks.STONE, 325), e(Blocks.COAL_ORE, 90), e(Blocks.IRON_ORE, 170),
                                e(Blocks.GOLD_ORE, 100), e(Blocks.REDSTONE_ORE, 80), e(Blocks.LAPIS_ORE, 70),
                                e(Blocks.DIAMOND_ORE, 110), e(Blocks.EMERALD_ORE, 55)};
                    default:
                        return new Entry[]{e(Blocks.STONE, 580), e(Blocks.COAL_ORE, 120), e(Blocks.IRON_ORE, 140),
                                e(Blocks.GOLD_ORE, 50), e(Blocks.REDSTONE_ORE, 40), e(Blocks.LAPIS_ORE, 40),
                                e(Blocks.DIAMOND_ORE, 24), e(Blocks.EMERALD_ORE, 6)};
                }
        }
    }

    private static Entry e(Block block, int weight) {
        return new Entry(block, weight);
    }

    private static Block pick(Entry[] table) {
        int total = 0;
        for (Entry en : table) {
            total += en.weight;
        }
        int r = RANDOM.nextInt(total);
        for (Entry en : table) {
            r -= en.weight;
            if (r < 0) {
                return en.block;
            }
        }
        return table[0].block;
    }

    private static void regenerate(ServerWorld ow, Mine m) {
        int floor = SpawnManager.FLOOR_Y;
        // игроков, которые стоят в шахте, поднимаем на поверхность
        for (ServerPlayerEntity p : new ArrayList<>(ow.getPlayers())) {
            if (Math.abs(p.getX() - (m.cx + 0.5)) <= HALF + 1 && Math.abs(p.getZ() - (m.cz + 0.5)) <= HALF + 1
                    && p.getY() < floor + 3 && p.getY() > floor - DEPTH - 2) {
                p.teleport(ow, p.getX(), floor + 1.0, p.getZ(), p.yaw, p.pitch);
                p.fallDistance = 0.0F;
            }
        }
        Entry[] table = table(m.realm, m.tier);
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int dy = 0; dy < DEPTH; dy++) {
                    ow.setBlockState(new BlockPos(m.cx + dx, floor - dy, m.cz + dz), pick(table).getDefaultState(), 18);
                }
            }
        }
        // в легендарной шахте Обычного мира спрятано 2-3 залежи взрывчатого вещества (не в верхних слоях)
        if (m.realm == Realm.OVERWORLD && m.tier == Tier.LEGENDARY) {
            int count = 2 + RANDOM.nextInt(2);
            for (int i = 0; i < count; i++) {
                int dx = RANDOM.nextInt(2 * HALF + 1) - HALF;
                int dz = RANDOM.nextInt(2 * HALF + 1) - HALF;
                int dy = 2 + RANDOM.nextInt(DEPTH - 2);
                ow.setBlockState(new BlockPos(m.cx + dx, floor - dy, m.cz + dz), DEPOSIT.getDefaultState(), 18);
            }
        }
        m.dirty = false;
        Text msg = new LiteralText("Автошахта " + m.id + " обновилась: " + m.realm.title + ", " + m.tier.title.toLowerCase())
                .formatted(Formatting.YELLOW);
        for (ServerPlayerEntity p : ow.getPlayers()) {
            if (SpawnManager.near(p)) {
                p.sendMessage(msg, true);
            }
        }
    }

    // ------------------------------------------------------------------ голограммы

    private static String clock(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    private static Text[] lines(Mine m, long now) {
        Text title = new LiteralText("АВТОШАХТА " + m.id).formatted(Formatting.GOLD, Formatting.BOLD);
        Text current = new LiteralText(m.realm.title).formatted(m.realm.color)
                .append(new LiteralText(" · ").formatted(Formatting.GRAY))
                .append(new LiteralText(m.tier.title).formatted(m.tier.color, Formatting.BOLD));
        Text timer = new LiteralText("Обновление через " + clock(m.nextRefresh - now)).formatted(Formatting.YELLOW);
        Text next = new LiteralText("Следующая: ").formatted(Formatting.GRAY)
                .append(new LiteralText(m.nextRealm.title).formatted(m.nextRealm.color))
                .append(new LiteralText(" · ").formatted(Formatting.GRAY))
                .append(new LiteralText(m.nextTier.title).formatted(m.nextTier.color));
        return new Text[]{title, current, timer, next};
    }

    private static void updateHolograms(ServerWorld ow, Mine m, long now) {
        BlockPos probe = new BlockPos(m.cx, SpawnManager.FLOOR_Y, m.cz);
        if (!ow.isChunkLoaded(probe)) {
            return;
        }
        Text[] lines = lines(m, now);
        Box box = new Box(m.cx - 3, SpawnManager.FLOOR_Y, m.cz - 3, m.cx + 4, SpawnManager.FLOOR_Y + 8, m.cz + 4);
        for (int i = 0; i < lines.length; i++) {
            final String tag = "arsenal_mine" + m.id + "_line" + i;
            List<ArmorStandEntity> found = ow.getEntitiesByClass(ArmorStandEntity.class, box,
                    s -> s.getScoreboardTags().contains(tag));
            ArmorStandEntity stand;
            if (found.isEmpty()) {
                // стойка: имя отображается примерно на 2.5 блока выше её основания
                double y = SpawnManager.FLOOR_Y + 2.9 - 0.3 * i;
                stand = new ArmorStandEntity(ow, m.cx + 0.5, y, m.cz + 0.5);
                stand.setInvisible(true);
                stand.setNoGravity(true);
                stand.setInvulnerable(true);
                stand.setCustomNameVisible(true);
                stand.addScoreboardTag(tag);
                stand.setCustomName(lines[i]);
                ow.spawnEntity(stand);
                continue;
            }
            stand = found.get(0);
            for (int k = 1; k < found.size(); k++) {
                found.get(k).remove();
            }
            Text old = stand.getCustomName();
            if (old == null || !Text.Serializer.toJson(old).equals(Text.Serializer.toJson(lines[i]))) {
                stand.setCustomName(lines[i]);
            }
        }
    }

    // ------------------------------------------------------------------ файл состояния

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_mines.json");
    }

    private static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Mine m : MINES) {
                if (m.realm == null) {
                    continue;
                }
                JsonObject o = new JsonObject();
                o.addProperty("realm", m.realm.name());
                o.addProperty("tier", m.tier.name());
                o.addProperty("nextRealm", m.nextRealm.name());
                o.addProperty("nextTier", m.nextTier.name());
                o.addProperty("nextRefresh", m.nextRefresh);
                o.addProperty("dirty", m.dirty);
                root.add("mine" + m.id, o);
            }
            Files.write(file(), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось сохранить автошахты: " + ex);
        }
    }

    private static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Mine m : MINES) {
                if (!root.has("mine" + m.id)) {
                    continue;
                }
                JsonObject o = root.getAsJsonObject("mine" + m.id);
                m.realm = Realm.valueOf(o.get("realm").getAsString());
                m.tier = Tier.valueOf(o.get("tier").getAsString());
                m.nextRealm = Realm.valueOf(o.get("nextRealm").getAsString());
                m.nextTier = Tier.valueOf(o.get("nextTier").getAsString());
                m.nextRefresh = o.get("nextRefresh").getAsLong();
                m.dirty = o.get("dirty").getAsBoolean();
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать автошахты: " + ex);
        }
    }
}
