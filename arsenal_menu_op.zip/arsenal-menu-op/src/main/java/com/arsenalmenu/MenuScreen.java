package com.arsenalmenu;

import com.arsenalmenu.ArsenalMenuClient.Entry;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Экран настроек Arsenal: строки "название [-] значение [+] [R]", поиск и страницы. */
public final class MenuScreen extends Screen {
    private static final int ROW_H = 22;
    private static final int TOP = 50;

    /** Значения, которые ещё не ушли на сервер (ключ -> число). */
    private final Map<String, Integer> pending = new LinkedHashMap<>();
    private final List<Entry> filtered = new ArrayList<>();
    private String filter = "";
    private int page;
    private int rows = 6;
    private int ticks;

    private TextFieldWidget search;
    private ButtonWidget[] minus;
    private ButtonWidget[] valueBtn;
    private ButtonWidget[] plus;
    private ButtonWidget[] reset;
    private ButtonWidget prev;
    private ButtonWidget next;

    private final Screen parent;

    public MenuScreen(Screen parent) {
        super(new LiteralText("Arsenal: настройки"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        rows = Math.max(3, Math.min(14, (this.height - TOP - 62) / ROW_H));
        int cx = this.width / 2;
        int left = cx - 190;

        search = new TextFieldWidget(this.textRenderer, cx - 100, 24, 200, 18, new LiteralText("Поиск"));
        search.setText(filter);
        search.setChangedListener(s -> {
            filter = s.toLowerCase(Locale.ROOT).trim();
            page = 0;
            rebuild();
        });
        this.addChild(search);
        this.setInitialFocus(search);

        minus = new ButtonWidget[rows];
        valueBtn = new ButtonWidget[rows];
        plus = new ButtonWidget[rows];
        reset = new ButtonWidget[rows];
        for (int r = 0; r < rows; r++) {
            final int row = r;
            int y = TOP + r * ROW_H;
            minus[r] = this.addButton(new ButtonWidget(cx + 20, y, 20, 20, new LiteralText("-"), b -> change(row, -1)));
            valueBtn[r] = this.addButton(new ButtonWidget(cx + 42, y, 76, 20, new LiteralText(""), b -> {
            }));
            valueBtn[r].active = false;
            plus[r] = this.addButton(new ButtonWidget(cx + 120, y, 20, 20, new LiteralText("+"), b -> change(row, 1)));
            reset[r] = this.addButton(new ButtonWidget(cx + 142, y, 48, 20, new LiteralText("Сброс"), b -> setDefault(row)));
        }
        int fy = this.height - 28;
        prev = this.addButton(new ButtonWidget(cx - 150, fy, 60, 20, new LiteralText("< Назад"), b -> {
            page--;
            refreshRows();
        }));
        next = this.addButton(new ButtonWidget(cx - 85, fy, 60, 20, new LiteralText("Вперёд >"), b -> {
            page++;
            refreshRows();
        }));
        this.addButton(new ButtonWidget(cx + 90, fy, 60, 20, new LiteralText("Закрыть"), b -> this.onClose()));
        // left нужен только для расчёта подписи (см. render)
        this.leftEdge = left;
        ArsenalMenuClient.requestData();
        rebuild();
    }

    private int leftEdge;

    /** Сервер прислал свежие цифры. */
    void onData() {
        for (Entry e : ArsenalMenuClient.entries) {
            Integer p = pending.get(e.key);
            if (p != null) {
                e.value = p;
            }
        }
        rebuild();
    }

    private void rebuild() {
        filtered.clear();
        for (Entry e : ArsenalMenuClient.entries) {
            if (filter.isEmpty() || e.key.toLowerCase(Locale.ROOT).contains(filter)
                    || e.label.toLowerCase(Locale.ROOT).contains(filter)) {
                filtered.add(e);
            }
        }
        refreshRows();
    }

    private int pages() {
        return Math.max(1, (filtered.size() + rows - 1) / rows);
    }

    private void refreshRows() {
        if (minus == null) {
            return;
        }
        page = Math.max(0, Math.min(page, pages() - 1));
        for (int r = 0; r < rows; r++) {
            int idx = page * rows + r;
            boolean has = idx < filtered.size();
            minus[r].visible = has;
            valueBtn[r].visible = has;
            plus[r].visible = has;
            reset[r].visible = has;
            if (has) {
                Entry e = filtered.get(idx);
                Text t = new LiteralText(e.value + " " + e.unit);
                valueBtn[r].setMessage(e.value != e.def ? ((LiteralText) t).formatted(Formatting.YELLOW) : t);
                minus[r].active = e.value > e.min;
                plus[r].active = e.value < e.max;
                reset[r].active = e.value != e.def;
            }
        }
        prev.active = page > 0;
        next.active = page < pages() - 1;
    }

    private Entry entryAt(int row) {
        int idx = page * rows + row;
        return idx < filtered.size() ? filtered.get(idx) : null;
    }

    private void change(int row, int dir) {
        Entry e = entryAt(row);
        if (e == null) {
            return;
        }
        int step = hasControlDown() ? 100 : hasShiftDown() ? 10 : 1;
        set(e, e.value + dir * step);
    }

    private void setDefault(int row) {
        Entry e = entryAt(row);
        if (e != null) {
            set(e, e.def);
        }
    }

    private void set(Entry e, int v) {
        e.value = Math.max(e.min, Math.min(e.max, v));
        pending.put(e.key, e.value);
        refreshRows();
    }

    private void flush() {
        if (pending.isEmpty()) {
            return;
        }
        for (Map.Entry<String, Integer> p : pending.entrySet()) {
            ArsenalMenuClient.sendValue(p.getKey(), p.getValue());
        }
        pending.clear();
    }

    @Override
    public void tick() {
        super.tick();
        if (search != null) {
            search.tick();
        }
        ticks++;
        if (ticks % 5 == 0) {
            flush();
        }
        if (ArsenalMenuClient.entries.isEmpty() && ticks % 40 == 0) {
            ArsenalMenuClient.requestData();
        }
    }

    @Override
    public void onClose() {
        flush();
        this.client.openScreen(parent);
    }

    @Override
    public void removed() {
        flush();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        int cx = this.width / 2;
        String title = "Arsenal: настройки сервера";
        this.textRenderer.drawWithShadow(m, title, cx - this.textRenderer.getWidth(title) / 2f, 8, 0xFFFFFF);
        search.render(m, mouseX, mouseY, delta);
        if (search.getText().isEmpty() && !search.isFocused()) {
            this.textRenderer.drawWithShadow(m, "Поиск...", cx - 96, 29, 0x777777);
        }
        super.render(m, mouseX, mouseY, delta);

        if (ArsenalMenuClient.entries.isEmpty()) {
            String s = "Жду данные от сервера. Нужны права оператора и мод Arsenal на сервере.";
            this.textRenderer.drawWithShadow(m, s, cx - this.textRenderer.getWidth(s) / 2f, TOP + 20, 0xFFAA55);
        } else if (filtered.isEmpty()) {
            String s = "Ничего не найдено";
            this.textRenderer.drawWithShadow(m, s, cx - this.textRenderer.getWidth(s) / 2f, TOP + 20, 0xAAAAAA);
        }

        String hover = null;
        for (int r = 0; r < rows; r++) {
            Entry e = entryAt(r);
            if (e == null) {
                continue;
            }
            int y = TOP + r * ROW_H;
            int color = e.value != e.def ? 0xFFFF55 : 0xFFFFFF;
            String shown = this.textRenderer.trimToWidth(e.label, 205);
            this.textRenderer.drawWithShadow(m, shown, leftEdge, y + 6, color);
            if (mouseY >= y && mouseY < y + 20 && mouseX >= leftEdge && mouseX < cx + 15) {
                hover = e.label + "   [" + e.key + "]  по умолчанию " + e.def + ", границы " + e.min + ".." + e.max;
            }
        }
        int fy = this.height - 28;
        String pg = (page + 1) + " / " + pages() + "  (" + filtered.size() + ")";
        this.textRenderer.drawWithShadow(m, pg, cx - 15, fy + 6, 0xFFFFFF);
        String help = hover != null ? hover : "Shift: шаг 10, Ctrl: шаг 100. Жёлтым выделено то, что отличается от стандарта.";
        this.textRenderer.drawWithShadow(m, this.textRenderer.trimToWidth(help, this.width - 20), 10, fy - 14,
                hover != null ? 0xFFFF55 : 0x999999);
    }
}
