package com.arsenalmenu;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

/** Разделы скупщика: название (правится прямо тут), открыть список предметов, удалить, добавить раздел. */
public final class SectionsScreen extends Screen {
    private final Screen parent;
    private final JsonArray sections;
    private int page;
    private int rows = 6;
    private boolean loading;
    private TextFieldWidget[] titles;
    private ButtonWidget[] open;
    private ButtonWidget[] del;
    private ButtonWidget prev;
    private ButtonWidget next;

    public SectionsScreen(Screen parent, JsonArray sections) {
        super(new LiteralText("Скупщик: разделы"));
        this.parent = parent;
        this.sections = sections;
    }

    @Override
    protected void init() {
        rows = Math.max(3, Math.min(12, (this.height - 90) / 24));
        int cx = this.width / 2;
        int left = cx - 150;
        titles = new TextFieldWidget[rows];
        open = new ButtonWidget[rows];
        del = new ButtonWidget[rows];
        for (int r = 0; r < rows; r++) {
            final int row = r;
            int y = 30 + r * 24;
            titles[r] = new TextFieldWidget(this.textRenderer, left, y + 1, 170, 18, new LiteralText(""));
            titles[r].setMaxLength(40);
            titles[r].setChangedListener(s -> {
                if (loading) {
                    return;
                }
                JsonObject sec = sectionAt(row);
                if (sec != null) {
                    sec.addProperty("title", s);
                    Store.markDirty(Store.BUYER);
                }
            });
            this.addChild(titles[r]);
            open[r] = this.addButton(new ButtonWidget(left + 176, y, 70, 20, new LiteralText("Открыть"), b -> openSection(row)));
            del[r] = this.addButton(new ButtonWidget(left + 250, y, 20, 20, new LiteralText("x"), b -> {
                int idx = page * rows + row;
                if (idx < sections.size()) {
                    sections.remove(idx);
                    Store.markDirty(Store.BUYER);
                    refresh();
                }
            }));
        }
        int fy = this.height - 28;
        prev = this.addButton(new ButtonWidget(cx - 190, fy, 40, 20, new LiteralText("<"), b -> {
            page--;
            refresh();
        }));
        next = this.addButton(new ButtonWidget(cx - 146, fy, 40, 20, new LiteralText(">"), b -> {
            page++;
            refresh();
        }));
        this.addButton(new ButtonWidget(cx - 100, fy, 110, 20, new LiteralText("+ Новый раздел"), b -> {
            JsonObject s = new JsonObject();
            s.addProperty("title", "Новый раздел");
            s.addProperty("icon", "minecraft:chest");
            s.add("items", new JsonArray());
            sections.add(s);
            Store.markDirty(Store.BUYER);
            page = Integer.MAX_VALUE / 2;
            refresh();
        }));
        this.addButton(new ButtonWidget(cx + 14, fy, 70, 20, new LiteralText("Сохранить"), b -> Store.save(Store.BUYER)));
        this.addButton(new ButtonWidget(cx + 88, fy, 60, 20, new LiteralText("Назад"), b -> this.onClose()));
        refresh();
    }

    private JsonObject sectionAt(int row) {
        int idx = page * rows + row;
        return idx < sections.size() ? sections.get(idx).getAsJsonObject() : null;
    }

    private void refresh() {
        int pages = Math.max(1, (sections.size() + rows - 1) / rows);
        page = Math.max(0, Math.min(page, pages - 1));
        loading = true;
        for (int r = 0; r < rows; r++) {
            JsonObject s = sectionAt(r);
            titles[r].setVisible(s != null);
            open[r].visible = s != null;
            del[r].visible = s != null;
            if (s != null) {
                titles[r].setText(s.has("title") ? s.get("title").getAsString() : "");
            }
        }
        loading = false;
        prev.active = page > 0;
        next.active = page < pages - 1;
    }

    private void openSection(int row) {
        JsonObject s = sectionAt(row);
        if (s == null) {
            return;
        }
        if (!s.has("items") || !s.get("items").isJsonArray()) {
            s.add("items", new JsonArray());
        }
        String title = s.has("title") ? s.get("title").getAsString() : "Раздел";
        this.client.openScreen(new ListScreen(this, "Скупщик: " + title, Store.BUYER, s.getAsJsonArray("items"),
                new ListScreen.Col[]{new ListScreen.Col("price", "Цена", 0, null)},
                e -> Catalog.keyName(e.has("key") ? e.get("key").getAsString() : "?"), Catalog.Mode.BUYER, it -> {
            JsonObject o = new JsonObject();
            o.addProperty("key", it.buyerKey);
            o.addProperty("price", 1);
            return o;
        }));
    }

    @Override
    public void tick() {
        super.tick();
        if (titles != null) {
            for (TextFieldWidget t : titles) {
                t.tick();
            }
        }
    }

    @Override
    public void onClose() {
        Store.saveIfDirty(Store.BUYER);
        this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        int cx = this.width / 2;
        String t = "Скупщик: разделы (название можно править)";
        this.textRenderer.drawWithShadow(m, t, cx - this.textRenderer.getWidth(t) / 2f, 12, 0xFFFFFF);
        super.render(m, mouseX, mouseY, delta);
        for (int r = 0; r < rows; r++) {
            if (sectionAt(r) != null) {
                titles[r].render(m, mouseX, mouseY, delta);
            }
        }
    }
}
