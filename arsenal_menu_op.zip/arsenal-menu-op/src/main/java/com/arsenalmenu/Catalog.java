package com.arsenalmenu;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Каталог предметов для выбора (ваниль генерируется здесь, предметы мода присылает сервер) и названия записей. */
public final class Catalog {
    public enum Mode { CARGO, BUYER, BLOCK }

    /** Один вариант в окне выбора. */
    public static final class Item2 {
        public final String name;
        public final String lower;
        public final JsonObject cargo;
        public final String buyerKey;
        public final String blockId;

        Item2(String name, String extraSearch, JsonObject cargo, String buyerKey, String blockId) {
            this.name = name;
            this.lower = (name + " " + extraSearch).toLowerCase(Locale.ROOT);
            this.cargo = cargo;
            this.buyerKey = buyerKey;
            this.blockId = blockId;
        }
    }

    /** Предметы мода от сервера. */
    public static volatile List<Item2> serverItems = new ArrayList<>();
    private static final Map<String, String> NAMES_BY_IDENTITY = new HashMap<>();
    private static final Map<String, String> NAMES_BY_KEY = new HashMap<>();
    private static List<Item2> vanilla;

    private Catalog() {
    }

    static void setServerItems(List<Item2> list) {
        serverItems = list;
        NAMES_BY_IDENTITY.clear();
        NAMES_BY_KEY.clear();
        for (Item2 it : list) {
            if (it.cargo != null) {
                NAMES_BY_IDENTITY.put(identity(it.cargo), it.name);
            }
            if (it.buyerKey != null && !it.buyerKey.isEmpty()) {
                NAMES_BY_KEY.put(it.buyerKey, it.name);
            }
        }
    }

    // ------------------------------------------------------------------ названия

    public static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 1 && n < r.length ? r[n] : String.valueOf(n);
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) ? o.get(k).getAsString() : null;
    }

    /** Тот же "ключ записи", что считает сервер (MenuBridge.identity). */
    public static String identity(JsonObject o) {
        if (o.has("kit")) {
            return "kit:" + str(o, "kit") + ":" + str(o, "part");
        }
        StringBuilder sb = new StringBuilder(str(o, "item"));
        if (o.has("potion")) {
            sb.append('#').append(str(o, "potion"));
        }
        if (o.has("enchantment")) {
            sb.append("|ench:").append(str(o, "enchantment"));
        }
        if (o.has("effects")) {
            sb.append("|fx:").append(str(o, "effects").trim());
        }
        return sb.toString();
    }

    private static String enchantName(String id) {
        Enchantment e = Registry.ENCHANTMENT.getOrEmpty(new Identifier(id)).orElse(null);
        if (e != null) {
            return new TranslatableText(e.getTranslationKey()).getString();
        }
        int i = id.indexOf(':');
        return i >= 0 ? id.substring(i + 1) : id;
    }

    private static String potionLabel(ItemStack stack, Potion p) {
        String n = stack.getName().getString();
        List<StatusEffectInstance> ef = p.getEffects();
        if (!ef.isEmpty()) {
            StatusEffectInstance e = ef.get(0);
            n += " " + roman(e.getAmplifier() + 1);
            if (!e.getEffectType().isInstant()) {
                int sec = e.getDuration() / 20;
                n += " " + (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60);
            }
            if (ef.size() > 1) {
                n += " [" + Registry.POTION.getId(p).getPath() + "]";
            }
        }
        return n;
    }

    private static String potionName(String itemId, String potionId) {
        Item item = Registry.ITEM.getOrEmpty(new Identifier(itemId)).orElse(null);
        Potion p = Registry.POTION.getOrEmpty(new Identifier(potionId)).orElse(null);
        if (item == null || p == null) {
            return itemId + "#" + potionId;
        }
        ItemStack st = new ItemStack(item);
        PotionUtil.setPotion(st, p);
        return potionLabel(st, p);
    }

    private static String itemName(String id) {
        Item item = Registry.ITEM.getOrEmpty(new Identifier(id)).orElse(null);
        if (item == null || item == Items.AIR) {
            return id;
        }
        return new ItemStack(item).getName().getString();
    }

    /** Название записи лута. */
    public static String cargoName(JsonObject e) {
        try {
            String idn = identity(e);
            String known = NAMES_BY_IDENTITY.get(idn);
            String name;
            if (known != null) {
                name = known;
            } else if (e.has("enchantment")) {
                StringBuilder lv = new StringBuilder();
                if (e.has("levels")) {
                    for (JsonElement l : e.getAsJsonArray("levels")) {
                        lv.append(lv.length() > 0 ? "/" : "").append(roman(l.getAsInt()));
                    }
                }
                name = "Книга: " + enchantName(str(e, "enchantment")) + (lv.length() > 0 ? " " + lv : "");
            } else if (e.has("potion")) {
                name = potionName(str(e, "item"), str(e, "potion"));
            } else if (e.has("item")) {
                name = itemName(str(e, "item"));
                if (e.has("effects")) {
                    name += " [" + str(e, "effects") + "]";
                }
            } else {
                name = idn;
            }
            if (e.has("enchants")) {
                name += " +чары";
            }
            return name;
        } catch (Exception ex) {
            return "?";
        }
    }

    /** Название по ключу скупщика: "minecraft:diamond", "minecraft:potion#minecraft:strong_healing", "kit:wither:helmet". */
    public static String keyName(String key) {
        String known = NAMES_BY_KEY.get(key);
        if (known != null) {
            return known;
        }
        int hash = key.indexOf('#');
        if (hash >= 0) {
            return potionName(key.substring(0, hash), key.substring(hash + 1));
        }
        return itemName(key);
    }

    public static String blockName(String id) {
        Block b = Registry.BLOCK.getOrEmpty(new Identifier(id)).orElse(null);
        return b == null ? id : b.getName().getString();
    }

    // ------------------------------------------------------------------ списки для выбора

    private static JsonObject tpl(String itemId) {
        JsonObject o = new JsonObject();
        o.addProperty("item", itemId);
        o.addProperty("min", 1);
        o.addProperty("max", 1);
        o.addProperty("weight", 10);
        return o;
    }

    private static List<Item2> buildVanilla() {
        List<Item2> out = new ArrayList<>();
        Set<String> skip = new HashSet<>();
        skip.add("potion");
        skip.add("splash_potion");
        skip.add("lingering_potion");
        skip.add("tipped_arrow");
        skip.add("enchanted_book");
        skip.add("air");
        for (Item it : Registry.ITEM) {
            Identifier id = Registry.ITEM.getId(it);
            if (skip.contains(id.getPath())) {
                continue;
            }
            out.add(new Item2(new ItemStack(it).getName().getString(), id.toString(), tpl(id.toString()), id.toString(), null));
        }
        String[] potionItems = {"potion", "splash_potion", "lingering_potion", "tipped_arrow"};
        for (Potion p : Registry.POTION) {
            if (p.getEffects().isEmpty()) {
                continue;
            }
            String pid = Registry.POTION.getId(p).toString();
            for (String pi : potionItems) {
                Item item = Registry.ITEM.get(new Identifier("minecraft", pi));
                ItemStack st = new ItemStack(item);
                PotionUtil.setPotion(st, p);
                JsonObject c = tpl("minecraft:" + pi);
                c.addProperty("potion", pid);
                out.add(new Item2(potionLabel(st, p), "minecraft:" + pi + " " + pid, c, "minecraft:" + pi + "#" + pid, null));
            }
        }
        for (Enchantment e : Registry.ENCHANTMENT) {
            String eid = Registry.ENCHANTMENT.getId(e).toString();
            for (int lvl = Math.max(1, e.getMinLevel()); lvl <= e.getMaxLevel(); lvl++) {
                JsonObject c = tpl("minecraft:enchanted_book");
                c.addProperty("enchantment", eid);
                JsonArray levels = new JsonArray();
                levels.add(lvl);
                c.add("levels", levels);
                out.add(new Item2("Книга: " + enchantName(eid) + " " + roman(lvl), eid + " книга", c, null, null));
            }
        }
        return out;
    }

    public static List<Item2> forMode(Mode mode) {
        List<Item2> out = new ArrayList<>();
        if (mode == Mode.BLOCK) {
            for (Block b : Registry.BLOCK) {
                if (b == Blocks.AIR) {
                    continue;
                }
                String id = Registry.BLOCK.getId(b).toString();
                out.add(new Item2(b.getName().getString(), id, null, null, id));
            }
        } else {
            if (vanilla == null) {
                vanilla = buildVanilla();
            }
            List<Item2> all = new ArrayList<>(serverItems);
            all.addAll(vanilla);
            for (Item2 it : all) {
                if (mode == Mode.CARGO ? it.cargo != null : it.buyerKey != null && !it.buyerKey.isEmpty()) {
                    out.add(it);
                }
            }
        }
        out.sort(Comparator.comparing(i -> i.name));
        return out;
    }
}
