package com.arsenalmenu;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Редактор списка записей (лут, цены, шахты): название, числовые поля, удаление, добавление через выбор предмета. */
public final class ListScreen extends Screen {
    public static final class Col {
        final String key;
        final String label;
        final int def;
        /** Если поля нет в записи, показывать значение этого поля (например, max = min). */
        final String fallbackKey;

        public Col(String key, String label, int def, String fallbackKey) {
            this.key = key;
            this.label = label;
            this.def = def;
            this.fallbackKey = fallbackKey;
        }
    }

    public interface NameFn {
        String name(JsonObject entry);
    }

    public interface Maker {
        JsonObject make(Catalog.Item2 item);
    }

    private static final int ROW_H = 22;
    private static final int TOP = 50;
    private static final int COL_W = 46;

    private final Screen parent;
    private final String heading;
    private final String file;
    private final JsonArray array;
    private final Col[] cols;
    private final NameFn nameFn;
    private final Catalog.Mode mode;
    private final Maker maker;
    private final List<Integer> view = new ArrayList<>();
    private String filter = "";
    private int page;
    private int rows = 8;
    private int left;
    private int nameW;
    private boolean loading;
    private TextFieldWidget search;
    private TextFieldWidget[][] fields;
    private ButtonWidget[] del;
    private ButtonWidget prev;
    private ButtonWidget next;

    public ListScreen(Screen parent, String heading, String file, JsonArray array, Col[] cols, NameFn nameFn,
                      Catalog.Mode mode, Maker maker) {
        super(new LiteralText(heading));
        this.parent = parent;
        this.heading = heading;
        this.file = file;
        this.array = array;
        this.cols = cols;
        this.nameFn = nameFn;
        this.mode = mode;
        this.maker = maker;
    }

    @Override
    protected void init() {
        rows = Math.max(3, Math.min(16, (this.height - TOP - 56) / ROW_H));
        int colsW = cols.length * (COL_W + 4);
        nameW = Math.min(210, this.width - 20 - colsW - 26);
        int total = nameW + 4 + colsW + 22;
        left = (this.width - total) / 2;

        search = new TextFieldWidget(this.textRenderer, left, 22, Math.min(total, 220), 18, new LiteralText("Поиск"));
        search.setMaxLength(60);
        search.setText(filter);
        search.setChangedListener(s -> {
            filter = s.toLowerCase(Locale.ROOT).trim();
            page = 0;
            rebuild();
        });
        this.addChild(search);

        fields = new TextFieldWidget[rows][cols.length];
        del = new ButtonWidget[rows];
        for (int r = 0; r < rows; r++) {
            final int row = r;
            int y = TOP + r * ROW_H;
            for (int c = 0; c < cols.length; c++) {
                final int col = c;
                TextFieldWidget f = new TextFieldWidget(this.textRenderer, left + nameW + 4 + c * (COL_W + 4), y + 1,
                        COL_W, 18, new LiteralText(""));
                f.setMaxLength(7);
                f.setTextPredicate(s -> s.matches("\\d*"));
                f.setChangedListener(s -> onEdit(row, col, s));
                this.addChild(f);
                fields[r][c] = f;
            }
            del[r] = this.addButton(new ButtonWidget(left + nameW + 4 + colsW, y, 20, 20, new LiteralText("x"), b -> remove(row)));
        }
        int fy = this.height - 28;
        int cx = this.width / 2;
        prev = this.addButton(new ButtonWidget(cx - 190, fy, 50, 20, new LiteralText("<"), b -> {
            page--;
            refresh();
        }));
        next = this.addButton(new ButtonWidget(cx - 136, fy, 50, 20, new LiteralText(">"), b -> {
            page++;
            refresh();
        }));
        this.addButton(new ButtonWidget(cx - 50, fy, 80, 20, new LiteralText("+ Добавить"), b ->
                this.client.openScreen(new PickerScreen(this, mode, this::add))));
        this.addButton(new ButtonWidget(cx + 34, fy, 70, 20, new LiteralText("Сохранить"), b -> Store.save(file)));
        this.addButton(new ButtonWidget(cx + 108, fy, 60, 20, new LiteralText("Назад"), b -> this.onClose()));
        rebuild();
    }

    private void rebuild() {
        view.clear();
        String[] words = filter.isEmpty() ? new String[0] : filter.split("\\s+");
        for (int i = 0; i < array.size(); i++) {
            String n = nameFn.name(array.get(i).getAsJsonObject()).toLowerCase(Locale.ROOT);
            boolean ok = true;
            for (String w : words) {
                if (!n.contains(w)) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                view.add(i);
            }
        }
        refresh();
    }

    private int pages() {
        return Math.max(1, (view.size() + rows - 1) / rows);
    }

    private JsonObject entryAt(int row) {
        int idx = page * rows + row;
        return idx < view.size() ? array.get(view.get(idx)).getAsJsonObject() : null;
    }

    private int valueOf(JsonObject e, Col c) {
        try {
            if (e.has(c.key)) {
                return e.get(c.key).getAsInt();
            }
            if (c.fallbackKey != null && e.has(c.fallbackKey)) {
                return e.get(c.fallbackKey).getAsInt();
            }
        } catch (Exception ignored) {
            // нечисловое значение: показываем по умолчанию
        }
        return c.def;
    }

    private void refresh() {
        if (fields == null) {
            return;
        }
        page = Math.max(0, Math.min(page, pages() - 1));
        loading = true;
        for (int r = 0; r < rows; r++) {
            JsonObject e = entryAt(r);
            del[r].visible = e != null;
            for (int c = 0; c < cols.length; c++) {
                TextFieldWidget f = fields[r][c];
                f.setVisible(e != null);
                if (e != null) {
                    f.setText(String.valueOf(valueOf(e, cols[c])));
                }
            }
        }
        loading = false;
        prev.active = page > 0;
        next.active = page < pages() - 1;
    }

    private void onEdit(int row, int col, String s) {
        if (loading || s.isEmpty()) {
            return;
        }
        JsonObject e = entryAt(row);
        if (e == null) {
            return;
        }
        try {
            e.addProperty(cols[col].key, Integer.parseInt(s));
            Store.markDirty(file);
        } catch (NumberFormatException ignored) {
            // слишком длинное число
        }
    }

    private void remove(int row) {
        int idx = page * rows + row;
        if (idx < view.size()) {
            array.remove(view.get(idx).intValue());
            Store.markDirty(file);
            rebuild();
        }
    }

    private void add(Catalog.Item2 item) {
        JsonObject e = maker.make(item);
        if (e == null) {
            return;
        }
        array.add(e);
        Store.markDirty(file);
        filter = "";
        page = Integer.MAX_VALUE / 2;   // последняя страница: новая запись добавляется в конец
    }

    @Override
    public void tick() {
        super.tick();
        if (search != null) {
            search.tick();
        }
        for (TextFieldWidget[] rowFields : fields == null ? new TextFieldWidget[0][] : fields) {
            for (TextFieldWidget f : rowFields) {
                f.tick();
            }
        }
    }

    @Override
    public void onClose() {
        Store.saveIfDirty(file);
        this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        int cx = this.width / 2;
        this.textRenderer.drawWithShadow(m, heading, cx - this.textRenderer.getWidth(heading) / 2f, 8, 0xFFFFFF);
        search.render(m, mouseX, mouseY, delta);
        if (search.getText().isEmpty() && !search.isFocused()) {
            this.textRenderer.drawWithShadow(m, "Поиск...", left + 4, 27, 0x777777);
        }
        for (int c = 0; c < cols.length; c++) {
            this.textRenderer.drawWithShadow(m, cols[c].label, left + nameW + 4 + c * (COL_W + 4) + 2, TOP - 11, 0xAAAAAA);
        }
        super.render(m, mouseX, mouseY, delta);
        String hover = null;
        for (int r = 0; r < rows; r++) {
            JsonObject e = entryAt(r);
            if (e == null) {
                continue;
            }
            int y = TOP + r * ROW_H;
            for (int c = 0; c < cols.length; c++) {
                fields[r][c].render(m, mouseX, mouseY, delta);
            }
            String name = nameFn.name(e);
            this.textRenderer.drawWithShadow(m, this.textRenderer.trimToWidth(name, nameW), left, y + 6, 0xFFFFFF);
            if (mouseY >= y && mouseY < y + 20 && mouseX >= left && mouseX < left + nameW) {
                hover = name;
            }
        }
        int fy = this.height - 28;
        String pg = (page + 1) + " / " + pages() + " (" + view.size() + ")";
        this.textRenderer.drawWithShadow(m, pg, cx - 128 + 0f, fy - 12, 0xFFFFFF);
        if (hover != null) {
            this.textRenderer.drawWithShadow(m, this.textRenderer.trimToWidth(hover, this.width - 20), 10, fy - 24, 0xFFFF55);
        }
    }
}
