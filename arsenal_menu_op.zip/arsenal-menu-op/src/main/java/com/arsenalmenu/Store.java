package com.arsenalmenu;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.network.PacketByteBuf;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Копии конфигов сервера (cargo, buyer, mines), которые правятся на клиенте и целиком уходят обратно. */
public final class Store {
    public static final String CARGO = "cargo";
    public static final String BUYER = "buyer";
    public static final String MINES = "mines";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<String, JsonObject> FILES = new HashMap<>();
    private static final Set<String> DIRTY = new HashSet<>();

    private Store() {
    }

    public static JsonObject get(String name) {
        return FILES.get(name);
    }

    public static boolean ready() {
        return FILES.containsKey(CARGO) && FILES.containsKey(BUYER) && FILES.containsKey(MINES);
    }

    public static void markDirty(String name) {
        DIRTY.add(name);
    }

    /** Запросить у сервера все файлы и каталог предметов. */
    public static void requestAll() {
        for (String n : new String[]{CARGO, BUYER, MINES}) {
            if (ClientPlayNetworking.canSend(ArsenalMenuClient.FILE_REQ)) {
                PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
                buf.writeString(n);
                ClientPlayNetworking.send(ArsenalMenuClient.FILE_REQ, buf);
            }
        }
        if (Catalog.serverItems.isEmpty() && ClientPlayNetworking.canSend(ArsenalMenuClient.CAT_REQ)) {
            ClientPlayNetworking.send(ArsenalMenuClient.CAT_REQ, new PacketByteBuf(Unpooled.buffer()));
        }
    }

    static void onFile(String name, byte[] gz) {
        try (InputStream in = new GZIPInputStream(new ByteArrayInputStream(gz));
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] tmp = new byte[8192];
            int n;
            while ((n = in.read(tmp)) > 0) {
                out.write(tmp, 0, n);
            }
            JsonObject o = new JsonParser().parse(new String(out.toByteArray(), StandardCharsets.UTF_8)).getAsJsonObject();
            // свои несохранённые правки не затираем
            if (!DIRTY.contains(name)) {
                FILES.put(name, o);
            }
        } catch (Exception ex) {
            System.err.println("[ArsenalMenuOp] не удалось прочитать " + name + ": " + ex);
        }
    }

    public static void saveIfDirty(String name) {
        if (DIRTY.contains(name)) {
            save(name);
        }
    }

    public static void save(String name) {
        JsonObject o = FILES.get(name);
        if (o == null || !ClientPlayNetworking.canSend(ArsenalMenuClient.FILE_PUT)) {
            return;
        }
        try {
            byte[] raw = GSON.toJson(o).getBytes(StandardCharsets.UTF_8);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (GZIPOutputStream gz = new GZIPOutputStream(bo)) {
                gz.write(raw);
            }
            byte[] all = bo.toByteArray();
            int chunk = 30000;
            int total = Math.max(1, (all.length + chunk - 1) / chunk);
            for (int i = 0; i < total; i++) {
                int from = i * chunk;
                int to = Math.min(all.length, from + chunk);
                byte[] part = new byte[to - from];
                System.arraycopy(all, from, part, 0, part.length);
                PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
                buf.writeString(name);
                buf.writeVarInt(i);
                buf.writeVarInt(total);
                buf.writeByteArray(part);
                ClientPlayNetworking.send(ArsenalMenuClient.FILE_PUT, buf);
            }
            DIRTY.remove(name);
        } catch (Exception ex) {
            System.err.println("[ArsenalMenuOp] не удалось отправить " + name + ": " + ex);
        }
    }
}
