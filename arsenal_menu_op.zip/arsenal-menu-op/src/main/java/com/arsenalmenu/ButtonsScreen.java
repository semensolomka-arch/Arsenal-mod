package com.arsenalmenu;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.util.ArrayList;
import java.util.List;

/** Список кнопок-пунктов (по одной в строке, с листанием) и кнопка "Назад". */
public final class ButtonsScreen extends Screen {
    public static final class Opt {
        final String label;
        final Runnable action;

        public Opt(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }
    }

    private final Screen parent;
    private final String heading;
    private final List<Opt> opts = new ArrayList<>();
    private int page;
    private int rows = 6;
    private ButtonWidget[] btns;
    private ButtonWidget prev;
    private ButtonWidget next;
    private String note = "";

    public ButtonsScreen(Screen parent, String heading, List<Opt> opts) {
        super(new LiteralText(heading));
        this.parent = parent;
        this.heading = heading;
        this.opts.addAll(opts);
    }

    public void setNote(String s) {
        note = s == null ? "" : s;
    }

    @Override
    protected void init() {
        rows = Math.max(3, Math.min(12, (this.height - 90) / 24));
        int cx = this.width / 2;
        int w = Math.min(280, this.width - 20);
        btns = new ButtonWidget[rows];
        for (int r = 0; r < rows; r++) {
            final int row = r;
            btns[r] = this.addButton(new ButtonWidget(cx - w / 2, 30 + r * 24, w, 20, new LiteralText(""), b -> {
                int idx = page * rows + row;
                if (idx < opts.size()) {
                    opts.get(idx).action.run();
                }
            }));
        }
        int fy = this.height - 28;
        prev = this.addButton(new ButtonWidget(cx - 150, fy, 60, 20, new LiteralText("< Назад"), b -> {
            page--;
            refresh();
        }));
        next = this.addButton(new ButtonWidget(cx - 85, fy, 60, 20, new LiteralText("Вперёд >"), b -> {
            page++;
            refresh();
        }));
        this.addButton(new ButtonWidget(cx + 90, fy, 60, 20, new LiteralText("Закрыть"), b -> this.onClose()));
        refresh();
    }

    private void refresh() {
        int pages = Math.max(1, (opts.size() + rows - 1) / rows);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int r = 0; r < rows; r++) {
            int idx = page * rows + r;
            boolean has = idx < opts.size();
            btns[r].visible = has;
            if (has) {
                btns[r].setMessage(new LiteralText(opts.get(idx).label));
            }
        }
        prev.active = page > 0;
        next.active = page < pages - 1;
    }

    @Override
    public void onClose() {
        this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        this.textRenderer.drawWithShadow(m, heading, this.width / 2f - this.textRenderer.getWidth(heading) / 2f, 12, 0xFFFFFF);
        super.render(m, mouseX, mouseY, delta);
        if (!note.isEmpty()) {
            this.textRenderer.drawWithShadow(m, note, this.width / 2f - this.textRenderer.getWidth(note) / 2f, this.height - 44, 0xFFAA55);
        }
    }
}
