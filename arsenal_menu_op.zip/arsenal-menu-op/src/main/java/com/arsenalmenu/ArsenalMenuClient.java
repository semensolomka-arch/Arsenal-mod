package com.arsenalmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Клиентская часть для оператора: клавиша U открывает экран настроек серверного мода Arsenal. */
public final class ArsenalMenuClient implements ClientModInitializer {
    public static final Identifier REQUEST = new Identifier("arsenal", "menu_request");
    public static final Identifier SET = new Identifier("arsenal", "menu_set");
    public static final Identifier DATA = new Identifier("arsenal", "menu_data");
    public static final Identifier FILE_REQ = new Identifier("arsenal", "file_req");
    public static final Identifier FILE_PUT = new Identifier("arsenal", "file_put");
    public static final Identifier FILE_DATA = new Identifier("arsenal", "file_data");
    public static final Identifier CAT_REQ = new Identifier("arsenal", "catalog_req");
    public static final Identifier OPEN = new Identifier("arsenal", "open_menu");
    public static final Identifier CAT_DATA = new Identifier("arsenal", "catalog_data");

    /** Одна настройка, как её прислал сервер. */
    public static final class Entry {
        public final String key;
        public final String label;
        public final String unit;
        public int value;
        public final int def;
        public final int min;
        public final int max;

        Entry(String key, String label, String unit, int value, int def, int min, int max) {
            this.key = key;
            this.label = label;
            this.unit = unit;
            this.value = value;
            this.def = def;
            this.min = min;
            this.max = max;
        }
    }

    /** Последние данные от сервера (пусто, пока не пришли). */
    public static volatile List<Entry> entries = new ArrayList<>();
    private static boolean wasDown;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(DATA, (client, handler, buf, responseSender) -> {
            final List<Entry> list = new ArrayList<>();
            int n = buf.readVarInt();
            for (int i = 0; i < n; i++) {
                list.add(new Entry(buf.readString(256), buf.readString(512), buf.readString(64),
                        buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt()));
            }
            client.execute(() -> {
                entries = list;
                if (client.currentScreen instanceof MenuScreen) {
                    ((MenuScreen) client.currentScreen).onData();
                }
            });
        });

        // команда /amenu на сервере: открыть меню без клавиши (телефон, Pojav)
        ClientPlayNetworking.registerGlobalReceiver(OPEN, (client, handler, buf, responseSender) ->
                client.execute(() -> client.openScreen(new MainScreen())));

        ClientPlayNetworking.registerGlobalReceiver(FILE_DATA, (client, handler, buf, responseSender) -> {
            final String name = buf.readString(32);
            final byte[] gz = buf.readByteArray();
            client.execute(() -> Store.onFile(name, gz));
        });

        ClientPlayNetworking.registerGlobalReceiver(CAT_DATA, (client, handler, buf, responseSender) -> {
            final List<Catalog.Item2> list = new ArrayList<>();
            int n = buf.readVarInt();
            for (int i = 0; i < n; i++) {
                String name = buf.readString(512);
                String cargo = buf.readString(4096);
                String key = buf.readString(256);
                try {
                    list.add(new Catalog.Item2(name, key + " " + cargo,
                            new com.google.gson.JsonParser().parse(cargo).getAsJsonObject(), key, null));
                } catch (Exception ignored) {
                    // битая запись каталога пропускается
                }
            }
            client.execute(() -> Catalog.setServerItems(list));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // клавиша U читается напрямую (без регистрации в настройках управления)
            boolean down = client.getWindow() != null
                    && GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_U) == GLFW.GLFW_PRESS;
            if (down && !wasDown && client.player != null && client.currentScreen == null) {
                client.openScreen(new MainScreen());
            }
            wasDown = down;
        });
    }

    public static void requestData() {
        if (ClientPlayNetworking.canSend(REQUEST)) {
            ClientPlayNetworking.send(REQUEST, new PacketByteBuf(io.netty.buffer.Unpooled.buffer()));
        }
    }

    public static void sendValue(String key, int value) {
        PacketByteBuf buf = new PacketByteBuf(io.netty.buffer.Unpooled.buffer());
        buf.writeString(key);
        buf.writeInt(value);
        ClientPlayNetworking.send(SET, buf);
    }

    static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }
}
