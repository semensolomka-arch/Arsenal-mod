package com.arsenalmenu;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/** Окно выбора предмета: вводишь часть названия ("исцеле") и жмёшь на нужный вариант. */
public final class PickerScreen extends Screen {
    private final Screen parent;
    private final List<Catalog.Item2> all;
    private final List<Catalog.Item2> view = new ArrayList<>();
    private final Consumer<Catalog.Item2> onPick;
    private String filter = "";
    private int page;
    private int rows = 8;
    private TextFieldWidget search;
    private ButtonWidget[] btns;
    private ButtonWidget prev;
    private ButtonWidget next;

    public PickerScreen(Screen parent, Catalog.Mode mode, Consumer<Catalog.Item2> onPick) {
        super(new LiteralText("Выбор"));
        this.parent = parent;
        this.all = Catalog.forMode(mode);
        this.onPick = onPick;
    }

    @Override
    protected void init() {
        rows = Math.max(3, Math.min(14, (this.height - 100) / 22));
        int cx = this.width / 2;
        int w = Math.min(320, this.width - 20);
        search = new TextFieldWidget(this.textRenderer, cx - w / 2, 26, w, 18, new LiteralText("Поиск"));
        search.setMaxLength(60);
        search.setText(filter);
        search.setChangedListener(s -> {
            filter = s.toLowerCase(Locale.ROOT).trim();
            page = 0;
            rebuild();
        });
        this.addChild(search);
        this.setInitialFocus(search);
        btns = new ButtonWidget[rows];
        for (int r = 0; r < rows; r++) {
            final int row = r;
            btns[r] = this.addButton(new ButtonWidget(cx - w / 2, 50 + r * 22, w, 20, new LiteralText(""), b -> pick(row)));
        }
        int fy = this.height - 28;
        prev = this.addButton(new ButtonWidget(cx - 150, fy, 60, 20, new LiteralText("< Назад"), b -> {
            page--;
            refresh();
        }));
        next = this.addButton(new ButtonWidget(cx - 85, fy, 60, 20, new LiteralText("Вперёд >"), b -> {
            page++;
            refresh();
        }));
        this.addButton(new ButtonWidget(cx + 90, fy, 60, 20, new LiteralText("Отмена"), b -> this.onClose()));
        rebuild();
    }

    private void rebuild() {
        view.clear();
        String[] words = filter.isEmpty() ? new String[0] : filter.split("\\s+");
        for (Catalog.Item2 it : all) {
            boolean ok = true;
            for (String w : words) {
                if (!it.lower.contains(w)) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                view.add(it);
            }
        }
        refresh();
    }

    private int pages() {
        return Math.max(1, (view.size() + rows - 1) / rows);
    }

    private void refresh() {
        if (btns == null) {
            return;
        }
        page = Math.max(0, Math.min(page, pages() - 1));
        int w = Math.min(320, this.width - 20) - 10;
        for (int r = 0; r < rows; r++) {
            int idx = page * rows + r;
            boolean has = idx < view.size();
            btns[r].visible = has;
            if (has) {
                btns[r].setMessage(new LiteralText(this.textRenderer.trimToWidth(view.get(idx).name, w)));
            }
        }
        prev.active = page > 0;
        next.active = page < pages() - 1;
    }

    private void pick(int row) {
        int idx = page * rows + row;
        if (idx < view.size()) {
            onPick.accept(view.get(idx));
            this.client.openScreen(parent);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (search != null) {
            search.tick();
        }
    }

    @Override
    public void onClose() {
        this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        int cx = this.width / 2;
        String t = "Что добавить? Начни вводить название";
        this.textRenderer.drawWithShadow(m, t, cx - this.textRenderer.getWidth(t) / 2f, 10, 0xFFFFFF);
        search.render(m, mouseX, mouseY, delta);
        super.render(m, mouseX, mouseY, delta);
        if (view.isEmpty()) {
            String s = "Ничего не найдено";
            this.textRenderer.drawWithShadow(m, s, cx - this.textRenderer.getWidth(s) / 2f, 60, 0xAAAAAA);
        }
        String pg = (page + 1) + " / " + pages() + "  (" + view.size() + ")";
        this.textRenderer.drawWithShadow(m, pg, cx - 15, this.height - 22, 0xFFFFFF);
    }
}
