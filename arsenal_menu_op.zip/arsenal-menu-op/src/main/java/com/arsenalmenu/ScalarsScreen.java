package com.arsenalmenu;

import com.google.gson.JsonObject;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.util.ArrayList;
import java.util.List;

/** Несколько отдельных чисел из файла (например, шансы уровней шахт или интервал магазина). */
public final class ScalarsScreen extends Screen {
    public static final class Field {
        final String label;
        final String[] path;
        final int def;

        public Field(String label, int def, String... path) {
            this.label = label;
            this.def = def;
            this.path = path;
        }
    }

    private final Screen parent;
    private final String heading;
    private final String file;
    private final JsonObject root;
    private final List<Field> defs = new ArrayList<>();
    private final List<TextFieldWidget> inputs = new ArrayList<>();
    private boolean loading;

    public ScalarsScreen(Screen parent, String heading, String file, JsonObject root, List<Field> fields) {
        super(new LiteralText(heading));
        this.parent = parent;
        this.heading = heading;
        this.file = file;
        this.root = root;
        this.defs.addAll(fields);
    }

    private int read(Field f) {
        JsonObject o = root;
        for (int i = 0; i < f.path.length - 1; i++) {
            if (!o.has(f.path[i]) || !o.get(f.path[i]).isJsonObject()) {
                return f.def;
            }
            o = o.getAsJsonObject(f.path[i]);
        }
        String last = f.path[f.path.length - 1];
        try {
            return o.has(last) ? o.get(last).getAsInt() : f.def;
        } catch (Exception ex) {
            return f.def;
        }
    }

    private void write(Field f, int v) {
        JsonObject o = root;
        for (int i = 0; i < f.path.length - 1; i++) {
            if (!o.has(f.path[i]) || !o.get(f.path[i]).isJsonObject()) {
                o.add(f.path[i], new JsonObject());
            }
            o = o.getAsJsonObject(f.path[i]);
        }
        o.addProperty(f.path[f.path.length - 1], v);
        Store.markDirty(file);
    }

    @Override
    protected void init() {
        inputs.clear();
        int cx = this.width / 2;
        loading = true;
        for (int i = 0; i < defs.size(); i++) {
            final Field f = defs.get(i);
            TextFieldWidget t = new TextFieldWidget(this.textRenderer, cx + 60, 34 + i * 24, 80, 18, new LiteralText(""));
            t.setMaxLength(7);
            t.setTextPredicate(s -> s.matches("\\d*"));
            t.setText(String.valueOf(read(f)));
            t.setChangedListener(s -> {
                if (!loading && !s.isEmpty()) {
                    try {
                        write(f, Integer.parseInt(s));
                    } catch (NumberFormatException ignored) {
                        // слишком длинное число
                    }
                }
            });
            this.addChild(t);
            inputs.add(t);
        }
        loading = false;
        this.addButton(new ButtonWidget(cx - 70, this.height - 28, 60, 20, new LiteralText("Сохранить"), b -> Store.save(file)));
        this.addButton(new ButtonWidget(cx + 10, this.height - 28, 60, 20, new LiteralText("Назад"), b -> this.onClose()));
    }

    @Override
    public void tick() {
        super.tick();
        for (TextFieldWidget t : inputs) {
            t.tick();
        }
    }

    @Override
    public void onClose() {
        Store.saveIfDirty(file);
        this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        int cx = this.width / 2;
        this.textRenderer.drawWithShadow(m, heading, cx - this.textRenderer.getWidth(heading) / 2f, 12, 0xFFFFFF);
        super.render(m, mouseX, mouseY, delta);
        for (int i = 0; i < defs.size(); i++) {
            this.textRenderer.drawWithShadow(m, this.textRenderer.trimToWidth(defs.get(i).label, 210), cx - 150, 39 + i * 24, 0xFFFFFF);
            inputs.get(i).render(m, mouseX, mouseY, delta);
        }
    }
}
