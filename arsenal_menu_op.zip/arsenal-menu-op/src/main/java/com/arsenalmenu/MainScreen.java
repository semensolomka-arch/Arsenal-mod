package com.arsenalmenu;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Главное меню оператора (клавиша U): лут, автошахты, скупщик, магазин, настройки. */
public final class MainScreen extends Screen {
    private ButtonWidget[] btns;
    private String note = "";

    public MainScreen() {
        super(new LiteralText("Arsenal"));
    }

    @Override
    protected void init() {
        Store.requestAll();
        int cx = this.width / 2;
        String[] names = {"Лут с ивентов", "Автошахты", "Скупщик", "Магазин скупщика", "Настройки"};
        btns = new ButtonWidget[names.length];
        for (int i = 0; i < names.length; i++) {
            final int n = i;
            btns[i] = this.addButton(new ButtonWidget(cx - 100, 40 + i * 26, 200, 20, new LiteralText(names[i]), b -> open(n)));
        }
        this.addButton(new ButtonWidget(cx - 50, 40 + names.length * 26 + 10, 100, 20, new LiteralText("Закрыть"), b -> this.onClose()));
    }

    private void open(int n) {
        if (n == 4) {
            this.client.openScreen(new MenuScreen(this));
            return;
        }
        if (!Store.ready()) {
            note = "Данные ещё не пришли с сервера. Нужны права оператора и новый мод Arsenal на сервере.";
            Store.requestAll();
            return;
        }
        note = "";
        switch (n) {
            case 0:
                this.client.openScreen(cargoTables());
                break;
            case 1:
                this.client.openScreen(mines());
                break;
            case 2:
                this.client.openScreen(new SectionsScreen(this, buyerSections()));
                break;
            default:
                this.client.openScreen(shopMenu());
                break;
        }
    }

    // ------------------------------------------------------------------ лут

    private static String tableTitle(String key) {
        switch (key) {
            case "peace": return "Мирный груз";
            case "explosive": return "Взрывной груз";
            case "deadly": return "Смертельный груз";
            case "goldrush": return "Золотая лихорадка: золотой шалкер";
            case "goldrush_red": return "Золотая лихорадка: красный шалкер";
            case "core": return "Ядро солнца (ПВП-арена)";
            case "xpevent": return "Опытный Тыпо: сундуки";
            case "ship_common": return "Таинственный корабль: обычный";
            case "ship_rare": return "Таинственный корабль: редкий";
            case "ship_secret": return "Таинственный корабль: секретный";
            case "ship_treasure": return "Таинственный корабль: сокровище";
            case "mine": return "Смертельная шахта: награда";
            default: return key;
        }
    }

    private Screen cargoTables() {
        List<ButtonsScreen.Opt> opts = new ArrayList<>();
        JsonObject loot = Store.get(Store.CARGO).has("loot") ? Store.get(Store.CARGO).getAsJsonObject("loot") : new JsonObject();
        final ButtonsScreen[] holder = new ButtonsScreen[1];
        for (java.util.Map.Entry<String, com.google.gson.JsonElement> en : loot.entrySet()) {
            final String key = en.getKey();
            final String k = key;
            if (!en.getValue().isJsonObject()) {
                continue;
            }
            JsonObject t = en.getValue().getAsJsonObject();
            if (!t.has("entries")) {
                continue;
            }
            final JsonArray entries = t.getAsJsonArray("entries");
            opts.add(new ButtonsScreen.Opt(tableTitle(key) + "  (" + entries.size() + ")", () ->
                    this.client.openScreen(new ListScreen(holder[0], "Лут: " + tableTitle(k), Store.CARGO, entries,
                            new ListScreen.Col[]{
                                    new ListScreen.Col("weight", "Вес", 10, null),
                                    new ListScreen.Col("min", "Мин", 1, null),
                                    new ListScreen.Col("max", "Макс", 1, "min")},
                            Catalog::cargoName, Catalog.Mode.CARGO, it -> new com.google.gson.JsonParser().parse(it.cargo.toString()).getAsJsonObject()))));
        }
        holder[0] = new ButtonsScreen(this, "Лут с ивентов", opts);
        holder[0].setNote("Вес: чем больше, тем чаще выпадает (0 = не выпадает)");
        return holder[0];
    }

    // ------------------------------------------------------------------ автошахты

    private Screen mines() {
        final JsonObject root = Store.get(Store.MINES);
        List<ButtonsScreen.Opt> opts = new ArrayList<>();
        final ButtonsScreen[] holder = new ButtonsScreen[1];
        opts.add(new ButtonsScreen.Opt("Параметры (шансы уровней, Ад, залежи)", () ->
                this.client.openScreen(new ScalarsScreen(holder[0], "Автошахты: параметры", Store.MINES, root, Arrays.asList(
                        new ScalarsScreen.Field("Шанс обычной шахты (вес)", 70, "tierWeights", "common"),
                        new ScalarsScreen.Field("Шанс эпической шахты (вес)", 25, "tierWeights", "epic"),
                        new ScalarsScreen.Field("Шанс легендарной шахты (вес)", 5, "tierWeights", "legendary"),
                        new ScalarsScreen.Field("Шанс Ада для второй шахты, %", 50, "netherChancePercent"),
                        new ScalarsScreen.Field("Залежей взрывчатки, от", 2, "deposits", "min"),
                        new ScalarsScreen.Field("Залежей взрывчатки, до", 3, "deposits", "max"))))));
        String[] realms = {"overworld", "nether", "end"};
        String[] realmRu = {"Обычный мир", "Ад", "Энд"};
        String[] tiers = {"common", "epic", "legendary"};
        String[] tierRu = {"обычная", "эпическая", "легендарная"};
        for (int r = 0; r < realms.length; r++) {
            for (int t = 0; t < tiers.length; t++) {
                final String realm = realms[r];
                final String tier = tiers[t];
                final String title = realmRu[r] + ": " + tierRu[t] + " шахта";
                opts.add(new ButtonsScreen.Opt(title, () -> {
                    if (!root.has("tables") || !root.get("tables").isJsonObject()) {
                        root.add("tables", new JsonObject());
                    }
                    JsonObject tables = root.getAsJsonObject("tables");
                    if (!tables.has(realm) || !tables.get(realm).isJsonObject()) {
                        tables.add(realm, new JsonObject());
                    }
                    JsonObject rt = tables.getAsJsonObject(realm);
                    if (!rt.has(tier) || !rt.get(tier).isJsonArray()) {
                        rt.add(tier, new JsonArray());
                    }
                    this.client.openScreen(new ListScreen(holder[0], title, Store.MINES, rt.getAsJsonArray(tier),
                            new ListScreen.Col[]{new ListScreen.Col("weight", "Вес", 10, null)},
                            e -> Catalog.blockName(e.has("block") ? e.get("block").getAsString() : "?"),
                            Catalog.Mode.BLOCK, it -> {
                        JsonObject o = new JsonObject();
                        o.addProperty("block", it.blockId);
                        o.addProperty("weight", 10);
                        return o;
                    }));
                }));
            }
        }
        holder[0] = new ButtonsScreen(this, "Автошахты", opts);
        holder[0].setNote("Вес блока: его доля среди остальных в шахте");
        return holder[0];
    }

    // ------------------------------------------------------------------ скупщик и магазин

    private JsonArray buyerSections() {
        JsonObject root = Store.get(Store.BUYER);
        if (!root.has("sections") || !root.get("sections").isJsonArray()) {
            root.add("sections", new JsonArray());
        }
        return root.getAsJsonArray("sections");
    }

    private JsonObject shop() {
        JsonObject root = Store.get(Store.BUYER);
        if (!root.has("shop") || !root.get("shop").isJsonObject()) {
            JsonObject s = new JsonObject();
            s.addProperty("intervalMinutes", 20);
            s.addProperty("offers", 9);
            s.add("items", new JsonArray());
            root.add("shop", s);
        }
        JsonObject shop = root.getAsJsonObject("shop");
        if (!shop.has("items") || !shop.get("items").isJsonArray()) {
            shop.add("items", new JsonArray());
        }
        return shop;
    }

    private Screen shopMenu() {
        final JsonObject shop = shop();
        List<ButtonsScreen.Opt> opts = new ArrayList<>();
        final ButtonsScreen[] holder = new ButtonsScreen[1];
        opts.add(new ButtonsScreen.Opt("Товары магазина", () ->
                this.client.openScreen(new ListScreen(holder[0], "Магазин скупщика: товары", Store.BUYER, shop.getAsJsonArray("items"),
                        new ListScreen.Col[]{
                                new ListScreen.Col("price", "Цена", 0, null),
                                new ListScreen.Col("count", "Штук", 1, null)},
                        e -> Catalog.keyName(e.has("key") ? e.get("key").getAsString() : "?"), Catalog.Mode.BUYER, it -> {
                    JsonObject o = new JsonObject();
                    o.addProperty("key", it.buyerKey);
                    o.addProperty("price", 1);
                    o.addProperty("count", 1);
                    return o;
                }))));
        opts.add(new ButtonsScreen.Opt("Параметры (как часто обновляется, сколько товаров)", () ->
                this.client.openScreen(new ScalarsScreen(holder[0], "Магазин: параметры", Store.BUYER, shop, Arrays.asList(
                        new ScalarsScreen.Field("Обновление ассортимента, минут", 20, "intervalMinutes"),
                        new ScalarsScreen.Field("Сколько товаров показывать (до 21)", 9, "offers"))))));
        holder[0] = new ButtonsScreen(this, "Магазин скупщика", opts);
        return holder[0];
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        this.renderBackground(m);
        String t = "Arsenal: меню оператора";
        this.textRenderer.drawWithShadow(m, t, this.width / 2f - this.textRenderer.getWidth(t) / 2f, 16, 0xFFFFFF);
        super.render(m, mouseX, mouseY, delta);
        if (!note.isEmpty()) {
            this.textRenderer.drawWithShadow(m, this.textRenderer.trimToWidth(note, this.width - 20), 10, this.height - 24, 0xFFAA55);
        }
    }
}
