package com.arsenal.event;

import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.MessageType;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Util;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Опытный Тыпо (ивент в общем цикле вместе с грузами и золотой лихорадкой). В случайном месте мира появляется площадка примерно 50 на 50 блоков,
 * местность выравнивается на одну высоту (потом возвращается как была), в центре площадка из лаймового бетона, по краю руины,
 * по бокам прилавки, цветы; по углам 4 места, помеченные морскими фонарями. Житель появляется в одном из них с пузырьком опыта в руках. ПКМ по жителю
 * с пузырьком: пузырёк идёт в инвентарь, игрок начинает светиться, а житель телепортируется на другое место и через
 * 30-60 секунд получает новый пузырёк. Пока пузырёк в инвентаре (пузырьки стакаются), он даёт опыт: за каждый по
 * 15 очков в секунду. Пузырёк нельзя положить ни в какой контейнер, только выбросить. Если отойти от ивента на 80 блоков,
 * игрока предупредят, на 100 блоков пузырьки заберут. ПКМ по жителю без пузырька отбрасывает на ~10 блоков и бьёт на
 * 4 сердца в обход брони. Идёт 15 минут, в конце на месте двух фонарей появляются сундуки с наградой (в основном опыт, таблица xpevent). Всё настраивается в общих настройках.
 */
public final class XpEvent {
    // ---- настройки (Settings), время в тиках
    public static int DURATION = 20 * 60 * 15;
    /** Сколько ивент стоит после появления сундуков. */
    public static int LINGER = 20 * 60;
    public static int BOTTLE_MIN = 20 * 30;
    public static int BOTTLE_MAX = 20 * 60;
    public static int POINTS_PER_BOTTLE = 15;
    public static int WARN_DISTANCE = 80;
    public static int REMOVE_DISTANCE = 100;
    /** Урон в здоровье (2 на сердце): по умолчанию 4 сердца. */
    public static int DAMAGE = 8;
    /** Примерная дальность отбрасывания в блоках. */
    public static int KNOCKBACK = 10;

    private static final String TAG_VILLAGER = "arsenal_xp_villager";
    private static final String NBT_BOTTLE = "ArsenalXpEvent";
    private static final int SPOT = 18;
    private static final int HALF = 25;
    private static final int MAX_DISTANCE = 4000;
    private static final Random RNG = new Random();

    private static final class Spot {
        BlockPos lantern;
        BlockState old;
        boolean chest;
        double x;
        double y;
        double z;
    }

    private static final class Active {
        int cx;
        int cz;
        /** Высота, на которую выровнена площадка: игрок стоит на этом y (пол на y0 - 1). */
        int y0;
        /** Блоки, которые ивент заменил: позиция -> id исходного состояния (чтобы вернуть местность). */
        final Map<Long, Integer> saved = new LinkedHashMap<>();
        int age;
        int serial;
        final List<Spot> spots = new ArrayList<>();
        int spot;
        UUID villager;
        boolean finished;
        boolean hasBottle = true;
        int bottleIn;
    }

    private static Active active;
    private static int serialCounter;
    private static int tick;

    private XpEvent() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(XpEvent::load);
        // остановка сервера не заканчивает ивент: он сохраняется и продолжится после запуска, как груз
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            save();
            active = null;
            serverRef = null;
        });
        ServerTickEvents.END_SERVER_TICK.register(XpEvent::onTick);
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> onUseEntity(player, world, hand, entity));
        // пузырёк ивента нельзя бросить как обычный бутылёк опыта
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (isBottle(stack)) {
                return TypedActionResult.fail(stack);
            }
            return TypedActionResult.pass(stack);
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(buildCommand()));
    }

    public static boolean isActive() {
        return active != null;
    }

    /** Координаты ивента "x y z" для /event или null, если он не идёт. */
    public static String coords() {
        Active a = active;
        return a == null ? null : a.cx + " " + a.y0 + " " + a.cz;
    }

    /** Запускает Опытного Тыпо в случайном месте (из общего цикла ивентов или командой). Нельзя, если он уже идёт. */
    public static boolean startRandom(MinecraftServer server) {
        return active == null && start(server);
    }

    // ------------------------------------------------------------------ предмет

    private static ItemStack bottle(int count, int serial) {
        ItemStack s = new ItemStack(Items.EXPERIENCE_BOTTLE, count);
        s.getOrCreateTag().putInt(NBT_BOTTLE, serial);
        s.setCustomName(new LiteralText("Пузырёк опыта").formatted(Formatting.GREEN, Formatting.BOLD));
        return s;
    }

    public static boolean isBottle(ItemStack s) {
        if (s.isEmpty() || s.getItem() != Items.EXPERIENCE_BOTTLE || !s.hasTag()) {
            return false;
        }
        NbtCompound t = s.getTag();
        return t != null && t.contains(NBT_BOTTLE);
    }

    private static boolean current(ItemStack s) {
        Active a = active;
        return a != null && isBottle(s) && s.getTag().getInt(NBT_BOTTLE) == a.serial;
    }

    private static int bottlesIn(ServerPlayerEntity p) {
        int n = 0;
        for (int i = 0; i < p.inventory.size(); i++) {
            ItemStack s = p.inventory.getStack(i);
            if (current(s)) {
                n += s.getCount();
            }
        }
        return n;
    }

    /** Забирает из инвентаря все пузырьки ивента (stale: только старые/чужие). Возвращает сколько забрано. */
    private static int stripBottles(ServerPlayerEntity p, boolean onlyStale) {
        int n = 0;
        for (int i = 0; i < p.inventory.size(); i++) {
            ItemStack s = p.inventory.getStack(i);
            if (isBottle(s) && (!onlyStale || !current(s))) {
                n += s.getCount();
                p.inventory.setStack(i, ItemStack.EMPTY);
            }
        }
        if (n > 0) {
            p.currentScreenHandler.sendContentUpdates();
        }
        return n;
    }

    // ------------------------------------------------------------------ команда

    private static LiteralArgumentBuilder<ServerCommandSource> buildCommand() {
        LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("xpevent")
                .requires(s -> s.hasPermissionLevel(2))
                .executes(ctx -> {
                    info(ctx.getSource());
                    return 1;
                });
        root.then(CommandManager.literal("start").executes(ctx -> {
            MinecraftServer server = ctx.getSource().getMinecraftServer();
            if (active != null) {
                ctx.getSource().sendFeedback(new LiteralText("Опытный Тыпо уже идёт"), false);
                return 0;
            }
            boolean ok = start(server);
            ctx.getSource().sendFeedback(new LiteralText(ok ? "Опытный Тыпо запущен" : "Не нашлось места, попробуйте ещё раз"), false);
            return ok ? 1 : 0;
        }));
        root.then(CommandManager.literal("stop").executes(ctx -> {
            end(ctx.getSource().getMinecraftServer(), true);
            ctx.getSource().sendFeedback(new LiteralText("Опытный Тыпо остановлен"), false);
            return 1;
        }));
        return root;
    }

    private static void info(ServerCommandSource source) {
        Active a = active;
        if (a == null) {
            source.sendFeedback(new LiteralText("Опытный Тыпо сейчас не идёт (он выпадает в общем цикле ивентов вместе с грузами)"), false);
        } else {
            source.sendFeedback(new LiteralText("Опытный Тыпо: " + coords() + (a.finished
                    ? ", сундуки открыты, ивент исчезнет через " + EventManager.fmt(DURATION + LINGER - a.age)
                    : ", осталось " + EventManager.fmt(DURATION - a.age))), false);
        }
    }

    // ------------------------------------------------------------------ запуск и конец

    private static void broadcast(MinecraftServer server, Text text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, Util.NIL_UUID);
    }

    private static boolean start(MinecraftServer server) {
        ServerWorld world = server.getOverworld();
        Active a = findSite(world);
        if (a == null) {
            return false;
        }
        a.serial = ++serialCounter;
        a.bottleIn = 0;
        // выравниваем местность и строим площадку (всё заменённое запоминается)
        build(world, a);
        active = a;
        a.spot = RNG.nextInt(a.spots.size());
        spawnVillager(world, a);
        save();
        saveBlocks(a);
        broadcast(server, new LiteralText("«").formatted(Formatting.GRAY)
                .append(new LiteralText("Опытный Тыпо").formatted(Formatting.GREEN, Formatting.BOLD))
                .append(new LiteralText("» на координатах ").formatted(Formatting.GRAY))
                .append(new LiteralText(a.cx + " " + a.y0 + " " + a.cz).formatted(Formatting.WHITE)));
        return true;
    }

    /**
     * Конец игры: житель и пузырьки пропадают, на месте двух случайных фонарей появляются сундуки с наградой (в основном
     * опыт). Сам ивент (вместе с сундуками) после этого стоит ещё LINGER (по умолчанию минуту) и только потом исчезает совсем.
     */
    private static void finish(MinecraftServer server, Active a) {
        a.finished = true;
        ServerWorld world = server.getOverworld();
        removeVillagers(world, a);
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < a.spots.size(); i++) {
            order.add(i);
        }
        java.util.Collections.shuffle(order, RNG);
        for (int k = 0; k < 2 && k < order.size(); k++) {
            Spot s = a.spots.get(order.get(k));
            s.chest = true;
            world.setBlockState(s.lantern, Blocks.CHEST.getDefaultState()
                    .with(net.minecraft.block.ChestBlock.FACING, net.minecraft.util.math.Direction.fromHorizontal(RNG.nextInt(4))), 3);
            net.minecraft.block.entity.BlockEntity be = world.getBlockEntity(s.lantern);
            if (be instanceof net.minecraft.inventory.Inventory) {
                CargoLoot.fill((net.minecraft.inventory.Inventory) be, CargoLoot.rollFlat("xpevent"));
                be.markDirty();
            }
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            stripBottles(p, false);
        }
        save();
        broadcast(server, new LiteralText("«").formatted(Formatting.GRAY)
                .append(new LiteralText("Опытный Тыпо").formatted(Formatting.GREEN, Formatting.BOLD))
                .append(new LiteralText("» закончился: на месте двух фонарей появились сундуки с наградой. Ивент исчезнет через "
                        + EventManager.fmt(LINGER)).formatted(Formatting.GRAY)));
    }

    private static void removeVillagers(ServerWorld world, Active a) {
        Entity v = a.villager == null ? null : world.getEntity(a.villager);
        if (v != null) {
            v.remove();
        }
        // на всякий случай убираем и забытых жителей ивента рядом
        Box box = new Box(a.cx - HALF - 5, 0, a.cz - HALF - 5, a.cx + HALF + 5, 256, a.cz + HALF + 5);
        for (VillagerEntity ve : world.getEntitiesByClass(VillagerEntity.class, box, e -> e.getScoreboardTags().contains(TAG_VILLAGER))) {
            ve.remove();
        }
    }

    /** Полная уборка: сундуки и фонари исчезают, земля возвращается. Вызывается по окончании LINGER, командой stop и при остановке сервера. */
    private static void end(MinecraftServer server, boolean announce) {
        Active a = active;
        if (a == null) {
            return;
        }
        active = null;
        save();   // файл ивента удаляется
        ServerWorld world = server.getOverworld();
        loadArea(world, a);
        removeVillagers(world, a);
        for (Spot s : a.spots) {
            if (s.chest) {
                // сундук исчезает вместе с ивентом, содержимое тоже (не выпадает на землю)
                net.minecraft.block.entity.BlockEntity be = world.getBlockEntity(s.lantern);
                if (be instanceof net.minecraft.inventory.Inventory) {
                    ((net.minecraft.inventory.Inventory) be).clear();
                }
            }
            if (s.old != null && !a.saved.containsKey(s.lantern.asLong())) {
                world.setBlockState(s.lantern, s.old, 3);   // ивент старого формата (до выравнивания)
            }
        }
        // возвращаем местность как была
        for (Map.Entry<Long, Integer> e : a.saved.entrySet()) {
            world.setBlockState(BlockPos.fromLong(e.getKey()), Block.getStateFromRawId(e.getValue()), 2);
        }
        try {
            Files.deleteIfExists(blocksFile(server));
        } catch (Exception ignored) {
            // не критично
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            stripBottles(p, false);
        }
        if (announce) {
            broadcast(server, new LiteralText("«").formatted(Formatting.GRAY)
                    .append(new LiteralText("Опытный Тыпо").formatted(Formatting.GREEN, Formatting.BOLD))
                    .append(new LiteralText("» закончился").formatted(Formatting.GRAY)));
        }
    }

    /** Для /event: сколько осталось (тиков) или -1. */
    public static int ticksLeft() {
        Active a = active;
        return a == null ? -1 : DURATION + LINGER - a.age;
    }

    public static boolean isFinished() {
        return active != null && active.finished;
    }

    // ------------------------------------------------------------------ сохранение

    private static MinecraftServer serverRef;

    private static Path stateFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_xpevent.json");
    }

    private static Path blocksFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_xpevent_blocks.json");
    }

    private static void saveBlocks(Active a) {
        MinecraftServer server = serverRef;
        if (server == null) {
            return;
        }
        try {
            JsonArray pos = new JsonArray();
            JsonArray ids = new JsonArray();
            for (Map.Entry<Long, Integer> e : a.saved.entrySet()) {
                pos.add(e.getKey());
                ids.add(e.getValue());
            }
            JsonObject o = new JsonObject();
            o.add("pos", pos);
            o.add("ids", ids);
            Files.write(blocksFile(server), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_xpevent_blocks.json: " + ex);
        }
    }

    private static void save() {
        MinecraftServer server = serverRef;
        if (server == null) {
            return;
        }
        try {
            Active a = active;
            if (a == null) {
                Files.deleteIfExists(stateFile(server));
                return;
            }
            JsonObject o = new JsonObject();
            o.addProperty("cx", a.cx);
            o.addProperty("cz", a.cz);
            o.addProperty("y0", a.y0);
            o.addProperty("age", a.age);
            o.addProperty("serial", a.serial);
            o.addProperty("serialCounter", serialCounter);
            o.addProperty("spot", a.spot);
            o.addProperty("villager", a.villager == null ? "" : a.villager.toString());
            o.addProperty("hasBottle", a.hasBottle);
            o.addProperty("bottleIn", a.bottleIn);
            o.addProperty("finished", a.finished);
            JsonArray spots = new JsonArray();
            for (Spot s : a.spots) {
                JsonObject so = new JsonObject();
                so.addProperty("pos", s.lantern.asLong());
                so.addProperty("old", s.old == null ? -1 : Block.getRawIdFromState(s.old));
                so.addProperty("chest", s.chest);
                so.addProperty("x", s.x);
                so.addProperty("y", s.y);
                so.addProperty("z", s.z);
                spots.add(so);
            }
            o.add("spots", spots);
            Files.write(stateFile(server), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_xpevent.json: " + ex);
        }
    }

    private static void load(MinecraftServer server) {
        serverRef = server;
        active = null;
        try {
            Path f = stateFile(server);
            if (!Files.exists(f)) {
                return;
            }
            JsonObject o = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            Active a = new Active();
            a.cx = o.get("cx").getAsInt();
            a.cz = o.get("cz").getAsInt();
            a.age = o.get("age").getAsInt();
            a.serial = o.get("serial").getAsInt();
            serialCounter = Math.max(serialCounter, o.get("serialCounter").getAsInt());
            a.spot = o.get("spot").getAsInt();
            String v = o.get("villager").getAsString();
            a.villager = v.isEmpty() ? null : UUID.fromString(v);
            a.hasBottle = o.get("hasBottle").getAsBoolean();
            a.bottleIn = o.get("bottleIn").getAsInt();
            a.finished = o.get("finished").getAsBoolean();
            for (JsonElement el : o.getAsJsonArray("spots")) {
                JsonObject so = el.getAsJsonObject();
                Spot s = new Spot();
                s.lantern = BlockPos.fromLong(so.get("pos").getAsLong());
                int id = so.get("old").getAsInt();
                s.old = id < 0 ? null : Block.getStateFromRawId(id);
                s.chest = so.get("chest").getAsBoolean();
                s.x = so.get("x").getAsDouble();
                s.y = so.get("y").getAsDouble();
                s.z = so.get("z").getAsDouble();
                a.spots.add(s);
            }
            if (a.spots.isEmpty()) {
                return;
            }
            a.y0 = o.has("y0") ? o.get("y0").getAsInt() : (int) a.spots.get(0).y;
            Path bf = blocksFile(server);
            if (Files.exists(bf)) {
                JsonObject b = new JsonParser().parse(new String(Files.readAllBytes(bf), StandardCharsets.UTF_8)).getAsJsonObject();
                JsonArray pos = b.getAsJsonArray("pos");
                JsonArray ids = b.getAsJsonArray("ids");
                for (int i = 0; i < pos.size(); i++) {
                    a.saved.put(pos.get(i).getAsLong(), ids.get(i).getAsInt());
                }
            }
            a.spot = Math.max(0, Math.min(a.spot, a.spots.size() - 1));
            active = a;
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_xpevent.json: " + ex);
        }
    }

    // ------------------------------------------------------------------ поиск места

    private static Active findSite(ServerWorld world) {
        for (int attempt = 0; attempt < 80; attempt++) {
            double angle = RNG.nextDouble() * Math.PI * 2;
            double dist = 300 + Math.sqrt(RNG.nextDouble()) * (MAX_DISTANCE - 300);
            int cx = (int) Math.round(Math.cos(angle) * dist);
            int cz = (int) Math.round(Math.sin(angle) * dist);
            if (!zoneFree(world, cx, cz)) {
                continue;
            }
            int[] cargo = EventManager.center();
            if (cargo != null && Math.abs(cargo[0] - cx) < 120 && Math.abs(cargo[1] - cz) < 120) {
                continue;
            }
            // замеряем высоты по сетке: вода и пропасти не подходят, холмы срежем, ямы засыплем
            List<Integer> hs = new ArrayList<>();
            int bad = 0;
            for (int dx = -HALF; dx <= HALF; dx += 5) {
                for (int dz = -HALF; dz <= HALF; dz += 5) {
                    int y = groundY(world, cx + dx, cz + dz);
                    if (y < 0) {
                        bad++;
                    } else {
                        hs.add(y);
                    }
                }
            }
            if (bad > 8 || hs.size() < 20) {
                continue;
            }
            java.util.Collections.sort(hs);
            int lo = hs.get(hs.size() / 10);
            int hi = hs.get(hs.size() * 9 / 10);
            if (hi - lo > 6) {
                continue;
            }
            int y0 = hs.get(hs.size() / 2);
            if (y0 < 12 || y0 > 190 || hasBlockEntities(world, cx, y0, cz)) {
                continue;
            }
            Active a = new Active();
            a.cx = cx;
            a.cz = cz;
            a.y0 = y0;
            int[][] corners = {{-SPOT, -SPOT}, {SPOT, -SPOT}, {-SPOT, SPOT}, {SPOT, SPOT}};
            for (int[] c : corners) {
                Spot s = new Spot();
                s.lantern = new BlockPos(cx + c[0], y0 - 1, cz + c[1]);
                s.x = cx + c[0] + 0.5;
                s.y = y0;
                s.z = cz + c[1] + 0.5;
                a.spots.add(s);
            }
            return a;
        }
        return null;
    }

    /** В площадке нет сундуков, спаунеров и прочих блок-сущностей (их выравнивание бы уничтожило). */
    private static boolean hasBlockEntities(ServerWorld world, int cx, int y0, int cz) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int y = y0 - 8; y <= y0 + 12; y++) {
                    m.set(cx + dx, y, cz + dz);
                    if (world.getBlockEntity(m) != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ постройка

    private static void loadArea(ServerWorld world, Active a) {
        for (int x = (a.cx - HALF - 1) >> 4; x <= (a.cx + HALF + 1) >> 4; x++) {
            for (int z = (a.cz - HALF - 1) >> 4; z <= (a.cz + HALF + 1) >> 4; z++) {
                world.getChunk(x, z);
            }
        }
    }

    /** Ставит блок и запоминает, что там было (один раз), чтобы потом вернуть. */
    private static void put(ServerWorld world, Active a, BlockPos pos, BlockState state) {
        BlockState cur = world.getBlockState(pos);
        if (cur == state) {
            return;
        }
        a.saved.putIfAbsent(pos.asLong(), Block.getRawIdFromState(cur));
        world.setBlockState(pos, state, 2);
    }

    private static void put(ServerWorld world, Active a, int dx, int y, int dz, Block block) {
        put(world, a, new BlockPos(a.cx + dx, y, a.cz + dz), block.getDefaultState());
    }

    /** Выравнивает всю площадку на высоту y0 (срезает холмы и деревья, засыпает ямы и воду) и строит оформление. */
    private static void build(ServerWorld world, Active a) {
        loadArea(world, a);
        int y0 = a.y0;
        BlockState air = Blocks.AIR.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                int x = a.cx + dx;
                int z = a.cz + dz;
                int top = Math.min(254, world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) + 1);
                for (int y = top; y >= y0; y--) {
                    m.set(x, y, z);
                    if (!world.getBlockState(m).isAir()) {
                        put(world, a, m, air);
                    }
                }
                put(world, a, m.set(x, y0 - 1, z), Blocks.GRASS_BLOCK.getDefaultState());
                for (int y = y0 - 2; y >= y0 - 14; y--) {
                    m.set(x, y, z);
                    BlockState st = world.getBlockState(m);
                    boolean soft = st.isAir() || !st.getFluidState().isEmpty() || st.getMaterial().isReplaceable();
                    if (y >= y0 - 4 || soft) {
                        put(world, a, m, Blocks.DIRT.getDefaultState());
                    } else {
                        break;
                    }
                }
            }
        }
        decorate(world, a);
    }

    private static void decorate(ServerWorld world, Active a) {
        int y0 = a.y0;
        Random r = new Random(a.cx * 341873128712L + a.cz * 132897987541L);

        // центр: площадка 9x9, по краю каменные кирпичи, внутри шахматка из лаймового бетона и полированного андезита
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                Block b;
                if (Math.max(Math.abs(dx), Math.abs(dz)) == 4) {
                    b = Blocks.STONE_BRICKS;
                } else {
                    b = ((dx + dz) & 1) == 0 ? Blocks.LIME_CONCRETE : Blocks.POLISHED_ANDESITE;
                }
                put(world, a, dx, y0 - 1, dz, b);
            }
        }
        put(world, a, 0, y0 - 1, 0, Blocks.SEA_LANTERN);
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                put(world, a, sx * 4, y0, sz * 4, Blocks.STONE_BRICKS);
                put(world, a, sx * 4, y0 + 1, sz * 4, Blocks.STONE_BRICKS);
                put(world, a, sx * 4, y0 + 2, sz * 4, Blocks.SEA_LANTERN);
            }
        }

        // 4 места жителя: площадка 5x5, внутри лаймовый бетон, в центре морской фонарь (метка), по углам столбики
        for (Spot s : a.spots) {
            int px = s.lantern.getX() - a.cx;
            int pz = s.lantern.getZ() - a.cz;
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean edge = Math.max(Math.abs(dx), Math.abs(dz)) == 2;
                    put(world, a, px + dx, y0 - 1, pz + dz, edge ? Blocks.POLISHED_ANDESITE : Blocks.LIME_CONCRETE);
                }
            }
            put(world, a, px, y0 - 1, pz, Blocks.SEA_LANTERN);
            for (int sx = -1; sx <= 1; sx += 2) {
                for (int sz = -1; sz <= 1; sz += 2) {
                    put(world, a, px + sx * 2, y0, pz + sz * 2, Blocks.STONE_BRICKS);
                }
            }
        }

        // 4 прилавка из дуба по сторонам
        int[][] stalls = {{11, 0}, {-11, 0}, {0, 11}, {0, -11}};
        for (int[] st : stalls) {
            boolean alongX = st[1] == 0;   // прилавок вытянут перпендикулярно направлению от центра
            for (int k = -1; k <= 1; k++) {
                int dx = st[0] + (alongX ? 0 : k);
                int dz = st[1] + (alongX ? k : 0);
                put(world, a, dx, y0, dz, k == 0 ? Blocks.OAK_PLANKS : Blocks.OAK_LOG);
                if (k != 0) {
                    put(world, a, dx, y0 + 1, dz, Blocks.OAK_LOG);
                    put(world, a, dx, y0 + 2, dz, Blocks.OAK_LOG);
                }
                put(world, a, dx, y0 + 3, dz, Blocks.OAK_SLAB);
            }
        }

        // край площадки: невысокие руины из мшистого камня, с проёмами; по углам столбы
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != HALF) {
                    continue;
                }
                if (Math.abs(dx) == HALF && Math.abs(dz) == HALF) {
                    for (int h = 0; h < 3; h++) {
                        put(world, a, dx, y0 + h, dz, Blocks.MOSSY_STONE_BRICKS);
                    }
                    continue;
                }
                if (r.nextInt(10) < 7) {
                    Block b = r.nextBoolean() ? Blocks.MOSSY_COBBLESTONE : Blocks.MOSSY_STONE_BRICKS;
                    put(world, a, dx, y0, dz, b);
                    if (r.nextInt(10) < 3) {
                        put(world, a, dx, y0 + 1, dz, b);
                    }
                }
            }
        }

        // цветы и трава на свободной земле
        Block[] plants = {Blocks.DANDELION, Blocks.POPPY, Blocks.AZURE_BLUET, Blocks.OXEYE_DAISY, Blocks.CORNFLOWER};
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF + 1; dx <= HALF - 1; dx++) {
            for (int dz = -HALF + 1; dz <= HALF - 1; dz++) {
                int roll = r.nextInt(100);
                if (roll >= 12) {
                    continue;
                }
                Block pick = roll < 4 ? plants[r.nextInt(plants.length)] : Blocks.GRASS;
                m.set(a.cx + dx, y0, a.cz + dz);
                if (!world.getBlockState(m).isAir()) {
                    continue;
                }
                m.set(a.cx + dx, y0 - 1, a.cz + dz);
                if (world.getBlockState(m).getBlock() != Blocks.GRASS_BLOCK) {
                    continue;
                }
                put(world, a, dx, y0, dz, pick);
            }
        }
    }

    private static boolean zoneFree(ServerWorld world, int cx, int cz) {
        int r = HALF + 6;
        int[][] pts = {{0, 0}, {r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, -r}, {r, -r}, {-r, r}};
        for (int[] p : pts) {
            BlockPos pos = new BlockPos(cx + p[0], 64, cz + p[1]);
            if (SpawnProtection.contains(world, pos) || !world.getWorldBorder().contains(pos)) {
                return false;
            }
        }
        return !PrivateManager.intersects(world, new Box(cx - r, 0, cz - r, cx + r, 256, cz + r));
    }

    /** Первая свободная высота над твёрдой землёй (не вода), или -1. */
    private static int groundY(ServerWorld world, int x, int z) {
        world.getChunk(x >> 4, z >> 4);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y < 10 || y > 200) {
            return -1;
        }
        BlockState below = world.getBlockState(new BlockPos(x, y - 1, z));
        if (below.isAir() || !below.getFluidState().isEmpty()) {
            return -1;
        }
        return y;
    }

    // ------------------------------------------------------------------ житель

    private static void spawnVillager(ServerWorld world, Active a) {
        Spot sp = a.spots.get(a.spot);
        VillagerEntity v = EntityType.VILLAGER.create(world);
        if (v == null) {
            return;
        }
        v.refreshPositionAndAngles(sp.x, sp.y, sp.z, RNG.nextFloat() * 360.0F, 0.0F);
        v.setAiDisabled(true);
        v.setInvulnerable(true);
        v.setPersistent();
        v.setSilent(true);
        v.setCustomName(new LiteralText("Житель опыта").formatted(Formatting.GREEN, Formatting.BOLD));
        v.setCustomNameVisible(true);
        v.addScoreboardTag(TAG_VILLAGER);
        v.equipStack(EquipmentSlot.MAINHAND, a.hasBottle ? bottle(1, a.serial) : ItemStack.EMPTY);
        world.spawnEntity(v);
        a.villager = v.getUuid();
    }

    private static VillagerEntity villager(ServerWorld world, Active a) {
        Entity e = a.villager == null ? null : world.getEntity(a.villager);
        return e instanceof VillagerEntity && !e.removed ? (VillagerEntity) e : null;
    }

    private static ActionResult onUseEntity(net.minecraft.entity.player.PlayerEntity player, World world, Hand hand, Entity entity) {
        // пузырёк ивента нельзя класть в рамки и на стойки
        if ((entity instanceof ItemFrameEntity || entity instanceof ArmorStandEntity) && isBottle(player.getStackInHand(hand))) {
            return ActionResult.FAIL;
        }
        if (!(entity instanceof VillagerEntity) || !entity.getScoreboardTags().contains(TAG_VILLAGER)) {
            return ActionResult.PASS;
        }
        if (world.isClient || !(player instanceof ServerPlayerEntity)) {
            return ActionResult.SUCCESS;
        }
        if (hand != Hand.MAIN_HAND) {
            return ActionResult.SUCCESS;
        }
        ServerPlayerEntity sp = (ServerPlayerEntity) player;
        Active a = active;
        if (a == null || a.villager == null || !a.villager.equals(entity.getUuid())) {
            entity.remove();   // забытый житель прошлого ивента
            return ActionResult.FAIL;
        }
        ServerWorld sw = (ServerWorld) world;
        VillagerEntity v = (VillagerEntity) entity;
        if (a.hasBottle) {
            takeBottle(sw, sp, v, a);
        } else {
            punish(sp, v);
        }
        return ActionResult.SUCCESS;
    }

    private static void takeBottle(ServerWorld world, ServerPlayerEntity p, VillagerEntity v, Active a) {
        p.inventory.offerOrDrop(world, bottle(1, a.serial));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 20 * 5, 0, false, false));
        p.sendMessage(new LiteralText("Ты получил пузырёк опыта: ").formatted(Formatting.GREEN)
                .append(new LiteralText(POINTS_PER_BOTTLE + " очков опыта в секунду, пока он в инвентаре").formatted(Formatting.GRAY)), true);
        a.hasBottle = false;
        v.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        a.bottleIn = BOTTLE_MIN + RNG.nextInt(Math.max(1, BOTTLE_MAX - BOTTLE_MIN + 1));
        // житель уходит на другое место
        world.spawnParticles(ParticleTypes.PORTAL, v.getX(), v.getY() + 1.0, v.getZ(), 30, 0.3, 0.6, 0.3, 0.1);
        int next = a.spot;
        if (a.spots.size() > 1) {
            while (next == a.spot) {
                next = RNG.nextInt(a.spots.size());
            }
        }
        a.spot = next;
        Spot s = a.spots.get(next);
        v.refreshPositionAndAngles(s.x, s.y, s.z, RNG.nextFloat() * 360.0F, 0.0F);
        v.setVelocity(Vec3d.ZERO);
        world.spawnParticles(ParticleTypes.PORTAL, s.x, s.y + 1.0, s.z, 30, 0.3, 0.6, 0.3, 0.1);
        save();
    }

    /** Жителя без пузырька трогать нельзя: отбрасывает и бьёт, броня не помогает. */
    private static void punish(ServerPlayerEntity p, VillagerEntity v) {
        double dx = p.getX() - v.getX();
        double dz = p.getZ() - v.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.01) {
            dx = -Math.sin(Math.toRadians(p.yaw));
            dz = Math.cos(Math.toRadians(p.yaw));
            len = 1.0;
        }
        double speed = Math.max(0.5, KNOCKBACK * 0.16);
        p.setVelocity(dx / len * speed, 0.55, dz / len * speed);
        p.velocityModified = true;
        p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
        p.damage(DamageSource.MAGIC, DAMAGE);   // магический урон идёт мимо брони
        p.sendMessage(new LiteralText("Пузырька пока нет, не трогай жителя!").formatted(Formatting.RED), true);
    }

    // ------------------------------------------------------------------ тик

    private static void onTick(MinecraftServer server) {
        tick++;
        Active a = active;
        if (a == null) {
            if (tick % 40 == 0) {
                // пузырьки без идущего ивента не живут
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    stripBottles(p, true);
                }
            }
            return;
        }
        ServerWorld world = server.getOverworld();
        a.age++;
        if (a.age % 200 == 0) {
            save();
        }
        if (a.finished) {
            // сундуки уже стоят: ивент ещё LINGER на месте, потом исчезает (и только тогда пойдёт отсчёт до нового)
            if (a.age % 20 == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    stripBottles(p, false);
                }
            }
            if (a.age >= DURATION + LINGER) {
                end(server, false);
            }
            return;
        }
        if (a.age >= DURATION) {
            finish(server, a);
            return;
        }

        // новый пузырёк у жителя
        if (!a.hasBottle && --a.bottleIn <= 0) {
            a.hasBottle = true;
            save();
            VillagerEntity v = villager(world, a);
            if (v != null) {
                v.equipStack(EquipmentSlot.MAINHAND, bottle(1, a.serial));
            }
        }
        // житель стоит на месте (и пересоздаётся, если пропал)
        if (a.age % 10 == 0) {
            Spot s = a.spots.get(a.spot);
            if (world.isChunkLoaded(new BlockPos(s.x, s.y, s.z))) {
                VillagerEntity v = villager(world, a);
                if (v == null) {
                    spawnVillager(world, a);
                } else if (v.squaredDistanceTo(s.x, s.y, s.z) > 0.5) {
                    v.refreshPositionAndAngles(s.x, s.y, s.z, v.yaw, 0.0F);
                    v.setVelocity(Vec3d.ZERO);
                }
            }
        }

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (tick % 5 == 0) {
                guardContainers(p);
            }
            if (tick % 20 == 0) {
                secondly(p, a);
            }
        }
    }

    /** Пузырёк нельзя положить ни в сундук, ни в эндер-сундук, ни в другой контейнер, только выбросить. */
    private static void guardContainers(ServerPlayerEntity p) {
        if (p.currentScreenHandler == null) {
            return;
        }
        for (Slot slot : p.currentScreenHandler.slots) {
            if (slot.inventory == p.inventory) {
                continue;
            }
            ItemStack st = slot.getStack();
            if (isBottle(st)) {
                slot.setStack(ItemStack.EMPTY);
                p.inventory.offerOrDrop(p.world, st);
                p.sendMessage(new LiteralText("Пузырёк опыта нельзя положить в контейнер, его можно только выбросить")
                        .formatted(Formatting.RED), true);
            }
        }
    }

    /** Раз в секунду: стaрые пузырьки, расстояние до ивента, опыт и свечение. */
    private static void secondly(ServerPlayerEntity p, Active a) {
        stripBottles(p, true);
        int n = bottlesIn(p);
        if (n <= 0) {
            return;
        }
        double dist = p.world.getRegistryKey() == World.OVERWORLD
                ? Math.sqrt(Math.pow(p.getX() - a.cx, 2) + Math.pow(p.getZ() - a.cz, 2)) : Double.MAX_VALUE;
        if (dist >= REMOVE_DISTANCE) {
            stripBottles(p, false);
            p.sendMessage(new LiteralText("Вы слишком далеко от ивента, пузырьки опыта забраны").formatted(Formatting.RED), true);
            return;
        }
        if (dist >= WARN_DISTANCE) {
            p.sendMessage(new LiteralText("Не отходите от ивента далеко! Пузырьки заберут на " + REMOVE_DISTANCE
                    + " блоках (сейчас " + (int) dist + ")").formatted(Formatting.YELLOW), true);
        }
        int score = p.getScore();   // как у бутылька: счёт игрока опыт не меняет
        p.addExperience(n * POINTS_PER_BOTTLE);
        p.setScore(score);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 60, 0, false, false));
    }
}
