package com.arsenal.sphere;

import com.arsenal.Arsenal;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VData;
import com.arsenal.vi.VI;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Сферы (головы игроков) и талисманы (тотемы): уровни эффектов хранятся в NBT предмета (ArsenalData). */
public final class Spheres {
    /** Предметы с фиксированными уровнями (Флеш, Цербер, Stinger, Eternity, Infinity). */
    private static final Map<String, int[]> FIXED = new HashMap<>();
    /** Готовые величины эффектов вместо уровень * perLevel (талисман Dragon). */
    private static final Map<String, double[]> AMOUNTS = new HashMap<>();
    private static final Map<String, Boolean> KNOWN = new HashMap<>();

    private Spheres() {
    }

    public static void define(String id, int[] fixed, double[] amounts) {
        KNOWN.put(id, Boolean.TRUE);
        if (fixed != null) {
            FIXED.put(id, fixed);
        }
        if (amounts != null) {
            AMOUNTS.put(id, amounts);
        }
    }

    /** Вектор уровней: скорость, урон, броня, скорость атаки, макс. здоровье. */
    public static int[] v(int speed, int damage, int armor, int attackSpeed, int health) {
        return new int[]{speed, damage, armor, attackSpeed, health};
    }

    private static int[] one(SphereEffect effect, int level) {
        int[] r = new int[SphereEffect.COUNT];
        r[effect.ordinal()] = level;
        return r;
    }

    /** Сфера или талисман мода? */
    public static boolean isEffectItem(ItemStack stack) {
        VI vi = VI.of(stack);
        return vi != null && KNOWN.containsKey(vi.id);
    }

    public static boolean isSphere(ItemStack stack) {
        VI vi = VI.of(stack);
        return vi != null && vi.id.startsWith("sphere_");
    }

    /** Уровни эффектов в порядке SphereEffect. */
    public static int[] effects(ItemStack stack) {
        VI vi = VI.of(stack);
        if (vi != null && FIXED.containsKey(vi.id)) {
            return FIXED.get(vi.id).clone();
        }
        int[] result = new int[SphereEffect.COUNT];
        for (SphereEffect e : SphereEffect.values()) {
            result[e.ordinal()] = VData.get(stack, e.key());
        }
        return result;
    }

    /** Величина эффекта для атрибута: готовое значение или уровень * perLevel. */
    public static double amount(ItemStack stack, SphereEffect effect) {
        VI vi = VI.of(stack);
        if (vi != null && AMOUNTS.containsKey(vi.id)) {
            return AMOUNTS.get(vi.id)[effect.ordinal()];
        }
        return effects(stack)[effect.ordinal()] * effect.perLevel;
    }

    /** Строки описания: эффекты (и бонусы Dragon). */
    public static List<Text> loreLines(ItemStack stack) {
        List<Text> out = new ArrayList<>();
        VI vi = VI.of(stack);
        if (vi != null && AMOUNTS.containsKey(vi.id)) {
            double[] a = AMOUNTS.get(vi.id);
            if (a[SphereEffect.SPEED.ordinal()] > 0) {
                out.add(new LiteralText(Lang.format("tooltip.arsenal.bonus_speed",
                        Math.round(a[SphereEffect.SPEED.ordinal()] * 100))).formatted(Formatting.GRAY));
            }
            if (a[SphereEffect.DAMAGE.ordinal()] > 0) {
                out.add(new LiteralText(Lang.format("tooltip.arsenal.bonus_damage",
                        Math.round(a[SphereEffect.DAMAGE.ordinal()]))).formatted(Formatting.GRAY));
            }
            return out;
        }
        int[] levels = effects(stack);
        for (SphereEffect e : SphereEffect.values()) {
            int level = levels[e.ordinal()];
            if (level > 0) {
                out.add(new LiteralText(Lang.get("enchantment.arsenal.sphere_" + e.id) + " "
                        + com.arsenal.vi.EnchantLore.roman(level)).formatted(Formatting.GRAY));
            }
        }
        return out;
    }

    /** Предмет с уровнями эффектов, записанными в данные. */
    public static ItemStack stack(VI item, int[] levels) {
        ItemStack s = item.stack();
        for (SphereEffect e : SphereEffect.values()) {
            if (levels[e.ordinal()] > 0) {
                VData.set(s, e.key(), levels[e.ordinal()]);
            }
        }
        return s;
    }

    /** Сумма уровней = "очки" сферы: 1 обычная, 2 эпическая, 3-4 легендарная, 5 мифическая. */
    public static int points(int[] levels) {
        int sum = 0;
        for (int l : levels) {
            sum += l;
        }
        return sum;
    }

    /** Сфера или талисман с одним случайным эффектом заданного уровня. */
    public static ItemStack randomEffect(VI item, int level, java.util.Random rnd) {
        SphereEffect[] all = SphereEffect.values();
        return stack(item, one(all[rnd.nextInt(all.length)], level));
    }

    /** Мифическая сфера с одним из трёх наборов, как в креативе. */
    public static ItemStack mythic(java.util.Random rnd) {
        int i = rnd.nextInt(3);
        return stack(Arsenal.SPHERE_MYTHIC, i == 0 ? v(0, 3, 2, 0, 0) : i == 1 ? v(0, 2, 3, 0, 0) : v(2, 0, 3, 0, 0));
    }

    /** Полный набор (команда /arsenal list и выдача). */
    public static void addCreativeStacks(List<ItemStack> out) {
        VI[][] groups = {{Arsenal.SPHERE_COMMON}, {Arsenal.SPHERE_EPIC}, {Arsenal.SPHERE_LEGENDARY},
                {Arsenal.TALISMAN_COMMON}, {Arsenal.TALISMAN}, {Arsenal.TALISMAN_LEGENDARY}};
        int[] lvls = {1, 2, 3, 1, 2, 3};
        for (int g = 0; g < groups.length; g++) {
            for (SphereEffect e : SphereEffect.values()) {
                out.add(stack(groups[g][0], one(e, lvls[g])));
            }
        }
        // три мифические: урон 3 + броня 2, броня 3 + урон 2, броня 3 + скорость 2
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(0, 3, 2, 0, 0)));
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(0, 2, 3, 0, 0)));
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(2, 0, 3, 0, 0)));
        out.add(Arsenal.SPHERE_FLASH.stack());
        out.add(Arsenal.SPHERE_CERBERUS.stack());
        out.add(Arsenal.SPHERE_STINGER.stack());
        out.add(Arsenal.SPHERE_ETERNITY.stack());
        out.add(Arsenal.TALISMAN_STINGER.stack());
        out.add(Arsenal.TALISMAN_ETERNITY.stack());
        out.add(Arsenal.TALISMAN_INFINITY.stack());
        out.add(Arsenal.TALISMAN_DRAGON.stack());
    }
}
