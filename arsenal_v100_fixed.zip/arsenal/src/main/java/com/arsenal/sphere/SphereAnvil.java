package com.arsenal.sphere;

import com.arsenal.Arsenal;
import net.minecraft.item.Item;
import com.arsenal.vi.VI;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Свои рецепты наковальни:
 *  - две обычные/эпические/легендарные сферы -> одна сфера (эффекты складываются);
 *    результат должен быть эпической (2 очка, 30 ур.) или легендарной (3-4 очка, 30 ур.);
 *    мифическую в наковальне получить нельзя;
 *  - сфера + тотем бессмертия -> талисман того же вида (обычный/эпический/легендарный/Stinger/Eternity), всегда 30 ур.
 */
public final class SphereAnvil {
    public static final int EPIC_COST = 30;
    public static final int LEGENDARY_COST = 30;
    public static final int TALISMAN_COST = 30;
    public static final int MAX_EFFECT_LEVEL_IN_ANVIL = 3;
    public static final int MAX_POINTS_IN_ANVIL = 4;

    public static class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private SphereAnvil() {
    }

    private static boolean isMergeable(ItemStack s) {
        return Arsenal.SPHERE_COMMON.is(s) || Arsenal.SPHERE_EPIC.is(s) || Arsenal.SPHERE_LEGENDARY.is(s);
    }

    private static boolean canMakeTalisman(ItemStack s) {
        return isMergeable(s) || Arsenal.SPHERE_STINGER.is(s) || Arsenal.SPHERE_ETERNITY.is(s);
    }

    private static boolean isTotem(ItemStack s) {
        return s.getItem() == Items.TOTEM_OF_UNDYING && VI.of(s) == null;
    }

    /** null = это не наш рецепт, остаётся обычное поведение наковальни. */
    public static Result compute(ItemStack left, ItemStack right) {
        if (isTotem(right) && canMakeTalisman(left)) {
            return talisman(left);
        }
        if (isTotem(left) && canMakeTalisman(right)) {
            return talisman(right);
        }
        if (isMergeable(left) && isMergeable(right)) {
            return merge(left, right);
        }
        return null;
    }

    /** Каждая сфера даёт талисман своего вида; уровни эффектов переносятся. */
    private static Result talisman(ItemStack sphere) {
        if (Arsenal.SPHERE_ETERNITY.is(sphere)) {
            return new Result(Arsenal.TALISMAN_ETERNITY.stack(), TALISMAN_COST);
        }
        if (Arsenal.SPHERE_STINGER.is(sphere)) {
            return new Result(Arsenal.TALISMAN_STINGER.stack(), TALISMAN_COST);
        }
        VI target = Arsenal.SPHERE_COMMON.is(sphere) ? Arsenal.TALISMAN_COMMON
                : Arsenal.SPHERE_EPIC.is(sphere) ? Arsenal.TALISMAN
                : Arsenal.TALISMAN_LEGENDARY;
        int[] levels = Spheres.effects(sphere);
        return new Result(Spheres.stack(target, levels), TALISMAN_COST);
    }

    private static Result merge(ItemStack a, ItemStack b) {
        int[] la = Spheres.effects(a);
        int[] lb = Spheres.effects(b);
        int[] sum = new int[SphereEffect.COUNT];
        for (int i = 0; i < sum.length; i++) {
            sum[i] = la[i] + lb[i];
            if (sum[i] > MAX_EFFECT_LEVEL_IN_ANVIL) {
                return null;
            }
        }
        int points = Spheres.points(sum);
        if (points > MAX_POINTS_IN_ANVIL) {
            return null; // дальше только мифические и особые, их в наковальне не сделать
        }
        if (points == 2) {
            return new Result(Spheres.stack(Arsenal.SPHERE_EPIC, sum), EPIC_COST);
        }
        if (points >= 3) {
            return new Result(Spheres.stack(Arsenal.SPHERE_LEGENDARY, sum), LEGENDARY_COST);
        }
        return null;
    }
}
