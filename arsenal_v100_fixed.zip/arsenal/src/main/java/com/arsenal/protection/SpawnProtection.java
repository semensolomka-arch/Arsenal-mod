package com.arsenal.protection;

import com.arsenal.castle.CastleConstants;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.block.AbstractFurnaceBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorStandItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.item.DecorationItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MinecartItem;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Защита замка на нулевых координатах: внутри зоны нельзя ломать блоки, строить (блоки, вёдра, огонь,
 * рамки и т.п.), ставить трапки, а взрывы не разрушают блоки.
 *
 * Двери, люки, калитки, бочки, сундуки, печки, кнопки и рычаги внутри зоны тоже не открываются.
 * Зона: прямоугольник замка + 50 блоков вокруг (по высоте без ограничений), только в Обычном мире.
 * Обходить защиту могут операторы в творческом режиме (так им можно строить и чинить замок).
 */
public final class SpawnProtection {
    /** Сколько блоков вокруг замка тоже защищено. */
    public static final int MARGIN = 50;

    private static final int MIN_X = CastleConstants.MIN_X - MARGIN;
    private static final int MAX_X = CastleConstants.MAX_X + MARGIN;
    private static final int MIN_Z = CastleConstants.MIN_Z - MARGIN;
    private static final int MAX_Z = CastleConstants.MAX_Z + MARGIN;

    private static final Map<UUID, Long> LAST_MESSAGE = new HashMap<>();

    private SpawnProtection() {
    }

    public static boolean contains(World world, BlockPos pos) {
        return (world.getRegistryKey() == World.OVERWORLD
                && pos.getX() >= MIN_X && pos.getX() <= MAX_X && pos.getZ() >= MIN_Z && pos.getZ() <= MAX_Z)
                || com.arsenal.spawn.SpawnManager.contains(world, pos)
                || com.arsenal.spawn.PvpArena.contains(world, pos);
    }

    /**
     * Тихая зона: замок со спавном и ПВП-арена (/warp pvp) или площадка текущего ивента (груз, Опытный Тыпо, корабль).
     * Здесь не спавнятся мобы, не падают блоки и нельзя ставить дом.
     */
    public static boolean quietZone(World world, BlockPos pos) {
        return contains(world, pos) || com.arsenal.event.EventManager.inZone(world, pos);
    }

    /** Пересекается ли куб привата (сторона 2*half+1 вокруг блока) с зоной замка. */
    public static boolean overlapsZone(World world, BlockPos center, int half) {
        return (world.getRegistryKey() == World.OVERWORLD
                && center.getX() + half >= MIN_X && center.getX() - half <= MAX_X
                && center.getZ() + half >= MIN_Z && center.getZ() - half <= MAX_Z)
                || com.arsenal.spawn.SpawnManager.overlaps(world, center, half)
                || com.arsenal.spawn.PvpArena.overlaps(world, center, half);
    }

    /** Операторы в творческом режиме обходят защиту. */
    public static boolean bypass(PlayerEntity player) {
        return player.isCreative() && player.hasPermissionLevel(2);
    }

    public static void deny(ServerPlayerEntity player, String message) {
        long now = player.world.getTime();
        Long last = LAST_MESSAGE.get(player.getUuid());
        if (last != null && now - last < 20) {
            return;
        }
        LAST_MESSAGE.put(player.getUuid(), now);
        player.sendMessage(new LiteralText(message).formatted(Formatting.RED), true);
    }

    /** Двери, люки, калитки, бочки, сундуки, печки, кнопки и рычаги в зоне замка не открываются. */
    private static boolean locked(Block block) {
        return block instanceof DoorBlock || block instanceof TrapdoorBlock || block instanceof FenceGateBlock
                || block instanceof BarrelBlock || block instanceof ChestBlock || block instanceof EnderChestBlock
                || block instanceof AbstractFurnaceBlock || block instanceof AbstractButtonBlock
                || block instanceof LeverBlock || block instanceof ShulkerBoxBlock
                || block instanceof net.minecraft.block.RespawnAnchorBlock;   // Ядро солнца вне Незера взрывается
    }

    private static boolean places(Item item) {
        return item instanceof BlockItem || item instanceof FlintAndSteelItem || item instanceof FireChargeItem
                || item instanceof ArmorStandItem || item instanceof DecorationItem || item instanceof MinecartItem;
    }

    public static void init() {
        // ломать нельзя (в том числе в креативе у обычных игроков)
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            // шалкеры события ломаются (сервер сам решает, чей это шалкер, см. ShulkerEvent)
            if (world.getBlockState(pos).getBlock() instanceof ShulkerBoxBlock) {
                return ActionResult.PASS;
            }
            if (contains(world, pos) && !bypass(player) && !com.arsenal.spawn.MineManager.isBreakable(world, pos)) {
                if (!world.isClient) {
                    deny((ServerPlayerEntity) player, "В зоне замка нельзя ломать блоки");
                }
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        // строить нельзя: блоки, огонь, рамки, стойки и т.п.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            // двери, люки, бочки и т.п. в зоне замка не открываются (кроме операторов в творческом режиме)
            if (contains(world, hit.getBlockPos()) && !bypass(player)
                    && locked(world.getBlockState(hit.getBlockPos()).getBlock())) {
                if (!world.isClient) {
                    deny((ServerPlayerEntity) player, "В зоне замка этим нельзя пользоваться");
                }
                return ActionResult.FAIL;
            }
            ItemStack stack = player.getStackInHand(hand);
            if (!places(stack.getItem())) {
                return ActionResult.PASS;
            }
            BlockPos clicked = hit.getBlockPos();
            BlockPos target = clicked.offset(hit.getSide());
            if (!contains(world, clicked) && !contains(world, target)) {
                return ActionResult.PASS;
            }
            if (bypass(player)) {
                return ActionResult.PASS;
            }
            // в раскопанной шахте можно ставить факелы (шахта обновляется, поставленное исчезнет)
            if ((stack.getItem() == net.minecraft.item.Items.TORCH || stack.getItem() == net.minecraft.item.Items.SOUL_TORCH)
                    && com.arsenal.spawn.MineManager.isInterior(world, target)) {
                return ActionResult.PASS;
            }
            // сундуки, двери, кнопки и т.п. открываются как обычно, как в ванили
            if (!player.isSneaking()) {
                ActionResult result = world.getBlockState(clicked).onUse(world, player, hand, hit);
                if (result.isAccepted()) {
                    return result;
                }
            }
            if (!world.isClient) {
                deny((ServerPlayerEntity) player, "В зоне замка нельзя строить");
            }
            return ActionResult.FAIL;
        });

        // вёдра: нельзя выливать и набирать воду и лаву
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!(stack.getItem() instanceof BucketItem) || bypass(player)) {
                return TypedActionResult.pass(stack);
            }
            HitResult hit = player.raycast(5.0D, 1.0F, true);
            if (hit.getType() == HitResult.Type.BLOCK && contains(world, ((BlockHitResult) hit).getBlockPos())) {
                if (!world.isClient) {
                    deny((ServerPlayerEntity) player, "В зоне замка нельзя строить");
                }
                return TypedActionResult.fail(stack);
            }
            return TypedActionResult.pass(stack);
        });
    }
}
