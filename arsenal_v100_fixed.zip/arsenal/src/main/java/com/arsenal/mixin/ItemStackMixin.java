package com.arsenal.mixin;

import com.arsenal.vi.EnchantLore;
import com.arsenal.vi.VI;
import com.arsenal.vi.ViEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 1) Предметы мода на основе блока или огненного заряда не ставятся и не поджигают (кроме динамита, привата, наковальни).
 * 2) Названия зачарований мода дописываются в описание.
 */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true)
    private void arsenal$noPlace(ItemUsageContext context, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack self = (ItemStack) (Object) this;
        VI vi = VI.of(self);
        if (vi == null || vi.vanillaUse) {
            return;
        }
        if (!(self.getItem() instanceof BlockItem) && !(self.getItem() instanceof FireChargeItem)) {
            return;
        }
        if (context.getWorld().isClient) {
            return;
        }
        PlayerEntity player = context.getPlayer();
        if (player instanceof ServerPlayerEntity) {
            ViEvents.blockUseCancelled((ServerPlayerEntity) player, self, vi);
        }
        cir.setReturnValue(ActionResult.FAIL);
    }

    @Inject(method = "addEnchantment", at = @At("RETURN"))
    private void arsenal$enchantLore(Enchantment enchantment, int level, CallbackInfo ci) {
        EnchantLore.refresh((ItemStack) (Object) this);
    }
}
