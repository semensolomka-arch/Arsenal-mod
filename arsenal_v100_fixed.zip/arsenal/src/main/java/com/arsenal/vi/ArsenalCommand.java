package com.arsenal.vi;

import com.arsenal.Arsenal;
import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.sphere.SphereEffect;
import com.arsenal.sphere.Spheres;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * /arsenal give &lt;предмет&gt; [количество] и /arsenal list: выдача предметов мода (раньше они лежали во вкладке креатива,
 * а без клиентской части вкладки нет). Только для операторов.
 */
public final class ArsenalCommand {
    private ArsenalCommand() {
    }

    private static Map<String, Supplier<ItemStack>> catalog() {
        Map<String, Supplier<ItemStack>> m = new LinkedHashMap<>();
        for (VI vi : VI.all()) {
            m.put(vi.id, vi::stack);
        }
        m.put("infinity_sword", Arsenal::infinitySword);
        m.put("cerberus_sword", Arsenal::cerberusSword);
        m.put("eternity_sword", Arsenal::eternitySword);
        m.put("stinger_sword", Arsenal::stingerSword);
        m.put("artifact_full", ArtifactEffects::fullArtifact);
        VI[] withLevel = {Arsenal.SPHERE_COMMON, Arsenal.SPHERE_EPIC, Arsenal.SPHERE_LEGENDARY,
                Arsenal.TALISMAN_COMMON, Arsenal.TALISMAN, Arsenal.TALISMAN_LEGENDARY};
        int[] lvls = {1, 2, 3, 1, 2, 3};
        for (int i = 0; i < withLevel.length; i++) {
            for (SphereEffect e : SphereEffect.values()) {
                final VI vi = withLevel[i];
                final int level = lvls[i];
                final SphereEffect effect = e;
                m.put(vi.id + "_" + e.id, () -> {
                    int[] l = new int[SphereEffect.COUNT];
                    l[effect.ordinal()] = level;
                    return Spheres.stack(vi, l);
                });
            }
        }
        m.put("sphere_mythic_1", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(0, 3, 2, 0, 0)));
        m.put("sphere_mythic_2", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(0, 2, 3, 0, 0)));
        m.put("sphere_mythic_3", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(2, 0, 3, 0, 0)));
        return m;
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("arsenal")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("list").executes(ctx -> {
                            StringBuilder sb = new StringBuilder();
                            for (String id : catalog().keySet()) {
                                if (sb.length() > 0) {
                                    sb.append(", ");
                                }
                                sb.append(id);
                            }
                            ctx.getSource().sendFeedback(new LiteralText(sb.toString()).formatted(Formatting.GRAY), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("give")
                                .then(CommandManager.argument("item", StringArgumentType.word())
                                        .suggests((ctx, builder) -> CommandSource.suggestMatching(catalog().keySet(), builder))
                                        .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "item"), 1))
                                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 64))
                                                .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "item"),
                                                        IntegerArgumentType.getInteger(ctx, "count"))))))));
    }

    private static int give(ServerCommandSource src, String id, int count) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        Supplier<ItemStack> sup = catalog().get(id);
        if (sup == null) {
            src.sendError(new LiteralText("Нет такого предмета: " + id + ". Список: /arsenal list"));
            return 0;
        }
        ServerPlayerEntity player = src.getPlayer();
        for (int i = 0; i < count; i++) {
            ItemStack s = sup.get();
            VI vi = VI.of(s);
            if (vi != null && !vi.unique && s.getMaxCount() > 1) {
                s.setCount(1);
            }
            player.giveItemStack(s);
        }
        src.sendFeedback(new LiteralText("Выдано: " + id + " x" + count).formatted(Formatting.GREEN), false);
        return count;
    }
}
