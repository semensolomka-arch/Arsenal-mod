package com.arsenal;

import com.arsenal.vi.VI;
import com.arsenal.vi.ViEvents;
import com.arsenal.artifact.ArtifactEffect;
import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.enchantment.HomingEnchantment;
import com.arsenal.enchantment.ImpenetrableEnchantment;
import com.arsenal.expkeeper.ExpKeeper;
import com.arsenal.enchantment.MeleeEnchantment;
import com.arsenal.sphere.SphereEffect;
import com.arsenal.sphere.SphereEffects;
import com.arsenal.sphere.Spheres;
import com.arsenal.castle.CastleBuilder;
import com.arsenal.exp.ExpCommand;
import com.arsenal.kit.KitCommand;
import com.arsenal.special.Specials;
import com.arsenal.tool.Filters;
import com.arsenal.shulker.ShulkerEvent;
import com.arsenal.tool.ToolEnchants;
import com.arsenal.rune.RuneType;
import com.arsenal.rune.Runes;
import com.arsenal.bind.Binds;
import com.arsenal.protection.SpawnProtection;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Rarity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.text.TextColor;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.registry.Registry;

public class Arsenal implements ModInitializer {
    public static final String MODID = "arsenal";

    public static VI TRAP;
    public static VI STUN;
    public static VI SNOW_BALL;
    public static VI EXP_BUBBLE;
    public static VI ARTIFACT;

    // Только четыре пользовательских зелья III уровня: скорость/сила на 6 и 3 минуты.
    public static VI SPEED_III_6M, SPEED_III_3M;
    public static VI STRENGTH_III_6M, STRENGTH_III_3M;
    public static VI WINNER_POTION;
    /** Отмычки таинственного корабля: lockpick_common, lockpick_rare, lockpick_secret. */
    public static final VI[] LOCKPICKS = new VI[3];
    public static Enchantment IMPENETRABLE;
    public static Enchantment HOMING;
    public static Enchantment CRITICAL;
    public static Enchantment DESTROYER;

    // Сферы и талисманы
    public static VI SPHERE_COMMON;
    public static VI SPHERE_EPIC;
    public static VI SPHERE_LEGENDARY;
    public static VI SPHERE_MYTHIC;
    public static VI SPHERE_FLASH;
    public static VI SPHERE_CERBERUS;
    public static VI SPHERE_STINGER;
    public static VI SPHERE_ETERNITY;
    public static VI TALISMAN_COMMON;
    public static VI TALISMAN;            // эпический
    public static VI TALISMAN_LEGENDARY;
    public static VI TALISMAN_STINGER;
    public static VI TALISMAN_ETERNITY;
    public static VI TALISMAN_INFINITY;
    public static VI TALISMAN_DRAGON;
    public static VI EXPLOSIVE_TRAP;
    public static VI BLAST_CHARM;
    public static VI JAKE_LANTERN;
    public static VI JAKE_PICKAXE;
    public static VI EXP_BOTTLE_15;
    public static VI EXP_BOTTLE_30;
    public static VI EXP_BOTTLE_50;

    // Мечи
    public static VI INFINITY_SWORD;
    public static VI CERBERUS_SWORD;
    public static VI ETERNITY_SWORD;
    public static VI STINGER_SWORD;

    @Override
    public void onInitialize() {
        // Общие настройки (цифры): config/arsenal_settings.json, применяются при запуске мира
        Settings.init();
        MenuBridge.init();

        // Зачарование "Непробиваемый"
        IMPENETRABLE = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "impenetrable"),
                new ImpenetrableEnchantment());

        // Зачарование "Самонаводка" (трезубец), уровни I-IV
        HOMING = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "homing"), new HomingEnchantment());

        // Неразрушимость, Опытный, Дровосек, Автоплавка, Оглушение, Бур, Магнетизм
        ToolEnchants.init();
        com.arsenal.tool.GrindMenu.init();

        // Критический и Разрушитель (меч и топор). Максимум II: Разрушитель III есть только на мече Цербера
        CRITICAL = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "critical"), new MeleeEnchantment(2));
        DESTROYER = Registry.register(Registry.ENCHANTMENT, new Identifier(MODID, "destroyer"), new MeleeEnchantment(2));

        // Все предметы мода (ванильные предметы с меткой), взрывчатка, приваты, нерушимая наковальня
        ArsenalItems.register();
        com.arsenal.priv.Privates.initEvents();
        com.arsenal.pvp.FireworkRule.init();

        // --- Бинды на ПКМ (/binds): оружие в руке, предмет лежит в инвентаре ---
        // ПКМ по блоку
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || !Binds.keyAvailable(player, Binds.Key.USE)
                    || Binds.boundTo(player, Binds.Key.USE).isEmpty()) {
                return ActionResult.PASS;
            }

            // Сначала обычное взаимодействие с блоком (сундук, дверь, кнопка...).
            // На шифте, как и в ванили, взаимодействие с блоком пропускается.
            if (!player.isSneaking()) {
                ActionResult result = world.getBlockState(hit.getBlockPos()).onUse(world, player, hand, hit);
                if (result.isAccepted()) {
                    return result;
                }
            }

            if (world.isClient) {
                // реальную работу и сообщения делает сервер; клиент только угадывает, сработает ли предмет
                return Binds.pickReady(player, Binds.Key.USE) != null ? ActionResult.SUCCESS : ActionResult.PASS;
            }
            return Binds.trigger((ServerPlayerEntity) player, Binds.Key.USE) ? ActionResult.SUCCESS : ActionResult.PASS;
        });

        // ПКМ в пустоту (или по мобу/игроку)
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack held = player.getStackInHand(hand);
            if (hand != Hand.MAIN_HAND || !Binds.keyAvailable(player, Binds.Key.USE)
                    || Binds.boundTo(player, Binds.Key.USE).isEmpty()) {
                return TypedActionResult.pass(held);
            }
            if (world.isClient) {
                return Binds.pickReady(player, Binds.Key.USE) != null
                        ? TypedActionResult.success(held)
                        : TypedActionResult.pass(held);
            }
            return Binds.trigger((ServerPlayerEntity) player, Binds.Key.USE)
                    ? TypedActionResult.success(held)
                    : TypedActionResult.pass(held);
        });

        // F и Q перехватывает сервер по пакетам действий игрока (ServerPlayNetworkHandlerMixin)
        Binds.init();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            TrapManager.tick();
            SphereEffects.tick(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> TrapManager.clearAll());

        // /expkeeper: эффекты за опыт на 24 часа
        ExpKeeper.init();
        com.arsenal.sync.Unstick.init();   // страховка от залипшего инвентаря
        com.arsenal.buyer.Buyer.init();   // скупщик: /buyer и /b
        StunZones.init();
        HealCooldown.init();
        TurtleCooldown.init();
        ArtifactEffects.init();
        Runes.init();
        KitCommand.init();
        SpawnProtection.init();
        ShulkerEvent.init();
        com.arsenal.blast.SpawnerUtil.init();
        com.arsenal.blast.JakePickaxeItem.init();
        com.arsenal.blast.IceWave.init();
        Filters.init();
        ExpCommand.init();
        Specials.init();
        com.arsenal.combat.Combat.init();
        com.arsenal.pvp.PvpManager.init();
        com.arsenal.event.EventManager.init();
        com.arsenal.event.XpEvent.init();
        com.arsenal.event.DeadlyMine.init();
        com.arsenal.event.MysteryShip.init();
        com.arsenal.tp.TeleportManager.init();
        com.arsenal.hub.HubManager.init();
        com.arsenal.spawn.SpawnManager.init();
        com.arsenal.spawn.PvpArena.init();
        com.arsenal.priv.PrivateCommand.init();
        CastleBuilder.init();

        // Крафты мода и серверная логика предметов (должны идти последними)
        com.arsenal.recipe.ArsenalRecipes.build();
        ViEvents.init();
        com.arsenal.vi.ArsenalCommand.init();
    }

    /** Талисманы спасают от смерти (из правой или левой руки), как тотем бессмертия, и пропадают. */
    public static boolean isTalisman(ItemStack stack) {
        VI vi = VI.of(stack);
        return vi != null && (vi == TALISMAN_COMMON || vi == TALISMAN || vi == TALISMAN_LEGENDARY
                || vi == TALISMAN_STINGER || vi == TALISMAN_ETERNITY || vi == TALISMAN_INFINITY
                || vi == TALISMAN_DRAGON);
    }

    /** Номер редкости отмычки (0 обычная, 1 редкая, 2 секретная) или -1, если это не отмычка. */
    public static int lockpickRarity(ItemStack stack) {
        for (int i = 0; i < LOCKPICKS.length; i++) {
            if (LOCKPICKS[i] != null && LOCKPICKS[i].is(stack)) {
                return i;
            }
        }
        return -1;
    }

    /** Меч Infinity: острота 8, Критический II, Разрушитель II + все топ-чары для меча. */
    public static ItemStack infinitySword() {
        ItemStack s = INFINITY_SWORD.stack();
        s.addEnchantment(Enchantments.SHARPNESS, 8);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(DESTROYER, 2);
        return topSword(s);
    }

    /** Меч Eternity: как Infinity, но острота 7 (Небесная кара 7, Бич 7, Разрушитель II, Критический II и т.д.). Без отдачи. */
    public static ItemStack eternitySword() {
        ItemStack s = ETERNITY_SWORD.stack();
        s.addEnchantment(Enchantments.SHARPNESS, 7);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(DESTROYER, 2);
        return topSword(s);
    }

    /** Меч Stinger: острота 6, Небесная кара 7, Бич 7, Критический II, без Разрушителя, Прочность 4, Добыча 5, Разящий клинок 3, Заговор огня 2, Починка. */
    public static ItemStack stingerSword() {
        ItemStack s = STINGER_SWORD.stack();
        s.addEnchantment(Enchantments.SHARPNESS, 6);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(CRITICAL, 2);
        s.addEnchantment(Enchantments.LOOTING, 5);
        s.addEnchantment(Enchantments.UNBREAKING, 4);
        s.addEnchantment(Enchantments.SWEEPING, 3);       // Разящий клинок, как на мече Dragon
        s.addEnchantment(Enchantments.FIRE_ASPECT, 2);    // Заговор огня, как на мече Dragon
        s.addEnchantment(Enchantments.MENDING, 1);        // Починка, как на мече Dragon
        return s;
    }

    /**
     * Броня Eternity (незерит): все защиты V, Прочность V, Починка, Непробиваемый на всех частях.
     * Броня Stinger (алмаз): все защиты IV, Прочность IV, Починка, Непробиваемый только на нагруднике и поножах.
     */
    private static void addArmorSets(java.util.List<ItemStack> out) {
        out.addAll(java.util.Arrays.asList(infinityArmor()));
        out.addAll(java.util.Arrays.asList(eternityArmor()));
        out.addAll(java.util.Arrays.asList(stingerArmor()));
    }

    private static final String[] ARMOR_NAMES = {"Шлем", "Нагрудник", "Поножи", "Ботинки"};

    private static Item[] netheriteArmor() {
        return new Item[]{Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS};
    }

    /** Броня Eternity (незерит): все защиты V, Прочность V, Починка, Непробиваемый на всех частях. */
    public static ItemStack[] eternityArmor() {
        Item[] items = netheriteArmor();
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            result[i] = armorPiece(items[i], ARMOR_NAMES[i] + " ETERNITY", NameDecor.DARK_PINK, 5, 5, 1);
        }
        addUtilityEnchants(result);
        return result;
    }

    // ---------------- трезубцы для китов ----------------

    /** Трезубец Stinger: Прочность III, Починка, Самонаводка II, Добыча III, Пронзатель III, Верность II. */
    public static ItemStack stingerTrident() {
        ItemStack s = new ItemStack(Items.TRIDENT);
        s.addEnchantment(Enchantments.UNBREAKING, 3);
        s.addEnchantment(Enchantments.MENDING, 1);
        s.addEnchantment(HOMING, 2);
        s.addEnchantment(Enchantments.LOOTING, 3);
        s.addEnchantment(Enchantments.IMPALING, 3);
        s.addEnchantment(Enchantments.LOYALTY, 2);
        s.setCustomName(NameDecor.decorate(new LiteralText("Трезубец STINGER"), NameDecor.LIGHT_RED));
        return s;
    }

    /** Трезубец Eternity: Прочность IV, Самонаводка III, Пронзатель IV, Добыча IV, Починка, Верность III. */
    public static ItemStack eternityTrident() {
        ItemStack s = new ItemStack(Items.TRIDENT);
        s.addEnchantment(Enchantments.UNBREAKING, 4);
        s.addEnchantment(HOMING, 3);
        s.addEnchantment(Enchantments.IMPALING, 4);
        s.addEnchantment(Enchantments.LOOTING, 4);
        s.addEnchantment(Enchantments.MENDING, 1);
        s.addEnchantment(Enchantments.LOYALTY, 3);
        s.setCustomName(NameDecor.decorate(new LiteralText("Трезубец ETERNITY"), NameDecor.DARK_PINK));
        return s;
    }

    /** Трезубец Infinity: Самонаводка IV, Добыча V, Прочность V, Починка, Пронзатель V, Верность III. */
    public static ItemStack infinityTrident() {
        ItemStack s = new ItemStack(Items.TRIDENT);
        s.addEnchantment(HOMING, 4);
        s.addEnchantment(Enchantments.LOOTING, 5);
        s.addEnchantment(Enchantments.UNBREAKING, 5);
        s.addEnchantment(Enchantments.MENDING, 1);
        s.addEnchantment(Enchantments.IMPALING, 5);
        s.addEnchantment(Enchantments.LOYALTY, 3);
        s.setCustomName(NameDecor.decorate(new LiteralText("Трезубец INFINITY"), NameDecor.LIME));
        return s;
    }

    /** Броня Infinity (незерит): как Eternity (защиты V, Прочность V, Починка), но Непробиваемый II на всех частях. */
    public static ItemStack[] infinityArmor() {
        Item[] items = netheriteArmor();
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            result[i] = armorPiece(items[i], ARMOR_NAMES[i] + " INFINITY", NameDecor.LIME, 5, 5, 2);
        }
        addUtilityEnchants(result);
        return result;
    }

    /** Броня Stinger (незерит): все защиты IV, Прочность IV, Починка, Непробиваемый на нагруднике и поножах. */
    public static ItemStack[] stingerArmor() {
        Item[] items = netheriteArmor();
        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            int impenetrable = (i == 1 || i == 2) ? 1 : 0;
            result[i] = armorPiece(items[i], ARMOR_NAMES[i] + " STINGER", NameDecor.LIGHT_RED, 4, 4, impenetrable);
        }
        addUtilityEnchants(result);
        return result;
    }

    /**
     * Шлем: Подводное дыхание III + Подводник. Ботинки: Скорость души III + Подводная ходьба III + Невесомость IV
     * (максимальные ванильные уровни).
     */
    private static void addUtilityEnchants(ItemStack[] armor) {
        armor[0].addEnchantment(Enchantments.RESPIRATION, 3);
        armor[0].addEnchantment(Enchantments.AQUA_AFFINITY, 1);
        armor[3].addEnchantment(Enchantments.SOUL_SPEED, 3);
        armor[3].addEnchantment(Enchantments.DEPTH_STRIDER, 3);
        armor[3].addEnchantment(Enchantments.FEATHER_FALLING, 4);
    }

    private static ItemStack armorPiece(Item item, String name, TextColor color, int protection, int unbreaking,
                                        int impenetrable) {
        ItemStack s = new ItemStack(item);
        s.addEnchantment(Enchantments.PROTECTION, protection);
        s.addEnchantment(Enchantments.FIRE_PROTECTION, protection);
        s.addEnchantment(Enchantments.BLAST_PROTECTION, protection);
        s.addEnchantment(Enchantments.PROJECTILE_PROTECTION, protection);
        s.addEnchantment(Enchantments.UNBREAKING, unbreaking);
        s.addEnchantment(Enchantments.MENDING, 1);
        if (impenetrable > 0) {
            s.addEnchantment(IMPENETRABLE, impenetrable);
        }
        s.setCustomName(NameDecor.decorate(new LiteralText(name), color));
        return s;
    }

    /** Меч Цербера: острота 9, Критический II, Разрушитель III (только на нём) + все топ-чары для меча. */
    /**
     * Готовый вариант предметов, которым при выдаче нужны зачарования (меч Цербера и меч INFINITY), иначе null.
     * Без этого лут, магазин и прочее выдавали голый предмет.
     */
    public static ItemStack preset(VI vi) {
        if (vi == CERBERUS_SWORD) {
            return cerberusSword();
        }
        if (vi == INFINITY_SWORD) {
            return infinitySword();
        }
        return null;
    }

    public static ItemStack cerberusSword() {
        ItemStack s = CERBERUS_SWORD.stack();
        s.addEnchantment(Enchantments.SHARPNESS, 9);
        s.addEnchantment(Enchantments.SMITE, 7);
        s.addEnchantment(Enchantments.BANE_OF_ARTHROPODS, 7);
        s.addEnchantment(DESTROYER, 3);
        return topSword(s);
    }

    private static ItemStack topSword(ItemStack s) {
        s.addEnchantment(CRITICAL, 2);
        s.addEnchantment(Enchantments.LOOTING, 5);
        s.addEnchantment(Enchantments.FIRE_ASPECT, 2);
        s.addEnchantment(Enchantments.SWEEPING, 3);
        s.addEnchantment(Enchantments.UNBREAKING, 5);
        s.addEnchantment(Enchantments.MENDING, 1);
        return s;
    }
}
