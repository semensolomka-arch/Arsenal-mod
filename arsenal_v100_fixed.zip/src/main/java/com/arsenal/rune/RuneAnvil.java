package com.arsenal.rune;

import net.minecraft.item.ItemStack;

/**
 * Рецепт наковальни: тотем бессмертия или талисман + руна = тот же предмет с этой руной (10 уровней).
 * Одну и ту же руну дважды вложить нельзя, несовместимых рун нет.
 */
public final class RuneAnvil {
    public static class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private RuneAnvil() {
    }

    private static RuneType runeOf(ItemStack stack) {
        for (RuneType t : RuneType.values()) {
            if (t.vi != null && t.vi.is(stack)) {
                return t;
            }
        }
        return null;
    }

    /** null = это не наш рецепт. */
    public static Result compute(ItemStack left, ItemStack right) {
        RuneType rr = runeOf(right);
        if (rr != null && Runes.canCarry(left)) {
            return add(left, rr);
        }
        RuneType lr = runeOf(left);
        if (lr != null && Runes.canCarry(right)) {
            return add(right, lr);
        }
        return null;
    }

    private static Result add(ItemStack carrier, RuneType rune) {
        if (Runes.has(carrier, rune)) {
            return null;
        }
        ItemStack result = carrier.copy();
        result.setCount(1);
        com.arsenal.vi.VData.set(result, rune.key(), 1);
        Runes.refreshLore(result);
        return new Result(result, Runes.ANVIL_COST);
    }
}
