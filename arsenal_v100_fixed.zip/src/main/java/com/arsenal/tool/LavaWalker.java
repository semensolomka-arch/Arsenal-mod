package com.arsenal.tool;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Лавоход: как Ледоход, но для лавы. Источник лавы под ногами (радиус 3 на I, 4 на II) превращается в обсидиан,
 * который через пару секунд снова становится лавой. На приседе не работает.
 */
public final class LavaWalker {
    private static final class Temp {
        final ServerWorld world;
        final BlockPos pos;
        final long expire;

        Temp(ServerWorld world, BlockPos pos, long expire) {
            this.world = world;
            this.pos = pos;
            this.expire = expire;
        }
    }

    private static final List<Temp> TEMPS = new ArrayList<>();

    private LavaWalker() {
    }

    /** Блок сейчас временный (его дроп отменяется, чтобы не получить обсидиан даром). */
    public static boolean isTemp(World world, BlockPos pos) {
        for (Temp t : TEMPS) {
            if (t.world == world && t.pos.equals(pos)) {
                return true;
            }
        }
        return false;
    }

    private static void revert(Temp t) {
        if (t.world.getBlockState(t.pos).isOf(Blocks.OBSIDIAN)) {
            t.world.setBlockState(t.pos, Blocks.LAVA.getDefaultState());
        }
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (Temp t : TEMPS) {
                revert(t);
            }
            TEMPS.clear();
        });
        ServerTickEvents.END_SERVER_TICK.register(LavaWalker::tick);
    }

    private static void tick(MinecraftServer server) {
        long now = server.getTicks();
        if (ToolEnchants.LAVA_WALKER != null) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                ItemStack boots = p.getEquippedStack(EquipmentSlot.FEET);
                if (boots.isEmpty() || p.isSneaking() || p.isSpectator() || p.isDead()) {
                    continue;
                }
                int lvl = EnchantmentHelper.getLevel(ToolEnchants.LAVA_WALKER, boots);
                if (lvl <= 0) {
                    continue;
                }
                ServerWorld w = p.getServerWorld();
                BlockPos base = p.getBlockPos();
                int r = Math.min(16, lvl + 2);
                int placed = 0;
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx * dx + dz * dz > r * r) {
                            continue;
                        }
                        BlockPos pos = new BlockPos(base.getX() + dx, base.getY() - 1, base.getZ() + dz);
                        BlockState st = w.getBlockState(pos);
                        if (!st.isOf(Blocks.LAVA) || st.get(FluidBlock.LEVEL) != 0 || !w.getBlockState(pos.up()).isAir()) {
                            continue;
                        }
                        w.setBlockState(pos, Blocks.OBSIDIAN.getDefaultState());
                        TEMPS.add(new Temp(w, pos, now + 60 + w.random.nextInt(40)));
                        placed++;
                    }
                }
                if (placed > 0) {
                    // 1 прочность за шаг (за одно появление обсидиана, не за каждый блок); Прочность на ботинках работает как обычно
                    boots.damage(1, p, e -> e.sendEquipmentBreakStatus(EquipmentSlot.FEET));
                }
            }
        }
        if (TEMPS.isEmpty()) {
            return;
        }
        Iterator<Temp> it = TEMPS.iterator();
        while (it.hasNext()) {
            Temp t = it.next();
            if (now >= t.expire) {
                revert(t);
                it.remove();
            }
        }
    }
}
