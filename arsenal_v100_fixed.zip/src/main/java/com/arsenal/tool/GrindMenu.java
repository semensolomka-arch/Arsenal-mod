package com.arsenal.tool;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Точило (обычное точило убрано): ПКМ по точилу открывает меню, предмет кладётся в верхний слот меню
 * (при закрытии он возвращается игроку). Под каждым зачарованием кнопка вкл/выкл (вкл = пойдёт на продажу), слева внизу вкл/выкл всё, справа внизу
 * «Продать»: навёл, и в описании видно, сколько зачарований продаётся и сколько за них опыта.
 * Опыт считается как у обычного точила, только за ванильные зачарования (за наши опыт не даётся).
 * Проклятия не снимаются.
 */
public final class GrindMenu {
    static final int ROWS = 4;
    static final int SIZE = ROWS * 9;
    /** Сюда игрок кладёт предмет. */
    static final int INPUT_SLOT = 4;
    private static final int HINT_SLOT = 13;
    private static final int ALL_SLOT = 29;
    private static final int SELL_SLOT = 33;
    private static final Random RANDOM = new Random();

    private GrindMenu() {
    }

    public static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || player.isSpectator()
                    || world.getBlockState(hit.getBlockPos()).getBlock() != Blocks.GRINDSTONE) {
                return ActionResult.PASS;
            }
            if (!world.isClient && player instanceof ServerPlayerEntity) {
                open((ServerPlayerEntity) player);
            }
            return ActionResult.SUCCESS;   // обычное точило не открывается никогда
        });
    }

    /** Все зачарования предмета (у книги сохранённые), в порядке предмета. */
    static Map<Enchantment, Integer> enchants(ItemStack stack) {
        Map<Enchantment, Integer> result = new LinkedHashMap<>();
        if (!stack.isEmpty()) {
            result.putAll(EnchantmentHelper.get(stack));
        }
        return result;
    }

    private static int baseXp(Enchantment e, int level) {
        return "minecraft".equals(Registry.ENCHANTMENT.getId(e).getNamespace()) ? Math.max(1, e.getMinPower(level)) : 0;
    }

    private static int half(int base) {
        return (int) Math.ceil(base / 2.0);
    }

    private static String range(int base) {
        if (base <= 0) {
            return "нет";
        }
        int h = half(base);
        return h == 1 ? "1" : h + "-" + (2 * h - 1);
    }

    public static void open(ServerPlayerEntity player) {
        GrindScreenHandler.Data data = new GrindScreenHandler.Data();
        fill(player, data);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new GrindScreenHandler(syncId, playerInventory, data),
                new LiteralText("Точило")));
    }

    private static int firstSlot(int n) {
        return 9 + (9 - n) / 2;
    }

    private static MutableText plain(String s, Formatting f) {
        return new LiteralText(s).formatted(f).styled(st -> st.withItalic(false));
    }

    private static void lore(ItemStack stack, Text... lines) {
        NbtList list = new NbtList();
        for (Text line : lines) {
            list.add(NbtString.of(Text.Serializer.toJson(line)));
        }
        stack.getOrCreateSubTag("display").put("Lore", list);
    }

    static void fill(ServerPlayerEntity player, GrindScreenHandler.Data data) {
        SimpleInventory inv = data.inventory;
        for (int i = 0; i < inv.size(); i++) {
            if (i != INPUT_SLOT) {
                inv.setStack(i, ItemStack.EMPTY);
            }
        }
        ItemStack held = inv.getStack(INPUT_SLOT);
        Map<Enchantment, Integer> map = enchants(held);
        data.selected.retainAll(map.keySet());
        if (map.isEmpty()) {
            ItemStack hint = new ItemStack(Items.PAPER);
            hint.setCustomName(plain(held.isEmpty() ? "Положите предмет в верхний слот" : "У предмета нет зачарований",
                    Formatting.GRAY));
            inv.setStack(HINT_SLOT, hint);
            return;
        }
        List<Enchantment> list = new ArrayList<>(map.keySet());
        int n = Math.min(9, list.size());
        int first = firstSlot(n);
        int selectable = 0;
        int chosen = 0;
        int baseTotal = 0;
        for (int i = 0; i < n; i++) {
            Enchantment e = list.get(i);
            int level = map.get(e);
            boolean curse = e.isCursed();
            boolean on = data.selected.contains(e);
            int base = baseXp(e, level);

            ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
            book.setCustomName(new LiteralText("").append(e.getName(level)).styled(st -> st.withItalic(false).withColor(Formatting.WHITE)));
            lore(book, plain(curse ? "Проклятие, снять нельзя" : "Опыт за зачарование: " + range(base), curse ? Formatting.RED : Formatting.GRAY));
            inv.setStack(first + i, book);

            ItemStack toggle;
            if (curse) {
                toggle = new ItemStack(Items.BARRIER);
                toggle.setCustomName(plain("Нельзя", Formatting.RED));
            } else {
                selectable++;
                toggle = new ItemStack(on ? Items.LIME_DYE : Items.GRAY_DYE);
                toggle.setCustomName(plain(on ? "Вкл: будет продано" : "Выкл", on ? Formatting.GREEN : Formatting.GRAY));
                lore(toggle, plain("Клик: " + (on ? "выключить" : "включить"), Formatting.DARK_GRAY));
                if (on) {
                    chosen++;
                    baseTotal += base;
                }
            }
            inv.setStack(first + i + 9, toggle);
        }
        if (selectable > 0) {
            boolean allOn = chosen == selectable;
            ItemStack all = new ItemStack(allOn ? Items.LIME_DYE : Items.GRAY_DYE);
            all.setCustomName(plain(allOn ? "Всё включено" : "Всё выключено", allOn ? Formatting.GREEN : Formatting.GRAY));
            lore(all, plain("Клик: " + (allOn ? "выключить всё" : "включить всё"), Formatting.DARK_GRAY));
            inv.setStack(ALL_SLOT, all);
        }
        ItemStack sell = new ItemStack(Items.EMERALD);
        sell.setCustomName(plain("Продать", Formatting.GOLD));
        if (chosen == 0) {
            lore(sell, plain("Ничего не выбрано", Formatting.GRAY));
        } else {
            lore(sell, plain("Зачарований: " + chosen, Formatting.WHITE), plain("Опыта: " + range(baseTotal), Formatting.GREEN));
        }
        inv.setStack(SELL_SLOT, sell);
    }

    static void onClick(ServerPlayerEntity player, int slot, GrindScreenHandler.Data data) {
        ItemStack held = data.inventory.getStack(INPUT_SLOT);
        Map<Enchantment, Integer> map = enchants(held);
        if (map.isEmpty()) {
            fill(player, data);
            return;
        }
        List<Enchantment> list = new ArrayList<>(map.keySet());
        int n = Math.min(9, list.size());
        int first = firstSlot(n);
        if (slot >= first + 9 && slot < first + 9 + n) {
            Enchantment e = list.get(slot - first - 9);
            if (!e.isCursed() && !data.selected.remove(e)) {
                data.selected.add(e);
            }
        } else if (slot == ALL_SLOT) {
            List<Enchantment> can = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                if (!list.get(i).isCursed()) {
                    can.add(list.get(i));
                }
            }
            if (data.selected.containsAll(can)) {
                data.selected.removeAll(can);
            } else {
                data.selected.addAll(can);
            }
        } else if (slot == SELL_SLOT) {
            sell(player, held, map, data);
        }
        fill(player, data);
    }

    private static void sell(ServerPlayerEntity player, ItemStack held, Map<Enchantment, Integer> map, GrindScreenHandler.Data data) {
        int base = 0;
        int count = 0;
        for (Enchantment e : new ArrayList<>(data.selected)) {
            Integer level = map.remove(e);
            if (level != null && !e.isCursed()) {
                base += baseXp(e, level);
                count++;
            } else if (level != null) {
                map.put(e, level);
            }
        }
        data.selected.clear();
        if (count == 0) {
            player.sendMessage(new LiteralText("Ничего не выбрано").formatted(Formatting.RED), true);
            return;
        }
        if (held.getItem() == Items.ENCHANTED_BOOK) {
            if (map.isEmpty()) {
                data.inventory.setStack(INPUT_SLOT, new ItemStack(Items.BOOK));   // как в обычном точиле
            } else {
                NbtList stored = new NbtList();
                for (Map.Entry<Enchantment, Integer> en : map.entrySet()) {
                    NbtCompound t = new NbtCompound();
                    t.putString("id", String.valueOf(Registry.ENCHANTMENT.getId(en.getKey())));
                    t.putShort("lvl", en.getValue().shortValue());
                    stored.add(t);
                }
                held.getOrCreateTag().put("StoredEnchantments", stored);
            }
        } else {
            EnchantmentHelper.set(map, held);
        }
        int xp = 0;
        if (base > 0) {
            int h = half(base);
            xp = h + RANDOM.nextInt(h);
            player.addExperience(xp);
        }
        player.world.playSound(null, player.getBlockPos(), SoundEvents.BLOCK_GRINDSTONE_USE, SoundCategory.BLOCKS, 1.0F, 1.0F);
        player.sendMessage(new LiteralText("Продано зачарований: " + count + (xp > 0 ? ", опыта: " + xp : "")).formatted(Formatting.GOLD), true);
    }
}
