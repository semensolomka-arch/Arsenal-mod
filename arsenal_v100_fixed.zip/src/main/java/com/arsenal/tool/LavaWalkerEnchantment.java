package com.arsenal.tool;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

/** Лавоход (ботинки): лава под ногами временно застывает. Совместим с Подводной ходьбой и Ледоходом. */
public class LavaWalkerEnchantment extends Enchantment {
    public LavaWalkerEnchantment() {
        super(Rarity.RARE, EnchantmentTarget.ARMOR_FEET, new EquipmentSlot[]{EquipmentSlot.FEET});
    }

    @Override
    public int getMaxLevel() {
        return 2;
    }

    @Override
    public int getMinPower(int level) {
        return level * 10;
    }

    @Override
    public int getMaxPower(int level) {
        return getMinPower(level) + 15;
    }

    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
}
