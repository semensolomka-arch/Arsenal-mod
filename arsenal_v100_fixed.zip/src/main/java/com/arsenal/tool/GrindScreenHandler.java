package com.arsenal.tool;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashSet;
import java.util.Set;

/**
 * Меню точила: сундук 9x4. Свободен только верхний слот (туда кладут предмет), остальные слоты это кнопки,
 * их клики обрабатывает GrindMenu, взять оттуда ничего нельзя.
 */
public class GrindScreenHandler extends GenericContainerScreenHandler {
    /** Состояние меню: сами слоты и какие зачарования включены на продажу. */
    static final class Data {
        final SimpleInventory inventory = new SimpleInventory(GrindMenu.SIZE) {
            @Override
            public void onClose(PlayerEntity player) {
                // при закрытии меню предмет возвращается игроку
                ItemStack stack = getStack(GrindMenu.INPUT_SLOT);
                if (!stack.isEmpty()) {
                    setStack(GrindMenu.INPUT_SLOT, ItemStack.EMPTY);
                    player.inventory.offerOrDrop(player.world, stack);
                }
            }
        };
        final Set<Enchantment> selected = new HashSet<>();
    }

    private final Data data;

    public GrindScreenHandler(int syncId, PlayerInventory playerInventory, Data data) {
        super(ScreenHandlerType.GENERIC_9X4, syncId, playerInventory, data.inventory, GrindMenu.ROWS);
        this.data = data;
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        boolean server = player instanceof ServerPlayerEntity;
        // кнопки: берём только клик, предметы не двигаются
        if (slotIndex >= 0 && slotIndex < GrindMenu.SIZE && slotIndex != GrindMenu.INPUT_SLOT) {
            if ((actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE) && server) {
                GrindMenu.onClick((ServerPlayerEntity) player, slotIndex, data);
            }
            return ItemStack.EMPTY;
        }
        // перетаскивание и "собрать все" могли бы задеть кнопки
        if (actionType == SlotActionType.QUICK_CRAFT || actionType == SlotActionType.PICKUP_ALL) {
            return ItemStack.EMPTY;
        }
        ItemStack result = super.onSlotClick(slotIndex, clickData, actionType, player);
        if (server) {
            GrindMenu.fill((ServerPlayerEntity) player, data);
        }
        return result;
    }

    /** Шифт-клик: из инвентаря в слот точила и обратно, в кнопки ничего не попадает. */
    @Override
    public ItemStack transferSlot(PlayerEntity player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasStack()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getStack();
        ItemStack copy = stack.copy();
        if (index == GrindMenu.INPUT_SLOT) {
            if (!this.insertItem(stack, GrindMenu.SIZE, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (index >= GrindMenu.SIZE) {
            if (!this.insertItem(stack, GrindMenu.INPUT_SLOT, GrindMenu.INPUT_SLOT + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setStack(ItemStack.EMPTY);
        } else {
            slot.markDirty();
        }
        return copy;
    }
}
