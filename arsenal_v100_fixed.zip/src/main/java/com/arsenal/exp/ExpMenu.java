package com.arsenal.exp;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;

/**
 * Меню /exp: сундук 3x9, где клик по бутыльку переработает опыт.
 * Клик: 1 штука, шифт-клик: максимум (опыт и пустые бутылки). Работает только на сервере.
 */
public final class ExpMenu {
    private static final int INFO_SLOT = 4;
    private static final int HINT_SLOT = 22;
    /** Слоты кнопок и что они делают (0 = обычная бутылочка). */
    private static final int[] SLOTS = {10, 12, 14, 16};
    private static final int[] LEVELS = {0, 15, 30, 50};

    private ExpMenu() {
    }

    public static void open(ServerPlayerEntity player) {
        SimpleInventory inventory = new SimpleInventory(27);
        fill(player, inventory);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new ExpScreenHandler(syncId, playerInventory, inventory),
                new LiteralText("Переработка опыта")));
    }

    private static void fill(ServerPlayerEntity player, SimpleInventory inventory) {
        for (int i = 0; i < inventory.size(); i++) {
            inventory.setStack(i, ItemStack.EMPTY);
        }
        int have = ExpCommand.totalPoints(player);
        int bottles = ExpCommand.emptyBottles(player);

        ItemStack info = new ItemStack(Items.EXPERIENCE_BOTTLE);
        MutableText infoName = new LiteralText("Ваш опыт: " + have + " оч. (" + player.experienceLevel + " ур.)")
                .formatted(Formatting.GREEN);
        infoName.append(new LiteralText("   пустых бутылок: " + bottles).formatted(bottles > 0 ? Formatting.GRAY : Formatting.RED));
        info.setCustomName(infoName.styled(s -> s.withItalic(false)));
        inventory.setStack(INFO_SLOT, info);

        for (int i = 0; i < SLOTS.length; i++) {
            inventory.setStack(SLOTS[i], button(LEVELS[i], have));
        }

        ItemStack hint = new ItemStack(Items.PAPER);
        hint.setCustomName(new LiteralText("Клик: 1 бутылёк, шифт-клик: максимум").formatted(Formatting.GRAY)
                .styled(s -> s.withItalic(false)));
        inventory.setStack(HINT_SLOT, hint);
    }

    private static ItemStack button(int levels, int have) {
        int cost = ExpCommand.costOf(levels);
        ItemStack stack = ExpCommand.stackOf(levels, 1);
        String title = levels == 0 ? "Обычная бутылочка" : "Бутылёк на " + levels + " ур.";
        MutableText name = new LiteralText(title).formatted(Formatting.WHITE);
        name.append(new LiteralText("   " + cost + " оч.").formatted(have >= cost ? Formatting.GREEN : Formatting.RED));
        stack.setCustomName(name.styled(s -> s.withItalic(false)));
        return stack;
    }

    static void onClick(ServerPlayerEntity player, int slot, boolean shift, SimpleInventory menu) {
        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] == slot) {
                ExpCommand.convert(player, LEVELS[i], shift ? -1 : 1);
                fill(player, menu);
                return;
            }
        }
    }
}
