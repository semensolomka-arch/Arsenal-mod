package com.arsenal.exp;

import com.arsenal.Arsenal;
import com.arsenal.vi.VI;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

/**
 * /exp: открывает меню (как /expkeeper), где опыт перерабатывается в бутылочки.
 * Старые команды тоже работают: /exp bottle [число], /exp 15|30|50 [число].
 * Нужны пустые стеклянные бутылки в инвентаре (по одной на каждый бутылёк).
 */
public final class ExpCommand {
    /** Сколько очков опыта стоит одна обычная бутылочка (в ванили бутылочка даёт в среднем 7). */
    public static final int VANILLA_BOTTLE_COST = 7;

    private ExpCommand() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("exp")
                        .executes(ctx -> {
                            ExpMenu.open(ctx.getSource().getPlayer());
                            return 1;
                        })
                        .then(option("bottle", 0))
                        .then(option("15", 15))
                        .then(option("30", 30))
                        .then(option("50", 50))));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> option(String name, int levels) {
        return CommandManager.literal(name)
                .executes(ctx -> convert(ctx.getSource().getPlayer(), levels, 1) ? 1 : 0)
                .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 64))
                        .executes(ctx -> convert(ctx.getSource().getPlayer(), levels,
                                IntegerArgumentType.getInteger(ctx, "count")) ? 1 : 0));
    }

    /** Стоимость одного бутылька в очках опыта (levels == 0: обычная бутылочка). */
    public static int costOf(int levels) {
        return levels == 0 ? VANILLA_BOTTLE_COST : pointsForLevel(levels);
    }

    public static ItemStack stackOf(int levels, int count) {
        if (levels == 0) {
            return new ItemStack(Items.EXPERIENCE_BOTTLE, count);
        }
        VI vi = levels == 15 ? Arsenal.EXP_BOTTLE_15 : levels == 30 ? Arsenal.EXP_BOTTLE_30 : Arsenal.EXP_BOTTLE_50;
        return vi.stack(count);
    }

    public static int emptyBottles(ServerPlayerEntity player) {
        int bottles = 0;
        for (int i = 0; i < player.inventory.size(); i++) {
            ItemStack s = player.inventory.getStack(i);
            if (s.getItem() == Items.GLASS_BOTTLE) {
                bottles += s.getCount();
            }
        }
        return bottles;
    }

    /**
     * Перерабатывает опыт в бутыльки. count &lt; 0: сделать максимум (но не больше 64 за раз).
     * Если чего-то не хватает, ничего не списывается и игроку пишется причина.
     */
    public static boolean convert(ServerPlayerEntity player, int levels, int count) {
        int per = costOf(levels);
        int have = totalPoints(player);
        int bottles = emptyBottles(player);
        if (count < 0) {
            count = Math.min(64, Math.min(bottles, have / per));
            if (count <= 0) {
                player.sendMessage(new LiteralText("Не хватает опыта или пустых бутылок (нужно " + per
                        + " оч. и 1 пустая бутылка на штуку)").formatted(Formatting.RED), false);
                return false;
            }
        }
        long cost = (long) per * count;
        if (have < cost) {
            player.sendMessage(new LiteralText("Не хватает опыта: нужно " + cost + ", у тебя " + have).formatted(Formatting.RED), false);
            return false;
        }
        if (bottles < count) {
            player.sendMessage(new LiteralText("Не хватает пустых бутылок: нужно " + count + ", у тебя " + bottles).formatted(Formatting.RED), false);
            return false;
        }
        int need = count;
        for (int i = 0; i < player.inventory.size() && need > 0; i++) {
            ItemStack s = player.inventory.getStack(i);
            if (s.getItem() == Items.GLASS_BOTTLE) {
                int take = Math.min(need, s.getCount());
                s.decrement(take);
                need -= take;
            }
        }
        setTotalPoints(player, (int) (have - cost));
        player.inventory.offerOrDrop(player.getServerWorld(), stackOf(levels, count));
        player.sendMessage(new LiteralText("Готово: бутыльков " + count + ", потрачено опыта " + cost).formatted(Formatting.GREEN), false);
        return true;
    }

    /** Сколько очков опыта нужно, чтобы с нуля дойти до уровня level (формулы ванили). */
    public static int pointsForLevel(int level) {
        if (level <= 16) {
            return level * level + 6 * level;
        }
        if (level <= 31) {
            return (int) (2.5 * level * level - 40.5 * level + 360);
        }
        return (int) (4.5 * level * level - 162.5 * level + 2220);
    }

    public static int totalPoints(PlayerEntity p) {
        return pointsForLevel(p.experienceLevel) + Math.round(p.experienceProgress * p.getNextLevelExperience());
    }

    public static void setTotalPoints(PlayerEntity p, int points) {
        int score = p.getScore();
        p.experienceLevel = 0;
        p.experienceProgress = 0.0F;
        p.totalExperience = 0;
        p.addExperience(Math.max(0, points));
        p.setScore(score);
    }
}
