package com.arsenal.exp;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

/** Бутылёк опыта на N уровней: ПКМ, опыт добавляется сразу (бутылёк не бросается). */
public final class ExpBottles {
    private ExpBottles() {
    }

    public static int points(int levels) {
        return ExpCommand.pointsForLevel(levels);
    }

    public static boolean use(ServerPlayerEntity user, ItemStack stack, int levels) {
        int score = user.getScore();
        user.addExperience(points(levels));
        user.setScore(score);
        if (!user.isCreative()) {
            stack.decrement(1);
        }
        user.world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6F, 1.0F);
        return true;
    }
}
