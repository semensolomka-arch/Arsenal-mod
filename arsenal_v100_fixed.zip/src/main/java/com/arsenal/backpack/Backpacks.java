package com.arsenal.backpack;

import com.arsenal.Arsenal;
import com.arsenal.vi.VI;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.List;

/**
 * Рюкзаки: 4 уровня и Infinity. Предмет-основа - цветной шалкер (не ставится на землю), по ПКМ открывается
 * сундук на 9/15/21/27/36 слотов. Содержимое лежит в NBT самого предмета (ArsenalBag).
 */
public final class Backpacks {
    public static final String BAG = "ArsenalBag";
    public static final int[] SLOTS = {9, 15, 21, 27, 36};
    /** Ширина рабочей области по центру окна (колонки) и число рядов окна. */
    public static final int[] WIDTH = {3, 5, 7, 9, 9};
    public static final int[] ROWS = {3, 3, 3, 3, 4};
    private static final Item[] BASE = {Items.PINK_SHULKER_BOX, Items.LIGHT_BLUE_SHULKER_BOX, Items.RED_SHULKER_BOX,
            Items.MAGENTA_SHULKER_BOX, Items.LIME_SHULKER_BOX};
    private static final int[] COLOR = {0xFF8FCB, 0x55FFFF, 0xFF5555, 0xFF55FF, 0x55FF55};

    /** Игроки с открытым рюкзаком: когда окно закрылось, играем звук закрытия шалкера. */
    private static final java.util.Map<java.util.UUID, Boolean> OPEN = new java.util.HashMap<>();

    private Backpacks() {
    }

    public static void init() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (OPEN.isEmpty()) {
                return;
            }
            java.util.Iterator<java.util.UUID> it = OPEN.keySet().iterator();
            while (it.hasNext()) {
                ServerPlayerEntity p = server.getPlayerManager().getPlayer(it.next());
                if (p == null) {
                    it.remove();
                } else if (!(p.currentScreenHandler instanceof BagScreenHandler)) {
                    p.world.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_SHULKER_BOX_CLOSE,
                            SoundCategory.BLOCKS, 0.5F, p.world.random.nextFloat() * 0.1F + 0.9F);
                    it.remove();
                }
            }
        });
    }

    public static void register() {
        for (int i = 0; i < 5; i++) {
            final int lvl = i;
            String id = i == 4 ? "backpack_infinity" : "backpack_" + (i + 1);
            Arsenal.BACKPACKS[i] = VI.register(id, BASE[i])
                    .unique(true)
                    .name(s -> title(lvl))
                    .lore(s -> lore(lvl))
                    .action((p, s) -> open(p, s));
        }
    }

    public static Text title(int lvl) {
        String roman = lvl == 4 ? "" : new String[]{"I", "II", "III", "IV"}[lvl];
        MutableText t = new LiteralText(lvl == 4 ? "Рюкзак INFINITY" : "Рюкзак (" + roman + " уровень)");
        Style st = Style.EMPTY.withColor(TextColor.fromRgb(COLOR[lvl])).withBold(lvl == 4);
        return t.setStyle(st);
    }

    private static String slotsWord(int n) {
        int a = n % 10;
        int b = n % 100;
        if (a == 1 && b != 11) {
            return n + " слот";
        }
        if (a >= 2 && a <= 4 && (b < 12 || b > 14)) {
            return n + " слота";
        }
        return n + " слотов";
    }

    private static List<Text> lore(int lvl) {
        List<Text> l = new ArrayList<>();
        l.add(new LiteralText("Особенности:").formatted(Formatting.GRAY));
        Style st = Style.EMPTY.withColor(TextColor.fromRgb(COLOR[lvl]));
        l.add(new LiteralText(" - нельзя поставить на землю;").setStyle(st));
        l.add(new LiteralText(" - возможность открыть через ПКМ;").setStyle(st));
        l.add(new LiteralText(" - вместимость " + slotsWord(SLOTS[lvl]) + ";").setStyle(st));
        return l;
    }

    /** Уровень рюкзака (0-4) или -1, если предмет не рюкзак. */
    public static int levelOf(ItemStack s) {
        VI vi = VI.of(s);
        if (vi == null) {
            return -1;
        }
        for (int i = 0; i < 5; i++) {
            if (Arsenal.BACKPACKS[i] == vi) {
                return i;
            }
        }
        return -1;
    }

    public static boolean isBackpack(ItemStack s) {
        return levelOf(s) >= 0;
    }

    private static long uidOf(ItemStack s) {
        return s.hasTag() && s.getTag().contains(VI.UID) ? s.getTag().getLong(VI.UID) : 0L;
    }

    /** Рюкзак игрока с таким номером (хотбар, инвентарь, вторая рука, курсор). */
    static ItemStack findByUid(PlayerEntity p, long uid) {
        List<ItemStack> all = new ArrayList<>(p.inventory.main);
        all.addAll(p.inventory.offHand);
        all.add(p.inventory.getCursorStack());
        for (ItemStack s : all) {
            if (!s.isEmpty() && isBackpack(s) && uidOf(s) == uid) {
                return s;
            }
        }
        return null;
    }

    /** Первый рюкзак в инвентаре: хотбар, потом остальное, потом вторая рука. */
    public static ItemStack find(PlayerEntity p) {
        List<ItemStack> all = new ArrayList<>(p.inventory.main);
        all.addAll(p.inventory.offHand);
        for (ItemStack s : all) {
            if (!s.isEmpty() && isBackpack(s)) {
                return s;
            }
        }
        return null;
    }

    public static boolean openFirst(ServerPlayerEntity p) {
        ItemStack s = find(p);
        return s != null && open(p, s);
    }

    public static boolean open(ServerPlayerEntity p, ItemStack stack) {
        int lvl = levelOf(stack);
        if (lvl < 0) {
            return false;
        }
        if (!stack.hasTag()) {
            return false;
        }
        long uid = uidOf(stack);
        if (uid == 0L) {
            uid = new java.util.Random().nextLong();
            stack.getTag().putLong(VI.UID, uid);
        }
        final long fuid = uid;
        int rows = ROWS[lvl];
        SimpleInventory inv = new SimpleInventory(rows * 9);
        load(stack, inv, lvl);
        p.world.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_SHULKER_BOX_OPEN, SoundCategory.BLOCKS,
                0.5F, p.world.random.nextFloat() * 0.1F + 0.9F);
        OPEN.put(p.getUuid(), Boolean.TRUE);
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, pi, pl) -> new BagScreenHandler(syncId, pi, inv, rows, lvl, fuid),
                title(lvl)));
        return true;
    }

    /** Номер слота в окне для k-го слота рюкзака (рабочая область по центру). */
    static int guiIndex(int lvl, int k) {
        int w = WIDTH[lvl];
        int lo = (9 - w) / 2;
        return (k / w) * 9 + lo + k % w;
    }

    /** Обратное преобразование: номер слота окна -> номер слота рюкзака или -1, если слот закрыт. */
    static int logicalIndex(int lvl, int gui) {
        int w = WIDTH[lvl];
        int lo = (9 - w) / 2;
        int row = gui / 9;
        int col = gui % 9;
        if (col < lo || col >= lo + w) {
            return -1;
        }
        int k = row * w + (col - lo);
        return k < SLOTS[lvl] ? k : -1;
    }

    static void load(ItemStack bag, SimpleInventory inv, int lvl) {
        for (int i = 0; i < inv.size(); i++) {
            inv.setStack(i, logicalIndex(lvl, i) >= 0 ? ItemStack.EMPTY : BagScreenHandler.filler());
        }
        if (!bag.hasTag() || !bag.getTag().contains(BAG, 9)) {
            return;
        }
        NbtList list = bag.getTag().getList(BAG, 10);
        for (int i = 0; i < list.size(); i++) {
            NbtCompound c = list.getCompound(i);
            int slot = c.getInt("Slot");
            if (slot < 0 || slot >= SLOTS[lvl]) {
                continue;
            }
            Item item = Registry.ITEM.get(new Identifier(c.getString("id")));
            if (item == Items.AIR) {
                continue;
            }
            ItemStack st = new ItemStack(item, Math.max(1, c.getInt("Count")));
            if (c.contains("tag", 10)) {
                st.setTag(c.getCompound("tag").copy());
            }
            inv.setStack(guiIndex(lvl, slot), st);
        }
    }

    static void save(ItemStack bag, SimpleInventory inv, int lvl) {
        NbtList list = new NbtList();
        for (int k = 0; k < SLOTS[lvl]; k++) {
            ItemStack s = inv.getStack(guiIndex(lvl, k));
            if (s.isEmpty()) {
                continue;
            }
            NbtCompound c = new NbtCompound();
            c.putInt("Slot", k);
            c.putString("id", Registry.ITEM.getId(s.getItem()).toString());
            c.putInt("Count", s.getCount());
            if (s.hasTag()) {
                c.put("tag", s.getTag().copy());
            }
            list.add(c);
        }
        if (list.isEmpty()) {
            bag.getTag().remove(BAG);
        } else {
            bag.getTag().put(BAG, list);
        }
    }

    /** Копирует содержимое старого рюкзака в новый (улучшение в верстаке). */
    public static void copyContents(ItemStack from, ItemStack to) {
        if (from.hasTag() && from.getTag().contains(BAG, 9) && to.hasTag()) {
            to.getTag().put(BAG, from.getTag().getList(BAG, 10).copy());
        }
    }
}
