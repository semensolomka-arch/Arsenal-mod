package com.arsenal.backpack;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;

/** Окно рюкзака: сундук на 1-4 ряда, лишние слоты закрыты серыми панелями. Содержимое сохраняется в рюкзак после каждого клика. */
public class BagScreenHandler extends ScreenHandler {
    private final SimpleInventory inv;
    private final int rows;
    private final int lvl;
    private final long uid;

    static ItemStack filler() {
        ItemStack s = new ItemStack(Items.GRAY_STAINED_GLASS_PANE);
        s.setCustomName(new LiteralText(" "));
        return s;
    }

    private static ScreenHandlerType<?> typeFor(int rows) {
        switch (rows) {
            case 1:
                return ScreenHandlerType.GENERIC_9X1;
            case 2:
                return ScreenHandlerType.GENERIC_9X2;
            case 3:
                return ScreenHandlerType.GENERIC_9X3;
            default:
                return ScreenHandlerType.GENERIC_9X4;
        }
    }

    private static final class BagSlot extends Slot {
        private final boolean enabled;

        BagSlot(Inventory inv, int index, int x, int y, boolean enabled) {
            super(inv, index, x, y);
            this.enabled = enabled;
        }

        @Override
        public boolean canInsert(ItemStack stack) {
            return enabled && !Backpacks.isBackpack(stack);
        }

        @Override
        public boolean canTakeItems(PlayerEntity player) {
            return enabled;
        }
    }

    public BagScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory inv, int rows, int lvl, long uid) {
        super(typeFor(rows), syncId);
        this.inv = inv;
        this.rows = rows;
        this.lvl = lvl;
        this.uid = uid;
        int offset = (rows - 4) * 18;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < 9; c++) {
                int idx = c + r * 9;
                this.addSlot(new BagSlot(inv, idx, 8 + c * 18, 18 + r * 18, Backpacks.logicalIndex(lvl, idx) >= 0));
            }
        }
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.addSlot(new Slot(playerInventory, c + r * 9 + 9, 8 + c * 18, 103 + r * 18 + offset));
            }
        }
        for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(playerInventory, c, 8 + c * 18, 161 + offset));
        }
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return Backpacks.findByUid(player, uid) != null;
    }

    private void saveTo(PlayerEntity player) {
        ItemStack bag = Backpacks.findByUid(player, uid);
        if (bag != null) {
            Backpacks.save(bag, inv, lvl);
        }
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        ItemStack result = super.onSlotClick(slotIndex, clickData, actionType, player);
        if (player instanceof ServerPlayerEntity) {
            saveTo(player);
        }
        return result;
    }

    @Override
    public ItemStack transferSlot(PlayerEntity player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasStack()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getStack();
        ItemStack copy = stack.copy();
        int bagEnd = rows * 9;
        if (index < bagEnd) {
            if (Backpacks.logicalIndex(lvl, index) < 0 || !this.insertItem(stack, bagEnd, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else {
            if (Backpacks.isBackpack(stack) || !this.insertItem(stack, 0, bagEnd, false)) {
                return ItemStack.EMPTY;
            }
        }
        if (stack.isEmpty()) {
            slot.setStack(ItemStack.EMPTY);
        } else {
            slot.markDirty();
        }
        return copy;
    }
}
