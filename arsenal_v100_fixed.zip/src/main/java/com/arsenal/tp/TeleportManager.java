package com.arsenal.tp;

import com.arsenal.combat.Combat;
import com.arsenal.event.EventManager;
import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import com.arsenal.pvp.PvpManager;
import com.arsenal.spawn.SpawnManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.util.Formatting;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Телепорты: /rtp (обычный, long, event, player, base), /sethome, /home, /delhome, /spawn, /tpa, /tpaccept, /tpdeny.
 * Любая телепортация идёт через ожидание 3 секунды: нельзя двигаться и получать урон, иначе она отменяется.
 * В режиме боя команды не работают вообще (см. CommandManagerMixin). В поединке любая телепортация это побег (PvpManager).
 */
public final class TeleportManager {
    public static int WAIT_TICKS = 60;
    public static int REQUEST_TTL = 20 * 60;
    public static int TPA_COOLDOWN = 20 * 20;
    public static int HOMES_MAX = 10;
    private static final Random RNG = new Random();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private enum Mode {
        NEAR("rtp", 4000, 20 * 10),
        LONG("rtp_long", 10000, 20 * 60),
        EVENT("rtp_event", 1500, 20 * 60 * 10),
        PLAYER("rtp_player", 300, 20 * 60 * 10),
        BASE("rtp_base", 150, 20 * 60 * 10);

        final String key;
        final int max;
        final int cooldown;

        Mode(String key, int max, int cooldown) {
            this.key = key;
            this.max = max;
            this.cooldown = cooldown;
        }
    }

    private static final class Dest {
        final ServerWorld world;
        final double x, y, z;
        final float yaw;

        Dest(ServerWorld world, double x, double y, double z, float yaw) {
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
        }
    }

    private static final class Wait {
        UUID id;
        int left;
        double x, y, z;
        float health;
        String cooldownKey;
        int cooldownTicks;
        Supplier<Dest> dest;
    }

    private static final class Request {
        UUID from;
        String fromName;
        UUID to;
        String toName;
        int expires;
    }

    private static final class Home {
        String name;
        String dim;
        double x, y, z;
        float yaw, pitch;
    }

    private static int tick;
    private static final Map<UUID, Wait> WAITS = new HashMap<>();
    private static final Map<UUID, Map<String, Integer>> COOLDOWNS = new HashMap<>();
    private static final List<Request> REQUESTS = new ArrayList<>();
    private static final Map<UUID, List<Home>> HOMES = new LinkedHashMap<>();
    private static Path homesFile;

    private TeleportManager() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(TeleportManager::loadHomes);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            saveHomes();
            WAITS.clear();
            REQUESTS.clear();
            COOLDOWNS.clear();
        });
        ServerTickEvents.END_SERVER_TICK.register(TeleportManager::onTick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.player.getUuid();
            WAITS.remove(id);
            REQUESTS.removeIf(r -> r.from.equals(id) || r.to.equals(id));
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(CommandManager.literal("rtp")
                    .executes(ctx -> rtp(ctx.getSource().getPlayer(), Mode.NEAR))
                    .then(CommandManager.literal("long").executes(ctx -> rtp(ctx.getSource().getPlayer(), Mode.LONG)))
                    .then(CommandManager.literal("event").executes(ctx -> rtp(ctx.getSource().getPlayer(), Mode.EVENT)))
                    .then(CommandManager.literal("player").executes(ctx -> rtp(ctx.getSource().getPlayer(), Mode.PLAYER)))
                    .then(CommandManager.literal("base").executes(ctx -> rtp(ctx.getSource().getPlayer(), Mode.BASE))));
            dispatcher.register(CommandManager.literal("spawn").executes(ctx -> spawn(ctx.getSource().getPlayer())));
            com.mojang.brigadier.builder.LiteralArgumentBuilder<net.minecraft.server.command.ServerCommandSource> warpCmd =
                    CommandManager.literal("warp").executes(ctx -> warp(ctx.getSource().getPlayer(), null));
            for (String warpName : com.arsenal.spawn.SpawnManager.WARPS) {
                warpCmd.then(CommandManager.literal(warpName).executes(ctx -> warp(ctx.getSource().getPlayer(), warpName)));
            }
            dispatcher.register(warpCmd);
            dispatcher.register(CommandManager.literal("sethome").then(
                    CommandManager.argument("name", StringArgumentType.greedyString())
                            .executes(ctx -> setHome(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "name")))));
            dispatcher.register(CommandManager.literal("home")
                    .executes(ctx -> home(ctx.getSource().getPlayer(), null))
                    .then(homeName().executes(ctx -> home(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "name")))));
            dispatcher.register(CommandManager.literal("delhome").then(
                    homeName().executes(ctx -> delHome(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "name")))));
            dispatcher.register(CommandManager.literal("tpa").then(
                    CommandManager.argument("player", StringArgumentType.word()).suggests(TeleportManager::suggestOnline)
                            .executes(ctx -> tpa(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "player")))));
            dispatcher.register(CommandManager.literal("tpaccept")
                    .executes(ctx -> accept(ctx.getSource().getPlayer(), null))
                    .then(CommandManager.argument("player", StringArgumentType.word()).suggests(TeleportManager::suggestRequests)
                            .executes(ctx -> accept(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "player")))));
            dispatcher.register(CommandManager.literal("tpdeny")
                    .executes(ctx -> deny(ctx.getSource().getPlayer(), null))
                    .then(CommandManager.argument("player", StringArgumentType.word()).suggests(TeleportManager::suggestRequests)
                            .executes(ctx -> deny(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "player")))));
        });
    }

    private static RequiredArgumentBuilder<ServerCommandSource, String> homeName() {
        return CommandManager.argument("name", StringArgumentType.greedyString()).suggests((ctx, builder) -> {
            List<String> names = new ArrayList<>();
            if (ctx.getSource().getEntity() instanceof ServerPlayerEntity) {
                for (Home h : homesOf(((ServerPlayerEntity) ctx.getSource().getEntity()).getUuid())) {
                    names.add(h.name);
                }
            }
            return CommandSource.suggestMatching(names, builder);
        });
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggestOnline(
            com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx, com.mojang.brigadier.suggestion.SuggestionsBuilder b) {
        return CommandSource.suggestMatching(ctx.getSource().getMinecraftServer().getPlayerManager().getPlayerNames(), b);
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggestRequests(
            com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx, com.mojang.brigadier.suggestion.SuggestionsBuilder b) {
        List<String> names = new ArrayList<>();
        if (ctx.getSource().getEntity() instanceof ServerPlayerEntity) {
            UUID me = ((ServerPlayerEntity) ctx.getSource().getEntity()).getUuid();
            for (Request r : REQUESTS) {
                if (r.to.equals(me)) {
                    names.add(r.fromName);
                }
            }
        }
        return CommandSource.suggestMatching(names, b);
    }

    // ------------------------------------------------------------------ общее

    private static void say(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(new LiteralText(text).formatted(color), false);
    }

    private static String fmt(int ticks) {
        int s = (ticks + 19) / 20;
        if (s >= 60) {
            return (s / 60) + " мин" + (s % 60 > 0 ? " " + (s % 60) + " с" : "");
        }
        return s + " с";
    }

    /** Не ждёт ли уже игрок телепорта и не идёт ли у команды кулдаун. */
    private static boolean ready(ServerPlayerEntity p, String key) {
        if (WAITS.containsKey(p.getUuid())) {
            say(p, "Вы уже ожидаете телепортацию", Formatting.RED);
            return false;
        }
        if (key != null && !SpawnProtection.bypass(p)) {
            Map<String, Integer> m = COOLDOWNS.get(p.getUuid());
            Integer end = m == null ? null : m.get(key);
            if (end != null && end > tick) {
                say(p, "Подождите ещё " + fmt(end - tick), Formatting.RED);
                return false;
            }
        }
        return true;
    }

    private static void setCooldown(ServerPlayerEntity p, String key, int ticks) {
        if (key != null && ticks > 0 && !SpawnProtection.bypass(p)) {
            COOLDOWNS.computeIfAbsent(p.getUuid(), k -> new HashMap<>()).put(key, tick + ticks);
        }
    }

    private static void begin(ServerPlayerEntity p, String cooldownKey, int cooldownTicks, Supplier<Dest> dest) {
        Wait w = new Wait();
        w.id = p.getUuid();
        w.left = WAIT_TICKS;
        w.x = p.getX();
        w.y = p.getY();
        w.z = p.getZ();
        w.health = p.getHealth() + p.getAbsorptionAmount();
        w.cooldownKey = cooldownKey;
        w.cooldownTicks = cooldownTicks;
        w.dest = dest;
        // на спавне любая телепортация моментальная (в режиме боя всё равно нельзя)
        if (SpawnManager.near(p) && !Combat.isInCombat(p)) {
            finish(p, w);
            return;
        }
        WAITS.put(p.getUuid(), w);
        say(p, "Телепортация через 3 секунды, не двигайтесь!", Formatting.YELLOW);
    }

    private static void cancel(ServerPlayerEntity p, String why) {
        WAITS.remove(p.getUuid());
        say(p, "Телепортация отменена: " + why, Formatting.RED);
    }

    private static void onTick(MinecraftServer server) {
        tick++;
        if (!REQUESTS.isEmpty()) {
            Iterator<Request> it = REQUESTS.iterator();
            while (it.hasNext()) {
                Request r = it.next();
                if (tick >= r.expires) {
                    it.remove();
                    ServerPlayerEntity from = server.getPlayerManager().getPlayer(r.from);
                    ServerPlayerEntity to = server.getPlayerManager().getPlayer(r.to);
                    if (from != null) {
                        say(from, "Запрос к игроку " + r.toName + " отклонён: вышло время", Formatting.RED);
                    }
                    if (to != null) {
                        say(to, "Запрос от игрока " + r.fromName + " отклонён: вышло время", Formatting.GRAY);
                    }
                }
            }
        }
        if (WAITS.isEmpty()) {
            return;
        }
        for (Wait w : new ArrayList<>(WAITS.values())) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(w.id);
            if (p == null || p.isDead()) {
                WAITS.remove(w.id);
                continue;
            }
            float hp = p.getHealth() + p.getAbsorptionAmount();
            double dx = p.getX() - w.x;
            double dz = p.getZ() - w.z;
            double dy = p.getY() - w.y;
            if (Combat.isInCombat(p)) {
                cancel(p, "вы в режиме боя");
            } else if (hp < w.health - 0.01F) {
                cancel(p, "вы получили урон");
            } else if (dx * dx + dz * dz > 0.09 || Math.abs(dy) > 0.6) {
                cancel(p, "вы двигались");
            } else {
                w.health = hp;
                w.left--;
                if (w.left > 0 && w.left % 20 == 0) {
                    p.sendMessage(new LiteralText("Телепортация через " + (w.left / 20) + " с. Не двигайтесь").formatted(Formatting.YELLOW), true);
                }
                if (w.left <= 0) {
                    WAITS.remove(w.id);
                    finish(p, w);
                }
            }
        }
    }

    private static void finish(ServerPlayerEntity p, Wait w) {
        Dest d = w.dest.get();
        if (d == null) {
            say(p, "Телепортация не удалась: место назначения недоступно", Formatting.RED);
            return;
        }
        if (EventManager.inZone(d.world, d.x, d.z) && !SpawnProtection.bypass(p)) {
            say(p, "Нельзя телепортироваться в зону ивента", Formatting.RED);
            return;
        }
        // телепорт из поединка: поражение, соперник возвращается на прежнее место, а сам игрок идёт куда хотел
        PvpManager.surrenderDuel(p.getServer(), p);
        p.stopRiding();
        p.teleport(d.world, d.x, d.y, d.z, Float.isNaN(d.yaw) ? p.yaw : d.yaw, p.pitch);
        p.fallDistance = 0.0F;
        d.world.playSound(null, d.x, d.y, d.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        setCooldown(p, w.cooldownKey, w.cooldownTicks);
        say(p, "Вы телепортированы", Formatting.GREEN);
    }

    // ------------------------------------------------------------------ безопасная точка

    private static Dest safeAt(ServerWorld world, int x, int z) {
        BlockPos column = new BlockPos(x, 64, z);
        if (!world.getWorldBorder().contains(column)) {
            return null;
        }
        world.getChunk(x >> 4, z >> 4);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y <= 2 || y > 240) {
            return null;
        }
        BlockPos ground = new BlockPos(x, y - 1, z);
        BlockPos feet = new BlockPos(x, y, z);
        BlockState gs = world.getBlockState(ground);
        if (!gs.getFluidState().isEmpty() || !gs.isSideSolidFullSquare(world, ground, net.minecraft.util.math.Direction.UP)) {
            return null;
        }
        if (gs.isOf(Blocks.MAGMA_BLOCK) || gs.isOf(Blocks.CACTUS) || gs.isOf(Blocks.CAMPFIRE) || gs.isOf(Blocks.SOUL_CAMPFIRE)
                || gs.isOf(Blocks.FIRE) || gs.isOf(Blocks.SOUL_FIRE)) {
            return null;
        }
        BlockState fs = world.getBlockState(feet);
        BlockState hs = world.getBlockState(feet.up());
        if (!fs.getCollisionShape(world, feet).isEmpty() || !fs.getFluidState().isEmpty() || fs.isOf(Blocks.FIRE)
                || fs.isOf(Blocks.SOUL_FIRE) || fs.isOf(Blocks.SWEET_BERRY_BUSH)
                || !hs.getCollisionShape(world, feet.up()).isEmpty() || !hs.getFluidState().isEmpty()) {
            return null;
        }
        if (EventManager.inZone(world, feet) || SpawnProtection.contains(world, feet) || PrivateManager.isCovered(world, feet)) {
            return null;
        }
        return new Dest(world, x + 0.5, y, z + 0.5, Float.NaN);
    }

    private static Dest ringSearch(ServerWorld world, double cx, double cz, double min, double max) {
        for (int i = 0; i < 12; i++) {
            double angle = RNG.nextDouble() * Math.PI * 2.0;
            double r = min + RNG.nextDouble() * (max - min);
            Dest d = safeAt(world, (int) Math.floor(cx + Math.cos(angle) * r), (int) Math.floor(cz + Math.sin(angle) * r));
            if (d != null) {
                return d;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ /rtp, /spawn

    private static int rtp(ServerPlayerEntity p, Mode mode) {
        if (PvpManager.teleportBlocked(p) || !ready(p, mode.key)) {
            return 0;
        }
        MinecraftServer server = p.getServer();
        ServerWorld overworld = server.getOverworld();
        Dest d = null;
        switch (mode) {
            case NEAR:
                for (int i = 0; i < 30 && d == null; i++) {
                    int lim = WorldLimit.RADIUS - 5;
                    int x;
                    int z;
                    if (RNG.nextInt(100) < 85) {
                        // обычно 1000-1500 блоков от центра, но в теории может быть где угодно
                        double a = RNG.nextDouble() * Math.PI * 2.0;
                        double r = 1000.0 + RNG.nextDouble() * 500.0;
                        x = (int) Math.round(Math.cos(a) * r);
                        z = (int) Math.round(Math.sin(a) * r);
                    } else {
                        x = RNG.nextInt(lim * 2 + 1) - lim;
                        z = RNG.nextInt(lim * 2 + 1) - lim;
                    }
                    d = safeAt(overworld, x, z);
                }
                break;
            case LONG:
                for (int i = 0; i < 40 && d == null; i++) {
                    int lim = WorldLimit.RADIUS - 5;
                    int x = RNG.nextInt(lim * 2 + 1) - lim;
                    int z = RNG.nextInt(lim * 2 + 1) - lim;
                    if (Math.max(Math.abs(x), Math.abs(z)) < Math.min(2500, WorldLimit.RADIUS * 5 / 8)) {
                        continue;   // /rtp long: от 2500 блоков и дальше, до самой границы
                    }
                    d = safeAt(overworld, x, z);
                }
                break;
            case EVENT: {
                List<int[]> centers = EventManager.allCenters();
                if (centers.isEmpty()) {
                    say(p, "Сейчас нет ивента", Formatting.RED);
                    return 0;
                }
                int[] c = centers.get(RNG.nextInt(centers.size()));
                for (int i = 0; i < 40 && d == null; i++) {
                    // смещение от ивента по каждой оси в + или в -, без ограничения по расстоянию
                    int dx = (RNG.nextBoolean() ? 1 : -1) * (40 + RNG.nextInt(2500));
                    int dz = (RNG.nextBoolean() ? 1 : -1) * (40 + RNG.nextInt(2500));
                    d = safeAt(overworld, c[0] + dx, c[1] + dz);
                }
                break;
            }
            case PLAYER: {
                List<ServerPlayerEntity> list = new ArrayList<>();
                for (ServerPlayerEntity o : server.getPlayerManager().getPlayerList()) {
                    if (o != p && !o.isSpectator() && !o.hasStatusEffect(StatusEffects.INVISIBILITY)
                            && !com.arsenal.hub.HubManager.isActive(o.getUuid())
                            && o.getServerWorld() == overworld && !PvpManager.inFight(o)) {
                        list.add(o);
                    }
                }
                if (list.isEmpty()) {
                    say(p, "Нет подходящих игроков (невидимых игроков найти нельзя)", Formatting.RED);
                    return 0;
                }
                ServerPlayerEntity target = list.get(RNG.nextInt(list.size()));
                d = ringSearch(overworld, target.getX(), target.getZ(), 40, mode.max);
                break;
            }
            default: {
                List<PrivateManager.Entry> mine = new ArrayList<>();
                for (PrivateManager.Entry e : PrivateManager.all(overworld)) {
                    if (!e.isTrusted(p.getUuid())) {
                        mine.add(e);
                    }
                }
                if (mine.isEmpty()) {
                    say(p, "Нет приватов других игроков в обычном мире", Formatting.RED);
                    return 0;
                }
                PrivateManager.Entry e = mine.get(RNG.nextInt(mine.size()));
                d = ringSearch(overworld, e.pos.getX() + 0.5, e.pos.getZ() + 0.5, e.type.half + 5, mode.max);
                break;
            }
        }
        if (d == null) {
            say(p, "Не удалось найти безопасное место, попробуйте ещё раз", Formatting.RED);
            return 0;
        }
        final Dest dest = d;
        begin(p, mode.key, mode.cooldown, () -> dest);
        return 1;
    }

    private static int spawn(ServerPlayerEntity p) {
        if (PvpManager.teleportBlocked(p) || !ready(p, null)) {
            return 0;
        }
        ServerWorld ow = com.arsenal.spawn.SpawnWorld.get(p.getServer());
        begin(p, null, 0, () -> {
            com.arsenal.spawn.SpawnManager.ensureBuilt(ow);
            return new Dest(ow, com.arsenal.spawn.SpawnManager.SPAWN_X, com.arsenal.spawn.SpawnManager.SPAWN_Y,
                    com.arsenal.spawn.SpawnManager.SPAWN_Z, com.arsenal.spawn.SpawnManager.SPAWN_YAW);
        });
        return 1;
    }

    /** /warp: места на спавне: rtp, enchant, privat (private), mine1, mine2. */
    private static int warp(ServerPlayerEntity p, String name) {
        if (name == null) {
            say(p, "Доступные варпы: rtp, enchant, privat, mine1, mine2, pvp (/warp название)", Formatting.YELLOW);
            return 1;
        }
        if (PvpManager.teleportBlocked(p) || !ready(p, null)) {
            return 0;
        }
        ServerWorld ow = com.arsenal.spawn.SpawnWorld.get(p.getServer());
        if ("pvp".equals(name) && !com.arsenal.spawn.PvpArena.ready()) {
            say(p, "ПВП-арена ещё строится, подожди пару минут", Formatting.YELLOW);
            return 0;
        }
        begin(p, null, 0, () -> {
            double[] pt = com.arsenal.spawn.SpawnManager.warpPoint(ow, name);
            return new Dest(ow, pt[0], pt[1], pt[2], (float) pt[3]);
        });
        return 1;
    }

    /** Прыжок в яму на спавне: обычный /rtp (с ожиданием 3 секунды и кулдауном). */
    public static void portalRtp(ServerPlayerEntity p) {
        if (WAITS.containsKey(p.getUuid())) {
            return;
        }
        rtp(p, Mode.NEAR);
    }

    // ------------------------------------------------------------------ дома

    private static List<Home> homesOf(UUID id) {
        return HOMES.computeIfAbsent(id, k -> new ArrayList<>());
    }

    private static Home findHome(UUID id, String name) {
        for (Home h : homesOf(id)) {
            if (h.name.equalsIgnoreCase(name)) {
                return h;
            }
        }
        return null;
    }

    private static int setHome(ServerPlayerEntity p, String raw) {
        String name = raw.trim();
        if (name.isEmpty() || name.length() > 24) {
            say(p, "Название дома: от 1 до 24 символов", Formatting.RED);
            return 0;
        }
        if (!SpawnProtection.bypass(p)) {
            if (EventManager.inZone(p.world, p.getX(), p.getZ())) {
                say(p, "В зоне ивента дом ставить нельзя", Formatting.RED);
                return 0;
            }
            if (SpawnProtection.contains(p.world, p.getBlockPos())) {
                say(p, "В зоне замка и ПВП-арены дом ставить нельзя", Formatting.RED);
                return 0;
            }
            if (PrivateManager.foreignAt(p.world, p.getBlockPos(), p) != null) {
                say(p, "Вы не можете поставить точку дома в чужом регионе", Formatting.RED);
                return 0;
            }
        }
        Home h = findHome(p.getUuid(), name);
        if (h == null) {
            if (homesOf(p.getUuid()).size() >= HOMES_MAX) {
                say(p, "Максимум домов: " + HOMES_MAX + ". Удалите лишний: /delhome название", Formatting.RED);
                return 0;
            }
            h = new Home();
            homesOf(p.getUuid()).add(h);
        }
        h.name = name;
        h.dim = p.getServerWorld().getRegistryKey().getValue().toString();
        h.x = p.getX();
        h.y = p.getY();
        h.z = p.getZ();
        h.yaw = p.yaw;
        h.pitch = p.pitch;
        saveHomes();
        say(p, "Дом «" + name + "» установлен", Formatting.GREEN);
        return 1;
    }

    private static int home(ServerPlayerEntity p, String raw) {
        List<Home> list = homesOf(p.getUuid());
        Home h;
        if (raw == null || raw.trim().isEmpty()) {
            if (list.isEmpty()) {
                say(p, "У вас нет домов. Поставить: /sethome название", Formatting.RED);
                return 0;
            }
            if (list.size() > 1) {
                StringBuilder sb = new StringBuilder();
                for (Home x : list) {
                    sb.append(sb.length() == 0 ? "" : ", ").append(x.name);
                }
                say(p, "Ваши дома: " + sb + ". Телепорт: /home название", Formatting.YELLOW);
                return 1;
            }
            h = list.get(0);
        } else {
            h = findHome(p.getUuid(), raw.trim());
            if (h == null) {
                say(p, "Дом «" + raw.trim() + "» не найден", Formatting.RED);
                return 0;
            }
        }
        if (PvpManager.teleportBlocked(p) || !ready(p, null)) {
            return 0;
        }
        ServerWorld target = null;
        for (ServerWorld w : p.getServer().getWorlds()) {
            if (w.getRegistryKey().getValue().toString().equals(h.dim)) {
                target = w;
            }
        }
        if (target == null) {
            say(p, "Мир этого дома не найден", Formatting.RED);
            return 0;
        }
        final Dest d = new Dest(target, h.x, h.y, h.z, h.yaw);
        begin(p, null, 0, () -> d);
        return 1;
    }

    private static int delHome(ServerPlayerEntity p, String raw) {
        Home h = findHome(p.getUuid(), raw.trim());
        if (h == null) {
            say(p, "Дом «" + raw.trim() + "» не найден", Formatting.RED);
            return 0;
        }
        homesOf(p.getUuid()).remove(h);
        saveHomes();
        say(p, "Дом «" + h.name + "» удалён", Formatting.GREEN);
        return 1;
    }

    private static void loadHomes(MinecraftServer server) {
        HOMES.clear();
        homesFile = server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_homes.json");
        try {
            if (!Files.exists(homesFile)) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(homesFile), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : root.entrySet()) {
                List<Home> list = new ArrayList<>();
                for (JsonElement el : e.getValue().getAsJsonArray()) {
                    JsonObject o = el.getAsJsonObject();
                    Home h = new Home();
                    h.name = o.get("name").getAsString();
                    h.dim = o.get("dim").getAsString();
                    h.x = o.get("x").getAsDouble();
                    h.y = o.get("y").getAsDouble();
                    h.z = o.get("z").getAsDouble();
                    h.yaw = o.get("yaw").getAsFloat();
                    h.pitch = o.get("pitch").getAsFloat();
                    list.add(h);
                }
                HOMES.put(UUID.fromString(e.getKey()), list);
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать arsenal_homes.json: " + ex);
        }
    }

    private static void saveHomes() {
        if (homesFile == null) {
            return;
        }
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, List<Home>> e : HOMES.entrySet()) {
                JsonArray array = new JsonArray();
                for (Home h : e.getValue()) {
                    JsonObject o = new JsonObject();
                    o.addProperty("name", h.name);
                    o.addProperty("dim", h.dim);
                    o.addProperty("x", h.x);
                    o.addProperty("y", h.y);
                    o.addProperty("z", h.z);
                    o.addProperty("yaw", h.yaw);
                    o.addProperty("pitch", h.pitch);
                    array.add(o);
                }
                root.add(e.getKey().toString(), array);
            }
            Files.write(homesFile, GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось сохранить arsenal_homes.json: " + ex);
        }
    }

    // ------------------------------------------------------------------ /tpa, /tpaccept, /tpdeny

    private static int tpa(ServerPlayerEntity p, String name) {
        if (PvpManager.teleportBlocked(p)) {
            return 0;
        }
        ServerPlayerEntity t = p.getServer().getPlayerManager().getPlayer(name);
        if (t == null) {
            say(p, "Игрок не найден или не в сети", Formatting.RED);
            return 0;
        }
        if (t == p) {
            say(p, "Нельзя отправить запрос самому себе", Formatting.RED);
            return 0;
        }
        if (PvpManager.inFight(t)) {
            say(p, "Игрок сейчас в схватке", Formatting.RED);
            return 0;
        }
        if (com.arsenal.hub.HubManager.isActive(t.getUuid())) {
            say(p, "Игрок сейчас недоступен", Formatting.RED);
            return 0;
        }
        for (Request r : REQUESTS) {
            if (r.from.equals(p.getUuid()) && r.to.equals(t.getUuid())) {
                say(p, "Вы уже отправили запрос этому игроку", Formatting.RED);
                return 0;
            }
        }
        if (!ready(p, "tpa")) {
            return 0;
        }
        Request r = new Request();
        r.from = p.getUuid();
        r.fromName = p.getGameProfile().getName();
        r.to = t.getUuid();
        r.toName = t.getGameProfile().getName();
        r.expires = tick + REQUEST_TTL;
        REQUESTS.add(r);
        setCooldown(p, "tpa", TPA_COOLDOWN);
        say(p, "Запрос на телепортацию отправлен игроку " + r.toName + ". Он отклонится сам через 60 секунд", Formatting.YELLOW);
        MutableText msg = new LiteralText("Игрок " + r.fromName + " хочет телепортироваться к вам. ").formatted(Formatting.YELLOW);
        msg.append(button("[Принять]", "/tpaccept " + r.fromName, Formatting.GREEN));
        msg.append(new LiteralText(" "));
        msg.append(button("[Отклонить]", "/tpdeny " + r.fromName, Formatting.RED));
        t.sendMessage(msg, false);
        return 1;
    }

    private static MutableText button(String label, String command, Formatting color) {
        return new LiteralText(label).setStyle(Style.EMPTY.withColor(color)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new LiteralText(command))));
    }

    private static Request pick(ServerPlayerEntity t, String name) {
        Request found = null;
        for (Request r : REQUESTS) {
            if (r.to.equals(t.getUuid()) && (name == null || r.fromName.equalsIgnoreCase(name))) {
                found = r;
            }
        }
        return found;
    }

    private static int accept(ServerPlayerEntity t, String name) {
        Request r = pick(t, name);
        if (r == null) {
            say(t, "У вас нет запросов на телепортацию", Formatting.RED);
            return 0;
        }
        MinecraftServer server = t.getServer();
        ServerPlayerEntity from = server.getPlayerManager().getPlayer(r.from);
        if (from == null) {
            REQUESTS.remove(r);
            say(t, "Игрок " + r.fromName + " вышел из игры", Formatting.RED);
            return 0;
        }
        if (Combat.isInCombat(from) || PvpManager.inDeathFight(from)) {
            REQUESTS.remove(r);
            say(t, "Игрок " + r.fromName + " сейчас в бою, телепортация невозможна", Formatting.RED);
            return 0;
        }
        if (WAITS.containsKey(from.getUuid())) {
            say(t, "Игрок " + r.fromName + " уже ожидает другую телепортацию", Formatting.RED);
            return 0;
        }
        if (EventManager.inZone(t.world, t.getX(), t.getZ()) && !SpawnProtection.bypass(from)) {
            say(t, "В зоне ивента принимать телепортацию нельзя", Formatting.RED);
            return 0;
        }
        REQUESTS.remove(r);
        UUID tid = t.getUuid();
        begin(from, null, 0, () -> {
            ServerPlayerEntity target = server.getPlayerManager().getPlayer(tid);
            if (target == null || target.isDead() || PvpManager.inFight(target)) {
                return null;
            }
            return new Dest(target.getServerWorld(), target.getX(), target.getY(), target.getZ(), Float.NaN);
        });
        say(t, "Вы приняли запрос игрока " + r.fromName, Formatting.GREEN);
        return 1;
    }

    private static int deny(ServerPlayerEntity t, String name) {
        int n = 0;
        Iterator<Request> it = REQUESTS.iterator();
        while (it.hasNext()) {
            Request r = it.next();
            if (r.to.equals(t.getUuid()) && (name == null || r.fromName.equalsIgnoreCase(name))) {
                it.remove();
                n++;
                ServerPlayerEntity from = t.getServer().getPlayerManager().getPlayer(r.from);
                if (from != null) {
                    say(from, "Игрок " + r.toName + " отклонил ваш запрос на телепортацию", Formatting.RED);
                }
            }
        }
        if (n == 0) {
            say(t, "У вас нет запросов на телепортацию", Formatting.RED);
            return 0;
        }
        say(t, "Запрос отклонён", Formatting.GRAY);
        return 1;
    }
}
