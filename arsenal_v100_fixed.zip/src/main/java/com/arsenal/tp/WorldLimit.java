package com.arsenal.tp;

import com.arsenal.pvp.PvpManager;
import java.util.Random;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;
import net.minecraft.world.border.WorldBorder;

/** Граница мира (радиус от 0,0), урон за границей и выбор мест для ивентов. */
public final class WorldLimit {
    /** Радиус границы в блоках (граница квадратная: от -R до +R). */
    public static int RADIUS = 4000;
    private static MinecraftServer server;

    private WorldLimit() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            apply();
        });
        ServerTickEvents.END_SERVER_TICK.register(WorldLimit::tick);
    }

    public static void setRadius(int r) {
        RADIUS = Math.max(100, r);
        apply();
    }

    public static void apply() {
        if (server == null) {
            return;
        }
        WorldBorder b = server.getOverworld().getWorldBorder();
        b.setCenter(0.0, 0.0);
        b.setSize(RADIUS * 2.0);
        b.setDamagePerBlock(0.0);   // урон за границей наш, ванильный выключен
        b.setSafeZone(1000000.0);
    }

    /** На сколько блоков игрок вышел за границу (0 = внутри). */
    public static double outside(double x, double z) {
        return Math.max(0.0, Math.max(Math.abs(x), Math.abs(z)) - RADIUS);
    }

    private static void tick(MinecraftServer s) {
        if (s.getTicks() % 10 != 0) {
            return;
        }
        ServerWorld ow = s.getOverworld();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            if (p.getServerWorld() != ow || p.isSpectator() || p.isCreative() || p.isDead()
                    || p.interactionManager.getGameMode() == GameMode.SPECTATOR || PvpManager.inDeathFight(p)) {
                continue;
            }
            double d = outside(p.getX(), p.getZ());
            if (d <= 0.0) {
                continue;
            }
            // чем дальше, тем больнее: у самой границы ~1 сердце, ~100 блоков за ней — смерть с одного удара
            float dmg = (float) (1.0 + d * 0.2);
            p.sendMessage(new LiteralText("Вы за границей мира! Вернитесь назад (" + (int) d + " бл.)").formatted(Formatting.RED), true);
            p.timeUntilRegen = 0;
            p.damage(DamageSource.OUT_OF_WORLD, dmg);
        }
    }

    /** Место ивента: в границе, не ближе 100 блоков к ней и не ближе 400 блоков к 0,0. */
    public static int[] eventSpot(Random rng) {
        int lim = RADIUS - 100;
        for (int i = 0; i < 100; i++) {
            int x = rng.nextInt(lim * 2 + 1) - lim;
            int z = rng.nextInt(lim * 2 + 1) - lim;
            if ((long) x * x + (long) z * z >= 400L * 400L) {
                return new int[]{x, z};
            }
        }
        return new int[]{lim, 0};
    }
}
