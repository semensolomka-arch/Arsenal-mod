package com.arsenal.anvil;

import com.arsenal.Arsenal;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Map;

/**
 * Слияние одинаковых зачарований в наковальне (два одинаковых предмета или предмет + книга).
 * В ваниле Острота, Небесная кара и Бич членистоногих несовместимы между собой, поэтому у меча, где они стоят
 * вместе (меч Дракона), ни одно из них не складывалось, а Добыча сверх ванильного максимума даже падала до III.
 * Здесь зачарования, которые уже есть на обоих предметах, складываются по правилам мода:
 * одинаковые уровни дают +1, разные - берётся больший, потолки: Прочность, Добыча и Удача V, Острота, Небесная кара и
 * Бич членистоногих VII. Непробиваемый не складывается (I + I = I, II + I = II).
 */
public final class EnchantMerge {
    private EnchantMerge() {
    }

    public static int maxLevel(Enchantment e) {
        if (e == Enchantments.SHARPNESS || e == Enchantments.SMITE || e == Enchantments.BANE_OF_ARTHROPODS) {
            return 7;
        }
        if (e == Enchantments.UNBREAKING || e == Enchantments.LOOTING || e == Enchantments.FORTUNE) {
            return 5;
        }
        return e.getMaxLevel();
    }

    /**
     * out - результат, который посчитала ваниль (может быть пустым). Возвращает итоговый стак: либо out
     * (с исправленными уровнями), либо новый стак, если ваниль отказала, либо out без изменений.
     */
    public static ItemStack merge(ItemStack left, ItemStack right, ItemStack out) {
        boolean book = right.getItem() == Items.ENCHANTED_BOOK;
        if (!book && left.getItem() != right.getItem()) {
            return out;
        }
        Map<Enchantment, Integer> lm = EnchantmentHelper.get(left);
        Map<Enchantment, Integer> rm = EnchantmentHelper.get(right);
        if (lm.isEmpty() || rm.isEmpty()) {
            return out;
        }
        boolean shared = false;
        for (Enchantment e : rm.keySet()) {
            if (lm.containsKey(e)) {
                shared = true;
                break;
            }
        }
        if (!shared) {
            return out;
        }
        ItemStack result = out.isEmpty() ? left.copy() : out;
        Map<Enchantment, Integer> om = EnchantmentHelper.get(result);
        for (Map.Entry<Enchantment, Integer> en : rm.entrySet()) {
            Enchantment e = en.getKey();
            Integer ll = lm.get(e);
            if (ll == null) {
                continue;
            }
            int rl = en.getValue();
            int level;
            if (e == Arsenal.IMPENETRABLE || e == com.arsenal.tool.ToolEnchants.FARMER) {
                level = Math.max(ll, rl);
            } else {
                level = ll == rl ? ll + 1 : Math.max(ll, rl);
            }
            om.put(e, Math.min(level, maxLevel(e)));
        }
        EnchantmentHelper.set(om, result);
        return result;
    }
}
