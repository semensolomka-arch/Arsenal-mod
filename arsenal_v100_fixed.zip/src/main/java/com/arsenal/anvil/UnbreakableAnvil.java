package com.arsenal.anvil;

import com.arsenal.Lore;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VI;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

/**
 * Нерушимая наковальня: ванильная наковальня с меткой в Marks (см. ViEvents). Не портится от использования
 * (состояние возвращается, пока игрок в окне наковальни), при поломке выпадает она сама.
 */
public final class UnbreakableAnvil {
    public static VI VI_ITEM;

    private UnbreakableAnvil() {
    }

    public static void init() {
        VI_ITEM = VI.register("unbreakable_anvil", Items.ANVIL)
                .vanillaUse(true)
                .placeBlock(Blocks.ANVIL)
                .name(s -> new LiteralText(Lang.get("block.arsenal.unbreakable_anvil")).formatted(Formatting.YELLOW))
                .lore(s -> Lore.lines("tooltip.arsenal.unbreakable_anvil.", 4, 0xFFFFFF));
    }
}
