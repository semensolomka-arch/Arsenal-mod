package com.arsenal.anvil;

import com.arsenal.vi.VI;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;

/** Нерушимая Мечта шахтёра + любая кирка (инфинити, стингер и т.д.): кирка становится нерушимой, остальное не меняется. */
public final class DreamAnvil {
    public static final class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private DreamAnvil() {
    }

    private static boolean isDream(ItemStack s) {
        VI vi = VI.of(s);
        return vi != null && vi.id.equals("miner_dream_unbreakable");
    }

    public static Result compute(ItemStack left, ItemStack right) {
        ItemStack dream = isDream(left) ? left : isDream(right) ? right : null;
        if (dream == null) {
            return null;
        }
        ItemStack other = dream == left ? right : left;
        if (!(other.getItem() instanceof PickaxeItem) || isDream(other)) {
            return null;
        }
        if (other.hasTag() && other.getTag().getBoolean("Unbreakable")) {
            return null;
        }
        ItemStack result = other.copy();
        result.setCount(1);
        result.getOrCreateTag().putBoolean("Unbreakable", true);
        return new Result(result, 5);
    }
}
