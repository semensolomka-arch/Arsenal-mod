package com.arsenal.create;

import com.arsenal.Arsenal;
import com.arsenal.sphere.Spheres;
import com.arsenal.vi.VI;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.AbstractCookingRecipe;
import net.minecraft.recipe.BlastingRecipe;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Осколки сфер: награда за переплавку сфер в печке и меню обмена /spheres. */
public final class SpheresMenu {
    private SpheresMenu() {
    }

    /** Сколько осколков даёт переплавка сферы (по id предмета). */
    private static final Map<String, Integer> REWARD = new LinkedHashMap<>();

    static {
        REWARD.put("sphere_common", 5);
        REWARD.put("sphere_epic", 10);
        REWARD.put("sphere_legendary", 15);
        REWARD.put("sphere_mythic", 25);
        REWARD.put("sphere_eternity", 30);
        REWARD.put("sphere_stinger", 20);
        REWARD.put("sphere_flash", 45);
        REWARD.put("sphere_cerberus", 64);
        REWARD.put("sphere_armortality", 25);
        REWARD.put("sphere_immortality", 25);
    }

    public static int reward(ItemStack s) {
        if (s == null || s.isEmpty() || s.getItem() != Items.PLAYER_HEAD) {
            return 0;
        }
        VI vi = VI.of(s);
        if (vi == null) {
            return 0;
        }
        Integer r = REWARD.get(vi.id);
        return r == null ? 0 : r;
    }

    public static AbstractCookingRecipe recipe(ItemStack input, RecipeType<?> type) {
        int n = reward(input);
        if (n <= 0) {
            return null;
        }
        ItemStack out = Arsenal.SPHERE_SHARD.stack();
        out.setCount(n);
        Identifier id = new Identifier("arsenal", "sphere_smelt");
        Ingredient ing = Ingredient.ofItems(input.getItem());
        if (type == RecipeType.BLASTING) {
            return new BlastingRecipe(id, "", ing, out, 0.0F, 100);
        }
        return new SmeltingRecipe(id, "", ing, out, 0.0F, 200);
    }

    private static int count(PlayerInventory inv) {
        int n = 0;
        for (ItemStack s : inv.main) {
            if (!s.isEmpty() && VI.of(s) == Arsenal.SPHERE_SHARD) {
                n += s.getCount();
            }
        }
        for (ItemStack s : inv.offHand) {
            if (!s.isEmpty() && VI.of(s) == Arsenal.SPHERE_SHARD) {
                n += s.getCount();
            }
        }
        return n;
    }

    private static void take(PlayerInventory inv, int amount) {
        int left = amount;
        List<ItemStack> all = new ArrayList<>(inv.main);
        all.addAll(inv.offHand);
        for (ItemStack s : all) {
            if (left > 0 && !s.isEmpty() && VI.of(s) == Arsenal.SPHERE_SHARD) {
                int d = Math.min(left, s.getCount());
                s.decrement(d);
                left -= d;
            }
        }
    }

    // ------------------------------------------------------------------ меню

    private static final class Entry {
        final int slot;
        final int price;
        final Supplier<ItemStack> item;

        Entry(int slot, int price, Supplier<ItemStack> item) {
            this.slot = slot;
            this.price = price;
            this.item = item;
        }
    }

    private static final List<Entry> ENTRIES = new ArrayList<>();

    private static void e(int slot, int price, Supplier<ItemStack> item) {
        ENTRIES.add(new Entry(slot, price, item));
    }

    private static Supplier<ItemStack> lv(Supplier<VI> vi, int speed, int damage, int armor, int attackSpeed, int health) {
        return () -> Spheres.stack(vi.get(), Spheres.v(speed, damage, armor, attackSpeed, health));
    }

    static {
        e(4, 256, () -> Arsenal.SPHERE_CERBERUS.stack());
        e(12, 61, () -> Arsenal.SPHERE_STINGER.stack());
        e(13, 83, () -> Arsenal.SPHERE_ETERNITY.stack());
        e(14, 71, () -> Arsenal.SPHERE_FLASH.stack());
        // легендарные
        e(19, 27, lv(() -> Arsenal.SPHERE_LEGENDARY, 0, 3, 0, 0, 0));
        e(20, 27, lv(() -> Arsenal.SPHERE_LEGENDARY, 0, 2, 2, 0, 0));
        e(21, 27, lv(() -> Arsenal.SPHERE_LEGENDARY, 3, 0, 0, 0, 0));
        e(22, 22, lv(() -> Arsenal.SPHERE_LEGENDARY, 0, 0, 0, 3, 0));
        // мифические
        e(23, 48, lv(() -> Arsenal.SPHERE_MYTHIC, 2, 0, 3, 0, 0));
        e(24, 64, lv(() -> Arsenal.SPHERE_MYTHIC, 0, 3, 2, 0, 0));
        e(25, 80, lv(() -> Arsenal.SPHERE_MYTHIC, 0, 2, 3, 0, 0));
        // эпические
        e(29, 11, lv(() -> Arsenal.SPHERE_EPIC, 0, 0, 0, 2, 0));
        e(30, 16, lv(() -> Arsenal.SPHERE_EPIC, 0, 1, 1, 0, 0));
        e(31, 14, lv(() -> Arsenal.SPHERE_EPIC, 0, 0, 2, 0, 0));
        e(32, 14, lv(() -> Arsenal.SPHERE_EPIC, 0, 2, 0, 0, 0));
        // обычные
        e(39, 7, lv(() -> Arsenal.SPHERE_COMMON, 0, 1, 0, 0, 0));
        e(40, 7, lv(() -> Arsenal.SPHERE_COMMON, 0, 0, 1, 0, 0));
        e(41, 7, lv(() -> Arsenal.SPHERE_COMMON, 1, 0, 0, 0, 0));
    }

    private static final class SpheresPage implements CreateMenu.Page {
        @Override
        public String title() {
            return "Сферомант";
        }

        @Override
        public boolean editable(int slot) {
            return false;
        }

        @Override
        public void fill(ServerPlayerEntity p, SimpleInventory inv) {
            for (int i = 0; i < CreateMenu.SIZE; i++) {
                inv.setStack(i, ItemStack.EMPTY);
            }
            for (Entry en : ENTRIES) {
                ItemStack s = en.item.get();
                s.setCount(1);
                List<Text> lore = new ArrayList<>();
                lore.add(CreateMenu.plain(" ", Formatting.WHITE));
                lore.add(CreateMenu.plain("► ", Formatting.GOLD)
                        .append(CreateMenu.plain("Купить за ", Formatting.WHITE))
                        .append(CreateMenu.plain(en.price + " осколков сфер", Formatting.LIGHT_PURPLE)));
                CreateMenu.addLore(s, lore);
                inv.setStack(en.slot, s);
            }
        }

        @Override
        public void click(ServerPlayerEntity p, int slot, SimpleInventory inv) {
            for (Entry en : ENTRIES) {
                if (en.slot != slot) {
                    continue;
                }
                int have = count(p.inventory);
                if (have < en.price) {
                    CreateMenu.msg(p, "Не хватает осколков сфер: нужно " + en.price + ", у вас " + have + ".", Formatting.RED);
                    return;
                }
                take(p.inventory, en.price);
                p.inventory.offerOrDrop(p.world, en.item.get());
                CreateMenu.msg(p, "Куплено за " + en.price + " осколков сфер.", Formatting.GREEN);
                return;
            }
        }
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("spheres").executes(ctx -> {
                    CreateMenu.open(ctx.getSource().getPlayer(), new SpheresPage());
                    return 1;
                })));
    }
}
