package com.arsenal.create;

import com.arsenal.Arsenal;
import com.arsenal.item.SunGear;
import com.arsenal.kit.KitCommand;
import com.arsenal.vi.VI;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Все рецепты улучшения: "вещь, которую отдаю" -> "вещь, которую получаю", шансы по количеству вложенных вещей и цена в БФ.
 * Вещи описываются ключами: kit:КИТ:ЧАСТЬ, kit:sun_helmet и т.п., vi:ID, elytra, item:minecraft:...
 */
public final class Upgrades {
    private Upgrades() {
    }

    public enum Cat {
        GEAR("Снаряжение"), TOOLS("Инструменты"), ARMOR("Броня"), UNIQUE("Уникальные предметы"),
        PEACE("Яйца призыва мирных мобов"), HOSTILE("Яйца призыва враждебных мобов");

        public final String title;

        Cat(String title) {
            this.title = title;
        }
    }

    public static final class Recipe {
        public final String from;
        public final String to;
        public final double[] chances;
        public final int cost;
        public final Cat cat;

        Recipe(String from, String to, double[] chances, int cost, Cat cat) {
            this.from = from;
            this.to = to;
            this.chances = chances;
            this.cost = cost;
            this.cat = cat;
        }

        /** Шанс в процентах, если вложено count вещей. */
        public double chance(int count) {
            return chances[Math.min(Math.max(count, 1), chances.length) - 1];
        }

        public int maxCount() {
            return chances.length;
        }
    }

    /** Терять ли вложенные вещи при неудаче (БФ теряются всегда). */
    public static boolean LOSE_ITEMS_ON_FAIL = true;

    public static final String[] ALL_PARTS = {"sword", "trident", "bow", "crossbow", "pickaxe", "axe", "shovel",
            "helmet", "chestplate", "leggings", "boots"};

    private static final double[] T1 = {50, 97, 100};
    private static final double[] T2 = {33, 64, 95, 100};
    private static final double[] T3 = {20, 39, 58, 77, 96};
    private static final double[] T4 = {15, 29.3, 43.5, 58.7, 72};
    private static final double[] T5 = {40, 78, 100};
    private static final double[] CERBERUS = {10, 19.5, 29, 38.5, 48};
    private static final double[] GHAST_EGG = {25, 48, 72, 96, 100};
    private static final double[] RESIST_TO_WAVE = T3;
    private static final double[] WAVE_TO_RESIST = {1, 2, 2.9, 3.8, 4.8};
    private static final double[] DREAM = {5, 9.8, 14.5, 19.3, 24};

    private static final String[] KITS = {"griefer", "mustang", "ghast", "wither", "kraken", "dragon", "stinger", "eternity", "infinity"};

    private static final List<Recipe> ALL = new ArrayList<>();
    private static final Map<String, Recipe> BY_FROM = new HashMap<>();
    private static final Map<String, Recipe> BY_TO = new HashMap<>();
    private static boolean built = false;

    private static void add(String from, String to, double[] ch, int cost, Cat cat) {
        Recipe r = new Recipe(from, to, ch, cost, cat);
        ALL.add(r);
        BY_FROM.put(from, r);
        BY_TO.put(to, r);
    }

    private static synchronized void build() {
        if (built) {
            return;
        }
        built = true;
        for (Cat cat : new Cat[]{Cat.GEAR, Cat.TOOLS, Cat.ARMOR}) {
            String[] parts = cat == Cat.GEAR ? new String[]{"sword", "trident", "bow", "crossbow"}
                    : cat == Cat.TOOLS ? new String[]{"pickaxe", "axe", "shovel"}
                    : new String[]{"helmet", "chestplate", "leggings", "boots"};
            for (String part : parts) {
                String prev = null;
                for (String kit : KITS) {
                    if (cat == Cat.ARMOR && kit.equals("griefer")) {
                        continue;
                    }
                    if (KitCommand.lootGear(kit, part) == null) {
                        continue;
                    }
                    if (prev != null) {
                        boolean infinity = kit.equals("infinity");
                        double[] ch = infinity ? T4 : kit.equals("eternity") ? T3
                                : kit.equals("kraken") || kit.equals("dragon") || kit.equals("stinger") ? T2 : T1;
                        int cost = infinity ? (cat == Cat.ARMOR ? 3 : 4) : kit.equals("eternity") ? 3
                                : kit.equals("kraken") || kit.equals("dragon") || kit.equals("stinger") ? 2 : 1;
                        add("kit:" + prev + ":" + part, "kit:" + kit + ":" + part, ch, cost, cat);
                    }
                    prev = kit;
                }
                if (part.equals("sword")) {
                    add("kit:infinity:sword", "vi:cerberus_sword", CERBERUS, 6, Cat.GEAR);
                }
            }
        }

        // уникальные предметы
        add("vi:keeper_blast_resistance", "vi:burst_wave", RESIST_TO_WAVE, 3, Cat.UNIQUE);
        add("vi:burst_wave", "vi:keeper_blast_resistance", WAVE_TO_RESIST, 1, Cat.UNIQUE);
        add("vi:miner_dream_unbreakable", "vi:miner_dream", DREAM, 4, Cat.UNIQUE);
        add("vi:talisman_stinger", "vi:talisman_eternity", T2, 2, Cat.UNIQUE);
        add("vi:talisman_eternity", "vi:talisman_infinity", T2, 3, Cat.UNIQUE);
        add("elytra", "kit:sun_armor_elytra", T2, 2, Cat.UNIQUE);
        add("kit:sun_armor_elytra", "kit:sun_unbreakable_elytra", T3, 3, Cat.UNIQUE);
        add("kit:infinity:helmet", "kit:sun_helmet", T4, 3, Cat.UNIQUE);

        // яйца мирных мобов
        String[] peace = {"chicken", "pig", "cow", "turtle"};
        for (int i = 1; i < peace.length; i++) {
            add(egg(peace[i - 1]), egg(peace[i]), T1, 1, Cat.PEACE);
        }
        // яйца враждебных мобов
        String[] hostile = {"turtle", "cave_spider", "zombie", "skeleton", "enderman", "piglin", "hoglin", "wither_skeleton",
                "pillager", "vindicator", "slime", "blaze", "magma_cube", "evoker", "piglin_brute", "ghast"};
        for (int i = 1; i < hostile.length; i++) {
            double[] ch;
            int cost;
            if (hostile[i].equals("ghast")) {
                ch = GHAST_EGG;
                cost = 2;
            } else if (i >= 8) {
                ch = T5;
                cost = 1;
            } else {
                ch = T1;
                cost = 1;
            }
            add(egg(hostile[i - 1]), egg(hostile[i]), ch, cost, Cat.HOSTILE);
        }
    }

    private static String egg(String mob) {
        return "item:minecraft:" + mob + "_spawn_egg";
    }

    public static Recipe byFrom(String key) {
        build();
        return BY_FROM.get(key);
    }

    public static Recipe byTo(String key) {
        build();
        return BY_TO.get(key);
    }

    /** Все вещи категории по порядку цепочек (и те, что только ингредиенты, и те, что результат). */
    public static List<String> nodes(Cat cat) {
        build();
        Set<String> set = new LinkedHashSet<>();
        for (Recipe r : ALL) {
            if (r.cat == cat) {
                set.add(r.from);
                set.add(r.to);
            }
        }
        return new ArrayList<>(set);
    }

    /** Рецепт, по которому эта вещь создаётся внутри категории (null = создать нельзя). */
    public static Recipe creating(Cat cat, String key) {
        build();
        Recipe r = BY_TO.get(key);
        return r != null && r.cat == cat ? r : null;
    }

    public static String partOf(ItemStack s) {
        for (String part : ALL_PARTS) {
            if (KitCommand.isPart(s.getItem(), part)) {
                return part;
            }
        }
        return null;
    }

    public static String keyOf(ItemStack s) {
        if (s == null || s.isEmpty()) {
            return null;
        }
        String kit = KitCommand.kitOf(s);
        if (kit != null) {
            if (kit.startsWith("sun_")) {
                return "kit:" + kit;
            }
            String part = partOf(s);
            if (part != null) {
                return "kit:" + kit + ":" + part;
            }
        }
        VI vi = VI.of(s);
        if (vi != null) {
            return "vi:" + vi.id;
        }
        if (s.getItem() == Items.ELYTRA) {
            return "elytra";
        }
        if (s.getItem() instanceof SpawnEggItem) {
            return "item:" + Registry.ITEM.getId(s.getItem());
        }
        return null;
    }

    public static ItemStack stackOf(String key) {
        if (key == null) {
            return null;
        }
        if (key.equals("elytra")) {
            return new ItemStack(Items.ELYTRA);
        }
        if (key.startsWith("item:")) {
            return new ItemStack(Registry.ITEM.get(new Identifier(key.substring(5))));
        }
        if (key.startsWith("vi:")) {
            VI vi = VI.byId(key.substring(3));
            if (vi == null) {
                return null;
            }
            ItemStack preset = Arsenal.preset(vi);
            return preset != null ? preset : vi.stack();
        }
        if (key.startsWith("kit:")) {
            String[] k = key.split(":");
            if (k.length == 2) {
                switch (k[1]) {
                    case "sun_helmet": return SunGear.helmet();
                    case "sun_armor_elytra": return SunGear.armorElytra();
                    case "sun_unbreakable_elytra": return SunGear.unbreakableElytra();
                    default: return null;
                }
            }
            return KitCommand.lootGear(k[1], k[2]);
        }
        return null;
    }
}
