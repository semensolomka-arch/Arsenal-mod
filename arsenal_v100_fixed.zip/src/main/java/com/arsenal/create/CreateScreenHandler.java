package com.arsenal.create;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

/** Сундук 9x6 для меню /create: все слоты это кнопки, кроме тех, что страница объявила редактируемыми. */
public class CreateScreenHandler extends GenericContainerScreenHandler {
    private final CreateMenu.Page page;
    private final CreateMenu.PageInventory inv;

    public CreateScreenHandler(int syncId, PlayerInventory playerInventory, CreateMenu.PageInventory inv, CreateMenu.Page page) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, inv, 6);
        this.inv = inv;
        this.page = page;
    }

    /** Полная пересылка меню и курсора: клиент после клика по кнопке не должен "залипать" с предметом в руке. */
    private void resync(ServerPlayerEntity sp) {
        sp.networkHandler.sendPacket(new InventoryS2CPacket(this.syncId, this.getStacks()));
        sp.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(-1, -1, sp.inventory.getCursorStack()));
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        boolean server = player instanceof ServerPlayerEntity;
        if (slotIndex >= 0 && slotIndex < CreateMenu.SIZE && !page.editable(slotIndex)) {
            // возвращаем то, что клиент и сам ожидает от клика (содержимое слота), иначе сервер считает действие
            // отклонённым и на время перестаёт обновлять меню
            ItemStack before = this.slots.get(slotIndex).getStack().copy();
            if (server) {
                ServerPlayerEntity sp = (ServerPlayerEntity) player;
                if (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE) {
                    page.click(sp, slotIndex, inv);
                }
                if (sp.currentScreenHandler == this) {
                    resync(sp);
                }
            }
            return before;
        }
        if (actionType == SlotActionType.QUICK_CRAFT || actionType == SlotActionType.PICKUP_ALL) {
            if (server && ((ServerPlayerEntity) player).currentScreenHandler == this) {
                resync((ServerPlayerEntity) player);
            }
            return ItemStack.EMPTY;
        }
        ItemStack result = super.onSlotClick(slotIndex, clickData, actionType, player);
        if (server) {
            page.fill((ServerPlayerEntity) player, inv);
            resync((ServerPlayerEntity) player);
        }
        return result;
    }

    @Override
    public ItemStack transferSlot(PlayerEntity player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasStack()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getStack();
        ItemStack copy = stack.copy();
        if (index < CreateMenu.SIZE) {
            if (!page.editable(index) || !this.insertItem(stack, CreateMenu.SIZE, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else {
            boolean moved = false;
            for (int i = 0; i < CreateMenu.SIZE && !moved; i++) {
                if (page.editable(i) && !this.slots.get(i).hasStack()) {
                    this.slots.get(i).setStack(stack.copy());
                    stack.setCount(0);
                    moved = true;
                }
            }
            if (!moved) {
                return ItemStack.EMPTY;
            }
        }
        if (stack.isEmpty()) {
            slot.setStack(ItemStack.EMPTY);
        } else {
            slot.markDirty();
        }
        if (player instanceof ServerPlayerEntity) {
            page.fill((ServerPlayerEntity) player, inv);
            resync((ServerPlayerEntity) player);
        }
        return copy;
    }
}
