package com.arsenal.create;

import com.arsenal.Arsenal;
import com.arsenal.kit.KitCommand;
import com.arsenal.vi.VI;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.recipe.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.AbstractCookingRecipe;
import net.minecraft.recipe.BlastingRecipe;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Боевые фрагменты (БФ): сколько даёт переплавка вещи и учёт БФ в инвентаре. */
public final class BattleFragments {
    private BattleFragments() {
    }

    /** Сколько БФ даёт переплавка этого предмета (0 = не переплавляется). */
    public static int reward(ItemStack s) {
        if (s == null || s.isEmpty()) {
            return 0;
        }
        String kit = KitCommand.kitOf(s);
        if (s.getItem() instanceof ArmorItem && kit != null) {
            switch (kit) {
                case "wither":
                case "kraken":
                    return 1;
                case "dragon":
                    return 2;
                case "stinger":
                    return 3;
                case "eternity":
                    return 5;
                case "infinity":
                    return 8;
                default:
                    return 0;
            }
        }
        if (s.getItem() == Items.ELYTRA) {
            return "sun_armor_elytra".equals(kit) ? 5 : 3;
        }
        return 0;
    }

    public static boolean isBf(ItemStack s) {
        return !s.isEmpty() && VI.of(s) == Arsenal.BF;
    }

    public static int count(PlayerInventory inv) {
        int n = 0;
        for (ItemStack s : all(inv)) {
            if (isBf(s)) {
                n += s.getCount();
            }
        }
        return n;
    }

    public static boolean take(PlayerInventory inv, int amount) {
        if (count(inv) < amount) {
            return false;
        }
        int left = amount;
        for (ItemStack s : all(inv)) {
            if (left > 0 && isBf(s)) {
                int d = Math.min(left, s.getCount());
                s.decrement(d);
                left -= d;
            }
        }
        return true;
    }

    private static List<ItemStack> all(PlayerInventory inv) {
        List<ItemStack> list = new ArrayList<>(inv.main);
        list.addAll(inv.offHand);
        return list;
    }

    /** Рецепт переплавки для печи (подставляется в RecipeManagerMixin). */
    public static AbstractCookingRecipe recipe(ItemStack input, RecipeType<?> type) {
        int n = reward(input);
        if (n <= 0) {
            return null;
        }
        ItemStack out = Arsenal.BF.stack();
        out.setCount(n);
        Identifier id = new Identifier("arsenal", "bf_smelt");
        Ingredient ing = Ingredient.ofItems(input.getItem());
        if (type == RecipeType.BLASTING) {
            return new BlastingRecipe(id, "", ing, out, 0.0F, 100);
        }
        return new SmeltingRecipe(id, "", ing, out, 0.0F, 200);
    }
}
