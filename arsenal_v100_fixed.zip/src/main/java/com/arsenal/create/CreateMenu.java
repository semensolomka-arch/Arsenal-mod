package com.arsenal.create;

import com.arsenal.kit.KitCommand;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Меню /create: улучшение вещей из китов за боевые фрагменты (БФ).
 * Страницы: создание (положи вещи, нажми на зелёную панель), список категорий, список вещей категории, ингредиент.
 */
public final class CreateMenu {
    public static final int SIZE = 54;
    private static final Random RANDOM = new Random();

    private CreateMenu() {
    }

    public interface Page {
        String title();

        boolean editable(int slot);

        /** Перерисовать все нередактируемые слоты. */
        void fill(ServerPlayerEntity p, SimpleInventory inv);

        void click(ServerPlayerEntity p, int slot, SimpleInventory inv);
    }

    public static final class PageInventory extends SimpleInventory {
        Page page;

        PageInventory() {
            super(SIZE);
        }

        @Override
        public void onClose(PlayerEntity player) {
            for (int i = 0; i < size(); i++) {
                if (page != null && page.editable(i)) {
                    ItemStack s = getStack(i);
                    if (!s.isEmpty()) {
                        setStack(i, ItemStack.EMPTY);
                        player.inventory.offerOrDrop(player.world, s);
                    }
                }
            }
        }
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("create").executes(ctx -> {
                    open(ctx.getSource().getPlayer(), new CraftPage());
                    return 1;
                })));
    }

    static void open(ServerPlayerEntity player, Page page) {
        PageInventory inv = new PageInventory();
        inv.page = page;
        page.fill(player, inv);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new CreateScreenHandler(syncId, playerInventory, inv, page),
                new LiteralText(page.title())));
    }

    // ---------------------------------------------------------------- помощники оформления

    static MutableText plain(String s, Formatting f) {
        return new LiteralText(s).formatted(f).styled(st -> st.withItalic(false));
    }

    /** Строка с синей полоской слева: "▌ текст" (части с * подсвечиваются голубым). */
    static MutableText bar(String... parts) {
        MutableText t = plain("▌ ", Formatting.AQUA);
        for (String p : parts) {
            if (p.startsWith("*")) {
                t.append(plain(p.substring(1), Formatting.AQUA));
            } else {
                t.append(plain(p, Formatting.WHITE));
            }
        }
        return t;
    }

    static MutableText arrow(String text) {
        return plain("► ", Formatting.AQUA).append(plain(text, Formatting.WHITE));
    }

    static void addLore(ItemStack stack, List<Text> lines) {
        NbtCompound display = stack.getOrCreateSubTag("display");
        NbtList list = display.contains("Lore", 9) ? display.getList("Lore", 8) : new NbtList();
        for (Text line : lines) {
            list.add(NbtString.of(Text.Serializer.toJson(line)));
        }
        display.put("Lore", list);
    }

    static ItemStack button(Item item, Text name, List<Text> lore) {
        ItemStack s = new ItemStack(item);
        s.setCustomName(name);
        addLore(s, lore);
        return s;
    }

    static ItemStack pane(Item item) {
        ItemStack s = new ItemStack(item);
        s.setCustomName(plain(" ", Formatting.WHITE));
        return s;
    }

    static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(new LiteralText(text).formatted(color), false);
    }

    static void backButton(SimpleInventory inv, int slot) {
        inv.setStack(slot, button(Items.ARROW, plain("Назад", Formatting.YELLOW), new ArrayList<>()));
    }

    static String partName(String part) {
        switch (part) {
            case "sword": return "Меч";
            case "trident": return "Трезубец";
            case "bow": return "Лук";
            case "crossbow": return "Арбалет";
            case "pickaxe": return "Кирка";
            case "axe": return "Топор";
            case "shovel": return "Лопата";
            case "helmet": return "Шлем";
            case "chestplate": return "Нагрудник";
            case "leggings": return "Поножи";
            case "boots": return "Ботинки";
            default: return part;
        }
    }

    static String pct(double v) {
        return (Math.round(v * 10.0) / 10.0) + "%";
    }

    // ---------------------------------------------------------------- страница создания

    static final class CraftPage implements Page {
        static final int PREVIEW = 15;
        static final int INDICATOR = 24;
        static final int INFO = 33;
        static final int HELP = 45;
        static final int LIST = 49;

        static boolean ingredient(int s) {
            int r = s / 9;
            int c = s % 9;
            return r >= 1 && r <= 4 && c >= 1 && c <= 5;
        }

        @Override
        public String title() {
            return "Улучшение";
        }

        @Override
        public boolean editable(int slot) {
            return ingredient(slot);
        }

        /** Результат разбора вложенных вещей. */
        static final class Eval {
            String error;          // null и valid=false: ничего не положено
            boolean valid;
            String key;
            Upgrades.Recipe recipe;
            int count;
        }

        static Eval eval(SimpleInventory inv) {
            Eval e = new Eval();
            for (int i = 0; i < SIZE; i++) {
                if (!ingredient(i)) {
                    continue;
                }
                ItemStack s = inv.getStack(i);
                if (s.isEmpty()) {
                    continue;
                }
                String key = Upgrades.keyOf(s);
                if (key == null || Upgrades.byFrom(key) == null) {
                    e.error = "Эту вещь нельзя улучшить";
                    return e;
                }
                if (e.key == null) {
                    e.key = key;
                } else if (!e.key.equals(key)) {
                    e.error = "Все вещи должны быть одинаковыми";
                    return e;
                }
                e.count += s.getCount();
            }
            if (e.key == null) {
                return e;
            }
            e.recipe = Upgrades.byFrom(e.key);
            if (e.count > e.recipe.maxCount()) {
                e.error = "Слишком много вещей: максимум " + e.recipe.maxCount();
                return e;
            }
            e.valid = true;
            return e;
        }

        @Override
        public void fill(ServerPlayerEntity p, SimpleInventory inv) {
            for (int i = 0; i < SIZE; i++) {
                if (ingredient(i)) {
                    continue;
                }
                int r = i / 9;
                int c = i % 9;
                Item item = c == 0 || c == 8 ? Items.LIGHT_BLUE_STAINED_GLASS_PANE
                        : r == 0 || r == 5 ? Items.ORANGE_STAINED_GLASS_PANE : Items.GRAY_STAINED_GLASS_PANE;
                inv.setStack(i, pane(item));
            }
            List<Text> help = new ArrayList<>();
            help.add(plain(" ", Formatting.WHITE));
            help.add(bar("1. Поместите предмет в слот;"));
            help.add(bar("2. Добавьте предметы для ", "*повышения", " шанса;"));
            help.add(bar("3. Проверьте цену в ", "*боевых фрагментах", ";"));
            help.add(bar("4. Нажмите на ", "*зелёную панель", " для создания."));
            inv.setStack(HELP, button(Items.BOOK, plain("Как работают улучшения:", Formatting.AQUA), help));
            List<Text> list = new ArrayList<>();
            list.add(arrow("Нажмите, чтобы открыть список"));
            inv.setStack(LIST, button(Items.PAPER, plain("❏ Список рецептов ❏", Formatting.AQUA), list));

            Eval e = eval(inv);
            if (!e.valid) {
                List<Text> lore = new ArrayList<>();
                lore.add(plain(" ", Formatting.WHITE));
                lore.add(arrow(e.error != null ? e.error : "Начните выкладывать ингредиенты"));
                inv.setStack(INDICATOR, button(Items.RED_STAINED_GLASS_PANE,
                        plain(e.error != null ? "✘ Создать нельзя" : "✘ Вы ещё ничего не создаёте", Formatting.RED), lore));
                inv.setStack(PREVIEW, pane(Items.GRAY_STAINED_GLASS_PANE));
                inv.setStack(INFO, pane(Items.GRAY_STAINED_GLASS_PANE));
                return;
            }
            int cost = e.recipe.cost;
            double chance = e.recipe.chance(e.count);
            int have = BattleFragments.count(p.inventory);
            ItemStack preview = Upgrades.stackOf(e.recipe.to);
            List<Text> pl = new ArrayList<>();
            pl.add(plain(" ", Formatting.WHITE));
            pl.add(bar("Шанс создания: ", "*" + pct(chance)));
            addLore(preview, pl);
            inv.setStack(PREVIEW, preview);

            List<Text> lore = new ArrayList<>();
            lore.add(plain(" ", Formatting.WHITE));
            lore.add(bar("Шанс: ", "*" + pct(chance)));
            lore.add(bar("Цена попытки: ", "*" + cost + " БФ"));
            lore.add(bar("У вас: ", (have >= cost ? "" : "") + have + " БФ"));
            lore.add(plain(" ", Formatting.WHITE));
            lore.add(arrow("Нажмите, чтобы создать"));
            inv.setStack(INDICATOR, button(Items.LIME_STAINED_GLASS_PANE, plain("✔ Создать", Formatting.GREEN), lore));

            ItemStack info = new ItemStack(Items.PRISMARINE_CRYSTALS);
            info.setCustomName(plain("Цена: " + cost + " БФ", Formatting.AQUA));
            List<Text> il = new ArrayList<>();
            il.add(plain("БФ забираются при каждой попытке", Formatting.GRAY));
            addLore(info, il);
            inv.setStack(INFO, info);
        }

        @Override
        public void click(ServerPlayerEntity p, int slot, SimpleInventory inv) {
            if (slot == LIST) {
                open(p, new CategoriesPage());
                return;
            }
            if (slot != INDICATOR) {
                return;
            }
            Eval e = eval(inv);
            if (!e.valid) {
                return;
            }
            int cost = e.recipe.cost;
            if (!BattleFragments.take(p.inventory, cost)) {
                msg(p, "Не хватает боевых фрагментов: нужно " + cost, Formatting.RED);
                return;
            }
            boolean ok = RANDOM.nextDouble() * 100.0 < e.recipe.chance(e.count);
            if (ok || Upgrades.LOSE_ITEMS_ON_FAIL) {
                for (int i = 0; i < SIZE; i++) {
                    if (ingredient(i)) {
                        inv.setStack(i, ItemStack.EMPTY);
                    }
                }
            }
            if (ok) {
                ItemStack made = Upgrades.stackOf(e.recipe.to);
                p.inventory.offerOrDrop(p.world, made);
                msg(p, "Успех! Вы создали: " + made.getName().getString(), Formatting.GREEN);
                p.world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
            } else {
                msg(p, "Неудача! Создать вещь не получилось.", Formatting.RED);
                p.world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ITEM_BREAK, SoundCategory.PLAYERS, 1.0F, 1.0F);
            }
            fill(p, inv);
        }
    }

    // ---------------------------------------------------------------- категории

    static final class CatInfo {
        final int slot;
        final Item icon;
        final String title;
        final String[] desc;
        final Upgrades.Cat cat;   // null = скоро

        CatInfo(int slot, Item icon, String title, Upgrades.Cat cat, String... desc) {
            this.slot = slot;
            this.icon = icon;
            this.title = title;
            this.cat = cat;
            this.desc = desc;
        }
    }

    static final CatInfo[] CATS = {
            new CatInfo(11, Items.NETHERITE_SWORD, "Снаряжение", Upgrades.Cat.GEAR,
                    "для создания ", "*мечей", ", ", "*луков", " и ", "*арбалетов", "."),
            new CatInfo(13, Items.NETHERITE_PICKAXE, "Инструменты", Upgrades.Cat.TOOLS,
                    "для создания ", "*топоров", ", ", "*кирок", " и ", "*лопат", "."),
            new CatInfo(15, Items.DIAMOND_SWORD, "Фармер", null,
                    "для создания ", "*меча на Фармер", " с 3 по 13 уровни."),
            new CatInfo(20, Items.NETHERITE_CHESTPLATE, "Броня", Upgrades.Cat.ARMOR,
                    "для создания ", "*брони", "."),
            new CatInfo(24, Items.ENCHANTED_BOOK, "Фермер", null,
                    "для создания ", "*Фермер", " с 3 по 5 уровни."),
            new CatInfo(31, Items.TNT, "Уникальные предметы", Upgrades.Cat.UNIQUE,
                    "для создания ", "*Уникальных предметов", "."),
            new CatInfo(38, Items.PIG_SPAWN_EGG, "Яйца призыва мирных мобов", Upgrades.Cat.PEACE,
                    "для создания ", "*яиц призыва мирных мобов", "."),
            new CatInfo(40, Items.ZOMBIE_SPAWN_EGG, "Яйца призыва враждебных мобов", Upgrades.Cat.HOSTILE,
                    "для создания ", "*яиц призыва враждебных мобов", "."),
            new CatInfo(42, Items.WITCH_SPAWN_EGG, "Загадочные яйца", null,
                    "для создания ", "*Загадочных яиц", ".")};

    static final class CategoriesPage implements Page {
        @Override
        public String title() {
            return "Выбор категории рецептов";
        }

        @Override
        public boolean editable(int slot) {
            return false;
        }

        @Override
        public void fill(ServerPlayerEntity p, SimpleInventory inv) {
            for (int i = 0; i < SIZE; i++) {
                int r = i / 9;
                int c = i % 9;
                inv.setStack(i, pane(r >= 1 && r <= 4 && (c == 0 || c == 8)
                        ? Items.ORANGE_STAINED_GLASS_PANE : Items.GRAY_STAINED_GLASS_PANE));
            }
            for (CatInfo ci : CATS) {
                List<Text> lore = new ArrayList<>();
                lore.add(plain(" ", Formatting.WHITE));
                lore.add(bar("В данной категории показаны ингредиенты"));
                lore.add(bar(ci.desc));
                lore.add(plain(" ", Formatting.WHITE));
                lore.add(arrow(ci.cat == null ? "Скоро..." : "Нажмите, чтобы открыть категорию"));
                inv.setStack(ci.slot, button(ci.icon, plain("❏ Категория: ", Formatting.WHITE)
                        .append(plain(ci.title, Formatting.AQUA)).append(plain(" ❏", Formatting.WHITE)), lore));
            }
            backButton(inv, 52);
        }

        @Override
        public void click(ServerPlayerEntity p, int slot, SimpleInventory inv) {
            if (slot == 52) {
                open(p, new CraftPage());
                return;
            }
            for (CatInfo ci : CATS) {
                if (ci.slot == slot) {
                    if (ci.cat == null) {
                        msg(p, "Скоро...", Formatting.YELLOW);
                    } else {
                        open(p, new ListPage(ci.cat, 0));
                    }
                    return;
                }
            }
        }
    }

    // ---------------------------------------------------------------- список вещей категории

    static final class ListPage implements Page {
        static final int PER_PAGE = 28;
        private final Upgrades.Cat cat;
        private final int page;
        private final List<String> nodes;

        ListPage(Upgrades.Cat cat, int page) {
            this.cat = cat;
            this.page = page;
            this.nodes = Upgrades.nodes(cat);
        }

        private int pages() {
            return Math.max(1, (nodes.size() + PER_PAGE - 1) / PER_PAGE);
        }

        private static int slotOf(int i) {
            return (1 + i / 7) * 9 + 1 + i % 7;
        }

        @Override
        public String title() {
            return "Категория: " + cat.title;
        }

        @Override
        public boolean editable(int slot) {
            return false;
        }

        @Override
        public void fill(ServerPlayerEntity p, SimpleInventory inv) {
            for (int i = 0; i < SIZE; i++) {
                int r = i / 9;
                int c = i % 9;
                inv.setStack(i, pane(r >= 1 && r <= 4 && (c == 0 || c == 8)
                        ? Items.ORANGE_STAINED_GLASS_PANE : Items.GRAY_STAINED_GLASS_PANE));
            }
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx >= nodes.size()) {
                    break;
                }
                String key = nodes.get(idx);
                ItemStack s = Upgrades.stackOf(key);
                if (s == null) {
                    continue;
                }
                List<Text> lore = new ArrayList<>();
                lore.add(plain(" ", Formatting.WHITE));
                if (Upgrades.creating(cat, key) != null) {
                    lore.add(arrow("Нажмите, чтобы посмотреть ингредиенты"));
                } else {
                    lore.add(plain("✘ Эту вещь нельзя создать", Formatting.RED));
                }
                addLore(s, lore);
                inv.setStack(slotOf(i), s);
            }
            if (page > 0) {
                inv.setStack(45, button(Items.GRAY_DYE, plain("Назад: страница " + page, Formatting.GRAY), new ArrayList<>()));
            }
            if (page + 1 < pages()) {
                inv.setStack(53, button(Items.LIME_DYE, plain("Вперёд: страница " + (page + 2), Formatting.GREEN), new ArrayList<>()));
            }
            backButton(inv, 52);
        }

        @Override
        public void click(ServerPlayerEntity p, int slot, SimpleInventory inv) {
            if (slot == 52) {
                open(p, new CategoriesPage());
                return;
            }
            if (slot == 45 && page > 0) {
                open(p, new ListPage(cat, page - 1));
                return;
            }
            if (slot == 53 && page + 1 < pages()) {
                open(p, new ListPage(cat, page + 1));
                return;
            }
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx < nodes.size() && slotOf(i) == slot) {
                    Upgrades.Recipe r = Upgrades.creating(cat, nodes.get(idx));
                    if (r == null) {
                        msg(p, "Эту вещь нельзя создать.", Formatting.RED);
                    } else {
                        open(p, new RecipePage(cat, page, r));
                    }
                    return;
                }
            }
        }
    }

    // ---------------------------------------------------------------- ингредиент

    static final class RecipePage implements Page {
        private final Upgrades.Cat cat;
        private final int listPage;
        private final Upgrades.Recipe recipe;

        RecipePage(Upgrades.Cat cat, int listPage, Upgrades.Recipe recipe) {
            this.cat = cat;
            this.listPage = listPage;
            this.recipe = recipe;
        }

        @Override
        public String title() {
            return "Необходимый ингредиент";
        }

        @Override
        public boolean editable(int slot) {
            return false;
        }

        @Override
        public void fill(ServerPlayerEntity p, SimpleInventory inv) {
            for (int i = 0; i < SIZE; i++) {
                int r = i / 9;
                int c = i % 9;
                boolean ring = r >= 1 && r <= 3 && c >= 3 && c <= 5;
                inv.setStack(i, pane(ring ? Items.ORANGE_STAINED_GLASS_PANE : Items.GRAY_STAINED_GLASS_PANE));
            }
            ItemStack ing = Upgrades.stackOf(recipe.from);
            if (ing != null) {
                List<Text> lore = new ArrayList<>();
                lore.add(plain(" ", Formatting.WHITE));
                lore.add(plain("Шансы при использовании:", Formatting.WHITE));
                for (int n = 1; n <= recipe.maxCount(); n++) {
                    lore.add(plain("• ", Formatting.GREEN).append(plain(n + " ед. - ", Formatting.WHITE))
                            .append(plain(pct(recipe.chance(n)), Formatting.GREEN)));
                }
                lore.add(plain(" ", Formatting.WHITE));
                lore.add(bar("Цена попытки: ", "*" + recipe.cost + " БФ"));
                addLore(ing, lore);
                inv.setStack(22, ing);
            }
            ItemStack result = Upgrades.stackOf(recipe.to);
            if (result != null) {
                List<Text> lore = new ArrayList<>();
                lore.add(plain(" ", Formatting.WHITE));
                lore.add(plain("Результат создания", Formatting.GRAY));
                addLore(result, lore);
                inv.setStack(40, result);
            }
            backButton(inv, 52);
        }

        @Override
        public void click(ServerPlayerEntity p, int slot, SimpleInventory inv) {
            if (slot == 52) {
                open(p, new ListPage(cat, listPage));
            }
        }
    }
}
