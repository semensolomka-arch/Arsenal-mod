package com.arsenal.create;

import com.arsenal.Arsenal;
import com.arsenal.vi.VI;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Хранитель яиц (/eggkeeper): осколочные яйца обмениваются на случайные яйца призыва. */
public final class EggKeeper {
    private static final Random RNG = new Random();

    private EggKeeper() {
    }

    private static final class Mob {
        final String name;
        final Item egg;
        final int weight;
        final Formatting color;

        Mob(String name, Item egg, int weight, Formatting color) {
            this.name = name;
            this.egg = egg;
            this.weight = weight;
            this.color = color;
        }
    }

    private static Mob m(String name, Item egg) {
        return new Mob(name, egg, 10, Formatting.WHITE);
    }

    private static final class Tier {
        final int slot;
        final int price;
        final Mob[][] rows;

        Tier(int slot, int price, Mob[][] rows) {
            this.slot = slot;
            this.price = price;
            this.rows = rows;
        }

        List<Mob> all() {
            List<Mob> l = new ArrayList<>();
            for (Mob[] r : rows) {
                for (Mob x : r) {
                    l.add(x);
                }
            }
            return l;
        }
    }

    private static final Mob SLIME = new Mob("Слайм", Items.SLIME_SPAWN_EGG, 5, Formatting.GREEN);
    private static final Mob PHANTOM = new Mob("Фантом", Items.PHANTOM_SPAWN_EGG, 4, Formatting.BLUE);
    private static final Mob BRUTE = new Mob("Брутальный пиглин", Items.PIGLIN_BRUTE_SPAWN_EGG, 1, Formatting.YELLOW);

    private static final List<Tier> TIERS = new ArrayList<>();

    static {
        TIERS.add(new Tier(21, 16, new Mob[][]{
                {m("Пчела", Items.BEE_SPAWN_EGG), m("Векс", Items.VEX_SPAWN_EGG), SLIME, m("Лама", Items.LLAMA_SPAWN_EGG)},
                {m("Корова", Items.COW_SPAWN_EGG), m("Свинья", Items.PIG_SPAWN_EGG), m("Паук", Items.SPIDER_SPAWN_EGG), m("Зомби", Items.ZOMBIE_SPAWN_EGG)},
                {m("Хоглин", Items.HOGLIN_SPAWN_EGG), m("Панда", Items.PANDA_SPAWN_EGG), m("Пиглин", Items.PIGLIN_SPAWN_EGG), m("Скелет", Items.SKELETON_SPAWN_EGG)},
                {PHANTOM, m("Лошадь", Items.HORSE_SPAWN_EGG), m("Черепаха", Items.TURTLE_SPAWN_EGG), m("Житель", Items.VILLAGER_SPAWN_EGG)},
                {m("Эндермен", Items.ENDERMAN_SPAWN_EGG), m("Утопленник", Items.DROWNED_SPAWN_EGG), m("Пещерный паук", Items.CAVE_SPIDER_SPAWN_EGG)},
                {BRUTE}}));
        TIERS.add(new Tier(23, 48, new Mob[][]{
                {m("Свинья", Items.PIG_SPAWN_EGG), m("Паук", Items.SPIDER_SPAWN_EGG), m("Зомби", Items.ZOMBIE_SPAWN_EGG), SLIME},
                {m("Хоглин", Items.HOGLIN_SPAWN_EGG), m("Зоглин", Items.ZOGLIN_SPAWN_EGG), m("Скелет", Items.SKELETON_SPAWN_EGG), m("Пиглин", Items.PIGLIN_SPAWN_EGG)},
                {PHANTOM, m("Житель", Items.VILLAGER_SPAWN_EGG), m("Разбойник", Items.PILLAGER_SPAWN_EGG), m("Утопленник", Items.DROWNED_SPAWN_EGG)},
                {m("Поборник", Items.VINDICATOR_SPAWN_EGG), m("Эндермен", Items.ENDERMAN_SPAWN_EGG), m("Магма-куб", Items.MAGMA_CUBE_SPAWN_EGG)},
                {m("Визер-скелет", Items.WITHER_SKELETON_SPAWN_EGG), m("Зомби-пиглин", Items.ZOMBIFIED_PIGLIN_SPAWN_EGG)},
                {BRUTE}}));
        TIERS.add(new Tier(25, 64, new Mob[][]{
                {m("Ифрит", Items.BLAZE_SPAWN_EGG), m("Гаст", Items.GHAST_SPAWN_EGG), SLIME, m("Пиглин", Items.PIGLIN_SPAWN_EGG)},
                {m("Свинья", Items.PIG_SPAWN_EGG), m("Зомби", Items.ZOMBIE_SPAWN_EGG), m("Скелет", Items.SKELETON_SPAWN_EGG), m("Шалкер", Items.SHULKER_SPAWN_EGG)},
                {m("Житель", Items.VILLAGER_SPAWN_EGG), m("Разбойник", Items.PILLAGER_SPAWN_EGG), m("Поборник", Items.VINDICATOR_SPAWN_EGG)},
                {m("Эндермен", Items.ENDERMAN_SPAWN_EGG), m("Утопленник", Items.DROWNED_SPAWN_EGG), m("Магма-куб", Items.MAGMA_CUBE_SPAWN_EGG)},
                {m("Визер-скелет", Items.WITHER_SKELETON_SPAWN_EGG), m("Зомби-пиглин", Items.ZOMBIFIED_PIGLIN_SPAWN_EGG)},
                {BRUTE}}));
    }

    private static final int SOON_SLOT = 19;

    private static int count(PlayerInventory inv) {
        int n = 0;
        List<ItemStack> all = new ArrayList<>(inv.main);
        all.addAll(inv.offHand);
        for (ItemStack s : all) {
            if (!s.isEmpty() && VI.of(s) == Arsenal.SHARD_EGG) {
                n += s.getCount();
            }
        }
        return n;
    }

    private static void take(PlayerInventory inv, int amount) {
        int left = amount;
        List<ItemStack> all = new ArrayList<>(inv.main);
        all.addAll(inv.offHand);
        for (ItemStack s : all) {
            if (left > 0 && !s.isEmpty() && VI.of(s) == Arsenal.SHARD_EGG) {
                int d = Math.min(left, s.getCount());
                s.decrement(d);
                left -= d;
            }
        }
    }

    private static Item roll(Tier t) {
        List<Mob> all = t.all();
        int sum = 0;
        for (Mob x : all) {
            sum += x.weight;
        }
        int r = RNG.nextInt(sum);
        for (Mob x : all) {
            r -= x.weight;
            if (r < 0) {
                return x.egg;
            }
        }
        return all.get(0).egg;
    }

    private static final class Page implements CreateMenu.Page {
        @Override
        public String title() {
            return "Хранитель Яиц";
        }

        @Override
        public boolean editable(int slot) {
            return false;
        }

        @Override
        public void fill(ServerPlayerEntity p, SimpleInventory inv) {
            for (int i = 0; i < CreateMenu.SIZE; i++) {
                inv.setStack(i, ItemStack.EMPTY);
            }
            List<Text> soon = new ArrayList<>();
            soon.add(CreateMenu.plain("Скоро…", Formatting.GRAY));
            inv.setStack(SOON_SLOT, CreateMenu.button(Items.ENDERMAN_SPAWN_EGG, CreateMenu.plain("Скоро…", Formatting.GRAY), soon));
            for (Tier t : TIERS) {
                MutableText name = CreateMenu.plain("► ", Formatting.GOLD)
                        .append(CreateMenu.plain("Обменять ", Formatting.WHITE))
                        .append(CreateMenu.plain(String.valueOf(t.price), Formatting.YELLOW))
                        .append(CreateMenu.plain(" Осколочных яиц на ", Formatting.WHITE))
                        .append(CreateMenu.plain("1", Formatting.YELLOW))
                        .append(CreateMenu.plain(" Случайное яйца призыва", Formatting.WHITE));
                List<Text> lore = new ArrayList<>();
                lore.add(CreateMenu.plain(" ", Formatting.WHITE));
                lore.add(CreateMenu.plain("Может выпасть:", Formatting.GOLD));
                for (Mob[] row : t.rows) {
                    MutableText line = CreateMenu.plain("▌ ", Formatting.YELLOW);
                    for (int i = 0; i < row.length; i++) {
                        line.append(CreateMenu.plain(row[i].name, row[i].color));
                        if (i + 1 < row.length) {
                            line.append(CreateMenu.plain(", ", Formatting.WHITE));
                        }
                    }
                    lore.add(line);
                }
                ItemStack icon = Arsenal.SHARD_EGG.stack();
                icon.removeSubTag("display");
                icon.setCustomName(name);
                CreateMenu.addLore(icon, lore);
                inv.setStack(t.slot, icon);
            }
        }

        @Override
        public void click(ServerPlayerEntity p, int slot, SimpleInventory inv) {
            for (Tier t : TIERS) {
                if (t.slot != slot) {
                    continue;
                }
                int have = count(p.inventory);
                if (have < t.price) {
                    CreateMenu.msg(p, "Не хватает осколочных яиц: нужно " + t.price + ", у вас " + have + ".", Formatting.RED);
                    return;
                }
                take(p.inventory, t.price);
                p.inventory.offerOrDrop(p.world, new ItemStack(roll(t)));
                CreateMenu.msg(p, "Обмен выполнен: " + t.price + " осколочных яиц.", Formatting.GREEN);
                return;
            }
        }
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("eggkeeper").executes(ctx -> {
                    CreateMenu.open(ctx.getSource().getPlayer(), new Page());
                    return 1;
                })));
    }
}
