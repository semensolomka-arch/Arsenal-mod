package com.arsenal.create;

import com.arsenal.Arsenal;
import com.arsenal.tool.ToolEnchants;
import com.arsenal.vi.EnchantLore;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Map;

/** Меч "Выгодный фарм" с заданным уровнем Фармера и книга Фермера. */
public final class FarmItems {
    private FarmItems() {
    }

    public static ItemStack sword(int level) {
        ItemStack s = Arsenal.FARM_SWORD.stack();
        Map<Enchantment, Integer> map = EnchantmentHelper.get(s);
        map.put(ToolEnchants.FARMER, level);
        EnchantmentHelper.set(map, s);
        EnchantLore.refresh(s);
        return s;
    }

    public static ItemStack fermerBook(int level) {
        ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
        EnchantedBookItem.addEnchantment(book, new EnchantmentLevelEntry(ToolEnchants.FERMER, level));
        return book;
    }

    public static int farmLevel(ItemStack s) {
        return EnchantmentHelper.getLevel(ToolEnchants.FARMER, s);
    }

    public static int fermerLevel(ItemStack book) {
        Integer l = EnchantmentHelper.get(book).get(ToolEnchants.FERMER);
        return l == null ? 0 : l;
    }
}
