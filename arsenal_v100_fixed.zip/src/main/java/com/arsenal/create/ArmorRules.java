package com.arsenal.create;

import com.arsenal.vi.EnchantLore;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.Property;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Правила для брони: Починки на ней нет (у игроков она снимается), починить броню в наковальне нельзя,
 * при слиянии двух одинаковых частей берётся МЕНЬШАЯ прочность (то есть больший износ).
 */
public final class ArmorRules {
    private ArmorRules() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 40 != 0) {
                return;
            }
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                for (List<ItemStack> list : Arrays.asList(p.inventory.main, p.inventory.armor, p.inventory.offHand)) {
                    for (ItemStack s : list) {
                        strip(s);
                    }
                }
            }
        });
    }

    private static void strip(ItemStack s) {
        if (s.isEmpty() || !(s.getItem() instanceof ArmorItem) || !s.hasEnchantments()) {
            return;
        }
        Map<Enchantment, Integer> map = EnchantmentHelper.get(s);
        if (map.remove(Enchantments.MENDING) != null) {
            EnchantmentHelper.set(map, s);
            EnchantLore.refresh(s);
        }
    }

    /** Вызывается после подсчёта результата наковальни. */
    public static void anvil(ScreenHandler self, Property levelCost) {
        ItemStack left = self.getSlot(0).getStack();
        ItemStack right = self.getSlot(1).getStack();
        ItemStack out = self.getSlot(2).getStack();
        if (left.isEmpty() || right.isEmpty() || out.isEmpty() || !(left.getItem() instanceof ArmorItem)) {
            return;
        }
        if (left.getItem() != right.getItem() && left.getItem().canRepair(left, right)) {
            // ремонт материалом: невозможен
            self.getSlot(2).setStack(ItemStack.EMPTY);
            levelCost.set(0);
            return;
        }
        int damage = left.getItem() == right.getItem() ? Math.max(left.getDamage(), right.getDamage()) : left.getDamage();
        if (out.getDamage() != damage) {
            ItemStack fixed = out.copy();
            fixed.setDamage(damage);
            self.getSlot(2).setStack(fixed);
        }
    }
}
