package com.arsenal.buyer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.registry.Registry;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Collections;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Скупщик: /buyer и /b открывают меню, куда кладутся предметы на сдачу за очки скупщика.
 *  - разделы, предметы и цены лежат в config/arsenal_buyer.json (правятся через Mod Menu, перечитываются сами);
 *  - очки, автосдача и выключенные предметы хранятся в файле мира arsenal_buyer.json;
 *  - автоскупщик раз в 5 секунд сдаёт включённые предметы из инвентаря и хотбара (в том числе в бою);
 *  - в режиме боя /buyer не открывается: команды в бою запрещены целиком (CommandManagerMixin).
 * Предмет принимается только "чистым": без названия, зачарований и прочих данных (у зелий допустим только тип зелья).
 */
public final class Buyer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final int AUTO_PERIOD = 100;

    public static final class Entry {
        public final String key;
        public final int price;

        Entry(String key, int price) {
            this.key = key;
            this.price = price;
        }
    }

    public static final class Section {
        public final String title;
        public final List<Entry> items = new ArrayList<>();

        Section(String title) {
            this.title = title;
        }
    }

    /** Товар магазина: предмет (ключ как в ценах), цена в очках за покупку и сколько штук выдаётся. */
    public static final class ShopItem {
        public final String key;
        public final int price;
        public final int count;

        ShopItem(String key, int price, int count) {
            this.key = key;
            this.price = price;
            this.count = count;
        }
    }

    /** Все товары, которые могут появиться в магазине (Mod Menu), и текущий ассортимент (обновляется по таймеру). */
    private static final List<ShopItem> SHOP_POOL = new ArrayList<>();
    private static List<ShopItem> offers = new ArrayList<>();
    private static int shopMinutes = 20;
    private static int shopOfferCount = 9;
    private static int shopNext;
    private static final Random RNG = new Random();
    static final int MAX_OFFERS = 21;

    private static final List<Section> SECTIONS = new ArrayList<>();
    private static final Map<String, Integer> PRICES = new HashMap<>();
    private static long cfgModified = Long.MIN_VALUE;

    private static final Map<UUID, Long> POINTS = new HashMap<>();
    private static final Set<UUID> AUTO = new HashSet<>();
    private static final Map<UUID, Set<String>> DISABLED = new HashMap<>();
    private static boolean dirty;
    private static MinecraftServer server;

    private Buyer() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(buyerCommand("buyer"));
            dispatcher.register(buyerCommand("b"));
            dispatcher.register(CommandManager.literal("pay").then(CommandManager.argument("player", StringArgumentType.word())
                    .suggests((ctx, builder) -> CommandSource.suggestMatching(ctx.getSource().getPlayerNames(), builder))
                    .then(CommandManager.argument("amount", StringArgumentType.word()).executes(Buyer::pay))));
        });
        ServerLifecycleEvents.SERVER_STARTED.register(Buyer::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerTickEvents.END_SERVER_TICK.register(Buyer::tick);
    }

    private static LiteralArgumentBuilder<ServerCommandSource> buyerCommand(String name) {
        return CommandManager.literal(name).executes(ctx -> {
            openMain(ctx.getSource().getPlayer());
            return 1;
        }).then(CommandManager.literal("wipe").requires(src -> src.hasPermissionLevel(2))
                .executes(Buyer::wipeAll)
                .then(CommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, builder) -> CommandSource.suggestMatching(ctx.getSource().getPlayerNames(), builder))
                        .executes(Buyer::wipeOne)));
    }

    /** /buyer wipe: очки скупщика обнуляются у всех (и у тех, кого сейчас нет в сети). */
    private static int wipeAll(CommandContext<ServerCommandSource> ctx) {
        int n = POINTS.size();
        POINTS.clear();
        dirty = true;
        save();
        ctx.getSource().sendFeedback(new LiteralText("Очки скупщика обнулены у всех игроков (записей: " + n + ")")
                .formatted(Formatting.GREEN), true);
        return 1;
    }

    /** /buyer wipe ник: очки скупщика обнуляются у одного игрока (он должен быть в сети). */
    private static int wipeOne(CommandContext<ServerCommandSource> ctx) {
        String name = StringArgumentType.getString(ctx, "player");
        ServerPlayerEntity target = ctx.getSource().getMinecraftServer().getPlayerManager().getPlayer(name);
        if (target == null) {
            ctx.getSource().sendError(new LiteralText("Игрок " + name + " не в сети"));
            return 0;
        }
        long was = points(target.getUuid());
        POINTS.remove(target.getUuid());
        dirty = true;
        save();
        ctx.getSource().sendFeedback(new LiteralText("Очки скупщика игрока " + target.getGameProfile().getName()
                + " обнулены (было " + was + ")").formatted(Formatting.GREEN), true);
        target.sendMessage(new LiteralText("Ваши очки скупщика обнулены").formatted(Formatting.YELLOW), false);
        return 1;
    }

    /** /pay ник сумма и /pay ник all: перевод очков скупщика другому игроку (он должен быть в сети). */
    private static int pay(CommandContext<ServerCommandSource> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity from = ctx.getSource().getPlayer();
        String name = StringArgumentType.getString(ctx, "player");
        String amountText = StringArgumentType.getString(ctx, "amount");
        ServerPlayerEntity to = ctx.getSource().getMinecraftServer().getPlayerManager().getPlayer(name);
        if (to == null) {
            from.sendMessage(new LiteralText("Игрок " + name + " не в сети").formatted(Formatting.RED), false);
            return 0;
        }
        if (to.getUuid().equals(from.getUuid())) {
            from.sendMessage(new LiteralText("Нельзя переводить очки самому себе").formatted(Formatting.RED), false);
            return 0;
        }
        long balance = points(from.getUuid());
        long amount;
        if (amountText.equalsIgnoreCase("all")) {
            amount = balance;
        } else {
            try {
                amount = Long.parseLong(amountText);
            } catch (NumberFormatException e) {
                from.sendMessage(new LiteralText("Сумма должна быть числом или all").formatted(Formatting.RED), false);
                return 0;
            }
        }
        if (amount <= 0) {
            from.sendMessage(new LiteralText(amountText.equalsIgnoreCase("all") ? "У вас нет очков скупщика"
                    : "Сумма должна быть больше нуля").formatted(Formatting.RED), false);
            return 0;
        }
        if (amount > balance) {
            from.sendMessage(new LiteralText("Не хватает очков скупщика: у вас " + balance).formatted(Formatting.RED), false);
            return 0;
        }
        addPoints(from.getUuid(), -amount);
        addPoints(to.getUuid(), amount);
        from.sendMessage(new LiteralText("Вы перевели " + amount + " очков скупщика игроку " + to.getGameProfile().getName()
                + ". Баланс: " + points(from.getUuid())).formatted(Formatting.GREEN), false);
        to.sendMessage(new LiteralText("Игрок " + from.getGameProfile().getName() + " перевёл вам " + amount
                + " очков скупщика. Баланс: " + points(to.getUuid())).formatted(Formatting.GREEN), false);
        return 1;
    }

    // ---------------------------------------------------------------- настройки (config/arsenal_buyer.json)

    public static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_buyer.json");
    }

    /** Настройки по умолчанию: разделы, предметы и цены (за 1 штуку). Правятся через Mod Menu. */
    public static JsonObject defaultJson() {
        JsonObject root = new JsonObject();
        JsonArray sections = new JsonArray();
        sections.add(section("Ресурсы с шахты", "minecraft:diamond",
                "minecraft:coal", 2, "minecraft:charcoal", 2, "minecraft:iron_ingot", 8, "minecraft:gold_ingot", 10,
                "minecraft:diamond", 60, "minecraft:emerald", 40, "minecraft:lapis_lazuli", 3, "minecraft:redstone", 2,
                "minecraft:quartz", 3, "minecraft:glowstone_dust", 3, "minecraft:netherite_scrap", 150,
                "minecraft:ancient_debris", 160, "minecraft:netherite_ingot", 700));
        sections.add(section("Растительность", "minecraft:wheat",
                "minecraft:wheat", 1, "minecraft:carrot", 1, "minecraft:potato", 1, "minecraft:beetroot", 1,
                "minecraft:melon_slice", 1, "minecraft:pumpkin", 3, "minecraft:sugar_cane", 1, "minecraft:cactus", 1,
                "minecraft:bamboo", 1, "minecraft:kelp", 1, "minecraft:nether_wart", 3, "minecraft:sweet_berries", 1,
                "minecraft:cocoa_beans", 2, "minecraft:apple", 2));
        sections.add(section("Блоки", "minecraft:diamond_block",
                "minecraft:diamond_block", 540, "minecraft:emerald_block", 360, "minecraft:gold_block", 90,
                "minecraft:iron_block", 72, "minecraft:lapis_block", 27, "minecraft:redstone_block", 18,
                "minecraft:coal_block", 18, "minecraft:quartz_block", 12, "minecraft:glowstone", 12,
                "minecraft:obsidian", 6, "minecraft:netherite_block", 6300));
        sections.add(section("Зелья", "minecraft:potion",
                "minecraft:potion#minecraft:strong_healing", 30, "minecraft:potion#minecraft:strong_strength", 40,
                "minecraft:potion#minecraft:strong_swiftness", 30, "minecraft:potion#minecraft:strong_regeneration", 40,
                "minecraft:potion#minecraft:long_fire_resistance", 20, "minecraft:potion#minecraft:long_invisibility", 20));
        sections.add(section("Другое", "minecraft:ender_pearl",
                "minecraft:ender_pearl", 10, "minecraft:blaze_rod", 8, "minecraft:ghast_tear", 25,
                "minecraft:slime_ball", 3, "minecraft:gunpowder", 2, "minecraft:bone", 1, "minecraft:string", 1,
                "minecraft:shulker_shell", 30, "minecraft:nether_star", 500, "minecraft:totem_of_undying", 150,
                "minecraft:golden_apple", 40, "minecraft:enchanted_golden_apple", 400, "minecraft:experience_bottle", 5));
        root.add("sections", sections);
        root.add("shop", defaultShop());
        return root;
    }

    /** Магазин по умолчанию: раз в intervalMinutes из товаров выбирается offers случайных. */
    public static JsonObject defaultShop() {
        JsonObject shop = new JsonObject();
        shop.addProperty("intervalMinutes", 20);
        shop.addProperty("offers", 9);
        JsonArray items = new JsonArray();
        Object[][] list = {
                {"minecraft:golden_apple", 150, 1}, {"minecraft:enchanted_golden_apple", 1200, 1},
                {"minecraft:ender_pearl", 200, 16}, {"minecraft:experience_bottle", 100, 16},
                {"minecraft:totem_of_undying", 800, 1}, {"minecraft:obsidian", 120, 16},
                {"minecraft:diamond", 400, 8}, {"minecraft:netherite_ingot", 3000, 1},
                {"minecraft:potion#minecraft:strong_healing", 120, 1}, {"minecraft:potion#minecraft:strong_strength", 150, 1},
                {"minecraft:shulker_shell", 250, 2}, {"minecraft:elytra", 5000, 1}};
        for (Object[] it : list) {
            JsonObject e = new JsonObject();
            e.addProperty("key", (String) it[0]);
            e.addProperty("price", (Integer) it[1]);
            e.addProperty("count", (Integer) it[2]);
            items.add(e);
        }
        shop.add("items", items);
        return shop;
    }

    private static JsonObject section(String title, String icon, Object... keyPrice) {
        JsonObject s = new JsonObject();
        s.addProperty("title", title);
        s.addProperty("icon", icon);
        JsonArray items = new JsonArray();
        for (int i = 0; i + 1 < keyPrice.length; i += 2) {
            JsonObject e = new JsonObject();
            e.addProperty("key", (String) keyPrice[i]);
            e.addProperty("price", (Integer) keyPrice[i + 1]);
            items.add(e);
        }
        s.add("items", items);
        return s;
    }

    private static void ensureConfig() {
        Path file = configPath();
        if (Files.exists(file)) {
            return;
        }
        try {
            Files.createDirectories(file.getParent());
            Files.write(file, GSON.toJson(defaultJson()).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("[Arsenal] Не удалось создать настройки скупщика: " + e);
        }
    }

    /** Перечитывает config/arsenal_buyer.json, если файл изменился. */
    public static void reloadIfChanged() {
        ensureConfig();
        Path file = configPath();
        try {
            long stamp = Files.getLastModifiedTime(file).toMillis();
            if (stamp == cfgModified) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            List<Section> list = new ArrayList<>();
            Map<String, Integer> prices = new HashMap<>();
            for (JsonElement el : root.getAsJsonArray("sections")) {
                JsonObject so = el.getAsJsonObject();
                Section s = new Section(so.has("title") ? so.get("title").getAsString() : "Раздел");
                if (so.has("items")) {
                    for (JsonElement ie : so.getAsJsonArray("items")) {
                        JsonObject io = ie.getAsJsonObject();
                        if (!io.has("key")) {
                            continue;
                        }
                        String key = io.get("key").getAsString();
                        int price = io.has("price") ? Math.max(0, io.get("price").getAsInt()) : 0;
                        s.items.add(new Entry(key, price));
                        prices.put(key, price);
                    }
                }
                list.add(s);
            }
            JsonObject shop = root.has("shop") ? root.getAsJsonObject("shop") : defaultShop();
            List<ShopItem> pool = new ArrayList<>();
            if (shop.has("items")) {
                for (JsonElement ie : shop.getAsJsonArray("items")) {
                    JsonObject io = ie.getAsJsonObject();
                    if (!io.has("key")) {
                        continue;
                    }
                    int price = io.has("price") ? Math.max(0, io.get("price").getAsInt()) : 0;
                    int count = io.has("count") ? Math.max(1, io.get("count").getAsInt()) : 1;
                    pool.add(new ShopItem(io.get("key").getAsString(), price, count));
                }
            }
            shopMinutes = shop.has("intervalMinutes") ? Math.max(1, shop.get("intervalMinutes").getAsInt()) : 20;
            shopOfferCount = shop.has("offers") ? Math.max(1, Math.min(MAX_OFFERS, shop.get("offers").getAsInt())) : 9;
            SHOP_POOL.clear();
            SHOP_POOL.addAll(pool);
            shopNext = 0;   // настройки магазина изменились: ассортимент обновится в ближайшую секунду
            SECTIONS.clear();
            SECTIONS.addAll(list);
            PRICES.clear();
            PRICES.putAll(prices);
            cfgModified = stamp;
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать настройки скупщика: " + e);
        }
    }

    public static List<Section> sections() {
        return SECTIONS;
    }

    // ---------------------------------------------------------------- предметы и цены

    /** Ключ предмета для цен: "minecraft:diamond" или "minecraft:potion#minecraft:strong_healing"; null, если предмет не "чистый". */
    public static String keyOf(ItemStack st) {
        if (st.isEmpty() || st.isDamaged()) {
            return null;
        }
        com.arsenal.vi.VI vi = com.arsenal.vi.VI.of(st);
        if (vi != null) {
            // предмет мода: берётся, если на нём нет своих данных и настоящих зачарований
            NbtCompound t = st.getTag();
            if (t.contains(com.arsenal.vi.VData.KEY, 10)) {
                return null;
            }
            if (t.contains("Enchantments", 9)) {
                for (int i = 0; i < t.getList("Enchantments", 10).size(); i++) {
                    if (!t.getList("Enchantments", 10).getCompound(i).getString("id").isEmpty()) {
                        return null;
                    }
                }
            }
            if (t.contains("PrivateDurability", 3)) {
                return null;
            }
            return "arsenal:" + vi.id;
        }
        Identifier id = Registry.ITEM.getId(st.getItem());
        NbtCompound tag = st.getTag();
        if (tag == null || tag.isEmpty()) {
            return id.toString();
        }
        if (tag.getSize() == 1 && tag.contains("Potion", 8)) {
            return id + "#" + tag.getString("Potion");
        }
        return null;
    }

    public static int priceOf(ItemStack st) {
        String key = keyOf(st);
        if (key == null) {
            return 0;
        }
        Integer p = PRICES.get(key);
        return p == null ? 0 : p;
    }

    /** Сколько очков стоит весь стак (0, если скупщик это не принимает). */
    public static long value(ItemStack st) {
        return (long) priceOf(st) * st.getCount();
    }

    /** Почему скупщик не принимает этот предмет (для подсказки на панели сдачи). */
    static String reject(ItemStack st) {
        String name = st.getName().getString();
        if (st.isDamaged()) {
            return name + " - повреждённые вещи не принимаются";
        }
        String key = keyOf(st);
        if (key == null) {
            return name + " - есть название, зачарования или другие данные";
        }
        Integer p = PRICES.get(key);
        if (p == null) {
            return name + " - нет в списке скупщика (" + key + ")";
        }
        return name + " - цена 0";
    }

    public static ItemStack stackOf(String key) {
        try {
            if (key.startsWith("kit:")) {
                // вещь из кита: "kit:stinger:helmet" (те же вещи, что выпадают из грузов)
                String[] kp = key.split(":");
                ItemStack gear = kp.length == 3 ? com.arsenal.kit.KitCommand.lootGear(kp[1], kp[2]) : null;
                return gear == null || gear.isEmpty() ? new ItemStack(net.minecraft.item.Items.BARRIER) : gear;
            }
            String itemId = key;
            String potionId = null;
            int hash = key.indexOf('#');
            if (hash >= 0) {
                itemId = key.substring(0, hash);
                potionId = key.substring(hash + 1);
            }
            com.arsenal.vi.ItemRef ref = com.arsenal.vi.ItemRef.of(itemId);
            if (ref == null) {
                return new ItemStack(net.minecraft.item.Items.BARRIER);
            }
            Item item = ref.item;
            if (potionId == null) {
                ItemStack preset = com.arsenal.Arsenal.preset(ref.vi);
                if (preset != null) {
                    return preset;   // меч Цербера и меч INFINITY со своими зачарованиями
                }
            }
            ItemStack st = ref.stack(1);
            if (potionId != null) {
                Potion potion = Registry.POTION.getOrEmpty(new Identifier(potionId)).orElse(null);
                if (potion != null) {
                    PotionUtil.setPotion(st, potion);
                }
            }
            return st;
        } catch (Exception e) {
            return new ItemStack(net.minecraft.item.Items.BARRIER);
        }
    }

    // ---------------------------------------------------------------- данные игроков

    public static long points(UUID id) {
        Long v = POINTS.get(id);
        return v == null ? 0 : v;
    }

    static void addPoints(UUID id, long amount) {
        POINTS.put(id, points(id) + amount);
        dirty = true;
    }

    static boolean isAuto(UUID id) {
        return AUTO.contains(id);
    }

    static void setAuto(UUID id, boolean on) {
        if (on) {
            AUTO.add(id);
        } else {
            AUTO.remove(id);
        }
        dirty = true;
    }

    static boolean isEnabled(UUID id, String key) {
        Set<String> off = DISABLED.get(id);
        return off == null || !off.contains(key);
    }

    static void setEnabled(UUID id, String key, boolean on) {
        Set<String> off = DISABLED.computeIfAbsent(id, k -> new HashSet<>());
        if (on) {
            off.remove(key);
        } else {
            off.add(key);
        }
        dirty = true;
    }

    // ---------------------------------------------------------------- магазин

    public static List<ShopItem> offers() {
        return offers;
    }

    /** Сколько секунд до следующего обновления ассортимента магазина. */
    static int secondsToRefresh(MinecraftServer s) {
        return Math.max(0, (shopNext - s.getTicks() + 19) / 20);
    }

    private static void refreshShop(MinecraftServer s) {
        List<ShopItem> pool = new ArrayList<>(SHOP_POOL);
        Collections.shuffle(pool, RNG);
        offers = new ArrayList<>(pool.subList(0, Math.min(pool.size(), Math.min(shopOfferCount, MAX_OFFERS))));
        shopNext = s.getTicks() + shopMinutes * 20 * 60;
    }

    /** Сколько штук такого предмета поместится в основной инвентарь игрока. */
    static int room(ServerPlayerEntity p, ItemStack st) {
        int room = 0;
        int max = st.getMaxCount();
        for (ItemStack s : p.inventory.main) {
            if (s.isEmpty()) {
                room += max;
            } else if (s.getItem() == st.getItem() && ItemStack.areTagsEqual(s, st)) {
                room += Math.max(0, s.getMaxCount() - s.getCount());
            }
        }
        return room;
    }

    public static void openShop(ServerPlayerEntity player) {
        reloadIfChanged();
        SimpleInventory inv = new SimpleInventory(54);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new ShopScreenHandler(syncId, playerInventory, inv),
                new LiteralText("Магазин скупщика")));
    }

    // ---------------------------------------------------------------- меню

    public static void openMain(ServerPlayerEntity player) {
        reloadIfChanged();
        DepositInventory inv = new DepositInventory();
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new BuyerScreenHandler(syncId, playerInventory, inv),
                new LiteralText("Скупщик")));
    }

    public static void openAuto(ServerPlayerEntity player) {
        reloadIfChanged();
        SimpleInventory inv = new SimpleInventory(54);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new AutoScreenHandler(syncId, playerInventory, inv),
                new LiteralText("Автоскупщик")));
    }

    /** Инвентарь сдачи: при закрытии меню несданные предметы возвращаются игроку. */
    static final class DepositInventory extends SimpleInventory {
        DepositInventory() {
            super(54);
        }

        @Override
        public void onClose(net.minecraft.entity.player.PlayerEntity player) {
            for (int i = 0; i < BuyerScreenHandler.DEPOSIT_SLOTS; i++) {
                ItemStack st = getStack(i);
                if (!st.isEmpty()) {
                    setStack(i, ItemStack.EMPTY);
                    player.inventory.offerOrDrop(player.world, st);
                }
            }
            super.onClose(player);
        }
    }

    // ---------------------------------------------------------------- сдача

    /** Ручная сдача: продаёт принимаемые предметы из первых slots слотов инвентаря меню. */
    static void sell(ServerPlayerEntity player, SimpleInventory inv, int slots) {
        long total = 0;
        int count = 0;
        for (int i = 0; i < slots; i++) {
            ItemStack st = inv.getStack(i);
            long v = value(st);
            if (v > 0) {
                total += v;
                count += st.getCount();
                inv.setStack(i, ItemStack.EMPTY);
            }
        }
        if (total <= 0) {
            player.sendMessage(new LiteralText("Нечего сдавать").formatted(Formatting.RED), false);
            sound(player, SoundEvents.ENTITY_VILLAGER_NO);
            return;
        }
        addPoints(player.getUuid(), total);
        player.sendMessage(new LiteralText("Сдано предметов: " + count + ", получено " + total + " очков скупщика. Баланс: "
                + points(player.getUuid())).formatted(Formatting.GREEN), false);
        sound(player, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP);
    }

    /** Автосдача: инвентарь и хотбар игрока. */
    private static void autoSell(ServerPlayerEntity player) {
        UUID id = player.getUuid();
        long total = 0;
        int count = 0;
        for (int i = 0; i < player.inventory.main.size(); i++) {
            ItemStack st = player.inventory.main.get(i);
            String key = keyOf(st);
            if (key == null || !isEnabled(id, key)) {
                continue;
            }
            long v = value(st);
            if (v > 0) {
                total += v;
                count += st.getCount();
                player.inventory.main.set(i, ItemStack.EMPTY);
            }
        }
        if (total > 0) {
            addPoints(id, total);
            player.sendMessage(new LiteralText("Автоскупщик: +" + total + " очков (предметов: " + count + "), баланс "
                    + points(id)).formatted(Formatting.GREEN), true);
        }
    }

    static void sound(ServerPlayerEntity player, SoundEvent event) {
        player.world.playSound(null, player.getX(), player.getY(), player.getZ(), event, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    // ---------------------------------------------------------------- оформление предметов меню

    static ItemStack make(Item item, MutableText name, Text... lore) {
        ItemStack s = new ItemStack(item);
        s.setCustomName(name.styled(st -> st.withItalic(false)));
        if (lore.length > 0) {
            NbtList list = new NbtList();
            for (Text t : lore) {
                MutableText line = new LiteralText("").append(t).styled(st -> st.withItalic(false));
                list.add(NbtString.of(Text.Serializer.toJson(line)));
            }
            s.getOrCreateSubTag("display").put("Lore", list);
        }
        s.addHideFlag(ItemStack.TooltipSection.ADDITIONAL);
        return s;
    }

    static ItemStack glint(ItemStack s) {
        s.addEnchantment(Enchantments.UNBREAKING, 1);
        s.addHideFlag(ItemStack.TooltipSection.ENCHANTMENTS);
        return s;
    }

    static MutableText gray(String s) {
        return new LiteralText(s).formatted(Formatting.GRAY);
    }

    // ---------------------------------------------------------------- тик, загрузка, сохранение

    private static void tick(MinecraftServer s) {
        int t = s.getTicks();
        if (t % 20 == 0) {
            if (t >= shopNext && server != null) {
                refreshShop(s);
                for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
                    if (p.currentScreenHandler instanceof ShopScreenHandler) {
                        p.sendMessage(new LiteralText("Ассортимент магазина скупщика обновился").formatted(Formatting.YELLOW), false);
                    }
                }
            }
            for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
                if (p.currentScreenHandler instanceof AutoScreenHandler) {
                    ((AutoScreenHandler) p.currentScreenHandler).tickIcons();
                } else if (p.currentScreenHandler instanceof ShopScreenHandler) {
                    ((ShopScreenHandler) p.currentScreenHandler).tickTimer();
                }
            }
        }
        if (t % AUTO_PERIOD == 0) {
            reloadIfChanged();
            for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
                if (AUTO.contains(p.getUuid()) && !p.isSpectator()) {
                    autoSell(p);
                }
            }
        }
        if (t % 600 == 0 && dirty) {
            save();
        }
    }

    private static Path dataFile(MinecraftServer s) {
        return s.getSavePath(WorldSavePath.ROOT).resolve("arsenal_buyer.json");
    }

    private static void load(MinecraftServer s) {
        server = s;
        POINTS.clear();
        AUTO.clear();
        DISABLED.clear();
        cfgModified = Long.MIN_VALUE;
        reloadIfChanged();
        shopNext = 0;
        Path file = dataFile(s);
        if (!Files.exists(file)) {
            return;
        }
        try {
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            if (root.has("points")) {
                for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("points").entrySet()) {
                    POINTS.put(UUID.fromString(e.getKey()), e.getValue().getAsLong());
                }
            }
            if (root.has("auto")) {
                for (JsonElement e : root.getAsJsonArray("auto")) {
                    AUTO.add(UUID.fromString(e.getAsString()));
                }
            }
            if (root.has("disabled")) {
                for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("disabled").entrySet()) {
                    Set<String> set = new HashSet<>();
                    for (JsonElement k : e.getValue().getAsJsonArray()) {
                        set.add(k.getAsString());
                    }
                    DISABLED.put(UUID.fromString(e.getKey()), set);
                }
            }
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать данные скупщика: " + e);
        }
    }

    private static void save() {
        if (server == null) {
            return;
        }
        JsonObject root = new JsonObject();
        JsonObject pts = new JsonObject();
        for (Map.Entry<UUID, Long> e : POINTS.entrySet()) {
            pts.addProperty(e.getKey().toString(), e.getValue());
        }
        root.add("points", pts);
        JsonArray auto = new JsonArray();
        for (UUID id : AUTO) {
            auto.add(id.toString());
        }
        root.add("auto", auto);
        JsonObject dis = new JsonObject();
        for (Map.Entry<UUID, Set<String>> e : DISABLED.entrySet()) {
            if (e.getValue().isEmpty()) {
                continue;
            }
            JsonArray arr = new JsonArray();
            for (String k : e.getValue()) {
                arr.add(k);
            }
            dis.add(e.getKey().toString(), arr);
        }
        root.add("disabled", dis);
        try {
            Files.write(dataFile(server), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
            dirty = false;
        } catch (IOException e) {
            System.err.println("[Arsenal] Не удалось сохранить данные скупщика: " + e);
        }
    }
}
