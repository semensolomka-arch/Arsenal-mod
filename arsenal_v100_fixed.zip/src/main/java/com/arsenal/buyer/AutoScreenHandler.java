package com.arsenal.buyer;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.UUID;

/**
 * Меню "Автоскупщик": список разделов (иконка раздела каждую секунду меняется на другой его предмет),
 * внутри раздела - предметы с переключателем сдачи. Нижний ряд: слева стрела назад (из раздела - на предыдущую
 * страницу, с первой страницы - к списку разделов, из списка - в /buyer), по центру звезда Незера
 * (автосдача вкл/выкл), справа стрела вперёд, если предметы раздела не помещаются на одну страницу.
 * ПКМ по разделу включает или выключает сразу все его предметы.
 */
public class AutoScreenHandler extends GenericContainerScreenHandler {
    private static final int PER_PAGE = 45;
    private static final int BACK_SLOT = 45;
    private static final int TOGGLE_SLOT = 49;
    private static final int NEXT_SLOT = 53;

    private final SimpleInventory menu;
    private final ServerPlayerEntity player;
    /** -1: список разделов, иначе номер открытого раздела. */
    private int section = -1;
    private int page;

    public AutoScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, menu, 6);
        this.menu = menu;
        this.player = (ServerPlayerEntity) playerInventory.player;
        refresh();
    }

    void tickIcons() {
        if (section < 0) {
            refresh();
        }
    }

    private void resync() {
        if (player.currentScreenHandler != this) {
            return;
        }
        refresh();
        player.onHandlerRegistered(this, this.getStacks());
    }

    private void refresh() {
        for (int i = 0; i < 54; i++) {
            menu.setStack(i, ItemStack.EMPTY);
        }
        UUID id = player.getUuid();
        List<Buyer.Section> sections = Buyer.sections();
        int tick = player.getServer() == null ? 0 : player.getServer().getTicks() / 20;
        if (section < 0 || section >= sections.size()) {
            section = -1;
            for (int i = 0; i < sections.size() && i < PER_PAGE; i++) {
                Buyer.Section s = sections.get(i);
                int on = 0;
                for (Buyer.Entry e : s.items) {
                    if (Buyer.isEnabled(id, e.key)) {
                        on++;
                    }
                }
                ItemStack icon = s.items.isEmpty() ? new ItemStack(Items.BARRIER)
                        : Buyer.stackOf(s.items.get(tick % s.items.size()).key);
                ItemStack shown = Buyer.make(icon.getItem(), new LiteralText(s.title).formatted(Formatting.GOLD),
                        Buyer.gray("Предметов в разделе: " + s.items.size()),
                        Buyer.gray("Сдача включена для: " + on),
                        new LiteralText("ЛКМ - открыть раздел").formatted(Formatting.YELLOW),
                        new LiteralText("ПКМ - включить/выключить весь раздел").formatted(Formatting.YELLOW));
                if (icon.hasTag() && icon.getTag().contains("Potion")) {
                    shown.getOrCreateTag().putString("Potion", icon.getTag().getString("Potion"));
                }
                menu.setStack(i, shown);
            }
        } else {
            List<Buyer.Entry> items = sections.get(section).items;
            int pages = Math.max(1, (items.size() + PER_PAGE - 1) / PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx >= items.size()) {
                    break;
                }
                Buyer.Entry e = items.get(idx);
                boolean on = Buyer.isEnabled(id, e.key);
                ItemStack icon = Buyer.stackOf(e.key);
                MutableText name = new LiteralText("").append(icon.getName());
                name.formatted(on ? Formatting.GREEN : Formatting.RED);
                ItemStack shown = Buyer.make(icon.getItem(), name,
                        Buyer.gray("Цена: " + e.price + " очков за 1 шт."),
                        new LiteralText("Автосдача: " + (on ? "включена" : "выключена"))
                                .formatted(on ? Formatting.GREEN : Formatting.RED),
                        new LiteralText("Нажмите, чтобы переключить").formatted(Formatting.YELLOW));
                if (icon.hasTag() && icon.getTag().contains("Potion")) {
                    shown.getOrCreateTag().putString("Potion", icon.getTag().getString("Potion"));
                }
                menu.setStack(i, on ? Buyer.glint(shown) : shown);
            }
            if (page + 1 < pages) {
                menu.setStack(NEXT_SLOT, Buyer.make(Items.ARROW, new LiteralText("Вперёд").formatted(Formatting.YELLOW),
                        Buyer.gray("Страница " + (page + 1) + " из " + pages)));
            }
        }
        for (int i = PER_PAGE; i < 54; i++) {
            if (menu.getStack(i).isEmpty()) {
                menu.setStack(i, Buyer.make(Items.BLACK_STAINED_GLASS_PANE, new LiteralText(" ")));
            }
        }
        menu.setStack(BACK_SLOT, Buyer.make(Items.ARROW, new LiteralText("Назад").formatted(Formatting.YELLOW),
                Buyer.gray(section < 0 ? "В меню скупщика" : page > 0 ? "На предыдущую страницу" : "К списку разделов")));
        boolean auto = Buyer.isAuto(id);
        ItemStack star = Buyer.make(Items.NETHER_STAR,
                new LiteralText("Автосдача: " + (auto ? "включена" : "выключена"))
                        .formatted(auto ? Formatting.GREEN : Formatting.RED),
                Buyer.gray("Раз в 5 секунд сдаёт включённые предметы"),
                Buyer.gray("из инвентаря и хотбара"),
                new LiteralText("Нажмите, чтобы переключить").formatted(Formatting.YELLOW));
        menu.setStack(TOGGLE_SLOT, auto ? Buyer.glint(star) : star);
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity p) {
        if (slotIndex >= 0 && slotIndex < 54) {
            if (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE) {
                click(slotIndex, clickData);
            }
            if (player.getServer() != null) {
                player.getServer().execute(this::resync);
            }
            return ItemStack.EMPTY;
        }
        if (actionType == SlotActionType.QUICK_MOVE || actionType == SlotActionType.PICKUP_ALL
                || actionType == SlotActionType.QUICK_CRAFT) {
            return ItemStack.EMPTY;
        }
        return super.onSlotClick(slotIndex, clickData, actionType, p);
    }

    private void click(int slot, int clickData) {
        UUID id = player.getUuid();
        List<Buyer.Section> sections = Buyer.sections();
        if (slot == BACK_SLOT) {
            if (section < 0) {
                // открываем после обработки клика, иначе игрок остаётся "заблокированным" и клики не работают
                if (player.getServer() != null) {
                    player.getServer().execute(() -> Buyer.openMain(player));
                }
                return;
            }
            if (page > 0) {
                page--;
            } else {
                section = -1;
            }
        } else if (slot == TOGGLE_SLOT) {
            Buyer.setAuto(id, !Buyer.isAuto(id));
            Buyer.sound(player, SoundEvents.UI_BUTTON_CLICK);
        } else if (slot == NEXT_SLOT) {
            if (section >= 0) {
                int pages = (sections.get(section).items.size() + PER_PAGE - 1) / PER_PAGE;
                if (page + 1 < pages) {
                    page++;
                }
            }
        } else if (slot < PER_PAGE) {
            if (section < 0) {
                if (slot < sections.size()) {
                    if (clickData == 1) {
                        toggleSection(sections.get(slot));
                    } else {
                        section = slot;
                        page = 0;
                    }
                }
            } else {
                List<Buyer.Entry> items = sections.get(section).items;
                int idx = page * PER_PAGE + slot;
                if (idx < items.size()) {
                    String key = items.get(idx).key;
                    Buyer.setEnabled(id, key, !Buyer.isEnabled(id, key));
                    Buyer.sound(player, SoundEvents.UI_BUTTON_CLICK);
                }
            }
        }
        refresh();
    }

    private void toggleSection(Buyer.Section s) {
        UUID id = player.getUuid();
        boolean allOn = true;
        for (Buyer.Entry e : s.items) {
            if (!Buyer.isEnabled(id, e.key)) {
                allOn = false;
                break;
            }
        }
        for (Buyer.Entry e : s.items) {
            Buyer.setEnabled(id, e.key, !allOn);
        }
        Buyer.sound(player, SoundEvents.UI_BUTTON_CLICK);
    }
}
