package com.arsenal.buyer;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

/**
 * Меню "Скупщик": большой сундук. Верхние 5 рядов - место для сдачи (слоты 0-44), нижний ряд - кнопки:
 * слева звезда Незера (автоскупщик), по центру магнетит (магазин, пока "скоро" + баланс), справа панель:
 * красная, если нечего сдавать, зелёная, если есть что скупщик принимает (клик по ней сдаёт предметы).
 */
public class BuyerScreenHandler extends GenericContainerScreenHandler {
    static final int DEPOSIT_SLOTS = 45;
    private static final int AUTO_SLOT = 45;
    private static final int SHOP_SLOT = 49;
    private static final int SELL_SLOT = 53;

    private final SimpleInventory menu;
    private final ServerPlayerEntity player;

    public BuyerScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, menu, 6);
        this.menu = menu;
        this.player = (ServerPlayerEntity) playerInventory.player;
        refresh();
    }

    /**
     * Полная синхронизация меню с клиентом. Клиент сам "предсказывает" результат клика по ванильным правилам
     * (подобрать кнопку, переложить предмет), а сервер часть слотов блокирует, и тогда на экране остаются
     * призраки, а панель сдачи не обновляется. Поэтому после каждого клика пересчитываем панель и шлём всё заново.
     */
    private void resync() {
        if (player.currentScreenHandler != this) {
            return;
        }
        refresh();
        player.onHandlerRegistered(this, this.getStacks());
    }

    private void scheduleResync() {
        if (player.getServer() != null) {
            player.getServer().execute(this::resync);
        }
    }

    private void refresh() {
        long total = 0;
        int count = 0;
        String why = null;
        for (int i = 0; i < DEPOSIT_SLOTS; i++) {
            ItemStack st = menu.getStack(i);
            if (st.isEmpty()) {
                continue;
            }
            long v = Buyer.value(st);
            if (v > 0) {
                total += v;
                count += st.getCount();
            } else if (why == null) {
                why = Buyer.reject(st);
            }
        }
        for (int i = DEPOSIT_SLOTS; i < 54; i++) {
            menu.setStack(i, Buyer.make(Items.BLACK_STAINED_GLASS_PANE, new LiteralText(" ")));
        }
        boolean auto = Buyer.isAuto(player.getUuid());
        ItemStack star = Buyer.make(Items.NETHER_STAR, new LiteralText("Автоскупщик").formatted(Formatting.LIGHT_PURPLE),
                Buyer.gray("Сейчас: " + (auto ? "включён" : "выключен")),
                Buyer.gray("Нажмите, чтобы открыть разделы и настроить"));
        menu.setStack(AUTO_SLOT, auto ? Buyer.glint(star) : star);
        menu.setStack(SHOP_SLOT, Buyer.make(Items.LODESTONE, new LiteralText("Магазин скупщика").formatted(Formatting.GOLD),
                Buyer.gray("Ваш баланс очков скупщика: " + Buyer.points(player.getUuid())),
                new LiteralText("Нажмите, чтобы открыть магазин").formatted(Formatting.YELLOW)));
        if (total > 0) {
            menu.setStack(SELL_SLOT, Buyer.make(Items.GREEN_STAINED_GLASS_PANE, new LiteralText("Сдать").formatted(Formatting.GREEN),
                    Buyer.gray("Предметов: " + count),
                    new LiteralText("Вы получите: " + total + " очков").formatted(Formatting.GREEN),
                    Buyer.gray(why == null ? " " : "Не принимается: " + why),
                    Buyer.gray("Нажмите, чтобы сдать")));
        } else {
            menu.setStack(SELL_SLOT, Buyer.make(Items.RED_STAINED_GLASS_PANE, new LiteralText("Нечего сдавать").formatted(Formatting.RED),
                    Buyer.gray(why == null ? "Положите предметы, которые принимает скупщик" : "Не принимается: " + why)));
        }
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity p) {
        if (slotIndex >= DEPOSIT_SLOTS && slotIndex < 54) {
            if (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE) {
                button(slotIndex);
            }
            scheduleResync();
            return ItemStack.EMPTY;
        }
        // двойной клик и перетаскивание могли бы задеть кнопки
        if (actionType == SlotActionType.PICKUP_ALL || actionType == SlotActionType.QUICK_CRAFT) {
            scheduleResync();
            return ItemStack.EMPTY;
        }
        ItemStack result = super.onSlotClick(slotIndex, clickData, actionType, p);
        // Менять слоты прямо во время клика мало: сервер считает, что клиент всё предсказал сам, и не шлёт
        // обновление (панель оставалась бы красной), поэтому ещё и полная синхронизация после клика.
        refresh();
        scheduleResync();
        return result;
    }

    /** Шифт-клик: из инвентаря игрока только в слоты сдачи, обратно - в инвентарь; кнопки не трогаем. */
    @Override
    public ItemStack transferSlot(PlayerEntity p, int index) {
        if (index >= DEPOSIT_SLOTS && index < 54) {
            return ItemStack.EMPTY;
        }
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasStack()) {
            return ItemStack.EMPTY;
        }
        ItemStack original = slot.getStack();
        ItemStack copy = original.copy();
        boolean moved = index < DEPOSIT_SLOTS
                ? this.insertItem(original, 54, this.slots.size(), true)
                : this.insertItem(original, 0, DEPOSIT_SLOTS, false);
        if (!moved) {
            return ItemStack.EMPTY;
        }
        if (original.isEmpty()) {
            slot.setStack(ItemStack.EMPTY);
        } else {
            slot.markDirty();
        }
        return copy;
    }

    private void button(int slot) {
        if (slot == AUTO_SLOT) {
            // новое меню открываем после обработки клика, иначе игрок остаётся "заблокированным" и клики не работают
            if (player.getServer() != null) {
                player.getServer().execute(() -> Buyer.openAuto(player));
            }
        } else if (slot == SHOP_SLOT) {
            // новое меню открываем после обработки клика (иначе инвентарь игрока залипает)
            if (player.getServer() != null) {
                player.getServer().execute(() -> Buyer.openShop(player));
            }
            Buyer.sound(player, SoundEvents.UI_BUTTON_CLICK);
        } else if (slot == SELL_SLOT) {
            Buyer.sell(player, menu, DEPOSIT_SLOTS);
            refresh();
        }
    }
}
