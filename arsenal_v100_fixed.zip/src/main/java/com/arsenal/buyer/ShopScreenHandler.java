package com.arsenal.buyer;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.UUID;

/**
 * Магазин скупщика: за очки скупщика продаёт товары из настроек (Mod Menu). Ассортимент общий для всех и
 * обновляется по таймеру (по умолчанию раз в 20 минут): каждый раз выбирается несколько случайных товаров.
 * Слоты товаров - внутренняя область (3 ряда по 7), снизу слева стрела назад в /buyer, по центру баланс и таймер.
 */
public class ShopScreenHandler extends GenericContainerScreenHandler {
    private static final int BACK_SLOT = 45;
    private static final int INFO_SLOT = 49;

    private final SimpleInventory menu;
    private final ServerPlayerEntity player;

    public ShopScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, menu, 6);
        this.menu = menu;
        this.player = (ServerPlayerEntity) playerInventory.player;
        refresh();
    }

    /** Слот для товара номер i: внутренняя область, ряды 1-3, колонки 1-7. */
    private static int slotOf(int i) {
        return (1 + i / 7) * 9 + 1 + i % 7;
    }

    private static int indexOf(int slot) {
        int row = slot / 9;
        int col = slot % 9;
        if (row < 1 || row > 3 || col < 1 || col > 7) {
            return -1;
        }
        return (row - 1) * 7 + (col - 1);
    }

    void tickTimer() {
        refresh();
    }

    private void resync() {
        if (player.currentScreenHandler != this) {
            return;
        }
        refresh();
        player.onHandlerRegistered(this, this.getStacks());
    }

    private void refresh() {
        for (int i = 0; i < 54; i++) {
            menu.setStack(i, Buyer.make(Items.BLACK_STAINED_GLASS_PANE, new LiteralText(" ")));
        }
        UUID id = player.getUuid();
        long balance = Buyer.points(id);
        List<Buyer.ShopItem> offers = Buyer.offers();
        for (int i = 0; i < offers.size() && i < Buyer.MAX_OFFERS; i++) {
            Buyer.ShopItem it = offers.get(i);
            ItemStack shown = Buyer.stackOf(it.key);
            int shownCount = Math.max(1, Math.min(it.count, shown.getMaxCount()));
            shown.setCount(shownCount);
            boolean can = balance >= it.price;
            addLore(shown,
                    new LiteralText("").append(Buyer.gray("Цена: ")).append(
                            new LiteralText(it.price + " очков").formatted(can ? Formatting.GREEN : Formatting.RED)),
                    Buyer.gray("Количество: " + shownCount),
                    new LiteralText("Нажмите, чтобы купить").formatted(Formatting.YELLOW));
            menu.setStack(slotOf(i), shown);
        }
        if (offers.isEmpty()) {
            menu.setStack(22, Buyer.make(Items.BARRIER, new LiteralText("Магазин пока пуст").formatted(Formatting.RED),
                    Buyer.gray("Товары добавляются в настройках мода")));
        }
        menu.setStack(BACK_SLOT, Buyer.make(Items.ARROW, new LiteralText("Назад").formatted(Formatting.YELLOW),
                Buyer.gray("В меню скупщика")));
        int sec = player.getServer() == null ? 0 : Buyer.secondsToRefresh(player.getServer());
        menu.setStack(INFO_SLOT, Buyer.make(Items.LODESTONE, new LiteralText("Магазин скупщика").formatted(Formatting.GOLD),
                Buyer.gray("Ваш баланс очков скупщика: " + balance),
                Buyer.gray("Обновление через " + (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60))));
    }

    private static void addLore(ItemStack stack, Text... lines) {
        net.minecraft.nbt.NbtCompound display = stack.getOrCreateSubTag("display");
        NbtList lore = new NbtList();
        for (Text t : lines) {
            MutableText line = new LiteralText("").append(t).styled(st -> st.withItalic(false));
            lore.add(NbtString.of(Text.Serializer.toJson(line)));
        }
        display.put("Lore", lore);
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity p) {
        if (slotIndex >= 0 && slotIndex < 54) {
            if (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE) {
                click(slotIndex);
            }
            if (player.getServer() != null) {
                player.getServer().execute(this::resync);
            }
            return ItemStack.EMPTY;
        }
        if (actionType == SlotActionType.QUICK_MOVE || actionType == SlotActionType.PICKUP_ALL
                || actionType == SlotActionType.QUICK_CRAFT) {
            return ItemStack.EMPTY;
        }
        return super.onSlotClick(slotIndex, clickData, actionType, p);
    }

    private void click(int slot) {
        if (slot == BACK_SLOT) {
            if (player.getServer() != null) {
                player.getServer().execute(() -> Buyer.openMain(player));
            }
            return;
        }
        int idx = indexOf(slot);
        List<Buyer.ShopItem> offers = Buyer.offers();
        if (idx < 0 || idx >= offers.size()) {
            return;
        }
        Buyer.ShopItem it = offers.get(idx);
        UUID id = player.getUuid();
        long balance = Buyer.points(id);
        if (balance < it.price) {
            player.sendMessage(new LiteralText("Не хватает очков скупщика: нужно " + it.price + ", у вас " + balance)
                    .formatted(Formatting.RED), false);
            Buyer.sound(player, SoundEvents.ENTITY_VILLAGER_NO);
            return;
        }
        ItemStack give = Buyer.stackOf(it.key);
        int n = Math.max(1, Math.min(it.count, give.getMaxCount()));   // броня и оружие не стакаются: выдаём по одной
        give.setCount(n);
        if (Buyer.room(player, give) < n) {
            player.sendMessage(new LiteralText("В инвентаре нет места").formatted(Formatting.RED), false);
            Buyer.sound(player, SoundEvents.ENTITY_VILLAGER_NO);
            return;
        }
        Buyer.addPoints(id, -it.price);
        ItemStack name = give.copy();
        player.inventory.insertStack(give);
        if (!give.isEmpty()) {
            player.dropItem(give, false);   // на всякий случай: место проверено заранее
        }
        player.sendMessage(new LiteralText("Куплено: ").formatted(Formatting.GREEN)
                .append(name.getName()).append(" x" + n + " за " + it.price + " очков. Баланс: " + Buyer.points(id)), false);
        Buyer.sound(player, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP);
    }
}
