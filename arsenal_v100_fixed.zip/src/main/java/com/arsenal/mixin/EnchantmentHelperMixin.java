package com.arsenal.mixin;

import com.arsenal.vi.EnchantLore;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

@Mixin(EnchantmentHelper.class)
public abstract class EnchantmentHelperMixin {
    @Inject(method = "set", at = @At("RETURN"))
    private static void arsenal$enchantLore(Map<Enchantment, Integer> enchantments, ItemStack stack, CallbackInfo ci) {
        EnchantLore.refresh(stack);
    }
}
