package com.arsenal.mixin;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.registry.Registry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Стол зачарований смотрит только на тип зачарования (например, "инструмент"), а не на список предметов:
 * из-за этого Дровосек (только топор) выпадал на кирку. Убираем из столa наши зачарования, которые на предмет нельзя.
 */
@Mixin(EnchantmentHelper.class)
public abstract class EnchantTableMixin {
    @Inject(method = "getPossibleEntries", at = @At("RETURN"))
    private static void arsenal$respectItems(int power, ItemStack stack, boolean treasureAllowed,
                                             CallbackInfoReturnable<List<EnchantmentLevelEntry>> cir) {
        if (stack.getItem() == Items.BOOK) {
            return;
        }
        cir.getReturnValue().removeIf(e -> "arsenal".equals(Registry.ENCHANTMENT.getId(e.enchantment).getNamespace())
                && !e.enchantment.isAcceptableItem(stack));
    }
}
