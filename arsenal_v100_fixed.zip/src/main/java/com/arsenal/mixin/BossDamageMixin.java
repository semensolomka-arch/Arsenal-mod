package com.arsenal.mixin;

import com.arsenal.boss.BossManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Босс: настоящее здоровье всегда возвращается к максимуму, а нанесённый урон идёт в "виртуальное" здоровье
 * (см. BossManager). Так у босса может быть 12000 HP при потолке ванили 1024.
 */
@Mixin(LivingEntity.class)
public abstract class BossDamageMixin {
    @Unique
    private float arsenal$before;

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void arsenal$bossBefore(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        // кулдаун ударов босса по игроку
        if (!self.world.isClient && self instanceof net.minecraft.entity.player.PlayerEntity
                && BossManager.isBoss(source.getAttacker()) && !BossManager.hitReady(self)) {
            cir.setReturnValue(false);
            return;
        }
        if (!self.world.isClient && BossManager.isBoss(self)) {
            self.setHealth(self.getMaxHealth());
            arsenal$before = self.getHealth();
        }
    }

    @Inject(method = "damage", at = @At("RETURN"))
    private void arsenal$bossAfter(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!self.world.isClient && BossManager.isBoss(self)) {
            BossManager.onBossHit(self, source, arsenal$before - self.getHealth());
            self.setHealth(self.getMaxHealth());
        }
    }
}
