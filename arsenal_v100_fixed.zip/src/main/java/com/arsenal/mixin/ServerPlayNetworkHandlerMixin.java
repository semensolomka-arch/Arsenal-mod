package com.arsenal.mixin;

import com.arsenal.bind.Binds;
import com.arsenal.vi.Resync;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 1) Бинды /binds: клавиши Q (выбросить) и F (вторая рука) перехватываются на сервере по пакету действия игрока.
 * 2) Зелья стакаются до 64 только на сервере, ванильный клиент об этом не знает: после кликов с такими
 *    зельями инвентарь отправляется заново, чтобы "призраки" не накапливались.
 */
@Mixin(ServerPlayNetworkHandler.class)
public abstract class ServerPlayNetworkHandlerMixin {
    @Shadow
    public ServerPlayerEntity player;

    @Inject(method = "onPlayerAction", at = @At("HEAD"), cancellable = true)
    private void arsenal$binds(PlayerActionC2SPacket packet, CallbackInfo ci) {
        if (!player.server.isOnThread()) {
            return;   // сначала пакет переедет в основной поток, потом проверим
        }
        PlayerActionC2SPacket.Action action = packet.getAction();
        Binds.Key key;
        if (action == PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND) {
            key = Binds.Key.OFFHAND;
        } else if (action == PlayerActionC2SPacket.Action.DROP_ITEM || action == PlayerActionC2SPacket.Action.DROP_ALL_ITEMS) {
            key = Binds.Key.DROP;
        } else {
            return;
        }
        if (!Binds.keyAvailable(player, key) || Binds.boundTo(player, key).isEmpty()) {
            return;
        }
        Binds.trigger(player, key);
        Resync.inventory(player);
        ci.cancel();
    }

    @Inject(method = "onClickSlot", at = @At("RETURN"))
    private void arsenal$potionSync(ClickSlotC2SPacket packet, CallbackInfo ci) {
        if (!player.server.isOnThread()) {
            return;
        }
        boolean big = isBigPotion(player.inventory.getCursorStack()) || isBigPotion(packet.getStack());
        if (!big) {
            int slot = packet.getSlot();
            if (slot >= 0 && slot < player.currentScreenHandler.slots.size()) {
                Slot s = player.currentScreenHandler.getSlot(slot);
                big = s != null && isBigPotion(s.getStack());
            }
        }
        if (big) {
            Resync.inventory(player);
        }
    }

    private static boolean isBigPotion(ItemStack s) {
        return s != null && !s.isEmpty() && s.getCount() > 1 && s.getItem() instanceof PotionItem;
    }
}
