package com.arsenal.mixin;

import com.arsenal.vi.EnchantLore;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EnchantedBookItem.class)
public abstract class EnchantedBookMixin {
    @Inject(method = "addEnchantment", at = @At("RETURN"))
    private static void arsenal$enchantLore(ItemStack stack, EnchantmentLevelEntry entry, CallbackInfo ci) {
        EnchantLore.refresh(stack);
    }
}
