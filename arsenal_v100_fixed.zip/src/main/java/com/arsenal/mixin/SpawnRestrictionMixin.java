package com.arsenal.mixin;

import com.arsenal.protection.SpawnProtection;
import com.arsenal.spawn.PvpArena;
import com.arsenal.spawn.SpawnManager;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ServerWorldAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Random;

/**
 * В замке, на спавне, на ПВП-арене и в зоне ивентов мобы вообще не спавнятся (раньше они появлялись и сразу пропадали).
 */
@Mixin(SpawnRestriction.class)
public abstract class SpawnRestrictionMixin {
    @Inject(method = "canSpawn", at = @At("HEAD"), cancellable = true)
    private static void arsenal$noMobsOnSpawn(EntityType<?> type, ServerWorldAccess world, SpawnReason reason, BlockPos pos,
                                              Random random, CallbackInfoReturnable<Boolean> cir) {
        if (SpawnProtection.quietZone(world.toServerWorld(), pos) || SpawnManager.contains(world.toServerWorld(), pos)
                || PvpArena.mobFree(world.toServerWorld(), pos)) {
            cir.setReturnValue(false);
        }
    }
}
