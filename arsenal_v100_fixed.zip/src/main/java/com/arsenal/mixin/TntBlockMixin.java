package com.arsenal.mixin;

import com.arsenal.blast.BlastIgnite;
import net.minecraft.block.TntBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Динамит и стиллеры это ванильный TNT с меткой: при поджоге вместо обычного TNT создаётся своя сущность. */
@Mixin(TntBlock.class)
public abstract class TntBlockMixin {
    @Inject(method = "primeTnt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/LivingEntity;)V",
            at = @At("HEAD"), cancellable = true)
    private static void arsenal$prime(World world, BlockPos pos, LivingEntity igniter, CallbackInfo ci) {
        if (BlastIgnite.prime(world, pos, igniter, false)) {
            ci.cancel();
        }
    }

    @Inject(method = "onDestroyedByExplosion", at = @At("HEAD"), cancellable = true)
    private void arsenal$chain(World world, BlockPos pos, Explosion explosion, CallbackInfo ci) {
        LivingEntity cause = explosion == null ? null : explosion.getCausingEntity();
        if (BlastIgnite.prime(world, pos, cause, true)) {
            ci.cancel();
        }
    }
}
