package com.arsenal.mixin;

import com.arsenal.TurtleCooldown;
import com.arsenal.artifact.ArtifactEffect;
import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.rune.Runes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Эффекты Артефакта, связанные с получением и нанесением урона и наложением эффектов. */
@Mixin(LivingEntity.class)
public abstract class ArtifactLivingEntityMixin {
    /** Гравитация, Взрывоустойчивость, АнтиФантом: урон просто не проходит. */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void arsenal$artifactShield(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof ServerPlayerEntity)) {
            return;
        }
        ServerPlayerEntity player = (ServerPlayerEntity) self;

        // ПВП-арена: урона от падения (и от жемчуга эндера) нет
        if (source == DamageSource.FALL && com.arsenal.spawn.PvpArena.inside(player)) {
            cir.setReturnValue(false);
            return;
        }
        if (source == DamageSource.FALL && ArtifactEffects.has(player, ArtifactEffect.GRAVITY)) {
            ArtifactEffects.notifyTriggered(player, ArtifactEffect.GRAVITY);
            cir.setReturnValue(false);
            return;
        }
        if (source.isExplosive() && ArtifactEffects.has(player, ArtifactEffect.BLAST_RESISTANCE)) {
            ArtifactEffects.notifyTriggered(player, ArtifactEffect.BLAST_RESISTANCE);
            cir.setReturnValue(false);
            return;
        }
        Entity attacker = source.getAttacker();
        if (attacker instanceof PhantomEntity && ArtifactEffects.has(player, ArtifactEffect.ANTI_PHANTOM)) {
            attacker.kill();
            ArtifactEffects.notifyTriggered(player, ArtifactEffect.ANTI_PHANTOM);
            cir.setReturnValue(false);
        }
    }

    /** Руны: Шипы отражают входящий урон, Бессмертие не пропускает урон совсем (и отбрасывания тоже нет). */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void arsenal$runeDefense(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof ServerPlayerEntity)) {
            return;
        }
        Runes.reflect(self, source, amount);
        if (Runes.isImmortal(self) && !source.isOutOfWorld()) {
            cir.setReturnValue(false);
        }
    }

    /** Иллюминатор, Снеговик, Вампиризм: срабатывают при ударе, который реально нанёс урон. */
    @Inject(method = "damage", at = @At("RETURN"))
    private void arsenal$artifactHit(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) {
            return;
        }
        Entity attacker = source.getAttacker();
        if (!(attacker instanceof ServerPlayerEntity)) {
            return;
        }
        // только ближний бой: без стрел, взрывов и непрямого урона
        if (source.isProjectile() || source.isExplosive() || source.getSource() != attacker
                || "thorns".equals(source.getName())) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        if (self == attacker) {
            return;
        }
        ArtifactEffects.onMeleeHit((ServerPlayerEntity) attacker, self);
    }

    /** Справедливость: дебаффы от бросаемых зелий на игрока не накладываются (от кастомных предметов остаются). */
    @Inject(method = "addStatusEffect", at = @At("HEAD"), cancellable = true)
    private void arsenal$justice(StatusEffectInstance effect, CallbackInfoReturnable<Boolean> cir) {
        if (!ArtifactEffects.fromPotion) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof ServerPlayerEntity)) {
            return;
        }
        ServerPlayerEntity player = (ServerPlayerEntity) self;
        if (ArtifactEffects.isDebuff(effect.getEffectType()) && ArtifactEffects.has(player, ArtifactEffect.JUSTICE)) {
            ArtifactEffects.notifyTriggered(player, ArtifactEffect.JUSTICE);
            cir.setReturnValue(false);
        }
    }

    /** Черепашья мощь: после наложения эффектов зелья на игрока 5 минут повторно они не накладываются. */
    @Inject(method = "addStatusEffect", at = @At("HEAD"), cancellable = true)
    private void arsenal$turtleCooldown(StatusEffectInstance effect, CallbackInfoReturnable<Boolean> cir) {
        if (!TurtleCooldown.active) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof ServerPlayerEntity && !TurtleCooldown.tryApply(self)) {
            cir.setReturnValue(false);
        }
    }
}
