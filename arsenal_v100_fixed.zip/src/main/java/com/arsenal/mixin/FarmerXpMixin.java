package com.arsenal.mixin;

import com.arsenal.tool.ToolEnchants;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Фармер: опыт, выпадающий с моба, умножается на уровень зачарования меча убийцы. */
@Mixin(LivingEntity.class)
public abstract class FarmerXpMixin {
    @ModifyVariable(method = "dropXp", at = @At(value = "STORE", ordinal = 0), ordinal = 0)
    private int arsenal$farmerXp(int xp) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (xp <= 0 || self instanceof PlayerEntity) {
            return xp;
        }
        LivingEntity killer = self.getAttacker();
        if (killer instanceof PlayerEntity) {
            int level = EnchantmentHelper.getLevel(ToolEnchants.FARMER, killer.getMainHandStack());
            if (level >= 2) {
                return xp * level;
            }
        }
        return xp;
    }
}
