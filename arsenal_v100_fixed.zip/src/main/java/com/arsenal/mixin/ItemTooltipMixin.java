package com.arsenal.mixin;

import com.arsenal.vi.VI;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Только клиент с модом: он и сам показывает зачарования мода в списке чар, поэтому строки с названиями чар,
 * которые сервер дописывает в описание для чистых клиентов, прячем (иначе чары видны дважды).
 */
@Mixin(ItemStack.class)
public abstract class ItemTooltipMixin {
    @Inject(method = "getTooltip", at = @At("RETURN"))
    private void arsenal$hideEnchLore(PlayerEntity player, TooltipContext context, CallbackInfoReturnable<List<Text>> cir) {
        cir.getReturnValue().removeIf(t -> VI.MARK_ENCH.equals(t.getStyle().getInsertion()));
    }
}
