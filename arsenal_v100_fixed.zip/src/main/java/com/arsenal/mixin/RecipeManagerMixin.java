package com.arsenal.mixin;

import com.arsenal.recipe.ArsenalRecipes;
import net.minecraft.inventory.CraftingInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.recipe.RecipeType;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

/**
 * Крафты мода работают из кода (в датапаке результат с NBT не задать), а предметы мода
 * не годятся как ингредиенты ванильных рецептов (руны как красители, и т.п.).
 */
@Mixin(RecipeManager.class)
public abstract class RecipeManagerMixin {
    @SuppressWarnings({"unchecked", "rawtypes"})
    @Inject(method = "getFirstMatch(Lnet/minecraft/recipe/RecipeType;Lnet/minecraft/inventory/Inventory;Lnet/minecraft/world/World;)Ljava/util/Optional;",
            at = @At("RETURN"), cancellable = true)
    private <C extends Inventory, T extends Recipe<C>> void arsenal$recipes(RecipeType<T> type, C inventory, World world,
                                                                             CallbackInfoReturnable<Optional<T>> cir) {
        if ((type == RecipeType.SMELTING || type == RecipeType.BLASTING)
                && inventory instanceof net.minecraft.block.entity.AbstractFurnaceBlockEntity) {
            net.minecraft.item.ItemStack in = inventory.getStack(0);
            if (com.arsenal.create.BattleFragments.reward(in) > 0) {
                cir.setReturnValue((Optional) Optional.ofNullable(com.arsenal.create.BattleFragments.recipe(in, type)));
            }
            return;
        }
        if (type != RecipeType.CRAFTING || !(inventory instanceof CraftingInventory)) {
            return;
        }
        CraftingInventory inv = (CraftingInventory) inventory;
        // чинить броню сложением в верстаке нельзя
        if (cir.getReturnValue().isPresent() && cir.getReturnValue().get() instanceof net.minecraft.recipe.RepairItemRecipe) {
            for (int i = 0; i < inv.size(); i++) {
                if (inv.getStack(i).getItem() instanceof net.minecraft.item.ArmorItem) {
                    cir.setReturnValue(Optional.empty());
                    return;
                }
            }
        }
        CraftingRecipe mine = ArsenalRecipes.find(inv);
        if (mine != null) {
            cir.setReturnValue((Optional) Optional.of(mine));
            return;
        }
        if (cir.getReturnValue().isPresent() && ArsenalRecipes.hasModItem(inv)) {
            cir.setReturnValue(Optional.empty());
        }
    }
}
