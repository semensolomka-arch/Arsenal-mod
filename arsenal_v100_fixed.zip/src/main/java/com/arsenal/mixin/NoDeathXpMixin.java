package com.arsenal.mixin;

import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Опыт при смерти игрока никогда не выпадает. */
@Mixin(PlayerEntity.class)
public abstract class NoDeathXpMixin {
    @Inject(method = "getCurrentExperience", at = @At("HEAD"), cancellable = true)
    private void arsenal$noXp(PlayerEntity player, CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(0);
    }
}
