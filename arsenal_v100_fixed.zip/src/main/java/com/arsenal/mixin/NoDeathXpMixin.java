package com.arsenal.mixin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Опыт при смерти игрока никогда не выпадает. */
@Mixin(LivingEntity.class)
public abstract class NoDeathXpMixin {
    @Inject(method = "dropXp", at = @At("HEAD"), cancellable = true)
    private void arsenal$noXp(CallbackInfo ci) {
        if ((Object) this instanceof PlayerEntity) {
            ci.cancel();
        }
    }
}
