package com.arsenal.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * У капитана Таинственного корабля торговля выключена: ПКМ не открывает окно торговли (отмычку он выдаёт через
 * UseEntityCallback в MysteryShip). require = 0: если у этого метода в другой версии другое имя, мод всё равно запустится,
 * а окно торговли в этом случае закрывает сам MysteryShip в тике.
 */
@Mixin(WanderingTraderEntity.class)
public abstract class CaptainTradeMixin {
    @Inject(method = "interactMob", at = @At("HEAD"), cancellable = true, require = 0)
    private void arsenal$noCaptainTrade(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        Entity self = (Entity) (Object) this;
        if (self.getScoreboardTags().contains("arsenal_ship_captain")) {
            cir.setReturnValue(ActionResult.success(self.world.isClient));
        }
    }
}
