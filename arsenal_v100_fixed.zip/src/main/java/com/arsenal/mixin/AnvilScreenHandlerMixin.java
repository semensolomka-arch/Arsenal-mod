package com.arsenal.mixin;

import com.arsenal.anvil.EnchantMerge;
import com.arsenal.artifact.ArtifactAnvil;
import com.arsenal.rune.RuneAnvil;
import com.arsenal.sphere.SphereAnvil;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.Property;
import net.minecraft.screen.ScreenHandler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Подставляет свой результат в наковальню:
 *  - сферы: сфера + сфера и сфера + тотем = талисман (по 30 ур.), см. SphereAnvil;
 *  - обычные действия наковальни стоят не больше 30 ур., надпись "Слишком дорого!" не появляется;
 *  - Артефакт + предмет-эффект Хранителя опыта (10 ур.), см. ArtifactAnvil;
 *  - тотем или талисман + руна (10 ур.), см. RuneAnvil;
 *  - одинаковые зачарования складываются по правилам мода (потолки, Непробиваемый не стакается), см. EnchantMerge.
 */
@Mixin(AnvilScreenHandler.class)
public abstract class AnvilScreenHandlerMixin {
    @Shadow
    @Final
    private Property levelCost;

    @Shadow
    private int repairItemUsage;

    /** Максимальная цена любого действия в наковальне (кроме артефакта и рун, они дешевле). */
    private static final int MAX_COST = 30;

    /** Убираем ванильный порог "Слишком дорого!" (40 ур.): итоговая цена всё равно режется до MAX_COST. */
    @ModifyConstant(method = "updateResult", constant = @Constant(intValue = 40), require = 0)
    private int arsenal$noTooExpensive(int original) {
        return Integer.MAX_VALUE;
    }

    @Inject(method = "updateResult", at = @At("RETURN"))
    private void arsenal$customRecipes(CallbackInfo ci) {
        ScreenHandler self = (ScreenHandler) (Object) this;
        arsenal$core(self);
        com.arsenal.create.ArmorRules.anvil(self, levelCost);
        // ваниль уже отправила клиенту свой результат: отправляем исправленный (иначе в подсказке старый уровень чар)
        self.sendContentUpdates();
    }

    private void arsenal$core(ScreenHandler self) {
        if (levelCost.get() > MAX_COST) {
            levelCost.set(MAX_COST);
        }
        ItemStack left = self.getSlot(0).getStack();
        ItemStack right = self.getSlot(1).getStack();
        if (left.isEmpty() || right.isEmpty()) {
            return;
        }

        ItemStack output = null;
        int cost = 0;

        SphereAnvil.Result sphere = SphereAnvil.compute(left, right);
        if (sphere != null) {
            output = sphere.stack;
            cost = sphere.cost;
        } else {
            ArtifactAnvil.Result artifact = ArtifactAnvil.compute(left, right);
            if (artifact != null) {
                output = artifact.stack;
                cost = artifact.cost;
            } else {
                RuneAnvil.Result rune = RuneAnvil.compute(left, right);
                if (rune != null) {
                    output = rune.stack;
                    cost = rune.cost;
                }
            }
        }
        if (output == null) {
            // обычное слияние: исправляем уровни одинаковых зачарований (Острота + Небесная кара + Бич и т.д.)
            ItemStack current = self.getSlot(2).getStack();
            boolean had = !current.isEmpty();
            ItemStack merged = EnchantMerge.merge(left, right, current);
            if (!had && !merged.isEmpty()) {
                self.getSlot(2).setStack(merged);
                levelCost.set(10);
                repairItemUsage = 0;
            }
            return;
        }

        self.getSlot(2).setStack(output);
        levelCost.set(cost);
        repairItemUsage = 0;
    }
}
