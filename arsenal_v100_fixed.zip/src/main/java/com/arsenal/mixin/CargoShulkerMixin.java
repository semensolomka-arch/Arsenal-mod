package com.arsenal.mixin;

import com.arsenal.event.EventManager;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Страховка для закрытых грузов: шалкер груза не открывается, пока груз не открылся, как бы игрок до него ни дотянулся.
 * Основная проверка стоит в CargoProtection (UseBlockCallback), но она срабатывает, только если ни один другой
 * обработчик клика не вернул результат раньше (в сетевой игре из-за этого шалкер иногда открывался до времени).
 * Здесь проверка прямо в блоке, на сервере.
 */
@Mixin(ShulkerBoxBlock.class)
public abstract class CargoShulkerMixin {
    @Inject(method = "onUse", at = @At("HEAD"), cancellable = true)
    private void arsenal$closedCargo(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand,
                                     BlockHitResult hit, CallbackInfoReturnable<ActionResult> cir) {
        if (world.isClient || SpawnProtection.bypass(player)) {
            return;
        }
        if (EventManager.shulkerState(world, pos) == 0) {
            if (player instanceof ServerPlayerEntity) {
                SpawnProtection.deny((ServerPlayerEntity) player, "Груз ещё закрыт, осталось " + EventManager.untilOpen());
            }
            cir.setReturnValue(ActionResult.FAIL);
        }
    }
}
