package com.arsenal.mixin;

import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.LuckEnchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LuckEnchantment.class)
public class LuckEnchantmentMixin {
    /** Удача (Fortune) и Добыча (Looting) стакаются в наковальне до V, как Прочность. */
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void arsenal$maxLevel(CallbackInfoReturnable<Integer> cir) {
        Object self = this;
        if (self == Enchantments.FORTUNE || self == Enchantments.LOOTING) {
            cir.setReturnValue(5);
        }
    }

    /** Из стола зачарований по-прежнему максимум III: IV и V стол выдать не может. */
    @Inject(method = "getMinPower", at = @At("HEAD"), cancellable = true)
    private void arsenal$tableLimit(int level, CallbackInfoReturnable<Integer> cir) {
        Object self = this;
        if ((self == Enchantments.FORTUNE || self == Enchantments.LOOTING) && level > 3) {
            cir.setReturnValue(10000);
        }
    }
}
