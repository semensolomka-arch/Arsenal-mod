package com.arsenal.mixin;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Починку на броню наложить нельзя (стол, наковальня, книги). */
@Mixin(Enchantment.class)
public abstract class MendingArmorMixin {
    @Inject(method = "isAcceptableItem", at = @At("HEAD"), cancellable = true)
    private void arsenal$noArmorMending(ItemStack stack, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this == Enchantments.MENDING && stack.getItem() instanceof ArmorItem) {
            cir.setReturnValue(false);
        }
    }
}
