package com.arsenal.mixin;

import com.arsenal.vi.EnchantLore;
import com.arsenal.vi.VI;
import com.arsenal.vi.ViEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 1) Предметы мода на основе блока или огненного заряда не ставятся и не поджигают (кроме динамита, привата, наковальни).
 * 2) Названия зачарований мода дописываются в описание.
 */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true)
    private void arsenal$noPlace(ItemUsageContext context, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack self = (ItemStack) (Object) this;
        VI vi = VI.of(self);
        if (vi == null || vi.vanillaUse) {
            return;
        }
        if (!(self.getItem() instanceof BlockItem) && !(self.getItem() instanceof FireChargeItem)) {
            return;
        }
        if (context.getWorld().isClient) {
            return;
        }
        PlayerEntity player = context.getPlayer();
        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity) player;
            ViEvents.blockUseCancelled(sp, self, vi);
            // клиент мог "поставить" блок и изменить соседей (трава под снегом белеет): пересылаем настоящие блоки вокруг
            net.minecraft.util.math.BlockPos hit = context.getBlockPos();
            net.minecraft.util.math.BlockPos placed = hit.offset(context.getSide());
            for (net.minecraft.util.math.BlockPos base : new net.minecraft.util.math.BlockPos[]{hit, placed}) {
                sp.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket(context.getWorld(), base));
                for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values()) {
                    sp.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket(
                            context.getWorld(), base.offset(d)));
                }
            }
        }
        cir.setReturnValue(ActionResult.FAIL);
    }

    @Inject(method = "addEnchantment", at = @At("RETURN"))
    private void arsenal$enchantLore(Enchantment enchantment, int level, CallbackInfo ci) {
        EnchantLore.refresh((ItemStack) (Object) this);
    }

    private static final java.util.Random ARSENAL_WEAR = new java.util.Random();

    /** Броня теряет в 3 раза меньше прочности. */
    @org.spongepowered.asm.mixin.injection.ModifyVariable(method = "damage(ILjava/util/Random;Lnet/minecraft/server/network/ServerPlayerEntity;)Z",
            at = @At("HEAD"), argsOnly = true)
    private int arsenal$armorWear(int amount) {
        ItemStack self = (ItemStack) (Object) this;
        if (amount > 0 && self.getItem() instanceof net.minecraft.item.ArmorItem) {
            int whole = amount / 3;
            int rest = amount % 3;
            return whole + (rest > 0 && ARSENAL_WEAR.nextInt(3) < rest ? 1 : 0);
        }
        return amount;
    }
}
