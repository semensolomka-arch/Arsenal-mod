package com.arsenal.mixin;

import com.arsenal.vi.Resync;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** После съеденной еды или выпитого зелья игроку заново отправляется инвентарь (меньше рассинхрона при лагах). */
@Mixin(LivingEntity.class)
public abstract class ConsumeSyncMixin {
    @Inject(method = "consumeItem", at = @At("RETURN"), require = 0)
    private void arsenal$resyncAfterUse(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof ServerPlayerEntity) {
            Resync.later((ServerPlayerEntity) self);
        }
    }
}
