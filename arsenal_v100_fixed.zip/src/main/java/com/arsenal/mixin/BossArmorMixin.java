package com.arsenal.mixin;

import com.arsenal.boss.BossManager;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Удары босса и его приспешников изнашивают броню игрока слабо и одинаково, как бы велик ни был урон. */
@Mixin(PlayerEntity.class)
public abstract class BossArmorMixin {
    @Inject(method = "damageArmor", at = @At("HEAD"), cancellable = true, require = 0)
    private void arsenal$bossWear(DamageSource source, float amount, CallbackInfo ci) {
        if (!BossManager.isBossSide(source.getAttacker())) {
            return;
        }
        ci.cancel();
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (BossManager.ARMOR_WEAR <= 0) {
            return;
        }
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = self.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                stack.damage(BossManager.ARMOR_WEAR, self, e -> e.sendEquipmentBreakStatus(slot));
            }
        }
    }
}
