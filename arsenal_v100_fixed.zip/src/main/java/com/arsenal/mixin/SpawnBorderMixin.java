package com.arsenal.mixin;

import com.arsenal.spawn.PvpArena;
import com.arsenal.spawn.SpawnManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Спавн это безопасная зона: игроки там не получают никакого урона (ни от игроков, ни от эффектов, ни от границы мира,
 * которая лежит ближе спавна). Исключение: команда /kill и пустота (OUT_OF_WORLD) и ПВП-арена (там урон есть).
 */
@Mixin(LivingEntity.class)
public abstract class SpawnBorderMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void arsenal$spawnIsSafe(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        if (self instanceof PlayerEntity && source != DamageSource.OUT_OF_WORLD && SpawnManager.near(self)) {
            // ПВП-арена: тут урон от игроков, мобов и эффектов работает (граница мира и удушье по-прежнему не бьют).
            // Обход вокруг ямы (спавн-уровень) остаётся безопасным.
            if (PvpArena.inside(self) && !PvpArena.inLobby(self) && source != DamageSource.IN_WALL) {
                return;
            }
            cir.setReturnValue(false);
        }
    }
}
