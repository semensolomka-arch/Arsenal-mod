package com.arsenal.mixin;

import com.arsenal.item.FastFurnace;
import com.arsenal.vi.Marks;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Быстрые печки: лишние тики плавки для помеченных печек. */
@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class FastFurnaceMixin {
    private static boolean arsenal$running;

    @Inject(method = "tick", at = @At("RETURN"))
    private void arsenal$fast(CallbackInfo ci) {
        if (arsenal$running || FastFurnace.MULT <= 1) {
            return;
        }
        BlockEntity self = (BlockEntity) (Object) this;
        World world = self.getWorld();
        if (world == null || world.isClient) {
            return;
        }
        if (!FastFurnace.ID.equals(Marks.idAt(world, self.getPos()))) {
            return;
        }
        arsenal$running = true;
        try {
            for (int i = 1; i < FastFurnace.MULT; i++) {
                ((AbstractFurnaceBlockEntity) (Object) this).tick();
            }
        } finally {
            arsenal$running = false;
        }
    }
}
