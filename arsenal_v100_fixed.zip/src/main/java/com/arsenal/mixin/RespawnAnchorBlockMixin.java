package com.arsenal.mixin;

import com.arsenal.event.MysteryShip;
import net.minecraft.block.BlockState;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Сокровище пиратов (якорь возрождения): клик по нему обрабатывает корабль, а не ваниль (вне Незера якорь взрывается). */
@Mixin(RespawnAnchorBlock.class)
public abstract class RespawnAnchorBlockMixin {
    @Inject(method = "onUse", at = @At("HEAD"), cancellable = true)
    private void arsenal$shipTreasure(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand,
                                      BlockHitResult hit, CallbackInfoReturnable<ActionResult> cir) {
        ActionResult r = MysteryShip.useAnchor(world, pos, player, hand);
        if (r != null) {
            cir.setReturnValue(r);
        }
    }
}
