package com.arsenal.mixin;

import com.arsenal.tool.Filters;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Запоминает, кто убил моба, пока выпадает его добыча (нужно зачарованию Фильтр). */
@Mixin(LivingEntity.class)
public abstract class LivingEntityDropMixin {
    @Inject(method = "drop(Lnet/minecraft/entity/damage/DamageSource;)V", at = @At("HEAD"), cancellable = true)
    private void arsenal$dropStart(DamageSource source, CallbackInfo ci) {
        // приспешники и босс не оставляют добычи
        if (com.arsenal.boss.BossManager.noLoot((LivingEntity) (Object) this)) {
            ci.cancel();
            return;
        }
        Filters.killer = source.getAttacker();
    }

    @Inject(method = "drop(Lnet/minecraft/entity/damage/DamageSource;)V", at = @At("RETURN"))
    private void arsenal$dropEnd(DamageSource source, CallbackInfo ci) {
        Filters.killer = null;
    }

    @Inject(method = "dropXp", at = @At("HEAD"), cancellable = true)
    private void arsenal$noBossXp(CallbackInfo ci) {
        if (com.arsenal.boss.BossManager.noLoot((LivingEntity) (Object) this)) {
            ci.cancel();
        }
    }
}
