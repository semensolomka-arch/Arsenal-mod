package com.arsenal.mixin;

import com.arsenal.Arsenal;
import com.arsenal.item.WinnerPotionItem;
import com.arsenal.vi.Cd;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Зелье победителя: после питья общий откат (на ванильные зелья он не действует). */
@Mixin(PotionItem.class)
public abstract class PotionItemMixin {
    @Inject(method = "finishUsing", at = @At("HEAD"))
    private void arsenal$winnerCooldown(ItemStack stack, World world, LivingEntity user,
                                        CallbackInfoReturnable<ItemStack> cir) {
        if (!world.isClient && user instanceof ServerPlayerEntity && Arsenal.WINNER_POTION.is(stack)) {
            Cd.set((ServerPlayerEntity) user, Arsenal.WINNER_POTION, WinnerPotionItem.COOLDOWN_TICKS);
        }
    }
}
