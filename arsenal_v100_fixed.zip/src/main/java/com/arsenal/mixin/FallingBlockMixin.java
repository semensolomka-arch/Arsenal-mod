package com.arsenal.mixin;

import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

/** В замке, на ПВП-арене и в зоне ивентов песок, гравий, наковальни и т.п. не падают. */
@Mixin(FallingBlock.class)
public abstract class FallingBlockMixin {
    @Inject(method = "scheduledTick", at = @At("HEAD"), cancellable = true)
    private void arsenal$noFalling(BlockState state, ServerWorld world, BlockPos pos, Random random, CallbackInfo ci) {
        if (SpawnProtection.quietZone(world, pos)) {
            ci.cancel();
        }
    }
}
