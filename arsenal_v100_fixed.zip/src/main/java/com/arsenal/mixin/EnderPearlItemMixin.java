package com.arsenal.mixin;

import com.arsenal.StunZones;
import com.arsenal.artifact.ArtifactEffect;
import com.arsenal.artifact.ArtifactEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EnderPearlItem.class)
public class EnderPearlItemMixin {
    /** После броска жемчуга эндера кулдаун 15 секунд (в ванили 1 секунда). */
    @Inject(method = "use", at = @At("RETURN"))
    private void arsenal$pearlCooldown(World world, PlayerEntity user, Hand hand,
                                       CallbackInfoReturnable<TypedActionResult<ItemStack>> cir) {
        user.getItemCooldownManager().set(Items.ENDER_PEARL, StunZones.PEARL_COOLDOWN_TICKS);
        if (!world.isClient) {
            StunZones.onPearlThrown(user);

            // Эндермен: шанс (по умолчанию 50%) не потратить жемчуг
            if (user instanceof ServerPlayerEntity && !user.isCreative()
                    && ArtifactEffects.has(user, ArtifactEffect.ENDERMAN) && world.random.nextInt(100) < ArtifactEffects.ENDERMAN_CHANCE) {
                user.getStackInHand(hand).increment(1);
                ArtifactEffects.notifyTriggered((ServerPlayerEntity) user, ArtifactEffect.ENDERMAN);
            }
        }
    }
}
