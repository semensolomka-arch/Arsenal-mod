package com.arsenal.mixin;

import com.arsenal.Arsenal;
import com.arsenal.WeaponEffects;
import com.arsenal.enchantment.ImpenetrableEnchantment;
import com.arsenal.rune.Runes;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * "Непробиваемый": после того как посчитаны броня и зачарования защиты,
 * с шансом (20% за каждую часть брони) срезаем ещё 20% урона. Бросок один на удар.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** Урон, с которым пришёл последний удар (до брони), нужен Разрушителю. */
    @Unique
    private float arsenal$rawDamage;

    @Inject(method = "damage", at = @At("HEAD"))
    private void arsenal$rememberDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        arsenal$rawDamage = amount;
    }

    // Убираем отдачу (отбрасывание), если атака была произведена мечом Цербера, Инфинити, Eternity или Stinger
    @Inject(method = "takeKnockback", at = @At("HEAD"), cancellable = true)
    private void arsenal$noKnockback(float strength, double x, double z, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        LivingEntity attacker = self.getAttacker();
        if (attacker != null) {
            ItemStack mainHand = attacker.getMainHandStack();
            if (!mainHand.isEmpty() && (Arsenal.CERBERUS_SWORD.is(mainHand) || Arsenal.INFINITY_SWORD.is(mainHand)
                    || Arsenal.ETERNITY_SWORD.is(mainHand) || Arsenal.STINGER_SWORD.is(mainHand))) {
                ci.cancel();
            }
        }
    }

    // Два имени, потому что в разных сборках маппингов этот метод называется по-разному.
    @Inject(method = {"modifyAppliedDamage", "applyEnchantmentsToDamage"}, at = @At("RETURN"), cancellable = true)
    private void arsenal$damage(DamageSource source, float amount, CallbackInfoReturnable<Float> cir) {
        float result = cir.getReturnValue();
        if (result <= 0.0F || source.isUnblockable()) {
            return;
        }

        LivingEntity self = (LivingEntity) (Object) this;

        // "Непробиваемый"
        int levels = 0;
        float weightedReduction = 0.0F;
        for (ItemStack stack : self.getArmorItems()) {
            int lvl = EnchantmentHelper.getLevel(Arsenal.IMPENETRABLE, stack);
            levels += lvl;
            weightedReduction += lvl * ImpenetrableEnchantment.damageReduction(lvl);
        }
        if (levels > 0) {
            float chance = Math.min(1.0F, levels * ImpenetrableEnchantment.CHANCE_PER_LEVEL);
            if (self.world.random.nextFloat() < chance) {
                // если части разного уровня, срез урона берётся средневзвешенным по уровням
                result *= 1.0F - weightedReduction / levels;
            }
        }

        // "Критический" и "Разрушитель" (меч и топор в руке атакующего)
        ItemStack weapon = WeaponEffects.meleeWeapon(source);
        if (!weapon.isEmpty()) {
            result = WeaponEffects.applyCritical(self, weapon, result, self.world.random);
            WeaponEffects.applyDestroyer(self, weapon, arsenal$rawDamage, self.world.random);
        }

        cir.setReturnValue(result);
    }

    /** Обычный тотем в руках перед проверкой (нужен, чтобы после срабатывания применить его руны). */
    @Unique
    private ItemStack arsenal$totemRunes;
    @Unique
    private Hand arsenal$totemHand;

    @Inject(method = "tryUseTotem", at = @At("HEAD"))
    private void arsenal$captureTotem(DamageSource source, CallbackInfoReturnable<Boolean> cir) {
        arsenal$totemRunes = null;
        arsenal$totemHand = null;
        if (source.isOutOfWorld()) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        for (Hand hand : Hand.values()) {
            ItemStack stack = self.getStackInHand(hand);
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                arsenal$totemRunes = stack.copy();
                arsenal$totemHand = hand;
                return;
            }
        }
    }

    /**
     * Талисман в любой руке (правой или левой) спасает от смерти как тотем бессмертия (и пропадает).
     * Эффекты сфер и талисманов при этом даются только из левой руки (см. SphereEffects).
     * Срабатывает, только если ванильный тотем не сработал. Руны тотема или талисмана применяются здесь же.
     */
    @Inject(method = "tryUseTotem", at = @At("RETURN"), cancellable = true)
    private void arsenal$talisman(DamageSource source, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;

        if (cir.getReturnValue()) {
            // сработал обычный тотем: применяем его руны
            if (arsenal$totemRunes != null) {
                Runes.onTotem(self, arsenal$totemRunes, arsenal$totemHand, source, arsenal$rawDamage);
            }
            arsenal$totemRunes = null;
            arsenal$totemHand = null;
            return;
        }
        if (source.isOutOfWorld() || !(self instanceof PlayerEntity)) {
            return;
        }
        ItemStack talisman = ItemStack.EMPTY;
        Hand talismanHand = null;
        for (Hand hand : Hand.values()) {
            ItemStack stack = self.getStackInHand(hand);
            if (Arsenal.isTalisman(stack)) {
                talisman = stack;
                talismanHand = hand;
                break;
            }
        }
        if (talisman.isEmpty()) {
            return;
        }
        ItemStack runeCopy = talisman.copy();
        talisman.decrement(1);
        self.setHealth(1.0F);
        self.clearStatusEffects();
        self.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 900, 1));
        self.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 100, 1));
        self.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 800, 0));
        self.world.sendEntityStatus(self, (byte) 35); // анимация тотема
        Runes.onTotem(self, runeCopy, talismanHand, source, arsenal$rawDamage);
        cir.setReturnValue(true);
    }
}
