package com.arsenal.sphere;

import com.arsenal.Arsenal;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VData;
import com.arsenal.vi.VI;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Сферы (головы игроков) и талисманы (тотемы): уровни эффектов хранятся в NBT предмета (ArsenalData). */
public final class Spheres {
    /** Предметы с фиксированными уровнями (Флеш, Цербер, Stinger, Eternity, Infinity). */
    private static final Map<String, int[]> FIXED = new HashMap<>();
    /** Готовые величины эффектов вместо уровень * perLevel (талисман Dragon). */
    private static final Map<String, double[]> AMOUNTS = new HashMap<>();
    private static final Map<String, Boolean> KNOWN = new HashMap<>();

    private Spheres() {
    }

    public static void define(String id, int[] fixed, double[] amounts) {
        KNOWN.put(id, Boolean.TRUE);
        if (fixed != null) {
            FIXED.put(id, fixed);
        }
        if (amounts != null) {
            AMOUNTS.put(id, amounts);
        }
    }

    /** Вектор уровней: скорость, урон, броня, скорость атаки, макс. здоровье. */
    public static int[] v(int speed, int damage, int armor, int attackSpeed, int health) {
        return new int[]{speed, damage, armor, attackSpeed, health};
    }

    private static int[] one(SphereEffect effect, int level) {
        int[] r = new int[SphereEffect.COUNT];
        r[effect.ordinal()] = level;
        return r;
    }

    /** Сфера или талисман мода? */
    public static boolean isEffectItem(ItemStack stack) {
        VI vi = VI.of(stack);
        return vi != null && KNOWN.containsKey(vi.id);
    }

    /** Сферы с проклятием утраты: при смерти выпадают с шансом 50%. */
    public static boolean isCursed(ItemStack stack) {
        VI vi = VI.of(stack);
        return vi != null && (vi.id.equals("sphere_flash") || vi.id.equals("sphere_cerberus"));
    }

    public static boolean isSphere(ItemStack stack) {
        VI vi = VI.of(stack);
        return vi != null && vi.id.startsWith("sphere_");
    }

    /** Уровни эффектов в порядке SphereEffect. */
    public static int[] effects(ItemStack stack) {
        VI vi = VI.of(stack);
        if (vi != null && FIXED.containsKey(vi.id)) {
            return FIXED.get(vi.id).clone();
        }
        int[] result = new int[SphereEffect.COUNT];
        for (SphereEffect e : SphereEffect.values()) {
            result[e.ordinal()] = VData.get(stack, e.key());
        }
        return result;
    }

    /** Величина эффекта для атрибута: готовое значение или уровень * perLevel. */
    public static double amount(ItemStack stack, SphereEffect effect) {
        VI vi = VI.of(stack);
        if (vi != null && AMOUNTS.containsKey(vi.id)) {
            return AMOUNTS.get(vi.id)[effect.ordinal()];
        }
        return effects(stack)[effect.ordinal()] * effect.perLevel;
    }

    /** Строки описания: эффекты (и бонусы Dragon). */
    public static List<Text> loreLines(ItemStack stack) {
        List<Text> out = new ArrayList<>();
        VI vi = VI.of(stack);
        if (vi != null && AMOUNTS.containsKey(vi.id)) {
            double[] a = AMOUNTS.get(vi.id);
            if (a[SphereEffect.SPEED.ordinal()] > 0) {
                out.add(new LiteralText(Lang.format("tooltip.arsenal.bonus_speed",
                        Math.round(a[SphereEffect.SPEED.ordinal()] * 100))).formatted(Formatting.GRAY));
            }
            if (a[SphereEffect.DAMAGE.ordinal()] > 0) {
                out.add(new LiteralText(Lang.format("tooltip.arsenal.bonus_damage",
                        Math.round(a[SphereEffect.DAMAGE.ordinal()]))).formatted(Formatting.GRAY));
            }
            return out;
        }
        int[] levels = effects(stack);
        for (SphereEffect e : SphereEffect.values()) {
            int level = levels[e.ordinal()];
            if (level > 0) {
                out.add(new LiteralText(Lang.get("enchantment.arsenal.sphere_" + e.id) + " "
                        + com.arsenal.vi.EnchantLore.roman(level)).formatted(Formatting.GRAY));
            }
        }
        if (isCursed(stack)) {
            out.add(new LiteralText("Проклятые утраты").formatted(Formatting.RED));
        }
        return out;
    }

    /** Предмет с уровнями эффектов, записанными в данные. */
    public static ItemStack stack(VI item, int[] levels) {
        ItemStack s = item.stack();
        for (SphereEffect e : SphereEffect.values()) {
            if (levels[e.ordinal()] > 0) {
                VData.set(s, e.key(), levels[e.ordinal()]);
            }
        }
        return s;
    }

    /** Сумма уровней = "очки" сферы: 1 обычная, 2 эпическая, 3-4 легендарная, 5 мифическая. */
    public static int points(int[] levels) {
        int sum = 0;
        for (int l : levels) {
            sum += l;
        }
        return sum;
    }

    /** Сфера или талисман с одним случайным эффектом заданного уровня. */
    public static ItemStack randomEffect(VI item, int level, java.util.Random rnd) {
        SphereEffect[] all = SphereEffect.values();
        return stack(item, one(all[rnd.nextInt(all.length)], level));
    }

    /** Три мифических набора (их же можно собрать в наковальне): урон 3 + броня 2, урон 2 + броня 3, скорость 2 + броня 3. */
    public static final int[][] MYTHIC = {v(0, 3, 2, 0, 0), v(0, 2, 3, 0, 0), v(2, 0, 3, 0, 0)};

    /** Мифическая сфера с одним из трёх наборов. */
    public static ItemStack mythic(java.util.Random rnd) {
        return stack(Arsenal.SPHERE_MYTHIC, MYTHIC[rnd.nextInt(MYTHIC.length)]);
    }

    public static boolean isMythicVector(int[] levels) {
        for (int[] m : MYTHIC) {
            if (java.util.Arrays.equals(m, levels)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ редкость, случайные и заданные эффекты

    private static final String[] IDS = {"speed", "damage", "armor", "attack_speed", "health"};
    /** Максимальный уровень одного эффекта у случайной сферы (как в наковальне). */
    public static final int RANDOM_MAX_LEVEL = 3;

    /** 1 обычная, 2 эпическая, 3 легендарная, 4 мифическая (сфера); 0 - предмет с фиксированными эффектами или не сфера. */
    public static int tier(VI vi) {
        if (vi == null) {
            return 0;
        }
        if (vi == Arsenal.SPHERE_COMMON || vi == Arsenal.TALISMAN_COMMON) {
            return 1;
        }
        if (vi == Arsenal.SPHERE_EPIC || vi == Arsenal.TALISMAN) {
            return 2;
        }
        if (vi == Arsenal.SPHERE_LEGENDARY || vi == Arsenal.TALISMAN_LEGENDARY) {
            return 3;
        }
        if (vi == Arsenal.SPHERE_MYTHIC) {
            return 4;
        }
        return 0;
    }

    /** Все наборы уровней с данной суммой очков, где каждый эффект не выше RANDOM_MAX_LEVEL. */
    public static List<int[]> combos(int points) {
        List<int[]> out = new ArrayList<>();
        fill(new int[SphereEffect.COUNT], 0, points, out);
        return out;
    }

    private static void fill(int[] cur, int index, int left, List<int[]> out) {
        if (index == SphereEffect.COUNT) {
            if (left == 0) {
                out.add(cur.clone());
            }
            return;
        }
        for (int l = 0; l <= RANDOM_MAX_LEVEL && l <= left; l++) {
            cur[index] = l;
            fill(cur, index + 1, left - l, out);
        }
        cur[index] = 0;
    }

    /** Случайный набор с суммой очков points: по одному очку в случайный эффект (не выше RANDOM_MAX_LEVEL). */
    public static int[] randomLevels(int points, java.util.Random rnd) {
        int[] r = new int[SphereEffect.COUNT];
        for (int p = 0; p < points; p++) {
            List<Integer> open = new ArrayList<>();
            for (int i = 0; i < r.length; i++) {
                if (r[i] < RANDOM_MAX_LEVEL) {
                    open.add(i);
                }
            }
            if (open.isEmpty()) {
                break;
            }
            r[open.get(rnd.nextInt(open.size()))]++;
        }
        return r;
    }

    /**
     * Сфера/талисман со случайными эффектами по редкости (как получаются в наковальне):
     * обычная 1 очко, эпическая 2 (один эффект II или два по I), легендарная 3-4 очка (например урон III, урон II + броня I,
     * урон II + броня II), мифическая - один из трёх наборов. Остальные предметы возвращаются как есть.
     */
    public static ItemStack randomFor(VI item, java.util.Random rnd) {
        int tier = tier(item);
        if (tier == 4) {
            return mythic(rnd);
        }
        if (tier == 0) {
            return item.stack();
        }
        int points = tier == 1 ? 1 : tier == 2 ? 2 : 3 + rnd.nextInt(2);
        return stack(item, randomLevels(points, rnd));
    }

    /** Набор уровней в виде строки для конфигов: "speed2 armor1". */
    public static String encode(int[] levels) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SphereEffect.COUNT; i++) {
            if (levels[i] > 0) {
                sb.append(sb.length() > 0 ? " " : "").append(IDS[i]).append(levels[i]);
            }
        }
        return sb.toString();
    }

    /** Читаемое описание: "Урон II, Броня I". */
    public static String describe(int[] levels) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SphereEffect.COUNT; i++) {
            if (levels[i] > 0) {
                sb.append(sb.length() > 0 ? ", " : "").append(Lang.get("enchantment.arsenal.sphere_" + IDS[i]))
                        .append(' ').append(com.arsenal.vi.EnchantLore.roman(levels[i]));
            }
        }
        return sb.toString();
    }

    private static int effectIndex(String name) {
        switch (name) {
            case "speed": case "скорость": case "spd":
                return 0;
            case "damage": case "dmg": case "урон":
                return 1;
            case "armor": case "броня":
                return 2;
            case "attack_speed": case "attackspeed": case "attack": case "atk": case "атака": case "скорость_атаки":
                return 3;
            case "health": case "hp": case "здоровье":
                return 4;
            default:
                return -1;
        }
    }

    /** Разбирает "speed2 armor1" (имя эффекта и уровень, через пробел или запятую). Ошибка: IllegalArgumentException с пояснением. */
    public static int[] parse(String text) {
        int[] r = new int[SphereEffect.COUNT];
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("^([\\p{L}_]+?)(\\d*)$");
        for (String tok : text.toLowerCase(java.util.Locale.ROOT).split("[\\s,]+")) {
            if (tok.isEmpty()) {
                continue;
            }
            java.util.regex.Matcher m = p.matcher(tok);
            int idx = m.matches() ? effectIndex(m.group(1)) : -1;
            if (idx < 0) {
                throw new IllegalArgumentException("Не понял эффект \"" + tok + "\". Есть: speed, damage, armor, attack_speed, health (например armor2)");
            }
            int level = m.group(2).isEmpty() ? 1 : Integer.parseInt(m.group(2));
            if (level < 1 || level > 10) {
                throw new IllegalArgumentException("Уровень эффекта \"" + tok + "\" должен быть от 1 до 10");
            }
            r[idx] = Math.max(r[idx], level);
        }
        if (points(r) == 0) {
            throw new IllegalArgumentException("Не указан ни один эффект");
        }
        return r;
    }

    /** Полный набор (команда /arsenal list и выдача). */
    public static void addCreativeStacks(List<ItemStack> out) {
        VI[][] groups = {{Arsenal.SPHERE_COMMON}, {Arsenal.SPHERE_EPIC}, {Arsenal.SPHERE_LEGENDARY},
                {Arsenal.TALISMAN_COMMON}, {Arsenal.TALISMAN}, {Arsenal.TALISMAN_LEGENDARY}};
        int[] lvls = {1, 2, 3, 1, 2, 3};
        for (int g = 0; g < groups.length; g++) {
            for (SphereEffect e : SphereEffect.values()) {
                out.add(stack(groups[g][0], one(e, lvls[g])));
            }
        }
        // три мифические: урон 3 + броня 2, броня 3 + урон 2, броня 3 + скорость 2
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(0, 3, 2, 0, 0)));
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(0, 2, 3, 0, 0)));
        out.add(stack(Arsenal.SPHERE_MYTHIC, v(2, 0, 3, 0, 0)));
        out.add(Arsenal.SPHERE_FLASH.stack());
        out.add(Arsenal.SPHERE_CERBERUS.stack());
        out.add(Arsenal.SPHERE_STINGER.stack());
        out.add(Arsenal.SPHERE_ETERNITY.stack());
        out.add(Arsenal.SPHERE_ARMORTALITY.stack());
        out.add(Arsenal.SPHERE_IMMORTALITY.stack());
        out.add(Arsenal.TALISMAN_STINGER.stack());
        out.add(Arsenal.TALISMAN_ETERNITY.stack());
        out.add(Arsenal.TALISMAN_INFINITY.stack());
        out.add(Arsenal.TALISMAN_DRAGON.stack());
    }
}
