package com.arsenal.sphere;

import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

/** Выдаёт эффекты сферы/талисмана из левой руки через атрибуты (в обход зелий). */
public final class SphereEffects {
    private SphereEffects() {
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            update(player);
        }
    }

    private static void update(PlayerEntity player) {
        ItemStack off = player.getOffHandStack();
        boolean mine = Spheres.isEffectItem(off);

        for (SphereEffect effect : SphereEffect.values()) {
            apply(player, effect, mine ? Spheres.amount(off, effect) : 0.0);
        }
    }

    private static void apply(PlayerEntity player, SphereEffect effect, double wanted) {
        EntityAttributeInstance instance = player.getAttributeInstance(effect.attribute);
        if (instance == null) {
            return;
        }
        EntityAttributeModifier current = instance.getModifier(effect.uuid);

        if (wanted <= 0.0) {
            if (current != null) {
                instance.removeModifier(current);
            }
            return;
        }
        if (current != null) {
            if (current.getValue() == wanted) {
                return;
            }
            instance.removeModifier(current);
        }
        instance.addTemporaryModifier(new EntityAttributeModifier(
                effect.uuid, "arsenal_" + effect.id, wanted, effect.operation));
    }
}
