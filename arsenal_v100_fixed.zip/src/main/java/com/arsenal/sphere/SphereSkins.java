package com.arsenal.sphere;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Скины голов-сфер. Сейчас стоят ЗАГЛУШКИ (у каждого вида своя "придуманная" текстура, в игре это обычный скин).
 * Настоящие значения (Value из textures головы, строка base64) можно вписать БЕЗ перекомпиляции
 * в файл config/arsenal_sphere_skins.json: {"sphere_common": "eyJ0ZXh0dXJlcyI6...", "sphere_epic": "..."}
 * или заменить в коде значения PLACEHOLDER_HASH.
 */
public final class SphereSkins {
    private static final Map<String, String> OVERRIDE = new HashMap<>();
    private static boolean loaded = false;

    private SphereSkins() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_sphere_skins.json");
    }

    private static synchronized void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        try (java.io.InputStream in = SphereSkins.class.getResourceAsStream("/arsenal_sphere_skins_default.json")) {
            if (in != null) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                }
                JsonObject def = new JsonParser().parse(new String(bo.toByteArray(), StandardCharsets.UTF_8)).getAsJsonObject();
                for (Map.Entry<String, JsonElement> e : def.entrySet()) {
                    OVERRIDE.put(e.getKey(), e.getValue().getAsString());
                }
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать встроенные скины: " + ex);
        }
        try {
            Path f = file();
            if (!Files.exists(f)) {
                JsonObject example = new JsonObject();
                example.addProperty("sphere_common", "");
                Files.write(f, example.toString().getBytes(StandardCharsets.UTF_8));
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : root.entrySet()) {
                String v = e.getValue().getAsString();
                if (!v.isEmpty()) {
                    OVERRIDE.put(e.getKey(), v);
                }
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать arsenal_sphere_skins.json: " + ex);
        }
    }

    /** Заглушка: выдуманный хеш текстуры (клиент не найдёт её и покажет обычную голову). */
    private static String placeholderValue(String id) {
        String hash = Integer.toHexString(id.hashCode());
        StringBuilder sb = new StringBuilder();
        while (sb.length() < 64) {
            sb.append(hash);
        }
        String json = "{\"textures\":{\"SKIN\":{\"url\":\"http://textures.minecraft.net/texture/" + sb.substring(0, 64) + "\"}}}";
        return java.util.Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    /** Записывает владельца головы (SkullOwner) с нужной текстурой. */
    public static void apply(ItemStack stack, String id) {
        load();
        String value = OVERRIDE.containsKey(id) ? OVERRIDE.get(id) : placeholderValue(id);
        UUID uuid = UUID.nameUUIDFromBytes(("arsenal:" + id).getBytes(StandardCharsets.UTF_8));
        NbtCompound owner = new NbtCompound();
        long most = uuid.getMostSignificantBits();
        long least = uuid.getLeastSignificantBits();
        owner.putIntArray("Id", new int[]{(int) (most >> 32), (int) most, (int) (least >> 32), (int) least});
        owner.putString("Name", "arsenal_" + id);
        NbtCompound props = new NbtCompound();
        NbtList textures = new NbtList();
        NbtCompound tex = new NbtCompound();
        tex.putString("Value", value);
        textures.add(tex);
        props.put("textures", textures);
        owner.put("Properties", props);
        stack.getOrCreateTag().put("SkullOwner", owner);
    }
}
