package com.arsenal.sphere;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.Random;

/** Проклятые утраты: сферы Flash и Cerberus при смерти пропадают с шансом 50%, иначе остаются. */
public final class CurseOfLoss {
    private CurseOfLoss() {
    }

    public static void onDeath(ServerPlayerEntity player) {
        Random rnd = new Random();
        drop(player, player.inventory.main, rnd);
        drop(player, player.inventory.offHand, rnd);
        drop(player, player.inventory.armor, rnd);
    }

    private static void drop(ServerPlayerEntity player, List<ItemStack> list, Random rnd) {
        for (int i = 0; i < list.size(); i++) {
            ItemStack s = list.get(i);
            if (s.isEmpty() || !Spheres.isCursed(s)) {
                continue;
            }
            int count = s.getCount();
            int dropped = 0;
            for (int k = 0; k < count; k++) {
                if (rnd.nextBoolean()) {
                    dropped++;
                }
            }
            if (dropped > 0) {
                s.decrement(dropped); // исчезают насовсем
            }
        }
    }
}
