package com.arsenal.sphere;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.Random;

/** Проклятые утраты: сферы Flash и Cerberus при смерти выпадают с шансом 50%, иначе остаются у игрока. */
public final class CurseOfLoss {
    private CurseOfLoss() {
    }

    public static void onDeath(ServerPlayerEntity player) {
        if (!player.world.getGameRules().getBoolean(net.minecraft.world.GameRules.KEEP_INVENTORY)) {
            return; // без keepInventory и так выпадает всё
        }
        Random rnd = new Random();
        drop(player, player.inventory.main, rnd);
        drop(player, player.inventory.offHand, rnd);
        drop(player, player.inventory.armor, rnd);
    }

    private static void drop(ServerPlayerEntity player, List<ItemStack> list, Random rnd) {
        for (int i = 0; i < list.size(); i++) {
            ItemStack s = list.get(i);
            if (s.isEmpty() || !Spheres.isCursed(s)) {
                continue;
            }
            int count = s.getCount();
            int dropped = 0;
            for (int k = 0; k < count; k++) {
                if (rnd.nextBoolean()) {
                    dropped++;
                }
            }
            if (dropped > 0) {
                ItemStack out = s.copy();
                out.setCount(dropped);
                player.dropItem(out, true, false);
                s.decrement(dropped);
            }
        }
    }
}
