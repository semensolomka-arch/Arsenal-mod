package com.arsenal.sync;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Страховка от "залипшего" инвентаря. Если меню закрыли или открыли прямо во время клика, сервер помечает окно
 * игрока заблокированным (ждёт подтверждения от клиента), а подтверждение приходит от другого окна и не принимается.
 * Тогда сервер молча игнорирует клики игрока по вещам: броня "снимается" только на экране, предметы не выбрасываются,
 * в руке остаётся прежнее. Обычная блокировка длится доли секунды, поэтому, если окно заблокировано три проверки
 * подряд (3 секунды), блокировка снимается, а инвентарь отправляется клиенту заново.
 *
 * Список заблокированных игроков в ScreenHandler приватный, а имена его методов зависят от маппингов,
 * поэтому поле ищется по типу (Set игроков) и правится через рефлексию.
 */
public final class Unstick {
    private static final Map<UUID, Integer> STUCK = new HashMap<>();
    private static Field restricted;

    static {
        try {
            for (Field f : ScreenHandler.class.getDeclaredFields()) {
                if (Set.class.isAssignableFrom(f.getType()) && f.getGenericType() instanceof ParameterizedType) {
                    Type[] args = ((ParameterizedType) f.getGenericType()).getActualTypeArguments();
                    if (args.length == 1 && args[0] == PlayerEntity.class) {
                        f.setAccessible(true);
                        restricted = f;
                        break;
                    }
                }
            }
        } catch (Throwable t) {
            restricted = null;
        }
        if (restricted == null) {
            System.err.println("[Arsenal] Unstick: не найден список заблокированных игроков, страховка отключена");
        }
    }

    private Unstick() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(Unstick::tick);
    }

    private static Set<?> set(ScreenHandler handler) {
        try {
            return (Set<?>) restricted.get(handler);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void tick(MinecraftServer server) {
        if (restricted == null || server.getTicks() % 20 != 0) {
            return;
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ScreenHandler current = p.currentScreenHandler;
            Set<?> cs = current == null ? null : set(current);
            Set<?> ps = set(p.playerScreenHandler);
            boolean stuck = cs != null && cs.contains(p) || ps != null && ps.contains(p);
            if (!stuck) {
                STUCK.remove(p.getUuid());
                continue;
            }
            int n = STUCK.merge(p.getUuid(), 1, Integer::sum);
            if (n >= 3) {
                STUCK.remove(p.getUuid());
                if (cs != null) {
                    cs.remove(p);
                }
                if (ps != null) {
                    ps.remove(p);
                }
                if (current != null && p.networkHandler != null) {
                    p.onHandlerRegistered(current, current.getStacks());
                }
            }
        }
    }
}
