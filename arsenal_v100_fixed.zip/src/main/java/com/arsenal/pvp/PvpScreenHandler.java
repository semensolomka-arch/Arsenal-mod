package com.arsenal.pvp;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

/** Меню-сундук для /pvp: предметы взять нельзя, клик по слоту обрабатывает Click. */
public class PvpScreenHandler extends GenericContainerScreenHandler {
    public interface Click {
        /** button: 0 = ЛКМ, 1 = ПКМ. */
        void click(ServerPlayerEntity player, int slot, int button);
    }

    private final int size;
    private final Click click;

    public PvpScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu, int rows, Click click) {
        super(rows == 3 ? ScreenHandlerType.GENERIC_9X3 : ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, menu, rows);
        this.size = rows * 9;
        this.click = click;
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < size) {
            if ((actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)
                    && player instanceof ServerPlayerEntity && click != null) {
                // Действие выполняем после обработки клика: если меню закрыть прямо внутри клика, сервер помечает
                // инвентарь игрока "заблокированным" и потом молча игнорирует все его действия с вещами
                // (броня не снимается, предметы не выкладываются и не выбрасываются, а в руке остаётся старое).
                final ServerPlayerEntity sp = (ServerPlayerEntity) player;
                final Click cb = click;
                final int slot = slotIndex;
                final int data = clickData;
                if (sp.getServer() != null) {
                    sp.getServer().execute(() -> cb.click(sp, slot, data));
                }
            }
            return ItemStack.EMPTY;
        }
        if (actionType == SlotActionType.QUICK_MOVE
                || actionType == SlotActionType.PICKUP_ALL
                || actionType == SlotActionType.QUICK_CRAFT) {
            return ItemStack.EMPTY;
        }
        return super.onSlotClick(slotIndex, clickData, actionType, player);
    }
}
