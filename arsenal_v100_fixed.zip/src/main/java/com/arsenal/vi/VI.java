package com.arsenal.vi;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Consumer;

/**
 * "Виртуальный предмет": ванильный предмет-основа + метка ArsenalId в NBT.
 * Клиенту ничего не нужно знать про мод: название и описание лежат прямо в NBT (display),
 * текстура ванильная. Вся логика (ПКМ, запреты) на сервере, см. ViEvents.
 */
public final class VI {
    public static final String TAG = "ArsenalId";
    public static final String UID = "ArsenalUid";
    /** Метка строк описания, которыми управляет мод (их можно безопасно пересобрать). */
    public static final String MARK = "arsenal";
    /** Метка строк с названиями зачарований мода. */
    public static final String MARK_ENCH = "arsenal_ench";
    private static final Random RNG = new Random();
    private static final Map<String, VI> BY_ID = new LinkedHashMap<>();

    /** Действие по ПКМ. true = сработало (предмет потрачен внутри). */
    public interface Action {
        boolean run(ServerPlayerEntity player, ItemStack stack);
    }

    public interface NameFn {
        Text name(ItemStack stack);
    }

    public interface LoreFn {
        List<Text> lore(ItemStack stack);
    }

    public final String id;
    public final Item base;
    public NameFn nameFn;
    public LoreFn loreFn;
    /** Всегда выглядит зачарованным. */
    public boolean glint;
    /** Оставить ванильное поведение (питьё зелья, установка блока). Иначе ПКМ ванильного вида отменяется. */
    public boolean vanillaUse;
    /** Никогда не стакается (в стаке один предмет): к NBT добавляется случайный номер. */
    public boolean unique;
    public Action action;
    /** Общая группа кулдауна (по умолчанию id). */
    public String cdGroup;
    /** Показывать кулдаун на ванильной основе (только если основа больше нигде не нужна). */
    public boolean visualCd;
    public Consumer<ItemStack> init;
    /** Блок, который ставится из этого предмета (TNT, наковальня): позиция запоминается в Marks. */
    public net.minecraft.block.Block placeBlock;
    /** Ванильное использование (питьё) запрещено, пока идёт кулдаун. */
    public boolean blockWhileCooling;

    private VI(String id, Item base) {
        this.id = id;
        this.base = base;
        this.cdGroup = id;
    }

    public static VI register(String id, Item base) {
        VI vi = new VI(id, base);
        BY_ID.put(id, vi);
        return vi;
    }

    public static VI byId(String id) {
        return id == null ? null : BY_ID.get(id);
    }

    public static Collection<VI> all() {
        return BY_ID.values();
    }

    /** Предмет мода по метке в NBT или null, если это обычный предмет. */
    public static VI of(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()) {
            return null;
        }
        NbtCompound tag = stack.getTag();
        if (tag == null || !tag.contains(TAG, 8)) {
            return null;
        }
        return BY_ID.get(tag.getString(TAG));
    }

    public boolean is(ItemStack stack) {
        return of(stack) == this;
    }

    // ---------- настройка (цепочкой) ----------

    public VI name(NameFn fn) {
        this.nameFn = fn;
        return this;
    }

    public VI lore(LoreFn fn) {
        this.loreFn = fn;
        return this;
    }

    public VI glint(boolean g) {
        this.glint = g;
        return this;
    }

    public VI vanillaUse(boolean v) {
        this.vanillaUse = v;
        return this;
    }

    public VI unique(boolean u) {
        this.unique = u;
        return this;
    }

    public VI action(Action a) {
        this.action = a;
        return this;
    }

    public VI cdGroup(String g) {
        this.cdGroup = g;
        return this;
    }

    public VI visualCd(boolean v) {
        this.visualCd = v;
        return this;
    }

    public VI placeBlock(net.minecraft.block.Block b) {
        this.placeBlock = b;
        return this;
    }

    public VI blockWhileCooling(boolean b) {
        this.blockWhileCooling = b;
        return this;
    }

    public VI init(Consumer<ItemStack> c) {
        this.init = c;
        return this;
    }

    // ---------- создание предметов ----------

    public ItemStack stack() {
        return stack(1);
    }

    public ItemStack stack(int count) {
        ItemStack s = new ItemStack(base, count);
        NbtCompound tag = s.getOrCreateTag();
        tag.putString(TAG, id);
        if (unique) {
            tag.putLong(UID, RNG.nextLong());
        }
        if (init != null) {
            init.accept(s);
        }
        refresh(s);
        return s;
    }

    /** Пересобирает название, описание и блеск по данным на предмете. */
    public static void refresh(ItemStack stack) {
        VI vi = of(stack);
        if (vi == null) {
            return;
        }
        NbtCompound display = stack.getOrCreateSubTag("display");
        if (vi.nameFn != null) {
            Text name = vi.nameFn.name(stack);
            if (name != null) {
                MutableText root = new LiteralText("").setStyle(Style.EMPTY.withItalic(false));
                root.append(name);
                display.putString("Name", Text.Serializer.toJson(root));
            }
        }
        List<Text> lines = vi.loreFn == null ? new ArrayList<>() : vi.loreFn.lore(stack);
        setManagedLore(stack, lines);
        NbtCompound tag = stack.getOrCreateTag();
        if (vi.glint && !tag.contains("Enchantments", 9)) {
            // пустое зачарование нужно только ради блеска; его строку в подсказке прячет флаг 1
            NbtList list = new NbtList();
            list.add(new NbtCompound());
            tag.put("Enchantments", list);
            tag.putInt("HideFlags", tag.getInt("HideFlags") | 1);
        }
    }

    /** Заменяет строки описания, которыми управляет мод; чужие строки остаются на месте. */
    public static void setManagedLore(ItemStack stack, List<Text> lines) {
        setManagedLore(stack, MARK, lines);
    }

    public static void setManagedLore(ItemStack stack, String mark, List<Text> lines) {
        NbtCompound display = stack.getOrCreateSubTag("display");
        NbtList old = display.contains("Lore", 9) ? display.getList("Lore", 8) : new NbtList();
        NbtList fresh = new NbtList();
        for (int i = 0; i < old.size(); i++) {
            String json = old.getString(i);
            if (!json.contains("\"insertion\":\"" + mark + "\"")) {
                fresh.add(NbtString.of(json));
            }
        }
        for (Text line : lines) {
            MutableText root = new LiteralText("").setStyle(Style.EMPTY.withItalic(false).withInsertion(mark));
            root.append(line);
            fresh.add(NbtString.of(Text.Serializer.toJson(root)));
        }
        if (fresh.isEmpty()) {
            display.remove("Lore");
        } else {
            display.put("Lore", fresh);
        }
    }
}
