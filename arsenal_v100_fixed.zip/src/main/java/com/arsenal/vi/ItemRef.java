package com.arsenal.vi;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

/** Ссылка на предмет по id из старых конфигов: arsenal:trap это предмет мода, остальное обычные предметы. */
public final class ItemRef {
    public final VI vi;
    public final Item item;

    private ItemRef(VI vi, Item item) {
        this.vi = vi;
        this.item = item;
    }

    /** null, если такого предмета нет. */
    public static ItemRef of(String id) {
        Identifier ident = Identifier.tryParse(id);
        if (ident == null) {
            return null;
        }
        if ("arsenal".equals(ident.getNamespace())) {
            VI vi = VI.byId(ident.getPath());
            if (vi == null && "trap_slab".equals(ident.getPath())) {
                return null;
            }
            if (vi != null) {
                return new ItemRef(vi, vi.base);
            }
        }
        Item item = Registry.ITEM.getOrEmpty(ident).orElse(null);
        return item == null ? null : new ItemRef(null, item);
    }

    public int maxCount() {
        if (vi != null) {
            return vi.unique ? 1 : vi.base.getMaxCount();
        }
        return item.getMaxCount();
    }

    public ItemStack stack(int count) {
        return vi != null ? vi.stack(count) : new ItemStack(item, count);
    }
}
