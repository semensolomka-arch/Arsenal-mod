package com.arsenal.vi;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Ванильный клиент не знает зачарований мода и не покажет их в подсказке.
 * Поэтому названия зачарований мода дописываются в описание предмета (строки с меткой arsenal_ench).
 */
public final class EnchantLore {
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private EnchantLore() {
    }

    public static String roman(int level) {
        return level >= 1 && level < ROMAN.length ? ROMAN[level] : String.valueOf(level);
    }

    public static void refresh(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()) {
            return;
        }
        List<Text> lines = new ArrayList<>();
        Map<Enchantment, Integer> map = EnchantmentHelper.get(stack);
        for (Map.Entry<Enchantment, Integer> e : map.entrySet()) {
            Identifier id = Registry.ENCHANTMENT.getId(e.getKey());
            if (id == null || !"arsenal".equals(id.getNamespace())) {
                continue;
            }
            String name = Lang.get("enchantment.arsenal." + id.getPath());
            lines.add(new LiteralText(name + " " + roman(e.getValue())).formatted(Formatting.GRAY));
        }
        boolean had = stack.getTag().contains("display", 10)
                && stack.getTag().getCompound("display").contains("Lore", 9);
        if (lines.isEmpty() && !had) {
            return;
        }
        VI.setManagedLore(stack, VI.MARK_ENCH, lines);
    }
}
