package com.arsenal.vi;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Ванильный клиент не знает зачарований мода и не покажет их в подсказке.
 * Поэтому названия зачарований мода дописываются в описание предмета (строки с меткой arsenal_ench).
 */
public final class EnchantLore {
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII"};

    private EnchantLore() {
    }

    public static String roman(int level) {
        return level >= 1 && level < ROMAN.length ? ROMAN[level] : String.valueOf(level);
    }

    public static void refresh(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()) {
            return;
        }
        fixGlint(stack);
        List<Text> lines = new ArrayList<>();
        Map<Enchantment, Integer> map = EnchantmentHelper.get(stack);
        for (Map.Entry<Enchantment, Integer> e : map.entrySet()) {
            Identifier id = Registry.ENCHANTMENT.getId(e.getKey());
            if (id == null || !"arsenal".equals(id.getNamespace())) {
                continue;
            }
            String name = Lang.get("enchantment.arsenal." + id.getPath());
            lines.add(new LiteralText(name + " " + roman(e.getValue())).formatted(Formatting.GRAY));
        }
        boolean had = stack.getTag().contains("display", 10)
                && stack.getTag().getCompound("display").contains("Lore", 9);
        if (lines.isEmpty() && !had) {
            return;
        }
        VI.setManagedLore(stack, VI.MARK_ENCH, lines);
    }

    /**
     * Предметы с блеском получают пустое "зачарование" и флаг скрытия чар (иначе строка пустого чара видна).
     * Если у предмета появились настоящие чары, пустышка и флаг убираются, иначе ванильные чары в подсказке скрыты.
     */
    private static void fixGlint(ItemStack stack) {
        VI vi = VI.of(stack);
        if (vi == null || !vi.glint) {
            return;
        }
        net.minecraft.nbt.NbtCompound tag = stack.getTag();
        if (tag == null || !tag.contains("Enchantments", 9)) {
            return;
        }
        net.minecraft.nbt.NbtList list = tag.getList("Enchantments", 10);
        boolean real = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.getCompound(i).contains("id")) {
                real = true;
                break;
            }
        }
        if (!real) {
            return;
        }
        for (int i = list.size() - 1; i >= 0; i--) {
            if (!list.getCompound(i).contains("id")) {
                list.remove(i);
            }
        }
        tag.putInt("HideFlags", tag.getInt("HideFlags") & ~1);
    }
}
