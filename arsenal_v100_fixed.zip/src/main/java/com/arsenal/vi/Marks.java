package com.arsenal.vi;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Какие из поставленных ванильных блоков (TNT, наковальня) на самом деле предметы мода.
 * Ключ: измерение|x|y|z, значение: id предмета (для наковальни ещё через двоеточие направление).
 * Хранится в config/arsenal_marks.json.
 */
public final class Marks {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, String> MAP = new HashMap<>();
    private static boolean dirty = false;

    private Marks() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_marks.json");
    }

    public static String key(World world, BlockPos pos) {
        return world.getRegistryKey().getValue().toString() + "|" + pos.getX() + "|" + pos.getY() + "|" + pos.getZ();
    }

    public static void put(World world, BlockPos pos, String value) {
        MAP.put(key(world, pos), value);
        dirty = true;
    }

    /** Значение метки или null. */
    public static String get(World world, BlockPos pos) {
        return MAP.get(key(world, pos));
    }

    /** Только id предмета (без направления). */
    public static String idAt(World world, BlockPos pos) {
        String v = get(world, pos);
        if (v == null) {
            return null;
        }
        int i = v.indexOf(':');
        return i < 0 ? v : v.substring(0, i);
    }

    public static void remove(World world, BlockPos pos) {
        if (MAP.remove(key(world, pos)) != null) {
            dirty = true;
        }
    }

    /** Все метки (копия), чтобы можно было перебирать и менять. */
    public static Map<String, String> snapshot() {
        return new HashMap<>(MAP);
    }

    public static void load() {
        MAP.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, com.google.gson.JsonElement> e : root.entrySet()) {
                MAP.put(e.getKey(), e.getValue().getAsString());
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать arsenal_marks.json: " + ex);
        }
        dirty = false;
    }

    public static void save() {
        if (!dirty) {
            return;
        }
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<String, String> e : MAP.entrySet()) {
                root.addProperty(e.getKey(), e.getValue());
            }
            Files.write(file(), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
            dirty = false;
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось сохранить arsenal_marks.json: " + ex);
        }
    }

    /** Убирает метки там, где блока уже нет (взорвали, сломали поршнем и т.п.). */
    public static void validate(MinecraftServer server) {
        Iterator<Map.Entry<String, String>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, String> e = it.next();
            String[] p = e.getKey().split("\\|");
            if (p.length != 4) {
                it.remove();
                dirty = true;
                continue;
            }
            ServerWorld world = null;
            for (ServerWorld w : server.getWorlds()) {
                if (w.getRegistryKey().getValue().toString().equals(p[0])) {
                    world = w;
                    break;
                }
            }
            if (world == null) {
                continue;
            }
            BlockPos pos;
            try {
                pos = new BlockPos(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
            } catch (NumberFormatException ex) {
                it.remove();
                dirty = true;
                continue;
            }
            if (!world.isChunkLoaded(pos)) {
                continue;
            }
            String id = e.getValue();
            int i = id.indexOf(':');
            VI vi = VI.byId(i < 0 ? id : id.substring(0, i));
            if (vi == null || vi.placeBlock == null || !world.getBlockState(pos).isOf(vi.placeBlock)
                    && !isAnvilFamily(vi, world.getBlockState(pos).getBlock())) {
                it.remove();
                dirty = true;
            }
        }
    }

    private static boolean isAnvilFamily(VI vi, net.minecraft.block.Block b) {
        return vi.placeBlock == net.minecraft.block.Blocks.ANVIL
                && (b == net.minecraft.block.Blocks.ANVIL || b == net.minecraft.block.Blocks.CHIPPED_ANVIL
                || b == net.minecraft.block.Blocks.DAMAGED_ANVIL);
    }
}
