package com.arsenal.vi;

import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Клиент ванильный и сам "угадывает" результат ПКМ (бросил жемчуг, поставил блок, начал пить),
 * а сервер это отменяет. После отмены отправляем игроку настоящее содержимое инвентаря.
 */
public final class Resync {
    private Resync() {
    }

    private static final java.util.Set<ServerPlayerEntity> LATER = new java.util.LinkedHashSet<>();

    /** Отправить инвентарь в конце тика (после того как сервер закончил менять стак): зелья и еда не "залипают". */
    public static void later(ServerPlayerEntity p) {
        LATER.add(p);
    }

    public static void init() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!LATER.isEmpty()) {
                for (ServerPlayerEntity p : LATER) {
                    inventory(p);
                }
                LATER.clear();
            }
        });
    }

    public static void inventory(ServerPlayerEntity p) {
        if (p == null || p.networkHandler == null) {
            return;
        }
        ScreenHandler h = p.currentScreenHandler;
        p.networkHandler.sendPacket(new InventoryS2CPacket(h.syncId, h.getStacks()));
        p.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(-1, -1, p.inventory.getCursorStack()));
    }
}
