package com.arsenal.vi;

import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Клиент ванильный и сам "угадывает" результат ПКМ (бросил жемчуг, поставил блок, начал пить),
 * а сервер это отменяет. После отмены отправляем игроку настоящее содержимое инвентаря.
 */
public final class Resync {
    private Resync() {
    }

    public static void inventory(ServerPlayerEntity p) {
        if (p == null || p.networkHandler == null) {
            return;
        }
        ScreenHandler h = p.currentScreenHandler;
        p.networkHandler.sendPacket(new InventoryS2CPacket(h.syncId, h.getStacks()));
        p.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(-1, -1, p.inventory.getCursorStack()));
    }
}
