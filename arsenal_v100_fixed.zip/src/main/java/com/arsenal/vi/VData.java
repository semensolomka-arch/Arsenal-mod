package com.arsenal.vi;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

/** Числовые данные предмета мода (уровни сфер, эффекты артефакта, руны) лежат в NBT: ArsenalData. */
public final class VData {
    public static final String KEY = "ArsenalData";

    private VData() {
    }

    public static int get(ItemStack stack, String key) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }
        NbtCompound tag = stack.getTag();
        if (tag == null || !tag.contains(KEY, 10)) {
            return 0;
        }
        return tag.getCompound(KEY).getInt(key);
    }

    public static void set(ItemStack stack, String key, int value) {
        if (value <= 0) {
            NbtCompound tag = stack.getTag();
            if (tag != null && tag.contains(KEY, 10)) {
                NbtCompound d = tag.getCompound(KEY);
                d.remove(key);
                if (d.isEmpty()) {
                    tag.remove(KEY);
                }
            }
        } else {
            stack.getOrCreateSubTag(KEY).putInt(key, value);
        }
        VI.refresh(stack);
    }
}
