package com.arsenal.vi;

import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Кулдауны предметов мода. Ванильный кулдаун привязан к виду предмета (а у нас у многих предметов
 * одна основа), поэтому время хранится отдельно по группе. Для предметов с редкой основой
 * (трапка, стан) дополнительно показывается ванильная "заливка" в хотбаре.
 */
public final class Cd {
    private static final Map<UUID, Map<String, Long>> MAP = new HashMap<>();

    private Cd() {
    }

    /** Сколько тиков осталось (0 = можно). */
    public static int left(PlayerEntity p, VI vi) {
        Map<String, Long> m = MAP.get(p.getUuid());
        if (m == null) {
            return 0;
        }
        Long until = m.get(vi.cdGroup);
        if (until == null) {
            return 0;
        }
        long left = until - p.world.getTime();
        return left <= 0 ? 0 : (int) left;
    }

    public static boolean is(PlayerEntity p, VI vi) {
        return left(p, vi) > 0;
    }

    public static void set(PlayerEntity p, VI vi, int ticks) {
        if (ticks <= 0) {
            return;
        }
        MAP.computeIfAbsent(p.getUuid(), u -> new HashMap<>()).put(vi.cdGroup, p.world.getTime() + ticks);
        for (VI other : VI.all()) {
            if (other.visualCd && other.cdGroup.equals(vi.cdGroup)) {
                p.getItemCooldownManager().set(other.base, ticks);
            }
        }
    }

    /** Сбрасывает кулдауны игрока (вход в хаб). */
    public static void clear(PlayerEntity p) {
        MAP.remove(p.getUuid());
    }

    public static void clearAll() {
        MAP.clear();
    }
}
