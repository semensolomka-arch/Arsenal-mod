package com.arsenal.vi;

import com.arsenal.Arsenal;
import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.sphere.SphereEffect;
import com.arsenal.sphere.Spheres;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * /arsenal give &lt;предмет&gt; [количество] и /arsenal list: выдача предметов мода (раньше они лежали во вкладке креатива,
 * а без клиентской части вкладки нет). Только для операторов.
 */
public final class ArsenalCommand {
    private ArsenalCommand() {
    }

    private static Map<String, Supplier<ItemStack>> catalog() {
        Map<String, Supplier<ItemStack>> m = new LinkedHashMap<>();
        for (VI vi : VI.all()) {
            m.put(vi.id, vi::stack);
        }
        for (int l = 2; l <= 13; l++) {
            final int lv = l;
            m.put("farm_sword_" + l, () -> com.arsenal.create.FarmItems.sword(lv));
        }
        for (int l = 2; l <= 5; l++) {
            final int lv = l;
            m.put("fermer_book_" + l, () -> com.arsenal.create.FarmItems.fermerBook(lv));
        }
        m.put("infinity_sword", Arsenal::infinitySword);
        m.put("cerberus_sword", Arsenal::cerberusSword);
        m.put("eternity_sword", Arsenal::eternitySword);
        m.put("stinger_sword", Arsenal::stingerSword);
        m.put("artifact_full", ArtifactEffects::fullArtifact);
        // вещи из китов по одной: kit_dragon_sword, kit_stinger_pickaxe, kit_infinity_helmet, kit_sun_helmet ...
        String[] kits = {"wither", "kraken", "dragon", "stinger", "eternity", "infinity", "ghast", "mustang", "griefer", "sun"};
        String[] parts = {"helmet", "chestplate", "leggings", "boots", "sword", "trident", "bow", "crossbow",
                "pickaxe", "axe", "shovel", "armor_elytra", "unbreakable_elytra"};
        for (String kit : kits) {
            for (String part : parts) {
                if (com.arsenal.kit.KitCommand.lootGear(kit, part) != null) {
                    final String k = kit;
                    final String p = part;
                    m.put("kit_" + kit + "_" + part, () -> com.arsenal.kit.KitCommand.lootGear(k, p));
                }
            }
        }
        VI[] withLevel = {Arsenal.SPHERE_COMMON, Arsenal.SPHERE_EPIC, Arsenal.SPHERE_LEGENDARY,
                Arsenal.TALISMAN_COMMON, Arsenal.TALISMAN, Arsenal.TALISMAN_LEGENDARY};
        int[] lvls = {1, 2, 3, 1, 2, 3};
        for (int i = 0; i < withLevel.length; i++) {
            for (SphereEffect e : SphereEffect.values()) {
                final VI vi = withLevel[i];
                final int level = lvls[i];
                final SphereEffect effect = e;
                m.put(vi.id + "_" + e.id, () -> {
                    int[] l = new int[SphereEffect.COUNT];
                    l[effect.ordinal()] = level;
                    return Spheres.stack(vi, l);
                });
            }
        }
        m.put("sphere_mythic_1", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(0, 3, 2, 0, 0)));
        m.put("sphere_mythic_2", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(0, 2, 3, 0, 0)));
        m.put("sphere_mythic_3", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(2, 0, 3, 0, 0)));
        return m;
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("amenu").requires(src -> src.hasPermissionLevel(2))
                        .executes(ctx -> com.arsenal.MenuBridge.openFor(ctx.getSource().getPlayer()))));
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("arsenal")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("list").executes(ctx -> {
                            StringBuilder sb = new StringBuilder();
                            for (String id : catalog().keySet()) {
                                if (sb.length() > 0) {
                                    sb.append(", ");
                                }
                                sb.append(id);
                            }
                            ctx.getSource().sendFeedback(new LiteralText(sb.toString()).formatted(Formatting.GRAY), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("menu")
                                .executes(ctx -> com.arsenal.MenuBridge.openFor(ctx.getSource().getPlayer())))
                        .then(settingsNode())
                        .then(CommandManager.literal("give")
                                .then(CommandManager.argument("query", StringArgumentType.greedyString())
                                        .suggests((ctx, builder) -> {
                                            String rem = builder.getRemaining();
                                            String low = rem.toLowerCase(java.util.Locale.ROOT);
                                            java.util.List<String> names = new java.util.ArrayList<>(catalog().keySet());
                                            names.addAll(russianNames().keySet());
                                            names.add("сфера на ");
                                            names.add("талисман на ");
                                            if (low.indexOf(' ') < 0 || names.stream().anyMatch(n -> n.startsWith(low) && n.length() > low.length())) {
                                                return CommandSource.suggestMatching(names, builder);
                                            }
                                            com.mojang.brigadier.suggestion.SuggestionsBuilder nb =
                                                    builder.createOffset(builder.getStart() + rem.lastIndexOf(' ') + 1);
                                            String first = low.split(" ")[0];
                                            VI fv = VI.byId(first);
                                            boolean fx = first.equals("сфера") || first.equals("талисман")
                                                    || (fv != null && com.arsenal.sphere.Spheres.tier(fv) > 0);
                                            return CommandSource.suggestMatching(fx ? effectTokens() : countTokens(), nb);
                                        })
                                        .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "query")))))));
    }

    /** Русские названия предметов (нижний регистр) -> id. */
    private static Map<String, String> russianNames() {
        Map<String, String> m = new java.util.TreeMap<>((x, y) -> x.length() != y.length() ? y.length() - x.length() : x.compareTo(y));
        for (VI vi : VI.all()) {
            for (String key : new String[]{"item.arsenal." + vi.id, "block.arsenal." + vi.id}) {
                if (com.arsenal.vi.Lang.has(key)) {
                    m.put(com.arsenal.vi.Lang.get(key).toLowerCase(java.util.Locale.ROOT).trim(), vi.id);
                }
            }
        }
        for (VI vi : VI.all()) {
            if (m.containsValue(vi.id)) {
                continue;
            }
            String nm = displayName(vi);
            if (nm != null && !nm.isEmpty()) {
                m.put(m.containsKey(nm) ? nm + " (" + vi.id + ")" : nm, vi.id);
            }
        }
        for (String key : catalog().keySet()) {
            if (key.startsWith("kit_")) {
                String rest = key.substring(4);
                int u = rest.indexOf('_');
                String kit = rest.substring(0, u);
                String part = rest.substring(u + 1);
                String pr = null;
                String kr = null;
                for (String[] x : PARTS_RU) {
                    if (x[1].equals(part)) {
                        pr = x[0];
                    }
                }
                for (String[] x : KITS_RU) {
                    if (x[1].equals(kit)) {
                        kr = x[0];
                        break;
                    }
                }
                if (pr != null && kr != null) {
                    m.put(pr + " " + kr, key);
                }
            }
        }
        return m;
    }

    private static final Map<String, String> DISPLAY = new java.util.HashMap<>();

    /** Название предмета, как его видит игрок (для предметов без записи в lang-файле). */
    private static String displayName(VI vi) {
        String cached = DISPLAY.get(vi.id);
        if (cached == null) {
            try {
                cached = vi.stack().getName().getString().toLowerCase(java.util.Locale.ROOT).trim();
            } catch (Exception ex) {
                cached = "";
            }
            DISPLAY.put(vi.id, cached);
        }
        return cached;
    }

    private static final String[][] PARTS_RU = {
            {"шлем", "helmet"}, {"нагрудник", "chestplate"}, {"поножи", "leggings"}, {"ботинки", "boots"},
            {"меч", "sword"}, {"трезубец", "trident"}, {"лук", "bow"}, {"арбалет", "crossbow"},
            {"кирка", "pickaxe"}, {"топор", "axe"}, {"лопата", "shovel"},
            {"элитры", "armor_elytra"}, {"нерушимые элитры", "unbreakable_elytra"}};
    private static final String[][] KITS_RU = {
            {"визера", "wither"}, {"кракена", "kraken"}, {"драгона", "dragon"}, {"стингер", "stinger"},
            {"этернити", "eternity"}, {"инфинити", "infinity"}, {"гаста", "ghast"}, {"мустанга", "mustang"},
            {"грифера", "griefer"}, {"солнца", "sun"}};

    /** "шлем инфинити", "кирку стингера": разбор по основам слов. null = не вещь из кита. */
    private static String parseKitItem(String low) {
        String[] t = low.split(" ");
        if (t.length < 2) {
            return null;
        }
        String[][] partStems = {{"шлем", "helmet"}, {"нагрудник", "chestplate"}, {"поножи", "leggings"}, {"ботинк", "boots"},
                {"меч", "sword"}, {"трезуб", "trident"}, {"лук", "bow"}, {"арбалет", "crossbow"},
                {"кирк", "pickaxe"}, {"топор", "axe"}, {"лопат", "shovel"}, {"элитр", "armor_elytra"}};
        String[][] kitStems = {{"визер", "wither"}, {"иссушител", "wither"}, {"кракен", "kraken"}, {"драгон", "dragon"},
                {"дракон", "dragon"}, {"стингер", "stinger"}, {"этернити", "eternity"}, {"инфинити", "infinity"},
                {"гаст", "ghast"}, {"мустанг", "mustang"}, {"гриф", "griefer"}, {"солнц", "sun"}};
        String part = null;
        String kit = null;
        for (String tok : t) {
            for (String[] x : partStems) {
                if (part == null && tok.startsWith(x[0])) {
                    part = x[1];
                }
            }
            for (String[] x : kitStems) {
                if (kit == null && tok.startsWith(x[0])) {
                    kit = x[1];
                }
            }
        }
        if (part == null || kit == null) {
            return null;
        }
        String id = "kit_" + kit + "_" + part;
        return catalog().containsKey(id) ? id : null;
    }

    private static final String[][] ALIASES = {
            {"цербера", "cerberus"}, {"цербер", "cerberus"}, {"флеша", "flash"}, {"флеш", "flash"},
            {"стингера", "stinger"}, {"стингер", "stinger"}, {"этернити", "eternity"}, {"инфинити", "infinity"},
            {"драгона", "dragon"}, {"драгон", "dragon"}, {"армортали", "armortality"}, {"иммортали", "immortality"},
            {"обычная", "common"}, {"обычный", "common"}, {"эпическая", "epic"}, {"эпический", "epic"},
            {"легендарная", "legendary"}, {"легендарный", "legendary"}, {"мифическая", "mythic"}, {"мифический", "mythic"}};

    private static String effectWord(String t) {
        switch (t) {
            case "урон": case "урона": return "damage";
            case "броня": case "брони": case "броню": return "armor";
            case "скорость": case "скорости": return "speed";
            case "атака": case "атаки": return "attack_speed";
            case "здоровье": case "здоровья": case "хп": case "макс.здоровье": return "health";
            default: return null;
        }
    }

    /** "урон 2 броня 2" -> "damage2 armor2"; "скорость атаки 3" -> "attack_speed3"; прочее проходит как есть. */
    private static String translateArgs(String text) {
        String[] t = text.trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < t.length; i++) {
            String tok = t[i];
            if (tok.isEmpty() || tok.equals("на") || tok.equals("и") || tok.equals("с") || tok.equals("+") || tok.equals("макс.")) {
                continue;
            }
            String e = effectWord(tok);
            if (e != null) {
                if (e.equals("speed") && i + 1 < t.length && (t[i + 1].equals("атаки") || t[i + 1].equals("атака"))) {
                    e = "attack_speed";
                    i++;
                }
                String lvl = "";
                if (i + 1 < t.length && t[i + 1].matches("\\d{1,2}")) {
                    lvl = t[++i];
                }
                out.append(e).append(lvl).append(' ');
            } else {
                out.append(tok).append(' ');
            }
        }
        return out.toString().trim();
    }

    private static java.util.List<String> countTokens() {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (int c = 2; c <= 64; c *= 2) {
            out.add("x" + c);
        }
        return out;
    }

    private static java.util.List<String> effectTokens() {
        java.util.List<String> out = new java.util.ArrayList<>();
        out.addAll(java.util.Arrays.asList("на", "урон", "броня", "скорость", "атака", "здоровье"));
        for (String e : new String[]{"speed", "damage", "armor", "attack_speed", "health"}) {
            for (int l = 1; l <= 5; l++) {
                out.add(e + l);
            }
        }
        for (int c = 2; c <= 64; c *= 2) {
            out.add("x" + c);
        }
        return out;
    }

    /** /arsenal settings list|get|set|reload: правка config/arsenal_settings.json прямо из игры. */
    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<ServerCommandSource> settingsNode() {
        com.mojang.brigadier.suggestion.SuggestionProvider<ServerCommandSource> keys = (ctx, b) -> {
            java.util.List<String> names = new java.util.ArrayList<>();
            for (com.arsenal.Settings.Def d : com.arsenal.Settings.defs()) {
                names.add(d.key);
            }
            return CommandSource.suggestMatching(names, b);
        };
        return CommandManager.literal("settings")
                .then(CommandManager.literal("list")
                        .executes(ctx -> listSettings(ctx.getSource(), null))
                        .then(CommandManager.argument("filter", StringArgumentType.word())
                                .executes(ctx -> listSettings(ctx.getSource(), StringArgumentType.getString(ctx, "filter")))))
                .then(CommandManager.literal("get")
                        .then(CommandManager.argument("key", StringArgumentType.word()).suggests(keys)
                                .executes(ctx -> getSetting(ctx.getSource(), StringArgumentType.getString(ctx, "key")))))
                .then(CommandManager.literal("set")
                        .then(CommandManager.argument("key", StringArgumentType.word()).suggests(keys)
                                .then(CommandManager.argument("value", IntegerArgumentType.integer())
                                        .executes(ctx -> setSetting(ctx.getSource(), StringArgumentType.getString(ctx, "key"),
                                                IntegerArgumentType.getInteger(ctx, "value"))))))
                .then(CommandManager.literal("reload").executes(ctx -> {
                    com.arsenal.Settings.load();
                    com.arsenal.Settings.apply();
                    com.arsenal.shulker.ShulkerEvent.reloadConfig();
                    com.arsenal.Settings.broadcast(ctx.getSource().getMinecraftServer());
                    ctx.getSource().sendFeedback(new LiteralText("Настройки перечитаны из config/arsenal_settings.json").formatted(Formatting.GREEN), true);
                    return 1;
                }));
    }

    private static com.arsenal.Settings.Def findDef(String key) {
        for (com.arsenal.Settings.Def d : com.arsenal.Settings.defs()) {
            if (d.key.equals(key)) {
                return d;
            }
        }
        return null;
    }

    private static int listSettings(ServerCommandSource src, String filter) {
        int n = 0;
        for (com.arsenal.Settings.Def d : com.arsenal.Settings.defs()) {
            if (filter != null && !d.key.contains(filter) && !d.label.toLowerCase().contains(filter.toLowerCase())) {
                continue;
            }
            src.sendFeedback(new LiteralText(d.key + " = " + com.arsenal.Settings.get(d.key) + " " + d.unit + "  (" + d.label + ")")
                    .formatted(Formatting.GRAY), false);
            n++;
        }
        if (n == 0) {
            src.sendError(new LiteralText("Ничего не найдено"));
        }
        return n;
    }

    private static int getSetting(ServerCommandSource src, String key) {
        com.arsenal.Settings.Def d = findDef(key);
        if (d == null) {
            src.sendError(new LiteralText("Нет настройки " + key + ". Список: /arsenal settings list"));
            return 0;
        }
        src.sendFeedback(new LiteralText(d.label + ": " + com.arsenal.Settings.get(key) + " " + d.unit
                + " (по умолчанию " + d.def + ", допустимо " + d.min + ".." + d.max + ")").formatted(Formatting.YELLOW), false);
        return 1;
    }

    private static int setSetting(ServerCommandSource src, String key, int value) {
        com.arsenal.Settings.Def d = findDef(key);
        if (d == null) {
            src.sendError(new LiteralText("Нет настройки " + key + ". Список: /arsenal settings list"));
            return 0;
        }
        Map<String, Integer> m = new LinkedHashMap<>();
        m.put(key, value);
        com.arsenal.Settings.save(m, true);
        com.arsenal.Settings.broadcast(src.getMinecraftServer());
        src.sendFeedback(new LiteralText(d.label + " = " + com.arsenal.Settings.get(key) + " " + d.unit
                + (com.arsenal.Settings.get(key) != value ? " (вне границ " + d.min + ".." + d.max + ", поправлено)" : ""))
                .formatted(Formatting.GREEN), true);
        return 1;
    }

    /**
     * /arsenal give &lt;предмет&gt; [эффекты] [xN]. Для сфер и талисманов (обычная, эпическая, легендарная, мифическая):
     * без эффектов выдаётся случайный набор по редкости, с эффектами - ровно они, например
     * /arsenal give sphere_epic speed2 или /arsenal give sphere_legendary damage2 armor1.
     */
    private static int give(ServerCommandSource src, String query) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        query = query.trim().replaceAll("\\s+", " ");
        String low = query.toLowerCase(java.util.Locale.ROOT);
        String first = low.split(" ")[0];
        String id;
        String args;
        if (catalog().containsKey(first) || VI.byId(first) != null) {
            id = first;
            args = query.substring(first.length());
        } else {
            id = null;
            args = null;
            for (Map.Entry<String, String> e : russianNames().entrySet()) {
                String n = e.getKey();
                if (low.equals(n) || low.startsWith(n + " ")) {
                    id = e.getValue();
                    args = query.substring(n.length());
                    break;
                }
            }
            if (id == null) {
                String kitId = parseKitItem(low);
                if (kitId != null) {
                    id = kitId;
                    args = "";
                }
            }
            if (id == null && (first.equals("сфера") || first.equals("талисман"))) {
                String rest = low.substring(first.length()).trim();
                String kind = first.equals("сфера") ? "sphere" : "talisman";
                String[] w = rest.isEmpty() ? new String[0] : rest.split(" ");
                if (w.length > 0) {
                    for (String[] al : ALIASES) {
                        if (w[0].equals(al[0])) {
                            String cand = kind + "_" + al[1];
                            if (kind.equals("talisman") && al[1].equals("epic")) {
                                cand = "talisman";
                            }
                            if (VI.byId(cand) != null) {
                                id = cand;
                                args = rest.substring(w[0].length());
                            }
                            break;
                        }
                    }
                }
                if (id == null) {
                    id = kind; // сфера/талисман "на ...": подбираем по сумме уровней
                    args = rest;
                }
            }
            if (id == null) {
                src.sendError(new LiteralText("Нет такого предмета: " + query + ". Список: /arsenal list"));
                return 0;
            }
        }
        args = translateArgs(args);
        if (id.equals("sphere") || id.equals("talisman")) {
            int[] lv;
            try {
                lv = com.arsenal.sphere.Spheres.parse(args.replaceAll("(^|\\s)[xх]?\\d{1,3}(?=\\s|$)", " "));
            } catch (IllegalArgumentException ex) {
                src.sendError(new LiteralText("Пример: /arsenal give сфера на урон 2 броня 2 (" + ex.getMessage() + ")"));
                return 0;
            }
            int pts = com.arsenal.sphere.Spheres.points(lv);
            if (id.equals("sphere")) {
                id = pts <= 1 ? "sphere_common" : pts == 2 ? "sphere_epic" : pts <= 4 ? "sphere_legendary" : "sphere_mythic";
            } else {
                id = pts <= 1 ? "talisman_common" : pts == 2 ? "talisman" : "talisman_legendary";
            }
        }
        Supplier<ItemStack> sup = catalog().get(id);
        VI base = VI.byId(id);
        if (sup == null && base == null) {
            src.sendError(new LiteralText("Нет такого предмета: " + id + ". Список: /arsenal list"));
            return 0;
        }
        // количество: "x5" или "5" среди слов
        int count = 1;
        StringBuilder fx = new StringBuilder();
        for (String tok : args.trim().split("\\s+")) {
            if (tok.isEmpty()) {
                continue;
            }
            String num = tok.startsWith("x") || tok.startsWith("х") ? tok.substring(1) : tok;
            if (num.matches("\\d{1,3}")) {
                count = Math.max(1, Math.min(2304, Integer.parseInt(num)));
            } else {
                fx.append(tok).append(' ');
            }
        }
        boolean tier = base != null && com.arsenal.sphere.Spheres.tier(base) > 0;
        int[] levels = null;
        if (fx.length() > 0) {
            if (!tier) {
                src.sendError(new LiteralText("Эффекты можно задавать только сферам и талисманам (обычная, эпическая, легендарная, мифическая)"));
                return 0;
            }
            try {
                levels = com.arsenal.sphere.Spheres.parse(fx.toString());
            } catch (IllegalArgumentException ex) {
                src.sendError(new LiteralText(ex.getMessage()));
                return 0;
            }
        }
        ServerPlayerEntity player = src.getPlayer();
        java.util.Random rnd = new java.util.Random();
        String what = id;
        for (int i = 0; i < count; i++) {
            ItemStack s;
            if (tier) {
                s = levels != null ? com.arsenal.sphere.Spheres.stack(base, levels) : com.arsenal.sphere.Spheres.randomFor(base, rnd);
                if (levels != null) {
                    what = id + " (" + com.arsenal.sphere.Spheres.describe(levels) + ")";
                }
            } else {
                s = sup != null ? sup.get() : base.stack();
            }
            VI vi = VI.of(s);
            if (vi != null && vi.unique && s.getMaxCount() > 1) {
                s.setCount(1);
            }
            player.giveItemStack(s);
        }
        src.sendFeedback(new LiteralText("Выдано: " + what + " x" + count).formatted(Formatting.GREEN), false);
        return count;
    }
}
