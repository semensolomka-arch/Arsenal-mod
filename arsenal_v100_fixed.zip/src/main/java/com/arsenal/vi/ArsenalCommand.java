package com.arsenal.vi;

import com.arsenal.Arsenal;
import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.sphere.SphereEffect;
import com.arsenal.sphere.Spheres;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * /arsenal give &lt;предмет&gt; [количество] и /arsenal list: выдача предметов мода (раньше они лежали во вкладке креатива,
 * а без клиентской части вкладки нет). Только для операторов.
 */
public final class ArsenalCommand {
    private ArsenalCommand() {
    }

    private static Map<String, Supplier<ItemStack>> catalog() {
        Map<String, Supplier<ItemStack>> m = new LinkedHashMap<>();
        for (VI vi : VI.all()) {
            m.put(vi.id, vi::stack);
        }
        m.put("infinity_sword", Arsenal::infinitySword);
        m.put("cerberus_sword", Arsenal::cerberusSword);
        m.put("eternity_sword", Arsenal::eternitySword);
        m.put("stinger_sword", Arsenal::stingerSword);
        m.put("artifact_full", ArtifactEffects::fullArtifact);
        // вещи из китов по одной: kit_dragon_sword, kit_stinger_pickaxe, kit_infinity_helmet, kit_sun_helmet ...
        String[] kits = {"wither", "kraken", "dragon", "stinger", "eternity", "infinity", "ghast", "mustang", "griefer", "sun"};
        String[] parts = {"helmet", "chestplate", "leggings", "boots", "sword", "trident", "bow", "crossbow",
                "pickaxe", "axe", "shovel", "armor_elytra", "unbreakable_elytra"};
        for (String kit : kits) {
            for (String part : parts) {
                if (com.arsenal.kit.KitCommand.lootGear(kit, part) != null) {
                    final String k = kit;
                    final String p = part;
                    m.put("kit_" + kit + "_" + part, () -> com.arsenal.kit.KitCommand.lootGear(k, p));
                }
            }
        }
        VI[] withLevel = {Arsenal.SPHERE_COMMON, Arsenal.SPHERE_EPIC, Arsenal.SPHERE_LEGENDARY,
                Arsenal.TALISMAN_COMMON, Arsenal.TALISMAN, Arsenal.TALISMAN_LEGENDARY};
        int[] lvls = {1, 2, 3, 1, 2, 3};
        for (int i = 0; i < withLevel.length; i++) {
            for (SphereEffect e : SphereEffect.values()) {
                final VI vi = withLevel[i];
                final int level = lvls[i];
                final SphereEffect effect = e;
                m.put(vi.id + "_" + e.id, () -> {
                    int[] l = new int[SphereEffect.COUNT];
                    l[effect.ordinal()] = level;
                    return Spheres.stack(vi, l);
                });
            }
        }
        m.put("sphere_mythic_1", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(0, 3, 2, 0, 0)));
        m.put("sphere_mythic_2", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(0, 2, 3, 0, 0)));
        m.put("sphere_mythic_3", () -> Spheres.stack(Arsenal.SPHERE_MYTHIC, Spheres.v(2, 0, 3, 0, 0)));
        return m;
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("amenu").requires(src -> src.hasPermissionLevel(2))
                        .executes(ctx -> com.arsenal.MenuBridge.openFor(ctx.getSource().getPlayer()))));
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("arsenal")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("list").executes(ctx -> {
                            StringBuilder sb = new StringBuilder();
                            for (String id : catalog().keySet()) {
                                if (sb.length() > 0) {
                                    sb.append(", ");
                                }
                                sb.append(id);
                            }
                            ctx.getSource().sendFeedback(new LiteralText(sb.toString()).formatted(Formatting.GRAY), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("menu")
                                .executes(ctx -> com.arsenal.MenuBridge.openFor(ctx.getSource().getPlayer())))
                        .then(settingsNode())
                        .then(CommandManager.literal("give")
                                .then(CommandManager.argument("item", StringArgumentType.word())
                                        .suggests((ctx, builder) -> CommandSource.suggestMatching(catalog().keySet(), builder))
                                        .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "item"), ""))
                                        .then(CommandManager.argument("args", StringArgumentType.greedyString())
                                                .suggests((ctx, builder) -> {
                                                    String rem = builder.getRemaining();
                                                    com.mojang.brigadier.suggestion.SuggestionsBuilder nb =
                                                            builder.createOffset(builder.getStart() + rem.lastIndexOf(' ') + 1);
                                                    return CommandSource.suggestMatching(effectTokens(), nb);
                                                })
                                                .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "item"),
                                                        StringArgumentType.getString(ctx, "args"))))))));
    }

    private static java.util.List<String> effectTokens() {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String e : new String[]{"speed", "damage", "armor", "attack_speed", "health"}) {
            for (int l = 1; l <= 5; l++) {
                out.add(e + l);
            }
        }
        for (int c = 2; c <= 64; c *= 2) {
            out.add("x" + c);
        }
        return out;
    }

    /** /arsenal settings list|get|set|reload: правка config/arsenal_settings.json прямо из игры. */
    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<ServerCommandSource> settingsNode() {
        com.mojang.brigadier.suggestion.SuggestionProvider<ServerCommandSource> keys = (ctx, b) -> {
            java.util.List<String> names = new java.util.ArrayList<>();
            for (com.arsenal.Settings.Def d : com.arsenal.Settings.defs()) {
                names.add(d.key);
            }
            return CommandSource.suggestMatching(names, b);
        };
        return CommandManager.literal("settings")
                .then(CommandManager.literal("list")
                        .executes(ctx -> listSettings(ctx.getSource(), null))
                        .then(CommandManager.argument("filter", StringArgumentType.word())
                                .executes(ctx -> listSettings(ctx.getSource(), StringArgumentType.getString(ctx, "filter")))))
                .then(CommandManager.literal("get")
                        .then(CommandManager.argument("key", StringArgumentType.word()).suggests(keys)
                                .executes(ctx -> getSetting(ctx.getSource(), StringArgumentType.getString(ctx, "key")))))
                .then(CommandManager.literal("set")
                        .then(CommandManager.argument("key", StringArgumentType.word()).suggests(keys)
                                .then(CommandManager.argument("value", IntegerArgumentType.integer())
                                        .executes(ctx -> setSetting(ctx.getSource(), StringArgumentType.getString(ctx, "key"),
                                                IntegerArgumentType.getInteger(ctx, "value"))))))
                .then(CommandManager.literal("reload").executes(ctx -> {
                    com.arsenal.Settings.load();
                    com.arsenal.Settings.apply();
                    com.arsenal.shulker.ShulkerEvent.reloadConfig();
                    com.arsenal.Settings.broadcast(ctx.getSource().getMinecraftServer());
                    ctx.getSource().sendFeedback(new LiteralText("Настройки перечитаны из config/arsenal_settings.json").formatted(Formatting.GREEN), true);
                    return 1;
                }));
    }

    private static com.arsenal.Settings.Def findDef(String key) {
        for (com.arsenal.Settings.Def d : com.arsenal.Settings.defs()) {
            if (d.key.equals(key)) {
                return d;
            }
        }
        return null;
    }

    private static int listSettings(ServerCommandSource src, String filter) {
        int n = 0;
        for (com.arsenal.Settings.Def d : com.arsenal.Settings.defs()) {
            if (filter != null && !d.key.contains(filter) && !d.label.toLowerCase().contains(filter.toLowerCase())) {
                continue;
            }
            src.sendFeedback(new LiteralText(d.key + " = " + com.arsenal.Settings.get(d.key) + " " + d.unit + "  (" + d.label + ")")
                    .formatted(Formatting.GRAY), false);
            n++;
        }
        if (n == 0) {
            src.sendError(new LiteralText("Ничего не найдено"));
        }
        return n;
    }

    private static int getSetting(ServerCommandSource src, String key) {
        com.arsenal.Settings.Def d = findDef(key);
        if (d == null) {
            src.sendError(new LiteralText("Нет настройки " + key + ". Список: /arsenal settings list"));
            return 0;
        }
        src.sendFeedback(new LiteralText(d.label + ": " + com.arsenal.Settings.get(key) + " " + d.unit
                + " (по умолчанию " + d.def + ", допустимо " + d.min + ".." + d.max + ")").formatted(Formatting.YELLOW), false);
        return 1;
    }

    private static int setSetting(ServerCommandSource src, String key, int value) {
        com.arsenal.Settings.Def d = findDef(key);
        if (d == null) {
            src.sendError(new LiteralText("Нет настройки " + key + ". Список: /arsenal settings list"));
            return 0;
        }
        Map<String, Integer> m = new LinkedHashMap<>();
        m.put(key, value);
        com.arsenal.Settings.save(m, true);
        com.arsenal.Settings.broadcast(src.getMinecraftServer());
        src.sendFeedback(new LiteralText(d.label + " = " + com.arsenal.Settings.get(key) + " " + d.unit
                + (com.arsenal.Settings.get(key) != value ? " (вне границ " + d.min + ".." + d.max + ", поправлено)" : ""))
                .formatted(Formatting.GREEN), true);
        return 1;
    }

    /**
     * /arsenal give &lt;предмет&gt; [эффекты] [xN]. Для сфер и талисманов (обычная, эпическая, легендарная, мифическая):
     * без эффектов выдаётся случайный набор по редкости, с эффектами - ровно они, например
     * /arsenal give sphere_epic speed2 или /arsenal give sphere_legendary damage2 armor1.
     */
    private static int give(ServerCommandSource src, String id, String args) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        Supplier<ItemStack> sup = catalog().get(id);
        VI base = VI.byId(id);
        if (sup == null && base == null) {
            src.sendError(new LiteralText("Нет такого предмета: " + id + ". Список: /arsenal list"));
            return 0;
        }
        // количество: "x5" или "5" среди слов
        int count = 1;
        StringBuilder fx = new StringBuilder();
        for (String tok : args.trim().split("\\s+")) {
            if (tok.isEmpty()) {
                continue;
            }
            String num = tok.startsWith("x") || tok.startsWith("х") ? tok.substring(1) : tok;
            if (num.matches("\\d{1,3}")) {
                count = Math.max(1, Math.min(2304, Integer.parseInt(num)));
            } else {
                fx.append(tok).append(' ');
            }
        }
        boolean tier = base != null && com.arsenal.sphere.Spheres.tier(base) > 0;
        int[] levels = null;
        if (fx.length() > 0) {
            if (!tier) {
                src.sendError(new LiteralText("Эффекты можно задавать только сферам и талисманам (обычная, эпическая, легендарная, мифическая)"));
                return 0;
            }
            try {
                levels = com.arsenal.sphere.Spheres.parse(fx.toString());
            } catch (IllegalArgumentException ex) {
                src.sendError(new LiteralText(ex.getMessage()));
                return 0;
            }
        }
        ServerPlayerEntity player = src.getPlayer();
        java.util.Random rnd = new java.util.Random();
        String what = id;
        for (int i = 0; i < count; i++) {
            ItemStack s;
            if (tier) {
                s = levels != null ? com.arsenal.sphere.Spheres.stack(base, levels) : com.arsenal.sphere.Spheres.randomFor(base, rnd);
                if (levels != null) {
                    what = id + " (" + com.arsenal.sphere.Spheres.describe(levels) + ")";
                }
            } else {
                s = sup != null ? sup.get() : base.stack();
            }
            VI vi = VI.of(s);
            if (vi != null && vi.unique && s.getMaxCount() > 1) {
                s.setCount(1);
            }
            player.giveItemStack(s);
        }
        src.sendFeedback(new LiteralText("Выдано: " + what + " x" + count).formatted(Formatting.GREEN), false);
        return count;
    }
}
