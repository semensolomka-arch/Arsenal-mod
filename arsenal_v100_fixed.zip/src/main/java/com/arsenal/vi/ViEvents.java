package com.arsenal.vi;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.DyeItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Серверная логика предметов мода: ПКМ, запрет ванильного поведения (блоки, броски, краска),
 * запоминание поставленных блоков (динамит, нерушимая наковальня).
 */
public final class ViEvents {
    private static final Map<UUID, Long> LAST_USE = new HashMap<>();
    private static final Map<UUID, Long> LAST_MSG = new HashMap<>();
    private static final List<Pending> PENDING = new ArrayList<>();

    private static class Pending {
        final ServerWorld world;
        final BlockPos pos;
        final VI vi;

        Pending(ServerWorld world, BlockPos pos, VI vi) {
            this.world = world;
            this.pos = pos;
            this.vi = vi;
        }
    }

    private ViEvents() {
    }

    // ------------------------------------------------------------------ использование

    /**
     * Выполняет действие предмета (с проверкой кулдауна). Вызывается и из ПКМ в воздух, и из ПКМ по блоку
     * (там клиент мог решить, что поставил блок, и пакет "использовать" не отправил).
     * В пределах одного тика действие не повторяется.
     */
    public static boolean runAction(ServerPlayerEntity sp, ItemStack stack, VI vi) {
        long now = sp.world.getTime();
        Long last = LAST_USE.get(sp.getUuid());
        if (last != null && last == now) {
            return true;
        }
        if (Cd.is(sp, vi)) {
            int sec = Math.max(1, (int) Math.ceil(Cd.left(sp, vi) / 20.0));
            message(sp, Lang.get("item.arsenal." + vi.id) + ": ещё " + sec + " сек.");
            return false;
        }
        LAST_USE.put(sp.getUuid(), now);
        return vi.action.run(sp, stack);
    }

    private static void message(ServerPlayerEntity sp, String text) {
        long now = sp.world.getTime();
        Long last = LAST_MSG.get(sp.getUuid());
        if (last != null && now - last < 10) {
            return;
        }
        LAST_MSG.put(sp.getUuid(), now);
        sp.sendMessage(new LiteralText(text).formatted(Formatting.YELLOW), true);
    }

    /** Вызывается из миксина ItemStack.useOnBlock: ванильное действие предмета отменяется. */
    public static void blockUseCancelled(ServerPlayerEntity sp, ItemStack stack, VI vi) {
        if (vi.action != null) {
            runAction(sp, stack, vi);
        }
        Resync.inventory(sp);
    }

    public static void init() {
        // ПКМ в воздух
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || !(player instanceof ServerPlayerEntity)) {
                return TypedActionResult.pass(stack);
            }
            VI vi = VI.of(stack);
            if (vi == null) {
                return TypedActionResult.pass(stack);
            }
            ServerPlayerEntity sp = (ServerPlayerEntity) player;
            if (vi.action != null) {
                boolean ok = runAction(sp, stack, vi);
                Resync.inventory(sp);
                return ok ? TypedActionResult.success(stack) : TypedActionResult.fail(stack);
            }
            if (vi.vanillaUse) {
                if (vi.blockWhileCooling && Cd.is(sp, vi)) {
                    int sec = Math.max(1, (int) Math.ceil(Cd.left(sp, vi) / 20.0));
                    message(sp, Lang.get("item.arsenal." + vi.id) + ": ещё " + sec + " сек.");
                    Resync.inventory(sp);
                    return TypedActionResult.fail(stack);
                }
                return TypedActionResult.pass(stack);
            }
            Resync.inventory(sp);
            return TypedActionResult.fail(stack);
        });

        // ПКМ по блоку: краситель на табличку и запоминание ставящихся блоков
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || !(world instanceof ServerWorld)) {
                return ActionResult.PASS;
            }
            ItemStack stack = player.getStackInHand(hand);
            VI vi = VI.of(stack);
            if (vi == null) {
                return ActionResult.PASS;
            }
            if (vi.base instanceof DyeItem && world.getBlockEntity(hit.getBlockPos()) instanceof SignBlockEntity) {
                if (player instanceof ServerPlayerEntity) {
                    Resync.inventory((ServerPlayerEntity) player);
                }
                return ActionResult.FAIL;
            }
            if (vi.placeBlock != null) {
                ItemPlacementContext ctx = new ItemPlacementContext(player, hand, stack, hit);
                if (ctx.canPlace()) {
                    PENDING.add(new Pending((ServerWorld) world, ctx.getBlockPos().toImmutable(), vi));
                }
            }
            return ActionResult.PASS;
        });

        // ПКМ по существу: краситель на овцу, ошейник волка и т.п. отменяем у предметов без ванильного применения
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) {
                return ActionResult.PASS;
            }
            VI vi = VI.of(player.getStackInHand(hand));
            if (vi != null && !vi.vanillaUse && vi.action == null) {
                if (player instanceof ServerPlayerEntity) {
                    Resync.inventory((ServerPlayerEntity) player);
                }
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        // поломка помеченных блоков: выпадает предмет мода
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient) {
                return true;
            }
            String id = Marks.idAt(world, pos);
            if (id == null) {
                return true;
            }
            VI vi = VI.byId(id);
            if (vi == null || vi.placeBlock == null) {
                Marks.remove(world, pos);
                return true;
            }
            if (!(state.getBlock() == vi.placeBlock || state.getBlock() instanceof AnvilBlock)) {
                Marks.remove(world, pos);
                return true;
            }
            Marks.remove(world, pos);
            if (!player.isCreative()) {
                Block.dropStack(world, pos, vi.stack());
            }
            world.removeBlock(pos, false);
            return false;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!PENDING.isEmpty()) {
                for (Pending p : PENDING) {
                    BlockState st = p.world.getBlockState(p.pos);
                    if (st.isOf(p.vi.placeBlock) && Marks.get(p.world, p.pos) == null) {
                        String v = p.vi.id;
                        if (st.getBlock() instanceof AnvilBlock) {
                            v = v + ":" + st.get(HorizontalFacingBlock.FACING).getName();
                        }
                        Marks.put(p.world, p.pos, v);
                    }
                }
                PENDING.clear();
            }
            keepAnvils(server);
            if (server.getTicks() % 100 == 0) {
                Marks.validate(server);
            }
            if (server.getTicks() % 600 == 0) {
                Marks.save();
            }
        });
        ServerLifecycleEvents.SERVER_STARTED.register(server -> Marks.load());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            Marks.save();
            PENDING.clear();
            LAST_USE.clear();
            LAST_MSG.clear();
            Cd.clearAll();
        });
    }

    /** Нерушимая наковальня: пока игрок ей пользуется, возвращаем целое состояние (ваниль её портит). */
    private static void keepAnvils(net.minecraft.server.MinecraftServer server) {
        boolean anyOpen = false;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.currentScreenHandler instanceof AnvilScreenHandler) {
                anyOpen = true;
                break;
            }
        }
        if (!anyOpen) {
            return;
        }
        for (Map.Entry<String, String> e : Marks.snapshot().entrySet()) {
            String v = e.getValue();
            if (!v.startsWith("unbreakable_anvil")) {
                continue;
            }
            String[] k = e.getKey().split("\\|");
            if (k.length != 4) {
                continue;
            }
            ServerWorld world = null;
            for (ServerWorld w : server.getWorlds()) {
                if (w.getRegistryKey().getValue().toString().equals(k[0])) {
                    world = w;
                    break;
                }
            }
            if (world == null) {
                continue;
            }
            BlockPos pos;
            try {
                pos = new BlockPos(Integer.parseInt(k[1]), Integer.parseInt(k[2]), Integer.parseInt(k[3]));
            } catch (NumberFormatException ex) {
                continue;
            }
            if (!world.isChunkLoaded(pos)) {
                continue;
            }
            BlockState st = world.getBlockState(pos);
            if (st.getBlock() == Blocks.ANVIL) {
                continue;
            }
            if (st.getBlock() == Blocks.CHIPPED_ANVIL || st.getBlock() == Blocks.DAMAGED_ANVIL || st.isAir()) {
                Direction dir = Direction.NORTH;
                int i = v.indexOf(':');
                if (i >= 0) {
                    Direction d = Direction.byName(v.substring(i + 1));
                    if (d != null && d.getAxis().isHorizontal()) {
                        dir = d;
                    }
                }
                world.setBlockState(pos, Blocks.ANVIL.getDefaultState().with(HorizontalFacingBlock.FACING, dir));
            }
        }
    }

    /** Есть ли у игрока предмет мода в любом слоте. */
    public static ItemStack find(PlayerEntity p, VI vi) {
        for (int i = 0; i < p.inventory.size(); i++) {
            ItemStack s = p.inventory.getStack(i);
            if (!s.isEmpty() && vi.is(s)) {
                return s;
            }
        }
        return ItemStack.EMPTY;
    }
}
