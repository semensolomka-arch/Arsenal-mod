package com.arsenal.vi;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Серверный загрузчик переводов мода. Клиент (ванильный) наших lang-файлов не знает,
 * поэтому все названия и описания превращаются в готовый текст на сервере.
 */
public final class Lang {
    private static final Map<String, String> MAP = new HashMap<>();
    private static boolean loaded = false;

    private Lang() {
    }

    private static synchronized void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        try (InputStream in = Lang.class.getResourceAsStream("/assets/arsenal/lang/ru_ru.json")) {
            if (in == null) {
                System.err.println("[Arsenal] не найден lang-файл ru_ru.json");
                return;
            }
            JsonObject root = new JsonParser().parse(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : root.entrySet()) {
                MAP.put(e.getKey(), e.getValue().getAsString());
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать lang-файл: " + ex);
        }
    }

    public static boolean has(String key) {
        load();
        return MAP.containsKey(key);
    }

    public static String get(String key) {
        load();
        String v = MAP.get(key);
        return v == null ? key : v;
    }

    public static String format(String key, Object... args) {
        String s = get(key);
        try {
            return String.format(s, args);
        } catch (Exception e) {
            return s;
        }
    }
}
