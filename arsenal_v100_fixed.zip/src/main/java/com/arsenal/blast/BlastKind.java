package com.arsenal.blast;

import com.arsenal.Lore;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.LiteralText;
import net.minecraft.text.TranslatableText;

/** Виды взрывчатки: время до взрыва, сила и особенности взрыва. Текстура у всех как у обычного TNT. */
public enum BlastKind {
    /** Взрыв через 5 секунд, в 3 раза сильнее обычного TNT (сила 4). */
    DYNAMITE_A("dynamite_a", 20 * 5, 4.0F * 3, Mode.PIERCE, 0xFF4500),
    /** Взрыв через 15 секунд, в 10 раз сильнее обычного TNT. */
    DYNAMITE_B("dynamite_b", 20 * 15, 4.0F * 10, Mode.PIERCE, 0xFF00E0),
    /** Как обычный TNT, но обсидиан ломает не очень хорошо. */
    C4("c4", 80, 4.0F, Mode.C4, 0x55FFFF),
    /** Как обычный TNT, но взрывается в воде и хорошо ломает обсидиан. */
    WAVE("burst_wave", 80, 4.0F, Mode.WAVE, 0xFF00E0),
    /** Стиллер: взрывается как TNT, но без урона и разрушения блоков; забирает один спавнер рядом (50% сохранить моба). */
    STEALER("stealer", 80, 0.0F, Mode.STEALER, 0xFF55FF, 0.50),
    /** Надёжный стиллер: то же, но шанс сохранить моба 75%. */
    RELIABLE_STEALER("reliable_stealer", 80, 0.0F, Mode.STEALER, 0x55FFFF, 0.75),
    /** Динамит Б2: через 5 секунд испаряет все блоки в радиусе 12 (кроме бедрока и приватов), без урона и выпадения. */
    DYNAMITE_B2("dynamite_b2", 20 * 5, 0.0F, Mode.VAPORIZE, 0xFF2020),
    /** Ледяная волна: взрыв как у обычного TNT, воду рядом на 10 секунд превращает в лёд. */
    ICE_WAVE("ice_wave", 80, 4.0F, Mode.ICE, 0x55FFFF);

    public enum Mode {
        /** Обычный взрыв другой силы. */
        VANILLA,
        /** Динамит А и Б: взрыв пробивает блоки (обсидиан и прочие прочные), но слабее, чем по воздуху. */
        PIERCE,
        C4, WAVE, STEALER, VAPORIZE, ICE
    }

    /** Эффективная стойкость обсидиана к взрыву (у ванильного 1200, у камня 6): чем меньше, тем легче ломается. */
    public static final float C4_OBSIDIAN_RESISTANCE = 12.0F;
    public static final float WAVE_OBSIDIAN_RESISTANCE = 4.0F;
    /** Динамит А и Б: стойкость обсидиана и множитель стойкости всех блоков (ванильная стойкость делится примерно пополам). */
    public static final float PIERCE_OBSIDIAN_RESISTANCE = 1200.0F;   // обычная стойкость: обсидиан не пробивается
    public static final float PIERCE_RESISTANCE_SCALE = 0.5F;

    public static BlastKind byId(String id) {
        for (BlastKind k : values()) {
            if (k.id.equals(id)) {
                return k;
            }
        }
        return null;
    }

    public final String id;
    public final int fuseTicks;
    public final float power;
    public final Mode mode;
    /** Цвет выделения в описании. */
    public final int highlight;
    /** Шанс сохранить моба в спавнере (только для стиллеров). */
    public final double keepChance;

    BlastKind(String id, int fuseTicks, float power, Mode mode, int highlight) {
        this(id, fuseTicks, power, mode, highlight, 0.0);
    }

    BlastKind(String id, int fuseTicks, float power, Mode mode, int highlight, double keepChance) {
        this.keepChance = keepChance;
        this.id = id;
        this.fuseTicks = fuseTicks;
        this.power = power;
        this.mode = mode;
        this.highlight = highlight;
    }

    /** Название с оформлением: А как у светильника Джейка, Б фиолетовое, C4 бело-фиолетовое, волна жёлто-фиолетовая. */
    public Text displayName(String translationKey) {
        switch (this) {
            case DYNAMITE_A:
                return Lore.gradientName(translationKey, 0xFF8C00, 0xFFB000, true);
            case C4:
                return Lore.gradientName(translationKey, 0xE040FB, 0xB388FF, false);
            case WAVE:
                return Lore.gradientName(translationKey, 0xFF2020, 0xFF00DC, false);
            case STEALER:
            case RELIABLE_STEALER:
            case DYNAMITE_B2:
            case ICE_WAVE:
                return new LiteralText(com.arsenal.vi.Lang.get(translationKey))
                        .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(highlight)).withItalic(false));
            default:
                return new LiteralText(com.arsenal.vi.Lang.get(translationKey))
                        .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xE53BFF)).withItalic(false));
        }
    }
}
