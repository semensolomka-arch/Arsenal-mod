package com.arsenal.blast;

import com.arsenal.TrapManager;
import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.LiteralText;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

/**
 * Спавнеры:
 * - спавнер из /give (без моба) ставится пустым, без моба (см. MobSpawnerBlockEntityMixin);
 * - яйцо призыва по спавнеру ставит или заменяет моба (прошлый моб пропадает);
 * - спавнер с мобом (например, после стиллера) ставится с этим мобом любым игроком, а не только оператором.
 */
public final class SpawnerUtil {
    private SpawnerUtil() {
    }

    public static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!(stack.getItem() instanceof SpawnEggItem) || player.isSpectator()) {
                return ActionResult.PASS;
            }
            BlockPos pos = hit.getBlockPos();
            if (!world.getBlockState(pos).isOf(Blocks.SPAWNER)) {
                return ActionResult.PASS;
            }
            if (world.isClient) {
                return ActionResult.SUCCESS;
            }
            BlockEntity be = world.getBlockEntity(pos);
            if (!(be instanceof MobSpawnerBlockEntity)) {
                return ActionResult.PASS;
            }
            if ((SpawnProtection.contains(world, pos) && !SpawnProtection.bypass(player)) || TrapManager.isProtected(pos)) {
                return ActionResult.FAIL;
            }
            EntityType<?> type = ((SpawnEggItem) stack.getItem()).getEntityType(stack.getTag());
            setMob(world, pos, (MobSpawnerBlockEntity) be, type);
            if (!player.isCreative()) {
                stack.decrement(1);
            }
            player.sendMessage(new LiteralText(com.arsenal.vi.Lang.get("name.arsenal.spawner").replace("%s", "")).append(new TranslatableText(type.getTranslationKey())), true);
            return ActionResult.SUCCESS;
        });
    }

    /** Ставит моба в спавнер, полностью заменяя прежнего (и в SpawnData, и в SpawnPotentials). */
    public static void setMob(World world, BlockPos pos, MobSpawnerBlockEntity be, EntityType<?> type) {
        BlockState state = world.getBlockState(pos);
        NbtCompound full = be.writeNbt(new NbtCompound());
        NbtCompound data = new NbtCompound();
        data.putString("id", Registry.ENTITY_TYPE.getId(type).toString());
        full.put("SpawnData", data.copy());
        full.put("SpawnPotentials", potentials(data));
        be.fromTag(state, full);
        be.markDirty();
        world.updateListeners(pos, state, state, 3);
    }

    private static NbtList potentials(NbtCompound data) {
        NbtList list = new NbtList();
        NbtCompound entry = new NbtCompound();
        entry.put("Entity", data.copy());
        entry.putInt("Weight", 1);
        list.add(entry);
        return list;
    }

    /** Предмет-спавнер с мобом. Одинаковые мобы стакаются, разные мобы лежат отдельными стаками. */
    public static ItemStack makeSpawner(String mobId, NbtCompound spawnData) {
        ItemStack stack = new ItemStack(Items.SPAWNER);
        NbtCompound blockEntityTag = new NbtCompound();
        blockEntityTag.put("SpawnData", spawnData.copy());
        blockEntityTag.put("SpawnPotentials", potentials(spawnData));
        stack.putSubTag("BlockEntityTag", blockEntityTag);

        Identifier id = Identifier.tryParse(mobId);
        EntityType<?> type = id == null ? EntityType.PIG : EntityType.get(mobId).orElse(EntityType.PIG);
        Text name = new LiteralText(com.arsenal.vi.Lang.get("name.arsenal.spawner").replace("%s", "")).append(new TranslatableText(type.getTranslationKey()))
                .setStyle(Style.EMPTY.withItalic(false));
        stack.getOrCreateSubTag("display").putString("Name", Text.Serializer.toJson(name));
        return stack;
    }
}
