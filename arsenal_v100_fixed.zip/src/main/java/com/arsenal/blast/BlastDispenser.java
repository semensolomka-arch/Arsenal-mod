package com.arsenal.blast;

import com.arsenal.vi.VI;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.entity.TntEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Раздатчик зажигает кастомную взрывчатку мода (динамит, стиллер и т.д.) как свою, а не как обычный TNT. */
public final class BlastDispenser {
    private BlastDispenser() {
    }

    public static void init() {
        DispenserBlock.registerBehavior(Items.TNT, new ItemDispenserBehavior() {
            @Override
            protected ItemStack dispenseSilently(BlockPointer pointer, ItemStack stack) {
                World world = pointer.getWorld();
                BlockPos pos = pointer.getBlockPos().offset(pointer.getBlockState().get(DispenserBlock.FACING));
                VI vi = VI.of(stack);
                BlastKind kind = vi == null ? null : BlastKind.byId(vi.id);
                if (kind != null) {
                    world.spawnEntity(new BlastEntity(world, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, null, kind));
                    world.playSound(null, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                            SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
                } else {
                    world.spawnEntity(new TntEntity(world, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, null));
                    world.playSound(null, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                            SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
                }
                stack.decrement(1);
                return stack;
            }
        });
    }
}
