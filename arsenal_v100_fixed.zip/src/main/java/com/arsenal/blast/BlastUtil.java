package com.arsenal.blast;

import com.arsenal.TrapManager;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.explosion.Explosion;

import java.util.HashSet;
import java.util.Set;

/** Взрывы динамита, C4 и разрывной волны. */
public final class BlastUtil {
    private BlastUtil() {
    }

    public static void explode(ServerWorld world, Entity source, double x, double y, double z, BlastKind kind) {
        if (kind.mode == BlastKind.Mode.STEALER) {
            StealerBlast.explode(world, x, y, z, kind);
            return;
        }
        if (kind.mode == BlastKind.Mode.VAPORIZE) {
            VaporizeBlast.explode(world, x, y, z);
            return;
        }
        if (kind.mode == BlastKind.Mode.ICE) {
            // обычный взрыв, плюс вода рядом на время становится льдом
            world.createExplosion(source, x, y, z, kind.power, Explosion.DestructionType.BREAK);
            IceWave.freeze(world, x, y, z);
            return;
        }
        if (kind.mode == BlastKind.Mode.VANILLA) {
            // обычный взрыв, просто другой силы (зону замка защищает ExplosionMixin)
            world.createExplosion(source, x, y, z, kind.power, Explosion.DestructionType.BREAK);
            return;
        }

        // Урон, отброс, звук и частицы как у обычного взрыва, но без разрушения блоков
        world.createExplosion(source, x, y, z, kind.power, Explosion.DestructionType.NONE);

        boolean wave = kind.mode == BlastKind.Mode.WAVE;
        boolean pierce = kind.mode == BlastKind.Mode.PIERCE;   // динамит А и Б
        float obsidian = pierce ? BlastKind.PIERCE_OBSIDIAN_RESISTANCE
                : wave ? BlastKind.WAVE_OBSIDIAN_RESISTANCE : BlastKind.C4_OBSIDIAN_RESISTANCE;
        float scale = pierce ? BlastKind.PIERCE_RESISTANCE_SCALE : 1.0F;
        // C4 и разрывная волна пробивают и защищённые приваты, динамит - нет (как раньше)
        boolean special = !pierce;
        Set<BlockPos> blocks = collect(world, x, y, z, kind.power, wave, obsidian, special, scale);

        java.util.List<BlockPos> privateHits = new java.util.ArrayList<>();
        for (BlockPos pos : blocks) {
            if (SpawnProtection.contains(world, pos) || TrapManager.isProtected(pos)) {
                continue;
            }
            if (pierce && com.arsenal.event.EventManager.inZone(world, pos)) {
                continue;   // зону грузов динамит не ломает, как и обычный взрыв
            }
            BlockState state = world.getBlockState(pos);
            if (pierce && isPierceProtected(state)) {
                continue;   // спавнеры и служебные блоки динамит не ломает
            }
            if (state.isAir() || state.getBlock() instanceof FluidBlock || state.getHardness(world, pos) < 0) {
                continue;   // воздух, вода, бедрок и прочее неломаемое
            }
            Block block = state.getBlock();
            com.arsenal.priv.PrivateManager.Entry privateEntry = com.arsenal.priv.PrivateManager.get(world, pos);
            if (privateEntry != null) {
                // минус прочность (защищённые и уникальный только от C4), удар применяем после взрыва
                if (!privateEntry.type.c4Only || special) {
                    privateHits.add(pos.toImmutable());
                }
                continue;
            }
            if (com.arsenal.priv.Privates.EXPLOSION_PROOF_REGION && com.arsenal.priv.PrivateManager.isCovered(world, pos)) {
                continue;   // территория привата не страдает
            }
            // C4 и разрывная волна: плачущий обсидиан -> обычный, древние обломки -> плачущий обсидиан
            if (special && block == Blocks.CRYING_OBSIDIAN) {
                world.setBlockState(pos, Blocks.OBSIDIAN.getDefaultState());
                continue;
            }
            if (special && block == Blocks.ANCIENT_DEBRIS) {
                world.setBlockState(pos, Blocks.CRYING_OBSIDIAN.getDefaultState());
                continue;
            }
            if (block instanceof TntBlock) {
                if (BlastIgnite.isBlast(world, pos)) {
                    BlastIgnite.prime(world, pos, null, true);   // цепная реакция: короткий запал
                } else {
                    TntBlock.primeTnt(world, pos);      // цепная реакция
                }
                world.removeBlock(pos, false);
                continue;
            }
            // как в ванили: предмет выпадает не всегда
            world.breakBlock(pos, world.random.nextFloat() < 1.0F / kind.power);
        }
        for (BlockPos pos : privateHits) {
            com.arsenal.priv.Privates.explosionHit(world, pos);
        }
    }

    /**
     * Те же лучи, что у ванильного взрыва, только с поправками:
     * вода не гасит взрыв (разрывная волна) и обсидиан считается менее прочным.
     */
    private static Set<BlockPos> collect(ServerWorld world, double x, double y, double z, float power,
                                         boolean ignoreFluid, float obsidianResistance, boolean special, float scale) {
        Set<BlockPos> set = new HashSet<>();
        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                for (int l = 0; l < 16; l++) {
                    if (j != 0 && j != 15 && k != 0 && k != 15 && l != 0 && l != 15) {
                        continue;
                    }
                    double dx = j / 15.0 * 2.0 - 1.0;
                    double dy = k / 15.0 * 2.0 - 1.0;
                    double dz = l / 15.0 * 2.0 - 1.0;
                    double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    dx /= len;
                    dy /= len;
                    dz /= len;
                    float strength = power * (0.7F + world.random.nextFloat() * 0.6F);
                    double px = x;
                    double py = y;
                    double pz = z;
                    for (; strength > 0.0F; strength -= 0.22500001F) {
                        BlockPos pos = new BlockPos(px, py, pz);
                        if (pos.getY() < 0 || pos.getY() > 255) {
                            break;
                        }
                        BlockState state = world.getBlockState(pos);
                        FluidState fluid = world.getFluidState(pos);
                        if (!state.isAir() || !fluid.isEmpty()) {
                            float resistance = resistanceOf(world, pos, state, fluid, ignoreFluid, obsidianResistance, special) * scale;
                            strength -= (resistance + 0.3F) * 0.3F;
                        }
                        if (strength > 0.0F) {
                            set.add(pos);
                        }
                        px += dx * 0.30000001192092896D;
                        py += dy * 0.30000001192092896D;
                        pz += dz * 0.30000001192092896D;
                    }
                }
            }
        }
        return set;
    }

    /** Блоки, которые динамит А и Б не ломает, как бы ни пробивал остальное. */
    private static boolean isPierceProtected(BlockState state) {
        return state.isOf(Blocks.SPAWNER) || state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.CRYING_OBSIDIAN)
                || state.isOf(Blocks.ANCIENT_DEBRIS) || state.isOf(Blocks.NETHERITE_BLOCK) || state.isOf(Blocks.BEDROCK) || state.isOf(Blocks.BARRIER)
                || state.isOf(Blocks.COMMAND_BLOCK) || state.isOf(Blocks.CHAIN_COMMAND_BLOCK)
                || state.isOf(Blocks.REPEATING_COMMAND_BLOCK) || state.isOf(Blocks.STRUCTURE_BLOCK)
                || state.isOf(Blocks.STRUCTURE_VOID) || state.isOf(Blocks.JIGSAW)
                || state.isOf(Blocks.END_PORTAL) || state.isOf(Blocks.END_PORTAL_FRAME)
                || state.isOf(Blocks.END_GATEWAY) || state.isOf(Blocks.NETHER_PORTAL);
    }

    private static float resistanceOf(ServerWorld world, BlockPos pos, BlockState state, FluidState fluid,
                                      boolean ignoreFluid, float obsidianResistance, boolean special) {
        Block block = state.getBlock();
        if (block instanceof FluidBlock) {
            return ignoreFluid ? 0.0F : block.getBlastResistance();
        }
        float resistance = block.getBlastResistance();
        if (!ignoreFluid) {
            resistance = Math.max(resistance, fluid.getBlastResistance());
        }
        // обсидиан, плачущий обсидиан и древние обломки: C4 и разрывная волна их ломают (у динамита лимит равен обычной стойкости)
        if (state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.CRYING_OBSIDIAN) || state.isOf(Blocks.ANCIENT_DEBRIS)) {
            resistance = Math.min(resistance, obsidianResistance);
        }
        // защищённый приват (незерит) и уникальный: C4 и разрывная волна пробивают их, как обсидиан
        if (special) {
            com.arsenal.priv.PrivateManager.Entry privateEntry = com.arsenal.priv.PrivateManager.get(world, pos);
            if (privateEntry != null && privateEntry.type.c4Only) {
                resistance = Math.min(resistance, obsidianResistance);
            }
        }
        return resistance;
    }
}
