package com.arsenal.blast;

import com.arsenal.Lore;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VI;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;

import java.util.EnumMap;
import java.util.Map;

/** Взрывчатое вещество, динамит А/Б, C4, разрывная волна и стиллеры: ванильные TNT и глина с меткой. */
public final class Blasts {
    /** Фиолетовый цвет названий (динамит Б, стиллер, концы градиентов). */
    public static final int PURPLE = 0xAA33FF;
    public static VI EXPLOSIVE_SUBSTANCE;
    private static final Map<BlastKind, VI> ITEMS = new EnumMap<>(BlastKind.class);

    private Blasts() {
    }

    public static VI vi(BlastKind kind) {
        return ITEMS.get(kind);
    }

    public static void init() {
        // Взрывчатое вещество: крафт из 9 пороха, пока без другого применения (блок глины не ставится)
        EXPLOSIVE_SUBSTANCE = VI.register("explosive_substance", Items.CLAY)
                .name(s -> new LiteralText(Lang.get("item.arsenal.explosive_substance")))
                .lore(s -> Lore.lines("tooltip.arsenal.explosive_substance.", 3, 0xC8A2FF));
        for (BlastKind kind : BlastKind.values()) {
            VI vi = VI.register(kind.id, Items.TNT)
                    .vanillaUse(true)
                    .placeBlock(Blocks.TNT)
                    .name(s -> kind.displayName("block.arsenal." + kind.id))
                    .lore(s -> Lore.lines("tooltip.arsenal." + kind.id + ".", 6, kind.highlight));
            ITEMS.put(kind, vi);
        }
    }
}
