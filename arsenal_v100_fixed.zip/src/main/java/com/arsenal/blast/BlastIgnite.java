package com.arsenal.blast;

import com.arsenal.vi.Marks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Зажигание поставленных динамитов и стиллеров (ванильный TNT с меткой в Marks). */
public final class BlastIgnite {
    private BlastIgnite() {
    }

    /** true = это была взрывчатка мода и она зажжена (ванильный TNT не создаётся). */
    public static boolean prime(World world, BlockPos pos, LivingEntity igniter, boolean chain) {
        if (world.isClient) {
            return false;
        }
        String id = Marks.idAt(world, pos);
        if (id == null) {
            return false;
        }
        BlastKind kind = BlastKind.byId(id);
        Marks.remove(world, pos);
        if (kind == null) {
            return false;
        }
        BlastEntity entity = new BlastEntity(world, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, igniter, kind);
        if (chain) {
            int fuse = kind.fuseTicks;
            entity.setFuse(world.random.nextInt(Math.max(1, fuse / 4)) + fuse / 8);
        }
        world.spawnEntity(entity);
        world.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
        return true;
    }

    /** Это блок взрывчатки мода? (для соседей по цепной реакции) */
    public static boolean isBlast(World world, BlockPos pos) {
        String id = Marks.idAt(world, pos);
        return id != null && BlastKind.byId(id) != null;
    }
}
