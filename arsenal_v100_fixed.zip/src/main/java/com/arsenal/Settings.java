package com.arsenal;

import com.arsenal.artifact.ArtifactEffects;
import com.arsenal.blast.IceWave;
import com.arsenal.entity.SnowClumpEntity;
import com.arsenal.event.CargoLoot;
import com.arsenal.event.DeadlyMine;
import com.arsenal.event.MysteryShip;
import com.arsenal.event.XpEvent;
import com.arsenal.combat.Combat;
import com.arsenal.event.EventManager;
import com.arsenal.expkeeper.ExpKeeper;
import com.arsenal.item.ExpBubbleItem;
import com.arsenal.item.WinnerPotionItem;
import com.arsenal.pvp.PvpManager;
import com.arsenal.spawn.MineManager;
import com.arsenal.spawn.PvpArena;
import com.arsenal.special.Specials;
import com.arsenal.tp.TeleportManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.arsenal.shulker.ShulkerEvent;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.LongConsumer;

/**
 * Общие настройки мода (цифры): кулдауны, длительности, интервалы. Файл config/arsenal_settings.json,
 * правится и в игре через Mod Menu. Значения применяются при запуске мира и сразу после сохранения в экране настроек
 * (если мир свой/одиночный). Время в файле задано в секундах, минутах или часах, как написано в подписи.
 */
public final class Settings {
    public static final class Def {
        public final String key;
        public final String label;
        public final String unit;
        public final int def;
        public final int min;
        public final int max;
        final long mult;
        final LongConsumer apply;
        /** Не null: значение лежит не в arsenal_settings.json, а в arsenal_shulker.json по этому пути. */
        final String[] path;

        Def(String key, String label, String unit, int def, int min, int max, long mult, LongConsumer apply) {
            this(key, label, unit, def, min, max, mult, apply, null);
        }

        Def(String key, String label, String unit, int def, int min, int max, long mult, LongConsumer apply, String[] path) {
            this.path = path;
            this.key = key;
            this.label = label;
            this.unit = unit;
            this.def = def;
            this.min = min;
            this.max = max;
            this.mult = mult;
            this.apply = apply;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final List<Def> DEFS = new ArrayList<>();
    private static final Map<String, Integer> VALUES = new LinkedHashMap<>();

    private static void sec(String key, String label, int def, int min, LongConsumer apply) {
        DEFS.add(new Def(key, label, "сек", def, min, 86400, 20L, apply));
    }

    /** Уровень эффекта (1, 2, 3...); в игру уходит уровень минус 1. */
    private static void level(String key, String label, int def, LongConsumer apply) {
        DEFS.add(new Def(key, label, "ур", def, 1, 255, 1L, v -> apply.accept(v - 1)));
    }

    /** Шанс в процентах. */
    private static void pct(String key, String label, int def, LongConsumer apply) {
        DEFS.add(new Def(key, label, "%", def, 0, 100, 1L, apply));
    }

    private static void min(String key, String label, int def, int min, LongConsumer apply) {
        DEFS.add(new Def(key, label, "мин", def, min, 10080, 20L * 60L, apply));
    }

    /** Число стопок лута в контейнере (хранится в arsenal_settings.json, применяется в CargoLoot). */
    private static void stacks(String key, String label, int def, int max, LongConsumer apply) {
        DEFS.add(new Def(key, label, "стоп", def, 1, max, 1L, apply));
    }

    private static void shulker(String key, String label, String unit, int def, int min, int max, String... path) {
        DEFS.add(new Def(key, label, unit, def, min, max, 1L, v -> {
        }, path));
    }

    static {
        DEFS.add(new Def("world_border_radius", "Граница мира: радиус", "бл", 4000, 500, 30000, 1L,
                v -> com.arsenal.tp.WorldLimit.setRadius((int) v)));
        DEFS.add(new Def("fast_furnace_mult", "Быстрая печка: во сколько раз быстрее", "x", 3, 1, 20, 1L,
                v -> com.arsenal.item.FastFurnace.MULT = (int) v));
        // бой и способности
        sec("combat_seconds", "Режим боя (длительность)", 30, 1, v -> Combat.TICKS = (int) v);
        sec("trap_cooldown", "Трапка: кулдаун", 40, 0, v -> {
            Abilities.TRAP_COOLDOWN = (int) v;
            Specials.TRAP_COOLDOWN = (int) v;
        });
        sec("trap_lifetime", "Трапка: сколько стоит клетка", 15, 1, v -> {
            Abilities.TRAP_LIFETIME = (int) v;
            Specials.TRAP_LIFETIME = (int) v;
        });
        sec("snow_cooldown", "Ком снега: кулдаун", 30, 0, v -> Abilities.SNOW_COOLDOWN = (int) v);
        sec("stun_cooldown", "Стан: кулдаун", 30, 0, v -> Abilities.STUN_COOLDOWN = (int) v);
        sec("stun_pearl_ban", "Стан: запрет жемчуга эндера", 30, 0, v -> Abilities.STUN_PEARL_BAN = (int) v);
        sec("stun_slow", "Стан: замедление", 10, 0, v -> Abilities.STUN_SLOW_TICKS = (int) v);
        sec("charm_cooldown", "Взрывная штучка: кулдаун", 60, 0, v -> Specials.CHARM_COOLDOWN = (int) v);
        sec("jake_cooldown", "Светильник Джейка: кулдаун", 30, 0, v -> Specials.JAKE_COOLDOWN = (int) v);
        sec("jake_glow", "Светильник Джейка: свечение", 10, 0, v -> Specials.JAKE_GLOW_TICKS = (int) v);
        sec("jake_pumpkin", "Светильник Джейка: тыква на голове", 15, 0, v -> Specials.JAKE_PUMPKIN_TICKS = (int) v);
        sec("pearl_cooldown", "Жемчуг эндера: кулдаун", 15, 0, v -> StunZones.PEARL_COOLDOWN_TICKS = (int) v);
        sec("heal_cooldown", "Исцеление: кулдаун", 10, 0, v -> HealCooldown.TICKS = (int) v);
        sec("turtle_cooldown", "Черепашья мощь: кулдаун", 300, 0, v -> TurtleCooldown.TICKS = (int) v);
        sec("exp_bubble_cooldown", "Пузырь опыта: кулдаун", 180, 0, v -> ExpBubbleItem.COOLDOWN_TICKS = (int) v);
        sec("winner_potion_cooldown", "Зелье победителя: кулдаун", 300, 0, v -> WinnerPotionItem.COOLDOWN_TICKS = (int) v);
        sec("ice_wave_seconds", "Ледяная волна: лёд держится", 10, 1, v -> IceWave.TICKS = (int) v);

        // эффекты кома снега
        sec("snow_blind_seconds", "Ком снега: слепота, длительность", 1, 1, v -> SnowClumpEntity.BLIND_TICKS = (int) v);
        level("snow_blind_level", "Ком снега: слепота, уровень", 3, v -> SnowClumpEntity.BLIND_AMP = (int) v);
        sec("snow_slow_seconds", "Ком снега: замедление, длительность", 10, 1, v -> SnowClumpEntity.SLOW_TICKS = (int) v);
        level("snow_slow_level", "Ком снега: замедление, уровень", 6, v -> SnowClumpEntity.SLOW_AMP = (int) v);

        // эффекты Хранителя опыта / Артефакта
        pct("illuminator_chance", "Иллюминатор: шанс срабатывания", 5, v -> ArtifactEffects.ILLUMINATOR_CHANCE = (int) v);
        sec("illuminator_seconds", "Иллюминатор: свечение, длительность", 15, 1, v -> ArtifactEffects.ILLUMINATOR_TICKS = (int) v);
        pct("snowman_chance", "Снеговик: шанс срабатывания", 5, v -> ArtifactEffects.SNOWMAN_CHANCE = (int) v);
        sec("snowman_seconds", "Снеговик: замедление, длительность", 5, 1, v -> ArtifactEffects.SNOWMAN_TICKS = (int) v);
        level("snowman_level", "Снеговик: замедление, уровень", 1, v -> ArtifactEffects.SNOWMAN_AMP = (int) v);
        pct("vampirism_chance", "Вампиризм: шанс срабатывания", 2, v -> ArtifactEffects.VAMPIRISM_CHANCE = (int) v);
        sec("vampirism_seconds", "Вампиризм: регенерация, длительность", 5, 1, v -> ArtifactEffects.VAMPIRISM_TICKS = (int) v);
        level("vampirism_level", "Вампиризм: регенерация, уровень", 2, v -> ArtifactEffects.VAMPIRISM_AMP = (int) v);
        pct("enderman_chance", "Эндермен: шанс не потратить жемчуг", 50, v -> ArtifactEffects.ENDERMAN_CHANCE = (int) v);
        sec("telekinesis_seconds", "Телекинез: защита добычи, длительность", 3, 1, v -> ArtifactEffects.TELEKINESIS_TICKS = (int) v);
        pct("hunter_percent", "Охотник: доля забираемого опыта", 50, v -> ArtifactEffects.HUNTER_PERCENT = (int) v);

        // события и автошахты
        min("event_interval", "Ивент (грузы): интервал между ивентами", 15, 1, v -> EventManager.INTERVAL = (int) v);
        min("event_open_at", "Ивент (грузы): через сколько открываются", 8, 1, v -> EventManager.OPEN_AT = (int) v);
        min("event_stay", "Ивент (грузы): сколько стоят открытыми", 5, 1, v -> EventManager.STAY = (int) v);
        DEFS.add(new Def("mine_refresh", "Автошахты: обновление", "мин", 15, 1, 10080, 60_000L,
                v -> MineManager.PERIOD_MS = v));

        // Опытный Тыпо (житель с пузырьками опыта)
        min("mine_duration", "Смертельная шахта: длительность", 10, 1, v -> DeadlyMine.DURATION = (int) v);
        sec("mine_glow", "Смертельная шахта: свечение после сломанного блока", 4, 1, v -> DeadlyMine.GLOW = (int) v);
        min("xp_event_duration", "Опытный Тыпо: длительность", 15, 1, v -> XpEvent.DURATION = (int) v);
        min("xp_event_linger", "Опытный Тыпо: стоит после сундуков", 1, 1, v -> XpEvent.LINGER = (int) v);
        sec("xp_event_bottle_min", "Опытный Тыпо: пузырёк у жителя, от", 30, 1, v -> XpEvent.BOTTLE_MIN = (int) v);
        sec("xp_event_bottle_max", "Опытный Тыпо: пузырёк у жителя, до", 60, 1, v -> XpEvent.BOTTLE_MAX = (int) v);
        DEFS.add(new Def("xp_event_points", "Опытный Тыпо: очков в секунду за пузырёк", "оч", 15, 0, 100000, 1L, v -> XpEvent.POINTS_PER_BOTTLE = (int) v));
        DEFS.add(new Def("xp_event_warn", "Опытный Тыпо: предупреждение на расстоянии", "бл", 80, 1, 1000, 1L, v -> XpEvent.WARN_DISTANCE = (int) v));
        DEFS.add(new Def("xp_event_remove", "Опытный Тыпо: пузырьки забирают на расстоянии", "бл", 100, 1, 1000, 1L, v -> XpEvent.REMOVE_DISTANCE = (int) v));
        DEFS.add(new Def("xp_event_hearts", "Опытный Тыпо: урон от жителя без пузырька", "сердец", 4, 0, 100, 1L, v -> XpEvent.DAMAGE = (int) v * 2));
        DEFS.add(new Def("xp_event_knockback", "Опытный Тыпо: отбрасывание", "бл", 10, 0, 50, 1L, v -> XpEvent.KNOCKBACK = (int) v));

        // Таинственный корабль
        min("ship_duration", "Таинственный корабль: длительность", 20, 1, v -> MysteryShip.DURATION = (int) v);
        sec("ship_key_min", "Таинственный корабль: отмычка у капитана, от", 30, 1, v -> MysteryShip.KEY_MIN = (int) v);
        sec("ship_key_max", "Таинственный корабль: отмычка у капитана, до", 60, 1, v -> MysteryShip.KEY_MAX = (int) v);
        DEFS.add(new Def("ship_chance_common", "Таинственный корабль: шанс обычной отмычки", "вес", 70, 0, 1000, 1L, v -> MysteryShip.CHANCE_COMMON = (int) v));
        DEFS.add(new Def("ship_chance_rare", "Таинственный корабль: шанс редкой отмычки", "вес", 25, 0, 1000, 1L, v -> MysteryShip.CHANCE_RARE = (int) v));
        DEFS.add(new Def("ship_chance_secret", "Таинственный корабль: шанс секретной отмычки", "вес", 5, 0, 1000, 1L, v -> MysteryShip.CHANCE_SECRET = (int) v));
        DEFS.add(new Def("ship_anchor_keys", "Таинственный корабль: секретных отмычек для сокровища", "шт", 4, 1, 64, 1L, v -> MysteryShip.ANCHOR_KEYS = (int) v));
        sec("ship_anchor_open", "Таинственный корабль: сокровище открывается через", 60, 1, v -> MysteryShip.ANCHOR_OPEN = (int) v);
        sec("ship_anchor_close", "Таинственный корабль: сокровище закрывается (исчезает) через", 60, 1, v -> MysteryShip.ANCHOR_CLOSE = (int) v);
        sec("ship_barrel_close", "Таинственный корабль: бочка закрывается через", 60, 1, v -> MysteryShip.BARREL_CLOSE = (int) v);
        DEFS.add(new Def("ship_hearts", "Таинственный корабль: урон от капитана без отмычки", "сердец", 4, 0, 100, 1L, v -> MysteryShip.DAMAGE = (int) v * 2));
        DEFS.add(new Def("ship_knockback", "Таинственный корабль: отбрасывание", "бл", 10, 0, 50, 1L, v -> MysteryShip.KNOCKBACK = (int) v));

        // шалкеры замка и золотая лихорадка (лежат в arsenal_shulker.json)
        shulker("shulker_interval_min", "Шалкеры замка: интервал волн, от", "мин", 3, 1, 10080, "spawnEveryMinutes", "min");
        shulker("shulker_interval_max", "Шалкеры замка: интервал волн, до", "мин", 5, 1, 10080, "spawnEveryMinutes", "max");
        shulker("shulker_wave_min", "Шалкеры замка: за волну, от", "шт", 5, 1, 200, "waveSize", "min");
        shulker("shulker_wave_max", "Шалкеры замка: за волну, до", "шт", 6, 1, 200, "waveSize", "max");
        shulker("shulker_dur_gray", "Серый шалкер: прочность", "уд", 5, 1, 1000, "durability", "gray");
        shulker("shulker_dur_blue", "Голубой шалкер: прочность", "уд", 8, 1, 1000, "durability", "blue");
        shulker("shulker_dur_purple", "Фиолетовый шалкер: прочность", "уд", 13, 1, 1000, "durability", "purple");
        shulker("rush_duration", "Золотая лихорадка: длительность", "мин", 10, 1, 10080, "goldRush", "durationMinutes");
        shulker("rush_interval", "Золотая лихорадка: интервал появления", "мин", 3, 1, 10080, "goldRush", "spawnEveryMinutes");
        shulker("rush_dur_gold", "Золотой шалкер: прочность", "уд", 30, 1, 1000, "goldRush", "durability", "gold");
        shulker("rush_dur_red", "Красный шалкер: прочность", "уд", 45, 1, 1000, "goldRush", "durability", "red");

        // сколько стопок лута в контейнерах (груз, бочки корабля, шалкеры и т.д.)
        stacks("stk_cargo_peace_min", "Мирный груз: стопок в каждом шалкере, от", 27, 27, v -> CargoLoot.setSlots("peace", false, (int) v));
        stacks("stk_cargo_peace_max", "Мирный груз: стопок в каждом шалкере, до", 27, 27, v -> CargoLoot.setSlots("peace", true, (int) v));
        stacks("stk_cargo_explosive_min", "Взрывной груз: стопок в каждом шалкере, от", 27, 27, v -> CargoLoot.setSlots("explosive", false, (int) v));
        stacks("stk_cargo_explosive_max", "Взрывной груз: стопок в каждом шалкере, до", 27, 27, v -> CargoLoot.setSlots("explosive", true, (int) v));
        stacks("stk_cargo_deadly_min", "Смертельный груз: стопок в каждом шалкере, от", 27, 27, v -> CargoLoot.setSlots("deadly", false, (int) v));
        stacks("stk_cargo_deadly_max", "Смертельный груз: стопок в каждом шалкере, до", 27, 27, v -> CargoLoot.setSlots("deadly", true, (int) v));
        shulker("stk_castle_gray_min", "Серый шалкер замка: стопок, от", "стоп", 3, 1, 64, "loot", "gray", "rolls", "0");
        shulker("stk_castle_gray_max", "Серый шалкер замка: стопок, до", "стоп", 5, 1, 64, "loot", "gray", "rolls", "1");
        shulker("stk_castle_blue_min", "Голубой шалкер замка: стопок, от", "стоп", 5, 1, 64, "loot", "blue", "rolls", "0");
        shulker("stk_castle_blue_max", "Голубой шалкер замка: стопок, до", "стоп", 7, 1, 64, "loot", "blue", "rolls", "1");
        shulker("stk_castle_purple_min", "Фиолетовый шалкер замка: стопок, от", "стоп", 8, 1, 64, "loot", "purple", "rolls", "0");
        shulker("stk_castle_purple_max", "Фиолетовый шалкер замка: стопок, до", "стоп", 11, 1, 64, "loot", "purple", "rolls", "1");
        stacks("stk_rush_gold_min", "Золотой шалкер: стопок на земле, от", 12, 100, v -> CargoLoot.setStacks("goldrush", false, (int) v));
        stacks("stk_rush_gold_max", "Золотой шалкер: стопок на земле, до", 15, 100, v -> CargoLoot.setStacks("goldrush", true, (int) v));
        stacks("stk_rush_red_min", "Красный шалкер: стопок на земле, от", 8, 100, v -> CargoLoot.setStacks("goldrush_red", false, (int) v));
        stacks("stk_rush_red_max", "Красный шалкер: стопок на земле, до", 10, 100, v -> CargoLoot.setStacks("goldrush_red", true, (int) v));
        stacks("stk_xp_min", "Опытный Тыпо: стопок в сундуке, от", 8, 27, v -> CargoLoot.setStacks("xpevent", false, (int) v));
        stacks("stk_xp_max", "Опытный Тыпо: стопок в сундуке, до", 12, 27, v -> CargoLoot.setStacks("xpevent", true, (int) v));
        stacks("stk_core_min", "Ядро солнца: стопок за раз, от", 2, 64, v -> CargoLoot.setStacks("core", false, (int) v));
        stacks("stk_core_max", "Ядро солнца: стопок за раз, до", 3, 64, v -> CargoLoot.setStacks("core", true, (int) v));
        stacks("stk_ship_common_min", "Корабль: бочка обычная, стопок от", 3, 27, v -> CargoLoot.setStacks("ship_common", false, (int) v));
        stacks("stk_ship_common_max", "Корабль: бочка обычная, стопок до", 5, 27, v -> CargoLoot.setStacks("ship_common", true, (int) v));
        stacks("stk_ship_rare_min", "Корабль: бочка редкая, стопок от", 4, 27, v -> CargoLoot.setStacks("ship_rare", false, (int) v));
        stacks("stk_ship_rare_max", "Корабль: бочка редкая, стопок до", 7, 27, v -> CargoLoot.setStacks("ship_rare", true, (int) v));
        stacks("stk_ship_secret_min", "Корабль: бочка секретная, стопок от", 5, 27, v -> CargoLoot.setStacks("ship_secret", false, (int) v));
        stacks("stk_ship_secret_max", "Корабль: бочка секретная, стопок до", 8, 27, v -> CargoLoot.setStacks("ship_secret", true, (int) v));
        stacks("stk_ship_treasure_min", "Корабль: сокровище, стопок от", 12, 54, v -> CargoLoot.setStacks("ship_treasure", false, (int) v));
        stacks("stk_ship_treasure_max", "Корабль: сокровище, стопок до", 16, 54, v -> CargoLoot.setStacks("ship_treasure", true, (int) v));

        // ПВП-арена (/warp pvp): опыт у Ядра солнца
        DEFS.add(new Def("arena_xp_radius", "ПВП-арена: радиус опыта у ядра", "бл", 15, 1, 100, 1L, v -> PvpArena.XP_RADIUS = (int) v));
        DEFS.add(new Def("arena_xp_points", "ПВП-арена: опыт в центре, очков в секунду", "оч", 315, 0, 100000, 1L, v -> PvpArena.XP_MAX = (int) v));
        sec("core_drop_seconds", "ПВП-арена: лут с ядра раз в", 15, 1, v -> PvpArena.DROP_TICKS = (int) v);

        // дуэли, телепорты, прочее
        DEFS.add(new Def("pvp_deadly_arena", "Смертельная схватка: размер арены (сторона квадрата)", "бл", 150, 30, 1000, 1L, v -> PvpManager.ARENA = (int) v));
        sec("pvp_loot_seconds", "Арена: время на сбор лута", 60, 1, v -> PvpManager.LOOT_TICKS = (int) v);
        min("pvp_shrink_after", "Арена: через сколько начинает сужаться", 30, 1, v -> PvpManager.SHRINK_AFTER = (int) v);
        sec("tp_wait", "Телепорт: ожидание", 3, 0, v -> TeleportManager.WAIT_TICKS = (int) v);
        sec("tpa_request_ttl", "Запрос /tpa: время жизни", 60, 1, v -> TeleportManager.REQUEST_TTL = (int) v);
        sec("tpa_cooldown", "/tpa: кулдаун", 20, 0, v -> TeleportManager.TPA_COOLDOWN = (int) v);
        DEFS.add(new Def("homes_max", "Максимум домов у игрока", "шт", 10, 1, 1000, 1L, v -> TeleportManager.HOMES_MAX = (int) v));
        DEFS.add(new Def("exp_keeper_hours", "Хранитель опыта: время действия перка", "ч", 24, 1, 8760, 3_600_000L,
                v -> ExpKeeper.DURATION_MS = v));
    }

    private Settings() {
    }

    /** Читает файл настроек (создаёт, если нет) и подписывается на запуск мира. */
    public static void init() {
        load();
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            load();
            apply();
        });
        // игроки получают цифры сервера, чтобы описания предметов совпадали с настройками хоста
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendTo(handler.player));
        // Клиентский мод "Arsenal Menu-Op" (только у оператора): запрос данных и изменение настройки
        ServerPlayNetworking.registerGlobalReceiver(MENU_REQUEST, (server, player, handler, buf, responseSender) ->
                server.execute(() -> {
                    if (player.hasPermissionLevel(2)) {
                        sendMenu(player);
                    }
                }));
        ServerPlayNetworking.registerGlobalReceiver(MENU_SET, (server, player, handler, buf, responseSender) -> {
            final String key = buf.readString(256);
            final int value = buf.readInt();
            server.execute(() -> {
                if (!player.hasPermissionLevel(2)) {
                    return;
                }
                for (Def d : DEFS) {
                    if (d.key.equals(key)) {
                        Map<String, Integer> m = new LinkedHashMap<>();
                        m.put(key, value);
                        save(m, true);
                        broadcast(server);
                        sendMenu(player);
                        return;
                    }
                }
            });
        });
    }

    public static final Identifier MENU_REQUEST = new Identifier(Arsenal.MODID, "menu_request");
    public static final Identifier MENU_SET = new Identifier(Arsenal.MODID, "menu_set");
    public static final Identifier MENU_DATA = new Identifier(Arsenal.MODID, "menu_data");

    /** Все настройки с подписями и границами: для клиентского экрана оператора. */
    private static void sendMenu(ServerPlayerEntity player) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeVarInt(DEFS.size());
        for (Def d : DEFS) {
            buf.writeString(d.key);
            buf.writeString(d.label);
            buf.writeString(d.unit);
            buf.writeInt(VALUES.get(d.key));
            buf.writeInt(d.def);
            buf.writeInt(d.min);
            buf.writeInt(d.max);
        }
        ServerPlayNetworking.send(player, MENU_DATA, buf);
    }

    // ------------------------------------------------------------------ синхронизация и описания

    public static final Identifier SYNC = new Identifier(Arsenal.MODID, "settings_sync");
    /** Цифры сервера, пока клиент подключён к чужому/своему миру (иначе null, берутся свои). */
    private static Map<String, Integer> remote;

    private static void sendTo(ServerPlayerEntity player) {
        PacketByteBuf buf = PacketByteBufs.create();
        List<Def> list = new ArrayList<>();
        for (Def d : DEFS) {
            if (d.path == null) {
                list.add(d);
            }
        }
        buf.writeVarInt(list.size());
        for (Def d : list) {
            buf.writeString(d.key);
            buf.writeVarInt(VALUES.get(d.key));
        }
        ServerPlayNetworking.send(player, SYNC, buf);
    }

    public static void broadcast(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            sendTo(p);
        }
    }

    /** Клиент: пришли цифры сервера. */
    public static void applyRemote(Map<String, Integer> values) {
        remote = values;
    }

    public static void clearRemote() {
        remote = null;
    }

    private static Def byKey(String key) {
        for (Def d : DEFS) {
            if (d.key.equals(key)) {
                return d;
            }
        }
        return null;
    }

    /** Время в секундах для описания: значение сервера (если подключены) или своё. */
    private static long seconds(Def d) {
        int v = remote != null && remote.containsKey(d.key) ? remote.get(d.key) : get(d.key);
        long unit = "мин".equals(d.unit) ? 60L : "ч".equals(d.unit) ? 3600L : 1L;
        return v * unit;
    }

    private static String word(String keyBase, long n, boolean acc) {
        String key = keyBase + (acc && com.arsenal.vi.Lang.has(keyBase + ".acc") ? ".acc" : "");
        String[] forms = com.arsenal.vi.Lang.get(key).split("\\|");
        boolean en = "en".equals(com.arsenal.vi.Lang.get("arsenal.plural"));
        int i;
        if (en) {
            i = n == 1 ? 0 : 1;
        } else {
            long a = n % 100;
            long b = n % 10;
            i = (b == 1 && a != 11) ? 0 : (b >= 2 && b <= 4 && (a < 12 || a > 14)) ? 1 : 2;
        }
        return forms[Math.min(i, forms.length - 1)];
    }

    private static int shown(Def d) {
        return remote != null && remote.containsKey(d.key) ? remote.get(d.key) : get(d.key);
    }

    private static String roman(int n) {
        if (n <= 0 || n >= 4000) {
            return String.valueOf(n);
        }
        int[] v = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] r = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length; i++) {
            while (n >= v[i]) {
                sb.append(r[i]);
                n -= v[i];
            }
        }
        return sb.toString();
    }

    /**
     * Значение настройки для описания. Время ("сек"/"мин"/"ч"): "30 секунд", "1 минута", "2 часа"; mod "acc" даёт
     * форму после «на», «раз в» ("1 секунду"). mod "roman" - римская цифра (уровень эффекта), "num" и всё остальное
     * (проценты, штуки) - просто число.
     */
    public static String format(String key, String mod) {
        Def d = byKey(key);
        if (d == null) {
            return key;
        }
        if ("roman".equals(mod)) {
            return roman(shown(d));
        }
        boolean time = "сек".equals(d.unit) || "мин".equals(d.unit) || "ч".equals(d.unit);
        if (!time || "num".equals(mod)) {
            return String.valueOf(shown(d));
        }
        boolean acc = "acc".equals(mod);
        long sec = seconds(d);
        if (sec >= 3600 && sec % 3600 == 0) {
            long n = sec / 3600;
            return n + " " + word("arsenal.unit.hours", n, acc);
        }
        if (sec >= 60 && sec % 60 == 0) {
            long n = sec / 60;
            return n + " " + word("arsenal.unit.minutes", n, acc);
        }
        return sec + " " + word("arsenal.unit.seconds", sec, acc);
    }

    /** Заменяет в строке описания {ключ}, {ключ:acc}, {ключ:roman}, {ключ:num} на значения из настроек. */
    public static String expand(String s) {
        if (s.indexOf('{') < 0) {
            return s;
        }
        StringBuilder out = new StringBuilder();
        int pos = 0;
        while (pos < s.length()) {
            int open = s.indexOf('{', pos);
            int close = open < 0 ? -1 : s.indexOf('}', open);
            if (open < 0 || close < 0) {
                out.append(s.substring(pos));
                break;
            }
            out.append(s, pos, open);
            String token = s.substring(open + 1, close);
            int colon = token.indexOf(':');
            String key = colon < 0 ? token : token.substring(0, colon);
            String mod = colon < 0 ? "" : token.substring(colon + 1);
            out.append(byKey(key) == null ? "{" + token + "}" : format(key, mod));
            pos = close + 1;
        }
        return out.toString();
    }

    public static List<Def> defs() {
        return Collections.unmodifiableList(DEFS);
    }

    public static int get(String key) {
        Integer v = VALUES.get(key);
        if (v != null) {
            return v;
        }
        for (Def d : DEFS) {
            if (d.key.equals(key)) {
                return d.def;
            }
        }
        return 0;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_settings.json");
    }

    public static void load() {
        VALUES.clear();
        JsonObject root = null;
        try {
            Path f = file();
            if (Files.exists(f)) {
                root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_settings.json: " + ex);
        }
        boolean missing = root == null;
        JsonObject shulkerRoot = readShulker();
        for (Def d : DEFS) {
            int v = d.def;
            if (d.path != null) {
                Integer sv = shulkerValue(shulkerRoot, d.path);
                VALUES.put(d.key, Math.max(d.min, Math.min(d.max, sv == null ? d.def : sv)));
                continue;
            }
            // раньше для грузов было одно число "стопок в шалкере": переносим его в "от" и "до"
            String oldKey = d.key.startsWith("stk_cargo_") && (d.key.endsWith("_min") || d.key.endsWith("_max"))
                    ? d.key.substring(0, d.key.length() - 4) : null;
            if (root != null && !root.has(d.key) && oldKey != null && root.has(oldKey)) {
                missing = true;
                try {
                    v = root.get(oldKey).getAsInt();
                } catch (Exception ex) {
                    v = d.def;
                }
            } else if (root != null && root.has(d.key)) {
                try {
                    v = root.get(d.key).getAsInt();
                } catch (Exception ex) {
                    v = d.def;
                }
            } else {
                missing = true;
            }
            VALUES.put(d.key, Math.max(d.min, Math.min(d.max, v)));
        }
        if (missing) {
            write();
        }
    }

    private static void write() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("_help", "Цифры мода. Время в секундах (сек), минутах (мин) или часах (ч), как указано в названии. Правится и в игре: Mod Menu - Arsenal - Общие настройки.");
            for (Def d : DEFS) {
                if (d.path == null) {
                    o.addProperty(d.key, VALUES.get(d.key));
                }
            }
            Files.write(file(), GSON.toJson(o).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_settings.json: " + ex);
        }
    }

    /** Кладёт значения в игру (в поля кулдаунов и т.п.). */
    public static void apply() {
        for (Def d : DEFS) {
            if (d.path != null) {
                continue;
            }
            try {
                d.apply.accept(VALUES.get(d.key) * d.mult);
            } catch (Throwable t) {
                System.err.println("[Arsenal] Настройка " + d.key + " не применилась: " + t);
            }
        }
    }

    /** Из экрана настроек: запоминает значения, пишет файл и (если applyNow) сразу применяет. */
    public static void save(Map<String, Integer> values, boolean applyNow) {
        for (Def d : DEFS) {
            Integer v = values.get(d.key);
            if (v != null) {
                VALUES.put(d.key, Math.max(d.min, Math.min(d.max, v)));
            }
        }
        // "до" не меньше "от"
        keepOrder("shulker_interval_min", "shulker_interval_max");
        keepOrder("shulker_wave_min", "shulker_wave_max");
        for (String k : new String[]{"cargo_peace", "cargo_explosive", "cargo_deadly", "castle_gray", "castle_blue", "castle_purple", "rush_gold", "rush_red", "xp", "core",
                "ship_common", "ship_rare", "ship_secret", "ship_treasure"}) {
            keepOrder("stk_" + k + "_min", "stk_" + k + "_max");
        }
        write();
        writeShulker();
        if (applyNow) {
            apply();
            ShulkerEvent.reloadConfig();
        }
    }

    private static void keepOrder(String lo, String hi) {
        if (VALUES.get(hi) < VALUES.get(lo)) {
            VALUES.put(hi, VALUES.get(lo));
        }
    }

    private static Path shulkerFile() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_shulker.json");
    }

    private static JsonObject readShulker() {
        try {
            Path f = shulkerFile();
            if (Files.exists(f)) {
                return new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_shulker.json: " + ex);
        }
        return null;
    }

    /** Дочерний элемент: по имени поля объекта или по номеру в массиве (например, "rolls" - "0"). */
    private static JsonElement child(JsonElement cur, String key) {
        if (cur == null) {
            return null;
        }
        if (cur.isJsonObject()) {
            return cur.getAsJsonObject().has(key) ? cur.getAsJsonObject().get(key) : null;
        }
        if (cur.isJsonArray()) {
            try {
                int i = Integer.parseInt(key);
                JsonArray a = cur.getAsJsonArray();
                return i >= 0 && i < a.size() ? a.get(i) : null;
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        return null;
    }

    private static Integer shulkerValue(JsonObject root, String[] path) {
        JsonElement cur = root;
        for (String p : path) {
            cur = child(cur, p);
            if (cur == null) {
                return null;
            }
        }
        try {
            return cur.getAsInt();
        } catch (Exception ex) {
            return null;
        }
    }

    private static void writeShulker() {
        try {
            if (!Files.exists(shulkerFile())) {
                ShulkerEvent.reloadConfig();   // создаёт файл из настроек по умолчанию
            }
            JsonObject root = readShulker();
            if (root == null) {
                return;
            }
            for (Def d : DEFS) {
                if (d.path == null) {
                    continue;
                }
                JsonElement cur = root;
                boolean ok = true;
                for (int i = 0; i < d.path.length - 1; i++) {
                    JsonElement next = child(cur, d.path[i]);
                    if (next == null) {
                        if (!cur.isJsonObject()) {
                            ok = false;   // в массиве нет нужного элемента: такой путь не создаём
                            break;
                        }
                        next = new JsonObject();
                        cur.getAsJsonObject().add(d.path[i], next);
                    }
                    cur = next;
                }
                if (!ok) {
                    continue;
                }
                String last = d.path[d.path.length - 1];
                if (cur.isJsonArray()) {
                    try {
                        int idx = Integer.parseInt(last);
                        if (idx >= 0 && idx < cur.getAsJsonArray().size()) {
                            cur.getAsJsonArray().set(idx, new JsonPrimitive(VALUES.get(d.key)));
                        }
                    } catch (NumberFormatException ignored) {
                        // не номер: пропускаем
                    }
                } else if (cur.isJsonObject()) {
                    cur.getAsJsonObject().addProperty(last, VALUES.get(d.key));
                }
            }
            Files.write(shulkerFile(), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_shulker.json: " + ex);
        }
    }
}
