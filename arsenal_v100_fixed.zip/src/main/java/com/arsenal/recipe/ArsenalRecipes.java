package com.arsenal.recipe;

import com.arsenal.Arsenal;
import com.arsenal.blast.BlastKind;
import com.arsenal.blast.Blasts;
import com.arsenal.vi.VI;
import net.minecraft.inventory.CraftingInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Все крафты мода (раньше лежали в data/arsenal/recipes и не работали). Ингредиент "обычный" = без метки мода. */
public final class ArsenalRecipes {
    private interface Ing {
        boolean test(ItemStack s);
    }

    private static final List<CraftingRecipe> LIST = new ArrayList<>();
    private static boolean built = false;

    private ArsenalRecipes() {
    }

    private static Ing plain(Item item) {
        return s -> s.getItem() == item && VI.of(s) == null;
    }

    private static Ing vi(VI v) {
        return v::is;
    }

    private abstract static class Base implements CraftingRecipe {
        final Identifier id;
        final Supplier<ItemStack> out;

        Base(String name, Supplier<ItemStack> out) {
            this.id = new Identifier("arsenal", name);
            this.out = out;
        }

        @Override
        public ItemStack craft(CraftingInventory inv) {
            return out.get();
        }

        @Override
        public ItemStack getOutput() {
            return out.get();
        }

        @Override
        public Identifier getId() {
            return id;
        }

        @Override
        public RecipeSerializer<?> getSerializer() {
            return RecipeSerializer.SHAPELESS;
        }

        @Override
        public boolean isIgnoredInRecipeBook() {
            return true;
        }
    }

    private static final class Shaped extends Base {
        final String pattern;   // 9 символов, строка за строкой
        final Map<Character, Ing> keys;

        Shaped(String name, Supplier<ItemStack> out, String pattern, Map<Character, Ing> keys) {
            super(name, out);
            this.pattern = pattern;
            this.keys = keys;
        }

        @Override
        public boolean matches(CraftingInventory inv, World world) {
            if (inv.getWidth() != 3 || inv.getHeight() != 3) {
                return false;
            }
            for (int i = 0; i < 9; i++) {
                char c = pattern.charAt(i);
                ItemStack s = inv.getStack(i);
                if (c == ' ') {
                    if (!s.isEmpty()) {
                        return false;
                    }
                } else if (s.isEmpty() || !keys.get(c).test(s)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public boolean fits(int width, int height) {
            return width >= 3 && height >= 3;
        }
    }

    private static final class Shapeless extends Base {
        final List<Ing> ingredients;

        Shapeless(String name, Supplier<ItemStack> out, List<Ing> ingredients) {
            super(name, out);
            this.ingredients = ingredients;
        }

        @Override
        public boolean matches(CraftingInventory inv, World world) {
            List<ItemStack> have = new ArrayList<>();
            for (int i = 0; i < inv.size(); i++) {
                if (!inv.getStack(i).isEmpty()) {
                    have.add(inv.getStack(i));
                }
            }
            if (have.size() != ingredients.size()) {
                return false;
            }
            boolean[] used = new boolean[have.size()];
            for (Ing ing : ingredients) {
                boolean found = false;
                for (int i = 0; i < have.size(); i++) {
                    if (!used[i] && ing.test(have.get(i))) {
                        used[i] = true;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public boolean fits(int width, int height) {
            return width * height >= ingredients.size();
        }
    }

    private static Map<Character, Ing> keys(Object... kv) {
        Map<Character, Ing> m = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put((Character) kv[i], (Ing) kv[i + 1]);
        }
        return m;
    }

    /** Заполняется после регистрации предметов (см. Arsenal.onInitialize). */
    public static synchronized void build() {
        if (built) {
            return;
        }
        built = true;
        Ing gunpowder = plain(Items.GUNPOWDER);
        Ing sand = plain(Items.SAND);
        Ing tnt = plain(Items.TNT);
        Ing fireCharge = plain(Items.FIRE_CHARGE);
        VI substance = Blasts.EXPLOSIVE_SUBSTANCE;
        VI dynA = Blasts.vi(BlastKind.DYNAMITE_A);
        VI dynB = Blasts.vi(BlastKind.DYNAMITE_B);

        LIST.add(new Shaped("dynamite_a", () -> dynA.stack(), "GSGTGTGSG",
                keys('G', gunpowder, 'S', sand, 'T', tnt)));
        LIST.add(new Shaped("dynamite_b", () -> dynB.stack(), "GSGTGTGSG",
                keys('G', gunpowder, 'S', sand, 'T', vi(dynA))));
        LIST.add(new Shaped("c4", () -> Blasts.vi(BlastKind.C4).stack(), "GSGTGTGSG",
                keys('G', gunpowder, 'S', sand, 'T', vi(dynB))));
        LIST.add(new Shaped("stealer", () -> Blasts.vi(BlastKind.STEALER).stack(), "GSGTGTGSG",
                keys('G', gunpowder, 'S', sand, 'T', vi(Blasts.vi(BlastKind.C4)))));
        LIST.add(new Shaped("reliable_stealer", () -> Blasts.vi(BlastKind.RELIABLE_STEALER).stack(), "GSGTGTGSG",
                keys('G', gunpowder, 'S', sand, 'T', vi(Blasts.vi(BlastKind.STEALER)))));
        LIST.add(new Shaped("dynamite_b2", () -> Blasts.vi(BlastKind.DYNAMITE_B2).stack(), "EAEAEAEAE",
                keys('E', vi(substance), 'A', vi(dynA))));
        LIST.add(new Shaped("ice_wave", () -> Blasts.vi(BlastKind.ICE_WAVE).stack(), "TITITITIT",
                keys('T', tnt, 'I', plain(Items.BLUE_ICE))));
        LIST.add(new Shaped("explosive_trap", () -> Arsenal.EXPLOSIVE_TRAP.stack(), "FEFSRSFEF",
                keys('F', fireCharge, 'E', vi(substance), 'S', sand, 'R', plain(Items.REDSTONE))));
        LIST.add(new Shaped("stun", () -> Arsenal.STUN.stack(), "SSSFEFSSS",
                keys('S', plain(Items.SPIDER_EYE), 'F', fireCharge, 'E', vi(substance))));
        LIST.add(new Shaped("trap", () -> Arsenal.TRAP.stack(), " S SES S ",
                keys('S', plain(Items.NETHERITE_SCRAP), 'E', vi(substance))));
        LIST.add(new Shaped("jake_pickaxe", () -> Arsenal.JAKE_PICKAXE.stack(), "RTRTPTRTR",
                keys('R', plain(Items.REDSTONE_BLOCK), 'T', tnt, 'P', plain(Items.GOLDEN_PICKAXE))));

        List<Ing> nine = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            nine.add(gunpowder);
        }
        LIST.add(new Shapeless("explosive_substance", () -> substance.stack(), nine));
        List<Ing> one = new ArrayList<>();
        one.add(vi(substance));
        LIST.add(new Shapeless("explosive_substance_to_gunpowder", () -> new ItemStack(Items.GUNPOWDER, 9), one));
    }

    public static CraftingRecipe find(CraftingInventory inv) {
        build();
        for (CraftingRecipe r : LIST) {
            if (r.matches(inv, null)) {
                return r;
            }
        }
        return null;
    }

    /** Есть ли в сетке предмет мода (в ванильных рецептах им не место). */
    public static boolean hasModItem(CraftingInventory inv) {
        for (int i = 0; i < inv.size(); i++) {
            if (VI.of(inv.getStack(i)) != null) {
                return true;
            }
        }
        return false;
    }
}
