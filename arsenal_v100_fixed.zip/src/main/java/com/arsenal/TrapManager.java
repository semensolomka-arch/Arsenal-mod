package com.arsenal;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/** Помнит, какие блоки (и содержимое сундуков и т.п.) были до трапки, и возвращает их по таймеру. */
public class TrapManager {
    /** 2 = отправить клиентам, 16 = без обновления соседей (чтобы факелы и т.п. не отваливались). */
    public static final int FLAGS = 2 | 16;

    private static final List<Entry> ENTRIES = new ArrayList<>();
    /** Блоки взрывной трапки, которые пока нельзя ломать (см. Specials). */
    private static final Set<BlockPos> PROTECTED = new HashSet<>();

    public static boolean isProtected(BlockPos pos) {
        return !PROTECTED.isEmpty() && PROTECTED.contains(pos);
    }

    private static class Entry {
        final ServerWorld world;
        final BlockPos pos;
        final BlockState original;
        final BlockEntity blockEntity; // сундук/печка/табличка и т.п. вместе с содержимым, может быть null
        /** Слепок содержимого блока-сущности, снятый до замены блока (надёжнее, чем сам объект), может быть null. */
        final NbtCompound blockEntityData;
        /** Какой блок поставила трапка (чтобы вернуть исходный только на его месте), может быть null. */
        final Block placed;
        int ticks;

        Entry(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, int ticks, Block placed) {
            this(world, pos, original, blockEntity, blockEntity == null ? null : blockEntity.writeNbt(new NbtCompound()), ticks, placed);
        }

        Entry(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, NbtCompound data, int ticks, Block placed) {
            this.placed = placed;
            this.world = world;
            this.pos = pos;
            this.original = original;
            this.blockEntity = blockEntity;
            this.blockEntityData = data;
            this.ticks = ticks;
        }
    }

    /**
     * Если в этой точке уже есть запись (вторая трапка поверх первой), настоящий исходный блок помнит первая запись:
     * новая наследует его и держится дольше из двух таймеров, а старая запись убирается, иначе по очереди вернулись бы
     * исходный блок и потом блок первой трапки, и земля не восстановилась бы.
     */
    private static Entry merged(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, int ticks, Block placed) {
        BlockPos ip = pos.toImmutable();
        for (Iterator<Entry> it = ENTRIES.iterator(); it.hasNext(); ) {
            Entry old = it.next();
            if (old.world == world && old.pos.equals(ip)) {
                it.remove();
                return new Entry(world, ip, old.original, old.blockEntity, old.blockEntityData,
                        Math.max(ticks, old.ticks), placed != null ? placed : old.placed);
            }
        }
        return new Entry(world, ip, original, blockEntity, ticks, placed);
    }

    public static void add(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, int ticks) {
        ENTRIES.add(merged(world, pos, original, blockEntity, ticks, null));
    }

    /** Для взрывной трапки: placed это блок, который мы поставили; пока он стоит, его нельзя сломать. */
    public static void add(ServerWorld world, BlockPos pos, BlockState original, BlockEntity blockEntity, int ticks, Block placed) {
        Entry e = merged(world, pos, original, blockEntity, ticks, placed);
        ENTRIES.add(e);
        if (e.placed != null) {
            PROTECTED.add(pos.toImmutable());
        }
    }

    /** Возвращает исходный блок сразу, даже если там кто-то стоит. */
    private static void restore(Entry e) {
        PROTECTED.remove(e.pos);
        BlockState cur = e.world.getBlockState(e.pos);
        // возвращаем, только если там наша плита, пустота или жидкость/что-то заменяемое
        boolean ours = (e.placed != null && cur.isOf(e.placed))
                || cur.isAir() || cur.getMaterial().isReplaceable();
        if (!ours) {
            return;
        }
        e.world.setBlockState(e.pos, e.original, FLAGS);
        if (e.blockEntity != null) {
            // setBlockState уже создал новый пустой сундук/печку: заполняем его сохранённым содержимым
            BlockEntity fresh = e.world.getBlockEntity(e.pos);
            if (fresh != null && e.blockEntityData != null) {
                fresh.fromTag(e.original, e.blockEntityData);
                fresh.markDirty();
            } else {
                e.blockEntity.cancelRemoval();
                e.world.setBlockEntity(e.pos, e.blockEntity);
                e.blockEntity.markDirty();
            }
        }
    }

    public static void tick() {
        Iterator<Entry> it = ENTRIES.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (--e.ticks <= 0) {
                restore(e);
                it.remove();
            }
        }
    }

    /** При остановке сервера всё возвращаем сразу. */
    public static void clearAll() {
        for (Entry e : ENTRIES) {
            restore(e);
        }
        ENTRIES.clear();
        PROTECTED.clear();
    }
}
