package com.arsenal.event;

import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.MessageType;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Ивент "Груз": раз в 15 минут в Обычном мире (до 4000 блоков от центра) появляется мирный или взрывной груз.
 * 4 шалкера на кварцевых (мирный) или бастионных (взрывной) площадках, круглая зона 50x50 с краем из шерсти.
 * Через 8 минут груз открывается: мирный отталкивает всех без урона, взрывной взрывает каждый шалкер как
 * динамит Б (блоки не ломаются). Ещё 5 минут лут можно забирать, потом груз исчезает, местность возвращается.
 * Смертельный груз: в центре узкая яма (9x9) глубиной 25 блоков, выход только по сложному паркуру вдоль стен, 4 красных шалкера на дне. За 10 секунд до открытия крыша ямы
 * закрывается, и пока груз не исчезнет, из ямы не выйти. В зоне постоянный режим боя и стан-зона. Когда груз исчезает,
 * яма засыпается (кто остался внутри, задыхается в блоках).
 * В мирной зоне нет PvP. В зоне нельзя ломать, строить, взрывать блоки, ставить приваты и трапки.
 *
 * Команды: /event, /event freeze|unfreeze, /event spawn груз мирный|взрывной, /event time skip.
 */
public final class EventManager {
    public enum Type {
        PEACE("peace", "Мирный груз", Formatting.AQUA, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.QUARTZ_BLOCK, Blocks.LIGHT_BLUE_WOOL),
        EXPLOSIVE("explosive", "Взрывной груз", Formatting.GOLD, Blocks.ORANGE_SHULKER_BOX, Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.ORANGE_WOOL),
        DEADLY("deadly", "Смертельный груз", Formatting.DARK_RED, Blocks.RED_SHULKER_BOX, Blocks.RED_NETHER_BRICKS, Blocks.RED_WOOL);

        final String key;
        public final String title;
        final Formatting color;
        final Block shulker;
        final Block base;
        final Block ring;

        Type(String key, String title, Formatting color, Block shulker, Block base, Block ring) {
            this.key = key;
            this.title = title;
            this.color = color;
            this.shulker = shulker;
            this.base = base;
            this.ring = ring;
        }

        static Type byKey(String key) {
            if ("explosive".equals(key)) {
                return EXPLOSIVE;
            }
            return "deadly".equals(key) ? DEADLY : PEACE;
        }
    }

    static final class Cargo {
        Type type;
        int cx, cy, cz;
        int age;
        boolean opened;
        boolean blasting;
        /** Смертельный груз: крыша ямы закрыта. */
        boolean roofClosed;
        int blastTick;
        int blastIndex;
        final List<BlockPos> shulkers = new ArrayList<>();
        final Map<Long, Integer> saved = new LinkedHashMap<>();
    }

    public static int INTERVAL = 20 * 60 * 15;
    public static int OPEN_AT = 20 * 60 * 8;
    public static int STAY = 20 * 60 * 5;
    /** Радиус зоны: 50 блоков в диаметре. */
    public static final double RADIUS = 25.5;
    private static final int MAX_DISTANCE = 4000;
    /** Смертельный груз: половина стороны ямы (4 значит 9x9), глубина ямы, за сколько тиков до открытия закрывается крыша. */
    private static final int PIT_HALF = 4;
    private static final int PIT_DEPTH = 25;
    private static final int ROOF_BEFORE = 20 * 10;
    /** За сколько тиков до закрытия крыши начинаются предупреждения над хотбаром. */
    private static final int ROOF_WARN = 20 * 10;
    private static final int HALF = 11;
    private static final Random RNG = new Random();

    private static int nextIn = INTERVAL;
    private static boolean frozen;
    private static boolean wasBusy;
    private static Cargo active;
    private static boolean loaded;

    private EventManager() {
    }

    // ------------------------------------------------------------------ зона

    public static boolean inZone(World world, double x, double z) {
        if (XpEvent.inZone(world, x, z) || MysteryShip.inZone(world, x, z) || DeadlyMine.inZone(world, x, z)) {
            return true;   // площадка Опытного Тыпо и Таинственный корабль защищены так же, как груз
        }
        Cargo c = active;
        if (c == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        double dx = x - (c.cx + 0.5);
        double dz = z - (c.cz + 0.5);
        return dx * dx + dz * dz <= RADIUS * RADIUS;
    }

    public static boolean inZone(World world, BlockPos pos) {
        return inZone(world, pos.getX() + 0.5, pos.getZ() + 0.5);
    }

    /** Точка в круглой зоне именно груза (без площадки Опытного Тыпо и корабля). От неё зависят режим боя и мирная зона. */
    private static boolean inCargoZone(World world, double x, double z) {
        Cargo c = active;
        if (c == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        double dx = x - (c.cx + 0.5);
        double dz = z - (c.cz + 0.5);
        return dx * dx + dz * dz <= RADIUS * RADIUS;
    }

    /** Центр текущего груза (x, z) или null, если груза сейчас нет. */
    public static int[] center() {
        Cargo c = active;
        return c == null ? null : new int[]{c.cx, c.cz};
    }

    /** Центры всех идущих сейчас ивентов (груз любого вида, Опытный Тыпо, Таинственный корабль, Смертельная шахта). */
    public static List<int[]> allCenters() {
        List<int[]> out = new ArrayList<>();
        int[] c = center();
        if (c != null) {
            out.add(c);
        }
        for (int[] o : new int[][]{XpEvent.center(), MysteryShip.center(), DeadlyMine.center()}) {
            if (o != null) {
                out.add(o);
            }
        }
        return out;
    }

    /** В зоне мирного груза PvP выключено. */
    public static boolean peaceAt(World world, double x, double z) {
        return active != null && active.type == Type.PEACE && inCargoZone(world, x, z);
    }

    /** Шалкер текущего груза. -1: не шалкер груза, 0: закрыт, 1: можно открывать. */
    public static int shulkerState(World world, BlockPos pos) {
        Cargo c = active;
        if (c == null || world.getRegistryKey() != World.OVERWORLD || !c.shulkers.contains(pos)) {
            return -1;
        }
        return c.opened ? 1 : 0;
    }

    public static String untilOpen() {
        Cargo c = active;
        if (c == null) {
            return "";
        }
        return fmt(Math.max(0, OPEN_AT - c.age));
    }

    // ------------------------------------------------------------------ запуск

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(EventManager::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            save();
            active = null;
            loaded = false;
        });
        ServerTickEvents.END_SERVER_TICK.register(EventManager::tick);
        CargoProtection.init();
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(buildCommand()));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> buildCommand() {
        LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("event")
                .executes(ctx -> {
                    info(ctx.getSource());
                    return 1;
                });
        root.then(CommandManager.literal("freeze").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> {
            frozen = true;
            save();
            ctx.getSource().sendFeedback(new LiteralText("Новые ивенты не будут появляться, пока не введёте /event unfreeze"), true);
            return 1;
        }));
        root.then(CommandManager.literal("unfreeze").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> {
            frozen = false;
            save();
            ctx.getSource().sendFeedback(new LiteralText("Ивенты снова появляются"), true);
            return 1;
        }));

        LiteralArgumentBuilder<ServerCommandSource> spawn = CommandManager.literal("spawn").requires(s -> s.hasPermissionLevel(2));
        for (String cargo : new String[]{"груз", "crate"}) {
            LiteralArgumentBuilder<ServerCommandSource> node = CommandManager.literal(cargo);
            for (String name : new String[]{"мирный", "peaceful"}) {
                node.then(CommandManager.literal(name).executes(ctx -> spawnCommand(ctx.getSource(), Type.PEACE)));
            }
            for (String name : new String[]{"взрывной", "explosive"}) {
                node.then(CommandManager.literal(name).executes(ctx -> spawnCommand(ctx.getSource(), Type.EXPLOSIVE)));
            }
            for (String name : new String[]{"смертельный", "deadly"}) {
                node.then(CommandManager.literal(name).executes(ctx -> spawnCommand(ctx.getSource(), Type.DEADLY)));
            }
            spawn.then(node);
        }
        // /event spawn exp  или  /event spawn Опытный Тыпо
        Command<ServerCommandSource> spawnXp = ctx -> {
            if (!XpEvent.startRandom(ctx.getSource().getMinecraftServer())) {
                ctx.getSource().sendFeedback(new LiteralText("Опытный Тыпо уже идёт или нет места").formatted(Formatting.RED), false);
                return 0;
            }
            return 1;
        };
        spawn.then(CommandManager.literal("exp").executes(spawnXp));
        for (String first : new String[]{"Опытный", "опытный"}) {
            for (String second : new String[]{"Тыпо", "тыпо"}) {
                spawn.then(CommandManager.literal(first).then(CommandManager.literal(second).executes(spawnXp)));
            }
        }
        // /event spawn mystery ship  или  /event spawn Таинственный корабль
        Command<ServerCommandSource> spawnShip = ctx -> {
            if (!MysteryShip.startRandom(ctx.getSource().getMinecraftServer())) {
                ctx.getSource().sendFeedback(new LiteralText("Таинственный корабль уже идёт или нет подходящей воды").formatted(Formatting.RED), false);
                return 0;
            }
            return 1;
        };
        spawn.then(CommandManager.literal("mystery").then(CommandManager.literal("ship").executes(spawnShip)));
        for (String first : new String[]{"Таинственный", "таинственный"}) {
            for (String second : new String[]{"корабль", "Корабль"}) {
                spawn.then(CommandManager.literal(first).then(CommandManager.literal(second).executes(spawnShip)));
            }
        }
        // /event spawn deadly mine  или  /event spawn смертельная шахта
        Command<ServerCommandSource> spawnMine = ctx -> {
            if (!DeadlyMine.startRandom(ctx.getSource().getMinecraftServer())) {
                ctx.getSource().sendFeedback(new LiteralText("Смертельная шахта уже идёт или нет места").formatted(Formatting.RED), false);
                return 0;
            }
            return 1;
        };
        spawn.then(CommandManager.literal("deadly").then(CommandManager.literal("mine").executes(spawnMine)));
        for (String first : new String[]{"смертельная", "Смертельная"}) {
            for (String second : new String[]{"шахта", "Шахта"}) {
                spawn.then(CommandManager.literal(first).then(CommandManager.literal(second).executes(spawnMine)));
            }
        }
        for (String rush : new String[]{"лихорадка", "goldrush"}) {
            spawn.then(CommandManager.literal(rush).executes(ctx -> spawnRushCommand(ctx.getSource())));
        }
        // /event spawn boss <джо|вошь|смертник|спидраннер>
        LiteralArgumentBuilder<ServerCommandSource> bossNode = CommandManager.literal("boss");
        for (com.arsenal.boss.BossType bt : com.arsenal.boss.BossType.values()) {
            Command<ServerCommandSource> run = ctx -> {
                if (!com.arsenal.boss.BossManager.spawn(ctx.getSource().getMinecraftServer(), bt)) {
                    ctx.getSource().sendFeedback(new LiteralText("Не удалось: арена не готова или внизу нет свободного места").formatted(Formatting.RED), false);
                    return 0;
                }
                return 1;
            };
            for (String nm : bt.names) {
                bossNode.then(CommandManager.literal(nm).executes(run));
            }
        }
        bossNode.then(CommandManager.literal("random").executes(ctx -> com.arsenal.boss.BossManager.startRandom(ctx.getSource().getMinecraftServer()) ? 1 : 0));
        spawn.then(bossNode);
        root.then(spawn);

        root.then(CommandManager.literal("time").requires(s -> s.hasPermissionLevel(2))
                .then(CommandManager.literal("skip").executes(ctx -> skip(ctx.getSource()))));
        return root;
    }

    /** Раз в 15 минут: мирный груз, взрывной груз, смертельный груз, золотая лихорадка, Опытный Тыпо или Таинственный корабль (поровну). */
    private static boolean startRandom(MinecraftServer server) {
        int r = RNG.nextInt(com.arsenal.boss.BossManager.CYCLE_PAUSED ? 7 : 8);
        if (r == 7) {
            if (com.arsenal.boss.BossManager.startRandom(server)) {
                nextIn = INTERVAL;
                save();
                return true;
            }
            r = RNG.nextInt(4);   // арена не готова или нет места: берём обычный ивент
        }
        if (r == 6) {
            if (DeadlyMine.startRandom(server)) {
                nextIn = INTERVAL;
                save();
                return true;
            }
            r = RNG.nextInt(4);   // шахта уже идёт или нет места: берём обычный ивент
        }
        if (r == 5) {
            if (MysteryShip.startRandom(server)) {
                nextIn = INTERVAL;
                save();
                return true;
            }
            r = RNG.nextInt(4);   // корабль уже идёт или нет подходящей воды: берём обычный ивент
        }
        if (r == 4) {
            if (XpEvent.startRandom(server)) {
                nextIn = INTERVAL;
                save();
                return true;
            }
            r = RNG.nextInt(4);   // Опытный Тыпо уже идёт или нет места: берём обычный ивент
        }
        if (r == 2 && com.arsenal.shulker.ShulkerEvent.startGoldRush(server)) {
            nextIn = INTERVAL;
            save();
            return true;
        }
        Type type = r == 0 ? Type.PEACE : r == 3 ? Type.DEADLY : Type.EXPLOSIVE;
        return spawn(server, type);
    }

    private static int spawnRushCommand(ServerCommandSource source) {
        MinecraftServer server = source.getMinecraftServer();
        if (!loaded) {
            source.sendFeedback(new LiteralText("Ивенты ещё не загружены").formatted(Formatting.RED), false);
            return 0;
        }
        if (!com.arsenal.shulker.ShulkerEvent.startGoldRush(server)) {
            source.sendFeedback(new LiteralText("Нет мест для шалкеров (/shulker add)").formatted(Formatting.RED), false);
            return 0;
        }
        return 1;
    }

    private static int spawnCommand(ServerCommandSource source, Type type) {
        MinecraftServer server = source.getMinecraftServer();
        if (!loaded) {
            source.sendFeedback(new LiteralText("Ивенты ещё не загружены").formatted(Formatting.RED), false);
            return 0;
        }
        if (active != null) {
            remove(server, false);
        }
        if (!spawn(server, type)) {
            source.sendFeedback(new LiteralText("Не удалось найти подходящее место, попробуйте ещё раз").formatted(Formatting.RED), false);
            return 0;
        }
        return 1;
    }

    /**
     * /event time skip (только операторы): что идёт, то и продвигается.
     * Груз: открывается, потом исчезает. Золотая лихорадка: заканчивается. Опытный Тыпо: появляются сундуки, а если сундуки
     * уже появились, ивент исчезает. Таинственный корабль: исчезает. Если ивента нет, запускается один случайный.
     */
    private static int skip(ServerCommandSource source) {
        MinecraftServer server = source.getMinecraftServer();
        if (!loaded) {
            return 0;
        }
        if (active != null) {
            if (!active.opened && !active.blasting) {
                active.age = OPEN_AT;
                source.sendFeedback(new LiteralText("Груз открывается"), true);
            } else if (active.opened) {
                active.age = OPEN_AT + STAY;
                source.sendFeedback(new LiteralText("Груз исчезает"), true);
            } else {
                source.sendFeedback(new LiteralText("Груз сейчас взрывается").formatted(Formatting.RED), false);
            }
            return 1;
        }
        if (com.arsenal.shulker.ShulkerEvent.isRush()) {
            com.arsenal.shulker.ShulkerEvent.stopGoldRush(server, true);
            source.sendFeedback(new LiteralText("Золотая лихорадка закончена"), true);
            return 1;
        }
        if (XpEvent.isActive()) {
            boolean chests = XpEvent.skip(server);
            source.sendFeedback(new LiteralText(chests ? "Опытный Тыпо закончился: появились сундуки" : "Опытный Тыпо исчезает"), true);
            return 1;
        }
        if (DeadlyMine.isActive()) {
            DeadlyMine.despawn(server);
            source.sendFeedback(new LiteralText("Смертельная шахта исчезает"), true);
            return 1;
        }
        if (com.arsenal.boss.BossManager.isActive()) {
            com.arsenal.boss.BossManager.despawn(server);
            source.sendFeedback(new LiteralText("Босс исчезает, таймер до нового ивента запущен"), true);
            return 1;
        }
        if (MysteryShip.isActive()) {
            MysteryShip.despawn(server);
            source.sendFeedback(new LiteralText("Таинственный корабль исчезает"), true);
            return 1;
        }
        // никакого ивента нет: запускаем один случайный
        if (!startRandom(server)) {
            source.sendFeedback(new LiteralText("Не удалось найти подходящее место, попробуйте ещё раз").formatted(Formatting.RED), false);
            return 0;
        }
        source.sendFeedback(new LiteralText("Время до ивента пропущено"), true);
        return 1;
    }

    private static void info(ServerCommandSource source) {
        MutableText out = new LiteralText("");
        Cargo c = active;
        if (c != null) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(c.type.title).formatted(c.type.color, Formatting.BOLD));
            out.append(new LiteralText("\nКоординаты: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.WHITE));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
            if (c.opened) {
                out.append(new LiteralText("Груз открыт, исчезнет через ").formatted(Formatting.GRAY));
                out.append(new LiteralText(fmt(OPEN_AT + STAY - c.age)).formatted(Formatting.GREEN));
            } else if (c.blasting) {
                out.append(new LiteralText("Груз взрывается!").formatted(Formatting.RED));
            } else {
                out.append(new LiteralText(c.type == Type.EXPLOSIVE ? "Взорвётся через " : "Откроется через ").formatted(Formatting.GRAY));
                out.append(new LiteralText(fmt(OPEN_AT - c.age)).formatted(Formatting.GREEN));
            }
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        if (com.arsenal.shulker.ShulkerEvent.isRush()) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText("Золотая лихорадка").formatted(Formatting.GOLD, Formatting.BOLD));
            out.append(new LiteralText("\nЗакончится через ").formatted(Formatting.GRAY));
            out.append(new LiteralText(fmt(com.arsenal.shulker.ShulkerEvent.rushTicksLeft())).formatted(Formatting.GREEN));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        if (XpEvent.isActive()) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText("Опытный Тыпо").formatted(Formatting.GREEN, Formatting.BOLD));
            out.append(new LiteralText("\nКоординаты: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(XpEvent.coords()).formatted(Formatting.WHITE));
            out.append(new LiteralText(XpEvent.isFinished() ? "\nСундуки открыты, исчезнет через " : "\nЗакончится через ").formatted(Formatting.GRAY));
            int left = XpEvent.ticksLeft() - (XpEvent.isFinished() ? 0 : XpEvent.LINGER);
            out.append(new LiteralText(fmt(XpEvent.isFinished() ? XpEvent.ticksLeft() : left)).formatted(Formatting.GREEN));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        if (DeadlyMine.isActive()) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText("Смертельная шахта").formatted(Formatting.DARK_PURPLE, Formatting.BOLD));
            out.append(new LiteralText("\nКоординаты: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(DeadlyMine.coords()).formatted(Formatting.WHITE));
            out.append(new LiteralText("\nЗакончится через ").formatted(Formatting.GRAY));
            out.append(new LiteralText(fmt(DeadlyMine.ticksLeft())).formatted(Formatting.GREEN));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        if (MysteryShip.isActive()) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText("Таинственный корабль").formatted(Formatting.GOLD, Formatting.BOLD));
            out.append(new LiteralText("\nКоординаты: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(MysteryShip.coords()).formatted(Formatting.WHITE));
            out.append(new LiteralText("\nУплывёт через ").formatted(Formatting.GRAY));
            out.append(new LiteralText(fmt(MysteryShip.ticksLeft())).formatted(Formatting.GREEN));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        if (com.arsenal.boss.BossManager.isActive()) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText("Босс «" + com.arsenal.boss.BossManager.type().title + "»").formatted(com.arsenal.boss.BossManager.type().format, Formatting.BOLD));
            out.append(new LiteralText("\nМесто: дно ПВП-арены (/warp pvp)").formatted(Formatting.GRAY));
            out.append(new LiteralText("\nЗдоровье: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(com.arsenal.boss.BossManager.hpText()).formatted(Formatting.GREEN));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        boolean waiting = active != null || com.arsenal.shulker.ShulkerEvent.isRush() || XpEvent.isActive() || MysteryShip.isActive() || DeadlyMine.isActive() || com.arsenal.boss.BossManager.isActive();
        out.append(new LiteralText(waiting ? "Следующий ивент через " : "Следующий ивент через ").formatted(Formatting.GRAY));
        if (waiting) {
            out.append(new LiteralText(fmt(INTERVAL) + " после того, как пропадёт нынешний").formatted(Formatting.GREEN));
        } else if (frozen) {
            out.append(new LiteralText("неизвестно (ивенты заморожены)").formatted(Formatting.RED));
        } else {
            out.append(new LiteralText(fmt(Math.max(0, nextIn))).formatted(Formatting.GREEN));
        }
        source.sendFeedback(out, false);
    }

    // ------------------------------------------------------------------ тик

    private static void tick(MinecraftServer server) {
        if (!loaded) {
            return;
        }
        // отсчёт до нового ивента идёт только когда прежний совсем пропал (груз, золотая лихорадка, Опытный Тыпо)
        boolean busy = active != null || com.arsenal.shulker.ShulkerEvent.isRush() || XpEvent.isActive() || MysteryShip.isActive() || DeadlyMine.isActive() || com.arsenal.boss.BossManager.isActive();
        if (wasBusy && !busy) {
            nextIn = INTERVAL;
        }
        wasBusy = busy;
        if (!busy && !frozen && nextIn > 0) {
            nextIn--;
        }
        Cargo c = active;
        if (c == null) {
            if (!frozen && nextIn <= 0 && server.getPlayerManager().getCurrentPlayerCount() > 0) {
                startRandom(server);
                if (active == null && !com.arsenal.shulker.ShulkerEvent.isRush() && !XpEvent.isActive() && !MysteryShip.isActive() && !DeadlyMine.isActive() && !com.arsenal.boss.BossManager.isActive()) {
                    nextIn = 20 * 30;
                }
            }
            return;
        }
        ServerWorld world = server.getOverworld();
        c.age++;
        if (c.type == Type.DEADLY) {
            tickDeadly(server, world, c);
        }
        if (c.blasting) {
            tickBlasts(server, world, c);
        } else if (!c.opened && c.age >= OPEN_AT) {
            open(server, world, c);
        }
        if (c.opened && c.age >= OPEN_AT + STAY) {
            remove(server, true);
            return;
        }
        if (c.age % 20 == 0) {
            updateLabels(world, c);
        }
        if (c.age % 600 == 0) {
            save();
        }
    }

    private static void open(MinecraftServer server, ServerWorld world, Cargo c) {
        if (c.type == Type.DEADLY) {
            for (BlockPos pos : c.shulkers) {
                world.spawnParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 40, 0.5, 0.5, 0.5, 0.1);
                world.playSound(null, pos, SoundEvents.BLOCK_SHULKER_BOX_OPEN, SoundCategory.BLOCKS, 2.0F, 0.7F);
            }
            c.opened = true;
            broadcast(server, new LiteralText("«Смертельный груз» открыт! Шалкеры в яме на ").formatted(Formatting.GRAY)
                    .append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.DARK_RED))
                    .append(new LiteralText(". Яма закрыта до исчезновения груза.").formatted(Formatting.GRAY)));
            save();
        } else if (c.type == Type.PEACE) {
            double cx = c.cx + 0.5;
            double cz = c.cz + 0.5;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.getServerWorld() != world || p.isSpectator()) {
                    continue;
                }
                double dx = p.getX() - cx;
                double dz = p.getZ() - cz;
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 16.0) {
                    continue;
                }
                if (dist < 0.01) {
                    double a = RNG.nextDouble() * Math.PI * 2;
                    dx = Math.cos(a);
                    dz = Math.sin(a);
                    dist = 1.0;
                }
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 20 * 8, 0, false, false));
                p.setVelocity(dx / dist * 1.7, 0.8, dz / dist * 1.7);
                p.velocityModified = true;
                p.fallDistance = 0.0F;
                p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
            }
            for (BlockPos pos : c.shulkers) {
                world.spawnParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 40, 0.5, 0.5, 0.5, 0.15);
                world.playSound(null, pos, SoundEvents.BLOCK_SHULKER_BOX_OPEN, SoundCategory.BLOCKS, 2.0F, 1.0F);
            }
            c.opened = true;
            broadcast(server, new LiteralText("«Мирный груз» открыт! Забирайте лут на ").formatted(Formatting.GRAY)
                    .append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.AQUA)));
            save();
        } else {
            // один взрыв: все в радиусе погибают, если не спрятались за блоками и нет тотема
            detonate(world, c);
            c.blasting = false;
            c.opened = true;
            broadcast(server, new LiteralText("«Взрывной груз» взорвался на ").formatted(Formatting.GRAY)
                    .append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.GOLD)).append(
                            new LiteralText("! Лут можно забирать.").formatted(Formatting.GRAY)));
            save();
        }
    }

    /**
     * Единственный взрыв взрывного груза. Блоки не ломаются. Все игроки и мобы в радиусе (по умолчанию 50 блоков)
     * получают смертельный урон, если до них доходит взрыв (как у обычного взрыва: блоки между ними прикрывают).
     * Тотем бессмертия спасает, выживших отбрасывает.
     */
    private static void detonate(ServerWorld world, Cargo c) {
        double x = c.cx + 0.5;
        double y = c.cy + 1.5;
        double z = c.cz + 0.5;
        net.minecraft.util.math.Vec3d center = new net.minecraft.util.math.Vec3d(x, y, z);
        // Точка, от которой считается "прикрытие блоками", над пирамидой: раньше она была внутри пирамиды,
        // и все лучи упирались в её блоки, поэтому никто не получал урон.
        double topY = c.cy + 8.5;
        net.minecraft.util.math.Vec3d blastPoint = new net.minecraft.util.math.Vec3d(x, topY, z);
        double radius = CargoLoot.blastRadius(50.0);

        // только эффект: настоящий урон наносится ниже, чтобы взрыв не ломал броню
        world.createExplosion(null, x, topY, z, 0.1F, Explosion.DestructionType.NONE);
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, x, topY, z, 8, 3.0, 1.0, 3.0, 0.0);
        world.playSound(null, new BlockPos(x, y, z), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 100.0F, 0.6F);

        net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(x - radius, y - radius, z - radius,
                x + radius, y + radius, z + radius);
        List<net.minecraft.entity.LivingEntity> victims = world.getEntitiesByClass(net.minecraft.entity.LivingEntity.class, box,
                e -> e instanceof net.minecraft.entity.player.PlayerEntity || e instanceof net.minecraft.entity.mob.MobEntity);
        for (net.minecraft.entity.LivingEntity e : victims) {
            if (e.isSpectator() || e.squaredDistanceTo(center) > radius * radius) {
                continue;
            }
            // полностью прикрыт блоками: взрыв не доходит
            if (Explosion.getExposure(blastPoint, e) < 0.05F) {
                continue;
            }
            // Броню игрока на время удара снимаем: при таком уроне она вся сломалась бы. Выжил (тотем) - вернём назад,
            // погиб - броня выпадает целой (при keepInventory остаётся на игроке).
            net.minecraft.entity.player.PlayerEntity armored = e instanceof net.minecraft.entity.player.PlayerEntity
                    ? (net.minecraft.entity.player.PlayerEntity) e : null;
            net.minecraft.entity.EquipmentSlot[] armorSlots = {net.minecraft.entity.EquipmentSlot.HEAD,
                    net.minecraft.entity.EquipmentSlot.CHEST, net.minecraft.entity.EquipmentSlot.LEGS,
                    net.minecraft.entity.EquipmentSlot.FEET};
            net.minecraft.item.ItemStack[] savedArmor = new net.minecraft.item.ItemStack[4];
            if (armored != null) {
                for (int i = 0; i < 4; i++) {
                    savedArmor[i] = armored.getEquippedStack(armorSlots[i]);
                    armored.equipStack(armorSlots[i], net.minecraft.item.ItemStack.EMPTY);
                }
            }
            e.damage(net.minecraft.entity.damage.DamageSource.explosion((Explosion) null), 100000.0F);
            if (armored != null) {
                boolean keep = armored.isAlive()
                        || world.getGameRules().getBoolean(net.minecraft.world.GameRules.KEEP_INVENTORY);
                for (int i = 0; i < 4; i++) {
                    if (savedArmor[i].isEmpty()) {
                        continue;
                    }
                    if (keep) {
                        armored.equipStack(armorSlots[i], savedArmor[i]);
                    } else {
                        armored.dropItem(savedArmor[i], true, false);
                    }
                }
            }
            if (e.isAlive()) {
                // выжил (тотем): отбрасываем от центра
                double dx = e.getX() - x;
                double dz = e.getZ() - z;
                double dist = Math.max(1.0, Math.sqrt(dx * dx + dz * dz));
                e.setVelocity(dx / dist * 1.7, 0.8, dz / dist * 1.7);
                e.velocityModified = true;
                if (e instanceof ServerPlayerEntity) {
                    ((ServerPlayerEntity) e).networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(e));
                }
            }
        }
    }

    /** Пересекается ли квадрат со стороной 2*half+1 вокруг блока с зоной текущего груза (для запрета приватов). */
    public static boolean overlapsZone(World world, BlockPos center, int half) {
        if (XpEvent.overlaps(world, center, half) || MysteryShip.overlaps(world, center, half) || DeadlyMine.overlaps(world, center, half)) {
            return true;
        }
        Cargo c = active;
        if (c == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        double cx = c.cx + 0.5;
        double cz = c.cz + 0.5;
        double nx = Math.max(center.getX() - half, Math.min(cx, center.getX() + half + 1.0));
        double nz = Math.max(center.getZ() - half, Math.min(cz, center.getZ() + half + 1.0));
        double dx = nx - cx;
        double dz = nz - cz;
        return dx * dx + dz * dz <= RADIUS * RADIUS;
    }

    private static void tickBlasts(MinecraftServer server, ServerWorld world, Cargo c) {
        if (c.blastIndex < c.shulkers.size() && c.blastTick % 10 == 0) {
            BlockPos p = c.shulkers.get(c.blastIndex++);
            // как динамит Б: сила из настроек (по умолчанию 40), блоки не ломаются, урон есть
            world.createExplosion(null, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5,
                    CargoLoot.blastPower(com.arsenal.blast.BlastKind.DYNAMITE_B.power), Explosion.DestructionType.NONE);
        }
        c.blastTick++;
        if (c.blastIndex >= c.shulkers.size() && c.blastTick > c.shulkers.size() * 10 + 10) {
            c.blasting = false;
            c.opened = true;
            broadcast(server, new LiteralText("«Взрывной груз» открыт! Лут можно забирать.").formatted(Formatting.GOLD));
            save();
        }
    }

    // ------------------------------------------------------------------ появление и удаление

    private static boolean spawn(MinecraftServer server, Type type) {
        ServerWorld world = server.getOverworld();
        Cargo c = findSite(world, type);
        if (c == null) {
            return false;
        }
        c.type = type;
        build(world, c);
        List<List<net.minecraft.item.ItemStack>> loot = CargoLoot.roll(type.key, c.shulkers.size());
        for (int i = 0; i < c.shulkers.size(); i++) {
            BlockEntity be = world.getBlockEntity(c.shulkers.get(i));
            if (be instanceof net.minecraft.inventory.Inventory) {
                CargoLoot.fill((net.minecraft.inventory.Inventory) be, loot.get(i));
                be.markDirty();
            }
        }
        active = c;
        nextIn = INTERVAL;
        spawnLabels(world, c);
        updateLabels(world, c);
        saveBlocks(c);
        save();
        if (type == Type.DEADLY) {
            startStunZone(world, c);
        }
        MutableText msg = new LiteralText("«").formatted(Formatting.GRAY);
        msg.append(new LiteralText(type.title).formatted(type.color, Formatting.BOLD));
        msg.append(new LiteralText("» на координатах ").formatted(Formatting.GRAY));
        msg.append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.WHITE));
        broadcast(server, msg);
        return true;
    }

    /** Убирает груз и возвращает местность как была. */
    private static void remove(MinecraftServer server, boolean announce) {
        Cargo c = active;
        if (c == null) {
            return;
        }
        ServerWorld world = server.getOverworld();
        if (c.type == Type.DEADLY) {
            com.arsenal.StunZones.removeCircle(world, c.cx + 0.5, c.cz + 0.5);
        }
        // чтобы убрать надписи и вернуть блоки, окрестности должны быть загружены (у ямы вся она лежит в этих чанках)
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                world.getChunk((c.cx >> 4) + dx, (c.cz >> 4) + dz);
            }
        }
        server.getCommandManager().execute(server.getCommandSource().withWorld(world).withSilent(),
                "kill @e[type=minecraft:armor_stand,tag=arsenal_cargo]");
        for (BlockPos p : c.shulkers) {
            world.setBlockState(p, Blocks.AIR.getDefaultState(), 2);
        }
        for (Map.Entry<Long, Integer> e : c.saved.entrySet()) {
            world.setBlockState(BlockPos.fromLong(e.getKey()), Block.getStateFromRawId(e.getValue()), 2);
        }
        active = null;
        try {
            Files.deleteIfExists(blocksFile());
        } catch (Exception ignored) {
            // не критично
        }
        save();
        if (announce) {
            broadcast(server, new LiteralText("«" + c.type.title + "» исчез.").formatted(Formatting.GRAY));
        }
    }

    // ------------------------------------------------------------------ место и постройка

    private static Cargo findSite(ServerWorld world, Type type) {
        for (int attempt = 0; attempt < 80; attempt++) {
            int[] spot = com.arsenal.tp.WorldLimit.eventSpot(RNG);
            int cx = spot[0];
            int cz = spot[1];
            if (!zoneFree(world, cx, cz)) {
                continue;
            }
            int y0 = groundY(world, cx, cz);
            if (y0 < 0) {
                continue;
            }
            if (type == Type.DEADLY && y0 < PIT_DEPTH + 15) {
                continue;   // яма не должна дойти до бедрока и лавы
            }
            int min = y0;
            int max = y0;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double a = i * Math.PI / 4;
                int y = groundY(world, cx + (int) Math.round(Math.cos(a) * 10), cz + (int) Math.round(Math.sin(a) * 10));
                if (y < 0) {
                    ok = false;
                } else {
                    min = Math.min(min, y);
                    max = Math.max(max, y);
                }
            }
            if (!ok || max - min > 5) {
                continue;
            }
            if (hasBlockEntities(world, cx, y0, cz)) {
                continue;
            }
            if (type == Type.DEADLY && pitHasBlockEntities(world, cx, y0, cz)) {
                continue;
            }
            Cargo c = new Cargo();
            c.cx = cx;
            c.cy = y0;
            c.cz = cz;
            return c;
        }
        return null;
    }

    private static boolean zoneFree(ServerWorld world, int cx, int cz) {
        if (XpEvent.near(cx, cz, 120) || MysteryShip.near(cx, cz, 120) || DeadlyMine.near(cx, cz, 120)) {
            return false;
        }
        int r = (int) RADIUS + 6;
        int[][] pts = {{0, 0}, {r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, -r}, {r, -r}, {-r, r}};
        for (int[] p : pts) {
            BlockPos pos = new BlockPos(cx + p[0], 64, cz + p[1]);
            if (SpawnProtection.contains(world, pos) || !world.getWorldBorder().contains(pos)) {
                return false;
            }
        }
        return !PrivateManager.intersects(world, new Box(cx - r - 60, 0, cz - r - 60, cx + r + 60, 256, cz + r + 60));
    }

    /** Первая свободная высота над твёрдой землёй (не вода), или -1. */
    private static int groundY(ServerWorld world, int x, int z) {
        world.getChunk(x >> 4, z >> 4);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y < 10 || y > 200) {
            return -1;
        }
        BlockState below = world.getBlockState(new BlockPos(x, y - 1, z));
        if (below.isAir() || !below.getFluidState().isEmpty()) {
            return -1;
        }
        return y;
    }

    private static boolean hasBlockEntities(ServerWorld world, int cx, int y0, int cz) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int y = y0 - 6; y <= y0 + 8; y++) {
                    m.set(cx + dx, y, cz + dz);
                    if (world.getBlockEntity(m) != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** В объёме ямы (вместе со стенками) есть сундуки, спаунеры и прочее: такое место не подходит. */
    private static boolean pitHasBlockEntities(ServerWorld world, int cx, int y0, int cz) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        int r = PIT_HALF + 1;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int y = y0 - PIT_DEPTH - 1; y <= y0 - 1; y++) {
                    m.set(cx + dx, y, cz + dz);
                    if (world.getBlockEntity(m) != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void put(ServerWorld world, Cargo c, BlockPos pos, BlockState state) {
        long key = pos.asLong();
        if (!c.saved.containsKey(key)) {
            c.saved.put(key, Block.getRawIdFromState(world.getBlockState(pos)));
        }
        world.setBlockState(pos, state, 2);
    }

    private static void square(ServerWorld world, Cargo c, int y, int half, Block block) {
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                put(world, c, new BlockPos(c.cx + dx, y, c.cz + dz), block.getDefaultState());
            }
        }
    }

    private static void build(ServerWorld world, Cargo c) {
        int y0 = c.cy;
        Type t = c.type;
        BlockState air = Blocks.AIR.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int y = y0 + 8; y >= y0; y--) {
                    m.set(c.cx + dx, y, c.cz + dz);
                    if (!world.getBlockState(m).isAir()) {
                        put(world, c, m.toImmutable(), air);
                    }
                }
                for (int y = y0 - 1; y >= y0 - 6; y--) {
                    m.set(c.cx + dx, y, c.cz + dz);
                    BlockState s = world.getBlockState(m);
                    if (s.isAir() || !s.getFluidState().isEmpty() || s.getMaterial().isReplaceable()) {
                        put(world, c, m.toImmutable(), Blocks.DIRT.getDefaultState());
                    } else {
                        break;
                    }
                }
            }
        }
        if (t == Type.DEADLY) {
            buildPit(world, c);
        } else {
            // пирамида в центре
            square(world, c, y0, 4, t.base);
            square(world, c, y0 + 1, 3, t.base);
            square(world, c, y0 + 2, 2, t.base);
            square(world, c, y0 + 3, 1, t.base);
            // четыре шалкера на площадках
            int[][] corners = {{8, 8}, {-8, 8}, {8, -8}, {-8, -8}};
            for (int[] corner : corners) {
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        put(world, c, new BlockPos(c.cx + corner[0] + dx, y0, c.cz + corner[1] + dz), t.base.getDefaultState());
                    }
                }
                BlockPos s = new BlockPos(c.cx + corner[0], y0 + 1, c.cz + corner[1]);
                put(world, c, s, t.shulker.getDefaultState());
                c.shulkers.add(s);
            }
        }
        // край зоны из шерсти
        int r = (int) RADIUS + 1;
        double inner = RADIUS - 2.0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < inner || d > RADIUS) {
                    continue;
                }
                int x = c.cx + dx;
                int z = c.cz + dz;
                world.getChunk(x >> 4, z >> 4);
                int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                BlockPos pos = new BlockPos(x, y, z);
                BlockState s = world.getBlockState(pos);
                if (y < 1 || s.isAir() || !s.getFluidState().isEmpty()) {
                    continue;
                }
                put(world, c, pos, t.ring.getDefaultState());
            }
        }
    }

    /**
     * Яма смертельного груза: PIT_HALF*2+1 в ширину и PIT_DEPTH в глубину, стенки и дно из чёрного камня (снаружи
     * не видно пещер и воды), паркур вдоль стен вместо лестницы, светящиеся блоки в стенах, на дне 4 красных шалкера.
     * Верх ямы открыт вровень с землёй, крыша закроется позже (closeRoof). Все заменённые блоки запоминаются.
     */
    private static void buildPit(ServerWorld world, Cargo c) {
        int y0 = c.cy;
        int yBot = y0 - PIT_DEPTH;
        int yFloor = yBot - 1;
        int wall = PIT_HALF + 1;
        BlockState shell = Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState();
        BlockState air = Blocks.AIR.getDefaultState();
        for (int dx = -wall; dx <= wall; dx++) {
            for (int dz = -wall; dz <= wall; dz++) {
                boolean edge = Math.abs(dx) == wall || Math.abs(dz) == wall;
                for (int y = y0 - 1; y >= yFloor; y--) {
                    BlockPos pos = new BlockPos(c.cx + dx, y, c.cz + dz);
                    if (y == yFloor || edge) {
                        boolean lamp = edge && y != yFloor && y < y0 - 2 && (y - yBot) % 6 == 3
                                && (Math.abs(dx) == wall ? Math.abs(dz) == 4 : Math.abs(dx) == 4);
                        put(world, c, pos, lamp ? Blocks.GLOWSTONE.getDefaultState() : shell);
                    } else {
                        put(world, c, pos, air);
                    }
                }
            }
        }
        // паркур вдоль стен: одиночные блоки по спирали, каждый на блок выше предыдущего, между ними по 2 блока воздуха
        // (лестницы нет: прыжок вниз это ~22 урона, а наверх без точных прыжков не выбраться)
        List<int[]> ring = new ArrayList<>();
        for (int x = -PIT_HALF; x <= PIT_HALF; x++) {
            ring.add(new int[]{x, -PIT_HALF});
        }
        for (int z = -PIT_HALF + 1; z <= PIT_HALF; z++) {
            ring.add(new int[]{PIT_HALF, z});
        }
        for (int x = PIT_HALF - 1; x >= -PIT_HALF; x--) {
            ring.add(new int[]{x, PIT_HALF});
        }
        for (int z = PIT_HALF - 1; z >= -PIT_HALF + 1; z--) {
            ring.add(new int[]{-PIT_HALF, z});
        }
        BlockState step = c.type.base.getDefaultState();
        for (int n = 0; n <= PIT_DEPTH - 3; n++) {
            int[] pos = ring.get((n * 3) % ring.size());
            put(world, c, new BlockPos(c.cx + pos[0], yBot + 1 + n, c.cz + pos[1]), step);
        }
        // четыре шалкера на дне
        int[][] corners = {{2, 2}, {-2, 2}, {2, -2}, {-2, -2}};
        for (int[] corner : corners) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    put(world, c, new BlockPos(c.cx + corner[0] + dx, yBot, c.cz + corner[1] + dz), c.type.base.getDefaultState());
                }
            }
            BlockPos s = new BlockPos(c.cx + corner[0], yBot + 1, c.cz + corner[1]);
            put(world, c, s, c.type.shulker.getDefaultState());
            c.shulkers.add(s);
        }
    }

    private static boolean overPit(Cargo c, double x, double z) {
        return Math.abs(x - (c.cx + 0.5)) <= PIT_HALF + 0.5 && Math.abs(z - (c.cz + 0.5)) <= PIT_HALF + 0.5;
    }

    /** Крыша ямы: слой блоков вровень с землёй. Тех, кто стоит или летит над ямой у самого верха, сначала опускаем на дно. */
    private static void closeRoof(MinecraftServer server, ServerWorld world, Cargo c) {
        int y0 = c.cy;
        int yBot = y0 - PIT_DEPTH;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.getServerWorld() != world || p.isSpectator() || !overPit(c, p.getX(), p.getZ())) {
                continue;
            }
            if (p.getY() > y0 - 4 && p.getY() < y0 + 6) {
                // у самого верха ямы: крыша закроется прямо здесь, поэтому отправляем вниз без урона
                double tx = c.cx + 0.5 + (RNG.nextInt(3) - 1);
                double tz = c.cz + 0.5 + (RNG.nextInt(3) - 1);
                p.teleport(world, tx, yBot + 1, tz, p.yaw, p.pitch);
                p.fallDistance = 0.0F;
            }
        }
        BlockState roof = Blocks.OBSIDIAN.getDefaultState();
        for (int dx = -PIT_HALF; dx <= PIT_HALF; dx++) {
            for (int dz = -PIT_HALF; dz <= PIT_HALF; dz++) {
                put(world, c, new BlockPos(c.cx + dx, y0 - 1, c.cz + dz), roof);
            }
        }
        c.roofClosed = true;
        world.playSound(null, new BlockPos(c.cx, y0, c.cz), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 4.0F, 0.5F);
        world.playSound(null, new BlockPos(c.cx, yBot + 1, c.cz), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 1.0F, 0.6F);
        saveBlocks(c);
        broadcast(server, new LiteralText("Крыша ямы «Смертельного груза» закрылась! Кто остался внутри, выйдет только когда груз исчезнет.")
                .formatted(Formatting.DARK_RED));
        save();
    }

    /** Смертельный груз каждый тик: крыша ямы, предупреждения, постоянный режим боя в зоне. */
    private static void tickDeadly(MinecraftServer server, ServerWorld world, Cargo c) {
        int closeAt = OPEN_AT - ROOF_BEFORE;
        if (!c.roofClosed && c.age >= closeAt) {
            closeRoof(server, world, c);
        }
        if (c.age % 10 != 0) {
            return;
        }
        boolean message = c.age % 20 == 0 && !c.opened;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            // режим боя только в зоне самого смертельного груза (раньше сюда попадали и Опытный Тыпо с кораблём)
            if (p.getServerWorld() != world || p.isSpectator() || !inCargoZone(world, p.getX(), p.getZ())) {
                continue;
            }
            if (!SpawnProtection.bypass(p)) {
                com.arsenal.combat.Combat.refresh(p);
            }
            if (message) {
                if (!c.roofClosed && c.age >= closeAt - ROOF_WARN) {
                    p.sendMessage(new LiteralText("Крыша ямы закроется через " + fmt(closeAt - c.age)).formatted(Formatting.RED), true);
                } else if (c.roofClosed) {
                    p.sendMessage(new LiteralText("Шалкеры откроются через " + fmt(OPEN_AT - c.age)).formatted(Formatting.RED), true);
                }
            }
        }
    }

    /** Стан-зона на весь срок жизни груза (после перезапуска сервера создаётся заново). */
    private static void startStunZone(ServerWorld world, Cargo c) {
        int left = OPEN_AT + STAY - c.age;
        if (left > 0) {
            com.arsenal.StunZones.addCircle(world, c.cx + 0.5, c.cz + 0.5, RADIUS, 0, 320, left);
        }
    }

    // ------------------------------------------------------------------ надписи

    private static void run(ServerWorld world, String command) {
        MinecraftServer server = world.getServer();
        server.getCommandManager().execute(server.getCommandSource().withWorld(world).withSilent(), command);
    }

    private static String json(Text text) {
        return Text.Serializer.toJson(text).replace("\\", "\\\\").replace("'", "\\'");
    }

    private static void spawnLabels(ServerWorld world, Cargo c) {
        Text title = new LiteralText(c.type.title).setStyle(Style.EMPTY.withColor(c.type.color).withBold(true));
        for (BlockPos p : c.shulkers) {
            double x = p.getX() + 0.5;
            double z = p.getZ() + 0.5;
            run(world, String.format(Locale.ROOT,
                    "summon minecraft:armor_stand %.2f %.2f %.2f {Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,"
                            + "CustomNameVisible:1b,Tags:[\"arsenal_cargo\",\"arsenal_cargo_t\"],CustomName:'%s'}",
                    x, p.getY() + 1.55, z, json(title)));
            run(world, String.format(Locale.ROOT,
                    "summon minecraft:armor_stand %.2f %.2f %.2f {Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,"
                            + "CustomNameVisible:1b,Tags:[\"arsenal_cargo\",\"arsenal_cargo_s\"],CustomName:'%s'}",
                    x, p.getY() + 1.25, z, json(new LiteralText(" "))));
        }
    }

    private static void updateLabels(ServerWorld world, Cargo c) {
        MutableText text;
        if (c.blasting) {
            text = new LiteralText("Взрывается!").formatted(Formatting.RED);
        } else if (c.opened) {
            text = new LiteralText("Исчезнет через ").formatted(Formatting.GRAY)
                    .append(new LiteralText(fmt(OPEN_AT + STAY - c.age)).formatted(c.type.color));
        } else {
            text = new LiteralText(c.type == Type.EXPLOSIVE ? "Взорвётся через " : "Будет открыт через ").formatted(Formatting.GRAY)
                    .append(new LiteralText(fmt(OPEN_AT - c.age)).formatted(c.type.color));
        }
        // у смертельного груза шалкеры (и надписи над ними) лежат на дне ямы
        double minY = c.type == Type.DEADLY ? c.cy - PIT_DEPTH - 2 : c.cy - 2;
        Box box = new Box(c.cx - 14, minY, c.cz - 14, c.cx + 14, c.cy + 8, c.cz + 14);
        for (ArmorStandEntity stand : world.getEntitiesByClass(ArmorStandEntity.class, box,
                e -> e.getScoreboardTags().contains("arsenal_cargo_s"))) {
            stand.setCustomName(text);
        }
    }

    // ------------------------------------------------------------------ утилиты

    static String fmt(int ticks) {
        int seconds = (Math.max(0, ticks) + 19) / 20;
        int m = seconds / 60;
        int s = seconds % 60;
        return m > 0 ? m + " мин. " + s + " сек." : s + " сек.";
    }

    private static void broadcast(MinecraftServer server, Text text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, Util.NIL_UUID);
    }

    // ------------------------------------------------------------------ сохранение

    private static Path stateFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_event.json");
    }

    private static Path blocksFile() {
        return serverRef.getSavePath(WorldSavePath.ROOT).resolve("arsenal_event_blocks.json");
    }

    private static MinecraftServer serverRef;

    private static void save() {
        if (serverRef == null) {
            return;
        }
        try {
            JsonObject root = new JsonObject();
            root.addProperty("nextIn", nextIn);
            root.addProperty("frozen", frozen);
            Cargo c = active;
            if (c != null) {
                JsonObject o = new JsonObject();
                o.addProperty("type", c.type.key);
                o.addProperty("cx", c.cx);
                o.addProperty("cy", c.cy);
                o.addProperty("cz", c.cz);
                o.addProperty("age", c.age);
                o.addProperty("opened", c.opened || c.blasting);
                JsonArray sh = new JsonArray();
                for (BlockPos p : c.shulkers) {
                    sh.add(p.asLong());
                }
                o.add("shulkers", sh);
                root.add("active", o);
            }
            Files.write(stateFile(serverRef), root.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_event.json: " + ex);
        }
    }

    private static void saveBlocks(Cargo c) {
        try {
            JsonArray pos = new JsonArray();
            JsonArray ids = new JsonArray();
            for (Map.Entry<Long, Integer> e : c.saved.entrySet()) {
                pos.add(e.getKey());
                ids.add(e.getValue());
            }
            JsonObject o = new JsonObject();
            o.add("pos", pos);
            o.add("ids", ids);
            Files.write(blocksFile(), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_event_blocks.json: " + ex);
        }
    }

    private static void load(MinecraftServer server) {
        serverRef = server;
        CargoLoot.load();
        nextIn = INTERVAL;
        frozen = false;
        active = null;
        try {
            Path f = stateFile(server);
            if (Files.exists(f)) {
                JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
                nextIn = root.get("nextIn").getAsInt();
                frozen = root.get("frozen").getAsBoolean();
                if (root.has("active")) {
                    JsonObject o = root.getAsJsonObject("active");
                    Cargo c = new Cargo();
                    c.type = Type.byKey(o.get("type").getAsString());
                    c.cx = o.get("cx").getAsInt();
                    c.cy = o.get("cy").getAsInt();
                    c.cz = o.get("cz").getAsInt();
                    c.age = o.get("age").getAsInt();
                    c.opened = o.get("opened").getAsBoolean();
                    for (JsonElement el : o.getAsJsonArray("shulkers")) {
                        c.shulkers.add(BlockPos.fromLong(el.getAsLong()));
                    }
                    Path bf = blocksFile();
                    if (Files.exists(bf)) {
                        JsonObject b = new JsonParser().parse(new String(Files.readAllBytes(bf), StandardCharsets.UTF_8)).getAsJsonObject();
                        JsonArray pos = b.getAsJsonArray("pos");
                        JsonArray ids = b.getAsJsonArray("ids");
                        for (int i = 0; i < pos.size(); i++) {
                            c.saved.put(pos.get(i).getAsLong(), ids.get(i).getAsInt());
                        }
                    }
                    c.roofClosed = c.type == Type.DEADLY && c.age >= OPEN_AT - ROOF_BEFORE;
                    active = c;
                    if (c.type == Type.DEADLY) {
                        startStunZone(server.getOverworld(), c);
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_event.json: " + ex);
        }
        loaded = true;
    }
}
