package com.arsenal.event;

import com.arsenal.Arsenal;
import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluids;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.network.MessageType;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.registry.Registry;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Таинственный корабль (ивент в общем цикле). Появляется только на воде (океан). Сам корабль берётся из готовой структуры
 * (ресурс arsenal_ship_structure.json, сделан из ship2.litematic): большой парусник с трюмом под ватерлинией, на корме
 * сокровище пиратов (якорь возрождения). Капитан (торговец, торговля у него выключена) стоит на главной палубе.
 * <ul>
 * <li>Капитан как житель в Опытном Тыпо: ПКМ даёт отмычку (обычная, редкая или секретная, шансы настраиваются), потом новая
 * через настраиваемый интервал. ПКМ без отмычки отбрасывает и бьёт.</li>
 * <li>В трюме и кормовой комнатке 10 бочек (9 разбросаны по трюму, 1 стоит в комнатке с золотом). ПКМ отмычкой открывает бочку:
 * в ней появляется лут (зависит от редкости отмычки), над ней надпись «Клад» и сколько осталось до закрытия. Через минуту
 * бочка закрывается вместе с лутом, её можно открыть снова.</li>
 * <li>Сокровище пиратов (якорь) открывается ПКМ секретными отмычками (по умолчанию 4), ещё через минуту оно открывается.
 * После этого ПКМ по якорю открывает окно с лутом (как сундук), лут не выбрасывается на палубу.</li>
 * </ul>
 * Местность под кораблём возвращается как была (журнал блоков в arsenal_ship_blocks.json). Всё настраивается в общих настройках.
 * Запускается и убирается только через /event (spawn Таинственный корабль, time skip).
 */
public final class MysteryShip {
    // ---- настройки (Settings), время в тиках
    public static int DURATION = 20 * 60 * 20;
    public static int KEY_MIN = 20 * 30;
    public static int KEY_MAX = 20 * 60;
    public static int CHANCE_COMMON = 70;
    public static int CHANCE_RARE = 25;
    public static int CHANCE_SECRET = 5;
    public static int ANCHOR_KEYS = 4;
    public static int ANCHOR_OPEN = 20 * 60;
    /** Через сколько после открытия сокровище закрывается (лут пропадает, второй раз за ивент не открыть). */
    public static int ANCHOR_CLOSE = 20 * 60;
    public static int BARREL_CLOSE = 20 * 60;
    /** Урон в здоровье (2 на сердце). */
    public static int DAMAGE = 8;
    public static int KNOCKBACK = 10;

    private static final String TAG_CAPTAIN = "arsenal_ship_captain";
    private static final String TAG_HOLO = "arsenal_ship_h";
    private static final String[] TABLES = {"ship_common", "ship_rare", "ship_secret"};
    private static final Formatting[] COLORS = {Formatting.GRAY, Formatting.DARK_PURPLE, Formatting.BLUE};
    private static final String[] NAMES = {"Обычная отмычка", "Редкая отмычка", "Секретная отмычка"};

    // ---- структура (координаты: x - ширина, y - высота от ватерлинии (киль y = -3, палуба y = 3), z - от носа к корме)
    /** Клетка структуры, вокруг которой корабль поворачивается (середина корпуса). */
    private static final int PX = 6;
    private static final int PZ = 48;
    private static final int MIN_X = 0;
    private static final int MAX_X = 19;
    private static final int MIN_Z = 17;
    private static final int MAX_Z = 70;
    /**
     * Бочки: {x, y, z}. Первая стоит в кормовой комнатке с золотом (как в схеме), остальные девять разбросаны по трюму
     * вдоль бортов и в носовой каюте.
     */
    private static final int[][] BARRELS = {
            {8, -1, 60},
            {3, -2, 43}, {8, -2, 44}, {3, -2, 47}, {9, -2, 49}, {4, -2, 50},
            {9, -2, 52}, {3, -2, 54}, {9, -1, 56}, {8, -1, 38}};
    /** Куда смотрит крышка бочки (в структуре без поворота): первая бочка смотрит к проходу, остальные вверх. */
    private static final Direction[] BARREL_FACING = {Direction.NORTH, Direction.UP, Direction.UP, Direction.UP, Direction.UP,
            Direction.UP, Direction.UP, Direction.UP, Direction.UP, Direction.UP};
    /** Сокровище пиратов (якорь) на крыше кормовой надстройки. */
    private static final int[] ANCHOR = {6, 8, 66};
    /** Где стоит капитан (центр блока, на уровне пола палубы). */
    private static final double[] CAPTAIN = {6.5, 4.0, 44.5};
    private static final BlockRotation[] ROTATIONS = {BlockRotation.NONE, BlockRotation.CLOCKWISE_90,
            BlockRotation.CLOCKWISE_180, BlockRotation.COUNTERCLOCKWISE_90};
    private static final int STATE_VERSION = 3;
    private static final int MAX_DISTANCE = 4000;
    private static final Random RNG = new Random();

    private static final class Ship {
        int cx;
        int cz;
        /** Высота верхнего блока воды: ватерлиния корабля (y = 0 в структуре), палуба на блок выше. */
        int sy;
        /** Поворот корабля: 0..3 (на сколько четвертей оборота по часовой стрелке). */
        int dir;
        int age;
        int serial;
        UUID captain;
        boolean hasKey = true;
        int keyIn;
        int anchorKeys;
        int anchorOpenIn = -1;
        boolean anchorOpen;
        /** Сколько тиков осталось до закрытия открытого сокровища (-1: не открыто). */
        int anchorCloseIn = -1;
        /** Сокровище уже открывалось и закрылось: больше за этот ивент не открывается. */
        boolean anchorDone;
        /** Лут сокровища: открывается как сундук, пока не забрали (null, пока сокровище закрыто). */
        SimpleInventory anchorLoot;
        final int[] barrelClose = new int[BARRELS.length];
        final int[] barrelRarity = new int[BARRELS.length];
        final Map<Long, Integer> saved = new LinkedHashMap<>();
        // вычисляется из cx, cz, dir
        int minX;
        int maxX;
        int minZ;
        int maxZ;
        final Map<String, String> holoCache = new HashMap<>();

        void prepare() {
            int[][] corners = {{MIN_X, MIN_Z}, {MIN_X, MAX_Z}, {MAX_X, MIN_Z}, {MAX_X, MAX_Z}};
            minX = Integer.MAX_VALUE;
            minZ = Integer.MAX_VALUE;
            maxX = Integer.MIN_VALUE;
            maxZ = Integer.MIN_VALUE;
            for (int[] c : corners) {
                BlockPos p = at(c[0], 0, c[1]);
                minX = Math.min(minX, p.getX());
                maxX = Math.max(maxX, p.getX());
                minZ = Math.min(minZ, p.getZ());
                maxZ = Math.max(maxZ, p.getZ());
            }
            minX -= 3;
            maxX += 4;
            minZ -= 3;
            maxZ += 4;
        }

        /** Блок структуры (x, y, z в её координатах) в мире с учётом поворота. */
        BlockPos at(int lx, int ly, int lz) {
            int dx = lx - PX;
            int dz = lz - PZ;
            int rx;
            int rz;
            switch (dir) {
                case 1:
                    rx = -dz;
                    rz = dx;
                    break;
                case 2:
                    rx = -dx;
                    rz = -dz;
                    break;
                case 3:
                    rx = dz;
                    rz = -dx;
                    break;
                default:
                    rx = dx;
                    rz = dz;
                    break;
            }
            return new BlockPos(cx + rx, sy + ly, cz + rz);
        }

        /** То же для точки (например, центр блока: x + 0.5, z + 0.5). */
        Vec3d vec(double lx, double ly, double lz) {
            double dx = lx - (PX + 0.5);
            double dz = lz - (PZ + 0.5);
            double rx;
            double rz;
            switch (dir) {
                case 1:
                    rx = -dz;
                    rz = dx;
                    break;
                case 2:
                    rx = -dx;
                    rz = -dz;
                    break;
                case 3:
                    rx = dz;
                    rz = -dx;
                    break;
                default:
                    rx = dx;
                    rz = dz;
                    break;
            }
            return new Vec3d(cx + 0.5 + rx, sy + ly, cz + 0.5 + rz);
        }
    }

    private static Ship active;
    private static int serialCounter;
    private static int tick;
    private static MinecraftServer serverRef;

    private MysteryShip() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(MysteryShip::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            save();
            active = null;
            serverRef = null;
        });
        ServerTickEvents.END_SERVER_TICK.register(MysteryShip::onTick);
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> onUseBlock(player, world, hand, hit.getBlockPos()));
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> onUseEntity(player, world, hand, entity));
    }

    // ------------------------------------------------------------------ публичное

    public static boolean isActive() {
        return active != null;
    }

    public static boolean startRandom(MinecraftServer server) {
        return active == null && start(server);
    }

    /** Корабль исчезает (для /event time skip): всё убирается, местность возвращается. Возвращает false, если корабля нет. */
    public static boolean despawn(MinecraftServer server) {
        if (active == null) {
            return false;
        }
        end(server, true);
        return true;
    }

    /** Центр ивента (x, z) или null. */
    public static int[] center() {
        Ship s = active;
        return s == null ? null : new int[]{s.cx, s.cz};
    }

    public static String coords() {
        Ship s = active;
        return s == null ? null : s.cx + " " + (s.sy + 4) + " " + s.cz;
    }

    public static int ticksLeft() {
        Ship s = active;
        return s == null ? -1 : DURATION - s.age;
    }

    /** Точка в зоне корабля: там действует та же защита, что у грузов. */
    public static boolean inZone(World world, double x, double z) {
        Ship s = active;
        if (s == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        return x >= s.minX && x < s.maxX && z >= s.minZ && z < s.maxZ;
    }

    public static boolean overlaps(World world, BlockPos center, int half) {
        Ship s = active;
        if (s == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        return center.getX() + half >= s.minX && center.getX() - half < s.maxX
                && center.getZ() + half >= s.minZ && center.getZ() - half < s.maxZ;
    }

    public static boolean near(int x, int z, int dist) {
        Ship s = active;
        return s != null && Math.abs(s.cx - x) < dist && Math.abs(s.cz - z) < dist;
    }

    // ------------------------------------------------------------------ отмычки

    public static ItemStack lockpick(int rarity) {
        return Arsenal.LOCKPICKS[rarity].stack();
    }

    /** Что капитан держит в руке: крюк с переливом, одинаковый для всех редкостей, по нему ничего не узнать. */
    private static ItemStack captainItem() {
        ItemStack st = new ItemStack(Items.TRIPWIRE_HOOK);
        NbtList ench = new NbtList();
        NbtCompound e = new NbtCompound();
        e.putString("id", "minecraft:protection");
        e.putShort("lvl", (short) 1);
        ench.add(e);
        st.getOrCreateTag().put("Enchantments", ench);
        st.getOrCreateTag().putInt("HideFlags", 1);
        return st;
    }

    private static boolean isLockpick(ItemStack st) {
        return !st.isEmpty() && Arsenal.lockpickRarity(st) >= 0;
    }

    private static int rarityOf(ItemStack st) {
        return Arsenal.lockpickRarity(st);
    }

    /** Отмычки не пропадают с концом ивента и годятся на следующий. */
    private static boolean valid(ItemStack st) {
        return active != null && isLockpick(st);
    }

    private static int rollRarity() {
        int total = Math.max(0, CHANCE_COMMON) + Math.max(0, CHANCE_RARE) + Math.max(0, CHANCE_SECRET);
        if (total <= 0) {
            return 0;
        }
        int r = RNG.nextInt(total);
        if (r < Math.max(0, CHANCE_COMMON)) {
            return 0;
        }
        r -= Math.max(0, CHANCE_COMMON);
        return r < Math.max(0, CHANCE_RARE) ? 1 : 2;
    }

    private static void broadcast(MinecraftServer server, Text text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, Util.NIL_UUID);
    }

    private static Text title() {
        return new LiteralText("Таинственный корабль").formatted(Formatting.GOLD, Formatting.BOLD);
    }

    // ------------------------------------------------------------------ запуск и конец

    private static boolean start(MinecraftServer server) {
        if (!loadStructure()) {
            return false;
        }
        ServerWorld world = server.getOverworld();
        Ship s = findSite(world);
        if (s == null) {
            return false;
        }
        s.serial = ++serialCounter;
        build(world, s);
        active = s;
        spawnCaptain(world, s);
        refreshHolos(world, s);
        save();
        saveBlocks(s);
        broadcast(server, new LiteralText("«").formatted(Formatting.GRAY).append(title())
                .append(new LiteralText("» на координатах ").formatted(Formatting.GRAY))
                .append(new LiteralText(coords()).formatted(Formatting.WHITE)));
        return true;
    }

    private static void end(MinecraftServer server, boolean announce) {
        Ship s = active;
        if (s == null) {
            return;
        }
        active = null;
        save();   // файл ивента удаляется
        ServerWorld world = server.getOverworld();
        loadArea(world, s);
        removeEntities(world, s);
        for (int i = 0; i < BARRELS.length; i++) {
            BlockEntity be = world.getBlockEntity(barrelPos(s, i));
            if (be instanceof Inventory) {
                ((Inventory) be).clear();
            }
        }
        closeAnchorWindows(server, s);
        for (Map.Entry<Long, Integer> e : s.saved.entrySet()) {
            world.setBlockState(BlockPos.fromLong(e.getKey()), Block.getStateFromRawId(e.getValue()), 2);
        }
        try {
            Files.deleteIfExists(blocksFile(server));
        } catch (Exception ignored) {
            // не критично
        }
        if (announce) {
            broadcast(server, new LiteralText("«").formatted(Formatting.GRAY).append(title())
                    .append(new LiteralText("» уплыл").formatted(Formatting.GRAY)));
        }
    }

    /** Корабль исчезает: окна с лутом сокровища закрываются, остаток лута пропадает вместе с кораблём. */
    private static void closeAnchorWindows(MinecraftServer server, Ship s) {
        SimpleInventory loot = s.anchorLoot;
        if (loot == null) {
            return;
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.currentScreenHandler instanceof GenericContainerScreenHandler
                    && ((GenericContainerScreenHandler) p.currentScreenHandler).getInventory() == loot) {
                p.closeHandledScreen();
            }
        }
        loot.clear();
        s.anchorLoot = null;
    }

    private static void removeEntities(ServerWorld world, Ship s) {
        Box box = new Box(s.minX - 4, s.sy - 8, s.minZ - 4, s.maxX + 4, s.sy + 20, s.maxZ + 4);
        for (Entity e : world.getEntitiesByClass(Entity.class, box,
                en -> en.getScoreboardTags().contains(TAG_CAPTAIN) || en.getScoreboardTags().contains(TAG_HOLO))) {
            e.remove();
        }
    }

    // ------------------------------------------------------------------ поиск места

    private static Ship findSite(ServerWorld world) {
        for (int attempt = 0; attempt < 150; attempt++) {
            double angle = RNG.nextDouble() * Math.PI * 2;
            double dist = 300 + Math.sqrt(RNG.nextDouble()) * (MAX_DISTANCE - 300);
            int cx = (int) Math.round(Math.cos(angle) * dist);
            int cz = (int) Math.round(Math.sin(angle) * dist);
            if (world.getBiome(new BlockPos(cx, 64, cz)).getCategory() != Biome.Category.OCEAN) {
                continue;
            }
            int[] cargo = EventManager.center();
            if (cargo != null && Math.abs(cargo[0] - cx) < 120 && Math.abs(cargo[1] - cz) < 120) {
                continue;
            }
            if (XpEvent.near(cx, cz, 120) || DeadlyMine.near(cx, cz, 120) || !zoneFree(world, cx, cz)) {
                continue;
            }
            Ship s = new Ship();
            s.cx = cx;
            s.cz = cz;
            s.sy = world.getSeaLevel() - 1;
            s.dir = RNG.nextInt(4);
            s.prepare();
            if (isWater(world, s)) {
                return s;
            }
        }
        return null;
    }

    private static boolean zoneFree(ServerWorld world, int cx, int cz) {
        int r = 32;
        int[][] pts = {{0, 0}, {r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, -r}, {r, -r}, {-r, r}};
        for (int[] p : pts) {
            BlockPos pos = new BlockPos(cx + p[0], 64, cz + p[1]);
            if (SpawnProtection.contains(world, pos) || !world.getWorldBorder().contains(pos)) {
                return false;
            }
        }
        return !PrivateManager.intersects(world, new Box(cx - r, 0, cz - r, cx + r, 256, cz + r));
    }

    /**
     * Под всем кораблём (и вокруг, где торчат паруса) сплошная вода нужной глубины, и над водой ничего нет (лёд, лодки, земля,
     * острова). Проверяется сетка точек по площади структуры.
     */
    private static boolean isWater(ServerWorld world, Ship s) {
        for (int lx = MIN_X; lx <= MAX_X + 1; lx += 3) {
            for (int lz = MIN_Z; lz <= MAX_Z + 1; lz += 3) {
                BlockPos top = s.at(Math.min(lx, MAX_X), 0, Math.min(lz, MAX_Z));
                world.getChunk(top.getX() >> 4, top.getZ() >> 4);
                if (world.getBlockState(top).getFluidState().getFluid() != Fluids.WATER) {
                    return false;
                }
                // выше воды только воздух (поверхность мира не выше ватерлинии)
                if (world.getTopY(Heightmap.Type.WORLD_SURFACE, top.getX(), top.getZ()) > s.sy + 2) {
                    return false;
                }
                for (int dy = 1; dy <= 4; dy++) {
                    if (world.getBlockState(top.down(dy)).getFluidState().isEmpty()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ постройка

    private static void loadArea(ServerWorld world, Ship s) {
        for (int x = (s.minX - 2) >> 4; x <= (s.maxX + 2) >> 4; x++) {
            for (int z = (s.minZ - 2) >> 4; z <= (s.maxZ + 2) >> 4; z++) {
                world.getChunk(x, z);
            }
        }
    }

    private static void put(ServerWorld world, Ship s, BlockPos pos, BlockState state) {
        BlockState cur = world.getBlockState(pos);
        if (cur == state) {
            return;
        }
        s.saved.putIfAbsent(pos.asLong(), Block.getRawIdFromState(cur));
        world.setBlockState(pos, state, 2);
    }

    private static void put(ServerWorld world, Ship s, int u, int v, int y, Block block) {
        put(world, s, s.at(u, v, y), block.getDefaultState());
    }

    private static BlockPos barrelPos(Ship s, int i) {
        return s.at(BARRELS[i][0], BARRELS[i][1], BARRELS[i][2]);
    }

    private static BlockPos anchorPos(Ship s) {
        return s.at(ANCHOR[0], ANCHOR[1], ANCHOR[2]);
    }

    // ---- структура корабля из ресурса
    private static BlockState[] palette;
    private static int[] data;
    /** Головы с текстурой: {x, y, z, id0, id1, id2, id3}, текстура в HEAD_TEXTURES (блок головы стоит в структуре). */
    private static final List<int[]> HEADS = new ArrayList<>();
    private static final List<String> HEAD_TEXTURES = new ArrayList<>();

    /** Читает arsenal_ship_structure.json (один раз). */
    private static boolean loadStructure() {
        if (data != null && palette != null) {
            return true;
        }
        try (InputStream in = MysteryShip.class.getResourceAsStream("/arsenal_ship_structure.json")) {
            if (in == null) {
                System.err.println("[Arsenal] Нет файла arsenal_ship_structure.json, Таинственный корабль не появится");
                return false;
            }
            JsonObject o = new JsonParser().parse(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonArray pal = o.getAsJsonArray("palette");
            BlockState[] ps = new BlockState[pal.size()];
            for (int i = 0; i < ps.length; i++) {
                ps[i] = parseState(pal.get(i).getAsString());
            }
            JsonArray blocks = o.getAsJsonArray("blocks");
            int[] d = new int[blocks.size()];
            for (int i = 0; i < d.length; i++) {
                d[i] = blocks.get(i).getAsInt();
            }
            HEADS.clear();
            HEAD_TEXTURES.clear();
            if (o.has("heads")) {
                for (JsonElement el : o.getAsJsonArray("heads")) {
                    JsonObject h = el.getAsJsonObject();
                    JsonArray id = h.getAsJsonArray("id");
                    HEADS.add(new int[]{h.get("x").getAsInt(), h.get("y").getAsInt(), h.get("z").getAsInt(),
                            id.get(0).getAsInt(), id.get(1).getAsInt(), id.get(2).getAsInt(), id.get(3).getAsInt()});
                    HEAD_TEXTURES.add(h.get("texture").getAsString());
                }
            }
            palette = ps;
            data = d;
            return true;
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_ship_structure.json: " + ex);
            return false;
        }
    }

    /** "dark_oak_slab[type=top,waterlogged=false]" в состояние блока. Неизвестный блок даст воздух (его не ставим). */
    private static BlockState parseState(String text) {
        String name = text;
        String props = "";
        int br = text.indexOf('[');
        if (br >= 0) {
            name = text.substring(0, br);
            props = text.substring(br + 1, text.endsWith("]") ? text.length() - 1 : text.length());
        }
        Identifier id = new Identifier(name);
        if (!Registry.BLOCK.containsId(id)) {
            System.err.println("[Arsenal] Таинственный корабль: неизвестный блок " + name);
            return Blocks.AIR.getDefaultState();
        }
        Block block = Registry.BLOCK.get(id);
        BlockState st = block.getDefaultState();
        if (!props.isEmpty()) {
            for (String pair : props.split(",")) {
                int eq = pair.indexOf('=');
                if (eq <= 0) {
                    continue;
                }
                Property<?> prop = block.getStateManager().getProperty(pair.substring(0, eq));
                if (prop != null) {
                    st = withValue(st, prop, pair.substring(eq + 1));
                }
            }
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState withValue(BlockState st, Property<T> prop, String value) {
        java.util.Optional<T> v = prop.parse(value);
        return v.isPresent() ? st.with(prop, v.get()) : st;
    }

    private static void build(ServerWorld world, Ship s) {
        loadArea(world, s);
        BlockRotation rot = ROTATIONS[s.dir & 3];
        BlockState[] rotated = new BlockState[palette.length];
        for (int i = 0; i < rotated.length; i++) {
            rotated[i] = palette[i].rotate(rot);
        }
        // сам корабль: блоки отсортированы снизу вверх. Воздух ниже ватерлинии (y <= 0) это трюм внутри корпуса:
        // он вытесняет воду. Воздух выше ватерлинии не трогаем.
        for (int i = 0; i + 3 < data.length; i += 4) {
            BlockState st = rotated[data[i + 3]];
            if (st.isAir() && data[i + 1] > 0) {
                continue;
            }
            put(world, s, s.at(data[i], data[i + 1], data[i + 2]), st);
        }
        // бочки в трюме и в кормовой комнатке
        for (int i = 0; i < BARRELS.length; i++) {
            put(world, s, barrelPos(s, i), Blocks.BARREL.getDefaultState()
                    .with(BarrelBlock.FACING, rot.rotate(BARREL_FACING[i])).with(BarrelBlock.OPEN, false));
        }
        // сокровище пиратов
        put(world, s, anchorPos(s), Blocks.RESPAWN_ANCHOR.getDefaultState().with(RespawnAnchorBlock.CHARGES, 0));
        // головы с текстурой
        for (int i = 0; i < HEADS.size(); i++) {
            int[] h = HEADS.get(i);
            BlockPos hp = s.at(h[0], h[1], h[2]);
            run(world, String.format(Locale.ROOT, "data merge block %d %d %d {SkullOwner:{Id:[I;%d,%d,%d,%d],Properties:{textures:[{Value:\"%s\"}]}}}",
                    hp.getX(), hp.getY(), hp.getZ(), h[3], h[4], h[5], h[6], HEAD_TEXTURES.get(i)));
        }
    }

    // ------------------------------------------------------------------ капитан

    private static Vec3d captainSpot(Ship s) {
        return s.vec(CAPTAIN[0], CAPTAIN[1], CAPTAIN[2]);
    }

    private static void spawnCaptain(ServerWorld world, Ship s) {
        Vec3d at = captainSpot(s);
        WanderingTraderEntity c = EntityType.WANDERING_TRADER.create(world);
        if (c == null) {
            return;
        }
        // смотрит в сторону кормы (там каюта с бочками)
        BlockPos fromPos = s.at(PX, 0, PZ);
        BlockPos toPos = s.at(PX, 0, PZ + 1);
        float yaw = (float) Math.toDegrees(Math.atan2(-(toPos.getX() - fromPos.getX()), toPos.getZ() - fromPos.getZ()));
        c.refreshPositionAndAngles(at.x, at.y, at.z, yaw, 0.0F);
        c.setAiDisabled(true);
        c.setInvulnerable(true);
        c.setPersistent();
        c.setSilent(true);
        c.setCustomName(new LiteralText("Капитан").formatted(Formatting.GOLD, Formatting.BOLD));
        c.setCustomNameVisible(false);
        c.addScoreboardTag(TAG_CAPTAIN);
        c.equipStack(EquipmentSlot.MAINHAND, s.hasKey ? captainItem() : ItemStack.EMPTY);
        world.spawnEntity(c);
        s.captain = c.getUuid();
    }

    private static WanderingTraderEntity captain(ServerWorld world, Ship s) {
        Entity e = s.captain == null ? null : world.getEntity(s.captain);
        return e instanceof WanderingTraderEntity && !e.removed ? (WanderingTraderEntity) e : null;
    }

    private static ActionResult onUseEntity(PlayerEntity player, World world, Hand hand, Entity entity) {
        if (!(entity instanceof WanderingTraderEntity) || !entity.getScoreboardTags().contains(TAG_CAPTAIN)) {
            return ActionResult.PASS;
        }
        if (world.isClient || !(player instanceof ServerPlayerEntity) || hand != Hand.MAIN_HAND) {
            return ActionResult.SUCCESS;
        }
        Ship s = active;
        if (s == null || s.captain == null || !s.captain.equals(entity.getUuid())) {
            entity.remove();   // забытый капитан прошлого ивента
            return ActionResult.FAIL;
        }
        ServerPlayerEntity p = (ServerPlayerEntity) player;
        ServerWorld sw = (ServerWorld) world;
        WanderingTraderEntity c = (WanderingTraderEntity) entity;
        if (s.hasKey) {
            int rarity = rollRarity();   // редкость определяется только в момент выдачи
            p.inventory.offerOrDrop(sw, lockpick(rarity));
            p.sendMessage(new LiteralText("Ты получил: ").formatted(Formatting.GRAY)
                    .append(new LiteralText(NAMES[rarity]).formatted(COLORS[rarity], Formatting.BOLD)), true);
            s.hasKey = false;
            s.keyIn = KEY_MIN + RNG.nextInt(Math.max(1, KEY_MAX - KEY_MIN + 1));
            c.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            sw.playSound(null, c.getBlockPos(), SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.NEUTRAL, 1.0F, 1.0F);
            save();
            refreshHolos(sw, s);
        } else {
            punish(p, c);
        }
        return ActionResult.SUCCESS;
    }

    /** Капитана без отмычки трогать нельзя: отбрасывает и бьёт, броня не помогает. */
    private static void punish(ServerPlayerEntity p, Entity c) {
        double dx = p.getX() - c.getX();
        double dz = p.getZ() - c.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.01) {
            dx = -Math.sin(Math.toRadians(p.yaw));
            dz = Math.cos(Math.toRadians(p.yaw));
            len = 1.0;
        }
        double speed = Math.max(0.5, KNOCKBACK * 0.16);
        p.setVelocity(dx / len * speed, 0.55, dz / len * speed);
        p.velocityModified = true;
        p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
        p.damage(DamageSource.MAGIC, DAMAGE);
        p.sendMessage(new LiteralText("Отмычки пока нет, не трогай капитана!").formatted(Formatting.RED), true);
    }

    // ------------------------------------------------------------------ бочки и сокровище

    private static ActionResult onUseBlock(PlayerEntity player, World world, Hand hand, BlockPos pos) {
        Ship s = active;
        if (s == null || hand != Hand.MAIN_HAND || !inZone(world, pos.getX() + 0.5, pos.getZ() + 0.5)) {
            return ActionResult.PASS;
        }
        int bi = -1;
        for (int i = 0; i < BARRELS.length; i++) {
            if (barrelPos(s, i).equals(pos)) {
                bi = i;
            }
        }
        boolean anchor = pos.equals(anchorPos(s));
        if (bi < 0 && !anchor) {
            return ActionResult.PASS;
        }
        if (world.isClient || !(player instanceof ServerPlayerEntity)) {
            // открытая бочка открывается как обычная, всё остальное решает сервер
            return bi >= 0 && s.barrelClose[bi] > 0 ? ActionResult.PASS : ActionResult.SUCCESS;
        }
        ServerPlayerEntity p = (ServerPlayerEntity) player;
        ServerWorld sw = (ServerWorld) world;
        ItemStack held = p.getMainHandStack();
        if (bi >= 0) {
            if (s.barrelClose[bi] > 0) {
                return ActionResult.PASS;   // бочка открыта: достаём лут как из обычной
            }
            if (!valid(held)) {
                p.sendMessage(new LiteralText("Бочка закрыта, нужна отмычка").formatted(Formatting.RED), true);
                return ActionResult.FAIL;
            }
            int rarity = rarityOf(held);
            if (!p.isCreative()) {
                held.decrement(1);
            }
            openBarrel(sw, s, bi, rarity);
            return ActionResult.SUCCESS;
        }
        // сокровище пиратов
        if (s.anchorDone) {
            p.sendMessage(new LiteralText("Сокровище уже закрылось, второй раз его не открыть").formatted(Formatting.GRAY), true);
            return ActionResult.FAIL;
        }
        if (s.anchorOpen) {
            openAnchorWindow(p, s);
            return ActionResult.SUCCESS;
        }
        if (s.anchorOpenIn >= 0) {
            p.sendMessage(new LiteralText("Сокровище откроется через " + EventManager.fmt(s.anchorOpenIn)).formatted(Formatting.AQUA), true);
            return ActionResult.FAIL;
        }
        if (!valid(held) || rarityOf(held) != 2) {
            p.sendMessage(new LiteralText("Нужны секретные отмычки: " + s.anchorKeys + "/" + ANCHOR_KEYS).formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }
        if (!p.isCreative()) {
            held.decrement(1);
        }
        s.anchorKeys++;
        sw.playSound(null, pos, SoundEvents.BLOCK_CHAIN_PLACE, SoundCategory.BLOCKS, 1.0F, 0.8F);
        if (s.anchorKeys >= ANCHOR_KEYS) {
            s.anchorOpenIn = ANCHOR_OPEN;
            p.sendMessage(new LiteralText("Сокровище откроется через " + EventManager.fmt(ANCHOR_OPEN)).formatted(Formatting.AQUA), true);
        } else {
            p.sendMessage(new LiteralText("Секретные отмычки: " + s.anchorKeys + "/" + ANCHOR_KEYS).formatted(Formatting.BLUE), true);
        }
        save();
        refreshHolos(sw, s);
        return ActionResult.SUCCESS;
    }

    private static void setBarrelOpen(ServerWorld world, BlockPos pos, boolean open) {
        BlockState st = world.getBlockState(pos);
        if (st.getBlock() == Blocks.BARREL && st.get(BarrelBlock.OPEN) != open) {
            world.setBlockState(pos, st.with(BarrelBlock.OPEN, open), 2);
        }
    }

    private static void openBarrel(ServerWorld world, Ship s, int i, int rarity) {
        BlockPos pos = barrelPos(s, i);
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof Inventory) {
            ((Inventory) be).clear();
            CargoLoot.fill((Inventory) be, CargoLoot.rollFlat(TABLES[rarity]));
            be.markDirty();
        }
        s.barrelClose[i] = BARREL_CLOSE;
        s.barrelRarity[i] = rarity;
        setBarrelOpen(world, pos, true);
        world.playSound(null, pos, SoundEvents.BLOCK_BARREL_OPEN, SoundCategory.BLOCKS, 1.0F, 1.0F);
        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 8, 0.3, 0.2, 0.3, 0.0);
        save();
        refreshHolos(world, s);
    }

    private static void closeBarrel(ServerWorld world, Ship s, int i) {
        BlockPos pos = barrelPos(s, i);
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof Inventory) {
            ((Inventory) be).clear();   // лут исчезает вместе с закрытием
            be.markDirty();
        }
        s.barrelClose[i] = 0;
        setBarrelOpen(world, pos, false);
        world.playSound(null, pos, SoundEvents.BLOCK_BARREL_CLOSE, SoundCategory.BLOCKS, 1.0F, 1.0F);
        save();
        refreshHolos(world, s);
    }

    private static void openAnchor(ServerWorld world, Ship s) {
        s.anchorOpen = true;
        s.anchorOpenIn = -1;
        s.anchorCloseIn = ANCHOR_CLOSE;
        BlockPos pos = anchorPos(s);
        BlockState st = world.getBlockState(pos);
        if (st.getBlock() == Blocks.RESPAWN_ANCHOR) {
            world.setBlockState(pos, st.with(RespawnAnchorBlock.CHARGES, 4), 2);
        }
        world.playSound(null, pos, SoundEvents.BLOCK_RESPAWN_ANCHOR_CHARGE, SoundCategory.BLOCKS, 2.0F, 1.0F);
        world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 40, 0.4, 0.4, 0.4, 0.3);
        // лут не выбрасывается: он ложится в окно сокровища (как в сундук), его открывает ПКМ по якорю
        List<ItemStack> loot = CargoLoot.rollFlat("ship_treasure");
        int size = loot.size() > 27 ? 54 : 27;
        s.anchorLoot = new SimpleInventory(size);
        CargoLoot.fill(s.anchorLoot, loot);
        save();
        refreshHolos(world, s);
    }

    /** Сокровище закрывается: окна с лутом закрываются, остаток лута пропадает, больше за ивент не откроется. */
    private static void closeAnchor(ServerWorld world, Ship s) {
        closeAnchorWindows(world.getServer(), s);
        s.anchorOpen = false;
        s.anchorOpenIn = -1;
        s.anchorCloseIn = -1;
        s.anchorDone = true;
        BlockPos pos = anchorPos(s);
        BlockState st = world.getBlockState(pos);
        if (st.getBlock() == Blocks.RESPAWN_ANCHOR) {
            world.setBlockState(pos, st.with(RespawnAnchorBlock.CHARGES, 0), 2);
        }
        world.playSound(null, pos, SoundEvents.BLOCK_RESPAWN_ANCHOR_DEPLETE, SoundCategory.BLOCKS, 1.5F, 1.0F);
        world.spawnParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 20, 0.4, 0.3, 0.4, 0.02);
        save();
        refreshHolos(world, s);
    }

    /**
     * Вызывается из миксина RespawnAnchorBlock: клик по сокровищу пиратов никогда не доходит до ванильного якоря
     * (он вне Незера взрывался). null: это не сокровище корабля, пусть работает ваниль.
     */
    public static ActionResult useAnchor(World world, BlockPos pos, PlayerEntity player, Hand hand) {
        Ship s = active;
        if (world.isClient || s == null || world.getRegistryKey() != World.OVERWORLD || !pos.equals(anchorPos(s))) {
            return null;
        }
        if (hand != Hand.MAIN_HAND) {
            return ActionResult.FAIL;
        }
        ActionResult r = onUseBlock(player, world, hand, pos);
        return r == ActionResult.PASS ? ActionResult.FAIL : r;
    }

    /** ПКМ по открытому сокровищу: окно с лутом, забирать можно всё. */
    private static void openAnchorWindow(ServerPlayerEntity p, Ship s) {
        SimpleInventory loot = s.anchorLoot;
        if (loot == null) {
            p.sendMessage(new LiteralText("В сокровище пусто").formatted(Formatting.GRAY), true);
            return;
        }
        int rows = loot.size() / 9;
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, inv, player) -> rows > 3
                        ? GenericContainerScreenHandler.createGeneric9x6(syncId, inv, loot)
                        : GenericContainerScreenHandler.createGeneric9x3(syncId, inv, loot),
                new LiteralText("Сокровище пиратов")));
    }

    private static boolean anchorEmpty(Ship s) {
        SimpleInventory loot = s.anchorLoot;
        if (loot == null) {
            return true;
        }
        for (int i = 0; i < loot.size(); i++) {
            if (!loot.getStack(i).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ надписи

    private static final class Holo {
        final String id;
        final double x;
        final double y;
        final double z;
        final Text text;

        Holo(String id, double x, double y, double z, Text text) {
            this.id = id;
            this.x = x;
            this.y = y;
            this.z = z;
            this.text = text;
        }
    }

    private static String sec(int ticks) {
        return Math.max(0, (ticks + 19) / 20) + " сек.";
    }

    private static List<Holo> wanted(ServerWorld world, Ship s) {
        List<Holo> list = new ArrayList<>();
        Vec3d c = captainSpot(s);
        list.add(new Holo("cap_a", c.x, c.y + 2.55, c.z, new LiteralText("Капитан").formatted(Formatting.GOLD, Formatting.BOLD)));
        list.add(new Holo("cap_b", c.x, c.y + 2.25, c.z, s.hasKey
                ? new LiteralText("Есть отмычка, бери скорее [ПКМ]").formatted(Formatting.GREEN)
                : new LiteralText("Подожди, сейчас поищу отмычку").formatted(Formatting.GRAY)));
        BlockPos a = anchorPos(s);
        Text status;
        if (s.anchorDone) {
            status = new LiteralText("Закрыто").formatted(Formatting.GRAY);
        } else if (s.anchorOpen) {
            status = anchorEmpty(s)
                    ? new LiteralText("Пусто").formatted(Formatting.GRAY)
                    : new LiteralText("Открыто").formatted(Formatting.GREEN);
        } else if (s.anchorOpenIn >= 0) {
            status = new LiteralText("Откроется через " + sec(s.anchorOpenIn)).formatted(Formatting.AQUA);
        } else {
            status = new LiteralText("Секретные отмычки: " + s.anchorKeys + "/" + ANCHOR_KEYS).formatted(Formatting.BLUE);
        }
        list.add(new Holo("anchor_a", a.getX() + 0.5, a.getY() + 1.85, a.getZ() + 0.5,
                new LiteralText("Сокровище пиратов").formatted(Formatting.GOLD, Formatting.BOLD)));
        list.add(new Holo("anchor_b", a.getX() + 0.5, a.getY() + 1.55, a.getZ() + 0.5, status));
        if (s.anchorOpen && !s.anchorDone) {
            list.add(new Holo("anchor_c", a.getX() + 0.5, a.getY() + 1.25, a.getZ() + 0.5,
                    new LiteralText("Закроется через " + sec(s.anchorCloseIn)).formatted(Formatting.RED)));
        }
        for (int i = 0; i < BARRELS.length; i++) {
            if (s.barrelClose[i] > 0) {
                BlockPos b = barrelPos(s, i);
                list.add(new Holo("b" + i + "_a", b.getX() + 0.5, b.getY() + 1.5, b.getZ() + 0.5,
                        new LiteralText("Клад").formatted(Formatting.YELLOW, Formatting.BOLD)));
                list.add(new Holo("b" + i + "_b", b.getX() + 0.5, b.getY() + 1.2, b.getZ() + 0.5,
                        new LiteralText("Закроется через " + sec(s.barrelClose[i])).formatted(Formatting.BLUE)));
            }
        }
        return list;
    }

    private static String json(Text text) {
        return Text.Serializer.toJson(text).replace("\\", "\\\\").replace("'", "\\'");
    }

    private static void run(ServerWorld world, String command) {
        MinecraftServer server = world.getServer();
        server.getCommandManager().execute(server.getCommandSource().withWorld(world).withSilent(), command);
    }

    /** Приводит надписи к нужному виду: недостающие создаёт, лишние убирает, у остальных меняет текст. */
    private static void refreshHolos(ServerWorld world, Ship s) {
        if (!world.isChunkLoaded(new BlockPos(s.cx, s.sy, s.cz))) {
            return;
        }
        Box box = new Box(s.minX - 2, s.sy - 6, s.minZ - 2, s.maxX + 2, s.sy + 12, s.maxZ + 2);
        Map<String, ArmorStandEntity> stands = new HashMap<>();
        for (ArmorStandEntity st : world.getEntitiesByClass(ArmorStandEntity.class, box, e -> e.getScoreboardTags().contains(TAG_HOLO))) {
            String id = null;
            for (String t : st.getScoreboardTags()) {
                if (t.startsWith(TAG_HOLO + "_")) {
                    id = t.substring(TAG_HOLO.length() + 1);
                }
            }
            if (id == null || stands.containsKey(id)) {
                st.remove();
            } else {
                stands.put(id, st);
            }
        }
        Set<String> keep = new HashSet<>();
        for (Holo h : wanted(world, s)) {
            keep.add(h.id);
            ArmorStandEntity st = stands.get(h.id);
            if (st == null) {
                run(world, String.format(Locale.ROOT,
                        "summon minecraft:armor_stand %.2f %.2f %.2f {Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,"
                                + "CustomNameVisible:1b,Tags:[\"%s\",\"%s_%s\"],CustomName:'%s'}",
                        h.x, h.y, h.z, TAG_HOLO, TAG_HOLO, h.id, json(h.text)));
            } else {
                st.setCustomName(h.text);
            }
        }
        for (Map.Entry<String, ArmorStandEntity> e : stands.entrySet()) {
            if (!keep.contains(e.getKey())) {
                e.getValue().remove();
            }
        }
    }

    // ------------------------------------------------------------------ тик

    private static void onTick(MinecraftServer server) {
        tick++;
        Ship s = active;
        if (s == null) {
            return;
        }
        ServerWorld world = server.getOverworld();
        s.age++;
        if (s.age >= DURATION) {
            end(server, true);
            return;
        }
        if (s.age % 200 == 0 || (s.anchorLoot != null && s.age % 40 == 0)) {
            save();   // лут сокровища сохраняется чаще: из него забирают предметы
        }
        if (!s.hasKey && --s.keyIn <= 0) {
            s.hasKey = true;
            WanderingTraderEntity c = captain(world, s);
            if (c != null) {
                c.equipStack(EquipmentSlot.MAINHAND, captainItem());
            }
            refreshHolos(world, s);
            save();
        }
        boolean loaded = world.isChunkLoaded(new BlockPos(s.cx, s.sy, s.cz));
        for (int i = 0; i < BARRELS.length; i++) {
            if (s.barrelClose[i] > 0 && --s.barrelClose[i] == 0) {
                if (loaded) {
                    closeBarrel(world, s, i);
                } else {
                    s.barrelClose[i] = 1;   // подождём, пока чанк загрузится
                }
            }
        }
        if (s.anchorOpenIn > 0 && --s.anchorOpenIn == 0) {
            if (loaded) {
                openAnchor(world, s);
            } else {
                s.anchorOpenIn = 1;
            }
        }
        if (s.anchorCloseIn > 0 && --s.anchorCloseIn == 0) {
            if (loaded) {
                closeAnchor(world, s);
            } else {
                s.anchorCloseIn = 1;
            }
        }
        // у капитана торговля выключена: если окно торговли всё же открылось, закрываем его
        if (loaded) {
            WanderingTraderEntity trader = captain(world, s);
            if (trader != null && trader.getCurrentCustomer() != null) {
                PlayerEntity customer = trader.getCurrentCustomer();
                trader.setCurrentCustomer(null);
                if (customer instanceof ServerPlayerEntity) {
                    ((ServerPlayerEntity) customer).closeHandledScreen();
                }
            }
        }
        // капитан стоит на палубе (и пересоздаётся, если пропал)
        if (loaded && s.age % 10 == 0) {
            Vec3d at = captainSpot(s);
            WanderingTraderEntity c = captain(world, s);
            if (c == null) {
                spawnCaptain(world, s);
            } else if (c.squaredDistanceTo(at.x, at.y, at.z) > 0.5) {
                c.refreshPositionAndAngles(at.x, at.y, at.z, c.yaw, 0.0F);
                c.setVelocity(Vec3d.ZERO);
            }
        }
        if (loaded && s.age % 20 == 0) {
            // открытые бочки сами закрываются, когда их отпускают, а они должны стоять открытыми до конца
            for (int i = 0; i < BARRELS.length; i++) {
                if (s.barrelClose[i] > 0) {
                    setBarrelOpen(world, barrelPos(s, i), true);
                }
            }
            refreshHolos(world, s);
        }
    }

    // ------------------------------------------------------------------ сохранение

    private static Path stateFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_ship.json");
    }

    private static Path blocksFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_ship_blocks.json");
    }

    private static void saveBlocks(Ship s) {
        MinecraftServer server = serverRef;
        if (server == null) {
            return;
        }
        try {
            JsonArray pos = new JsonArray();
            JsonArray ids = new JsonArray();
            for (Map.Entry<Long, Integer> e : s.saved.entrySet()) {
                pos.add(e.getKey());
                ids.add(e.getValue());
            }
            JsonObject o = new JsonObject();
            o.add("pos", pos);
            o.add("ids", ids);
            Files.write(blocksFile(server), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_ship_blocks.json: " + ex);
        }
    }

    private static JsonArray packLoot(SimpleInventory inv) {
        JsonArray arr = new JsonArray();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (st.isEmpty()) {
                continue;
            }
            JsonObject o = new JsonObject();
            o.addProperty("slot", i);
            o.addProperty("id", Registry.ITEM.getId(st.getItem()).toString());
            o.addProperty("count", st.getCount());
            if (st.hasTag()) {
                o.addProperty("tag", st.getTag().toString());
            }
            arr.add(o);
        }
        return arr;
    }

    private static SimpleInventory unpackLoot(int size, JsonArray arr) {
        SimpleInventory inv = new SimpleInventory(size);
        for (JsonElement el : arr) {
            JsonObject o = el.getAsJsonObject();
            net.minecraft.item.Item item = Registry.ITEM.getOrEmpty(new Identifier(o.get("id").getAsString())).orElse(null);
            int slot = o.get("slot").getAsInt();
            if (item == null || slot < 0 || slot >= size) {
                continue;
            }
            ItemStack st = new ItemStack(item, o.get("count").getAsInt());
            if (o.has("tag")) {
                try {
                    st.setTag(StringNbtReader.parse(o.get("tag").getAsString()));
                } catch (Exception ignored) {
                    // предмет вернётся без тега, лучше так, чем потерять совсем
                }
            }
            inv.setStack(slot, st);
        }
        return inv;
    }

    private static void save() {
        MinecraftServer server = serverRef;
        if (server == null) {
            return;
        }
        try {
            Ship s = active;
            if (s == null) {
                Files.deleteIfExists(stateFile(server));
                return;
            }
            JsonObject o = new JsonObject();
            o.addProperty("v", STATE_VERSION);
            o.addProperty("cx", s.cx);
            o.addProperty("cz", s.cz);
            o.addProperty("sy", s.sy);
            o.addProperty("dir", s.dir);
            o.addProperty("age", s.age);
            o.addProperty("serial", s.serial);
            o.addProperty("serialCounter", serialCounter);
            o.addProperty("captain", s.captain == null ? "" : s.captain.toString());
            o.addProperty("hasKey", s.hasKey);
            o.addProperty("keyIn", s.keyIn);
            o.addProperty("anchorKeys", s.anchorKeys);
            o.addProperty("anchorOpenIn", s.anchorOpenIn);
            o.addProperty("anchorOpen", s.anchorOpen);
            o.addProperty("anchorCloseIn", s.anchorCloseIn);
            o.addProperty("anchorDone", s.anchorDone);
            JsonArray close = new JsonArray();
            JsonArray rar = new JsonArray();
            for (int i = 0; i < BARRELS.length; i++) {
                close.add(s.barrelClose[i]);
                rar.add(s.barrelRarity[i]);
            }
            if (s.anchorLoot != null) {
                o.addProperty("anchorSize", s.anchorLoot.size());
                o.add("anchorLoot", packLoot(s.anchorLoot));
            }
            o.add("barrelClose", close);
            o.add("barrelRarity", rar);
            Files.write(stateFile(server), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_ship.json: " + ex);
        }
    }

    /** Корабль, сохранённый до замены структуры: возвращаем местность из журнала блоков и убираем надписи с капитаном. */
    private static void removeLegacy(MinecraftServer server, JsonObject o) {
        try {
            ServerWorld world = server.getOverworld();
            Path bf = blocksFile(server);
            if (Files.exists(bf)) {
                JsonObject b = new JsonParser().parse(new String(Files.readAllBytes(bf), StandardCharsets.UTF_8)).getAsJsonObject();
                JsonArray pos = b.getAsJsonArray("pos");
                JsonArray ids = b.getAsJsonArray("ids");
                for (int i = 0; i < pos.size(); i++) {
                    BlockPos p = BlockPos.fromLong(pos.get(i).getAsLong());
                    world.getChunk(p.getX() >> 4, p.getZ() >> 4);
                    world.setBlockState(p, Block.getStateFromRawId(ids.get(i).getAsInt()), 2);
                }
            }
            run(world, "kill @e[tag=" + TAG_CAPTAIN + "]");
            run(world, "kill @e[type=minecraft:armor_stand,tag=" + TAG_HOLO + "]");
            Files.deleteIfExists(bf);
            Files.deleteIfExists(stateFile(server));
            System.out.println("[Arsenal] Старый Таинственный корабль убран (структура корабля заменена)");
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось убрать старый Таинственный корабль: " + ex);
        }
    }

    private static void load(MinecraftServer server) {
        serverRef = server;
        active = null;
        try {
            Path f = stateFile(server);
            if (!Files.exists(f)) {
                return;
            }
            JsonObject o = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            if (!o.has("v") || o.get("v").getAsInt() < STATE_VERSION) {
                // корабль старой постройки (до замены структуры): продолжать его нельзя, убираем и возвращаем местность
                removeLegacy(server, o);
                return;
            }
            if (!loadStructure()) {
                return;
            }
            Ship s = new Ship();
            s.cx = o.get("cx").getAsInt();
            s.cz = o.get("cz").getAsInt();
            s.sy = o.get("sy").getAsInt();
            s.dir = o.get("dir").getAsInt();
            s.age = o.get("age").getAsInt();
            s.serial = o.get("serial").getAsInt();
            serialCounter = Math.max(serialCounter, o.get("serialCounter").getAsInt());
            String c = o.get("captain").getAsString();
            s.captain = c.isEmpty() ? null : UUID.fromString(c);
            s.hasKey = o.get("hasKey").getAsBoolean();
            s.keyIn = o.get("keyIn").getAsInt();
            s.anchorKeys = o.get("anchorKeys").getAsInt();
            s.anchorOpenIn = o.get("anchorOpenIn").getAsInt();
            s.anchorOpen = o.get("anchorOpen").getAsBoolean();
            s.anchorCloseIn = o.has("anchorCloseIn") ? o.get("anchorCloseIn").getAsInt() : (s.anchorOpen ? ANCHOR_CLOSE : -1);
            s.anchorDone = o.has("anchorDone") && o.get("anchorDone").getAsBoolean();
            if (o.has("anchorSize") && o.has("anchorLoot")) {
                s.anchorLoot = unpackLoot(o.get("anchorSize").getAsInt(), o.getAsJsonArray("anchorLoot"));
            }
            JsonArray close = o.getAsJsonArray("barrelClose");
            JsonArray rar = o.getAsJsonArray("barrelRarity");
            for (int i = 0; i < BARRELS.length && i < close.size(); i++) {
                s.barrelClose[i] = close.get(i).getAsInt();
                s.barrelRarity[i] = rar.get(i).getAsInt();
            }
            s.prepare();
            Path bf = blocksFile(server);
            if (Files.exists(bf)) {
                JsonObject b = new JsonParser().parse(new String(Files.readAllBytes(bf), StandardCharsets.UTF_8)).getAsJsonObject();
                JsonArray pos = b.getAsJsonArray("pos");
                JsonArray ids = b.getAsJsonArray("ids");
                for (int i = 0; i < pos.size(); i++) {
                    s.saved.put(pos.get(i).getAsLong(), ids.get(i).getAsInt());
                }
            }
            active = s;
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_ship.json: " + ex);
        }
    }
}
