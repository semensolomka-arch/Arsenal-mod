package com.arsenal.event;

import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.MessageType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Смертельная шахта (ивент в общем цикле). Что-то между автошахтой и смертельным грузом: та же круглая зона 50 блоков со стан-зоной
 * (нельзя жемчуг и хорус), но режима боя нет. В центре яма 9x9 глубиной 10 блоков, заполненная обсидианом и плачущим обсидианом;
 * блоки для копания начинаются на глубине 2 блока от края, так что выпрыгнуть нельзя: выбраться из ямы до конца ивента не получится.
 *
 * Игрок копает блок: лут (таблица mine) сразу кладётся в инвентарь, на 4 секунды включается свечение, а предмет, которым ломал,
 * меняется местами со случайным другим слотом инвентаря (хоть с бронёй, хоть с пустым слотом, хоть со второй рукой).
 * Больше в зоне ломать и строить нельзя, как и у груза. Через DURATION ивент исчезает, местность возвращается, а кого оставшегося в яме засыпает землёй.
 */
public final class DeadlyMine {
    // ---- настройки (Settings), время в тиках
    public static int DURATION = 20 * 60 * 10;
    /** Сколько светится игрок после сломанного блока. */
    public static int GLOW = 20 * 4;

    /** Радиус круглой зоны (как у груза). */
    public static final double RADIUS = 25.5;
    private static final int HALF = 26;
    private static final int PIT_HALF = 4;
    /** Глубина ямы от поверхности: пол на y0 - 1 - DEPTH. */
    private static final int DEPTH = 10;
    /** Сверху столько блоков ямы пустые, обсидиан начинается глубже. */
    private static final int GAP = 2;
    private static final int MAX_DISTANCE = 4000;
    private static final Random RNG = new Random();

    private static final class Active {
        int cx;
        int cz;
        /** Игрок стоит на этом y, земля на y0 - 1. */
        int y0;
        int age;
        /** Блоки, которые ивент заменил: позиция -> id исходного состояния (чтобы вернуть местность). */
        final Map<Long, Integer> saved = new LinkedHashMap<>();
    }

    private static Active active;
    private static MinecraftServer serverRef;

    private DeadlyMine() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(DeadlyMine::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            save();
            active = null;
            serverRef = null;
        });
        ServerTickEvents.END_SERVER_TICK.register(DeadlyMine::onTick);
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity) || !isMineBlock(world, pos)
                    || SpawnProtection.bypass(player) || player.isSpectator()) {
                return true;   // операторы в творческом режиме ломают как обычно (для починки)
            }
            mine((ServerWorld) world, (ServerPlayerEntity) player, pos, state);
            return false;      // сам блок убираем здесь, обычного выпадения нет
        });
    }

    public static boolean isActive() {
        return active != null;
    }

    /** Круглая зона шахты (диаметр 50): там защита как у груза, нет мобов, стан-зона. */
    public static boolean inZone(World world, double x, double z) {
        Active a = active;
        if (a == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        double dx = x - (a.cx + 0.5);
        double dz = z - (a.cz + 0.5);
        return dx * dx + dz * dz <= RADIUS * RADIUS;
    }

    public static boolean overlaps(World world, BlockPos center, int half) {
        Active a = active;
        if (a == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        return Math.abs(center.getX() - a.cx) <= half + HALF && Math.abs(center.getZ() - a.cz) <= half + HALF;
    }

    /** Идёт ли шахта ближе чем в dist блоков от точки (чтобы другие ивенты не появлялись рядом). */
    public static boolean near(int x, int z, int dist) {
        Active a = active;
        return a != null && Math.abs(a.cx - x) < dist && Math.abs(a.cz - z) < dist;
    }

    /** Блок для копания: обсидиан или плачущий обсидиан внутри ямы шахты. */
    public static boolean isMineBlock(World world, BlockPos pos) {
        Active a = active;
        if (a == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        if (Math.abs(pos.getX() - a.cx) > PIT_HALF || Math.abs(pos.getZ() - a.cz) > PIT_HALF
                || pos.getY() > a.y0 - 1 - GAP || pos.getY() < a.y0 - DEPTH) {
            return false;
        }
        Block b = world.getBlockState(pos).getBlock();
        return b == Blocks.OBSIDIAN || b == Blocks.CRYING_OBSIDIAN;
    }

    /** Центр ивента (x, z) или null. */
    public static int[] center() {
        Active a = active;
        return a == null ? null : new int[]{a.cx, a.cz};
    }

    public static String coords() {
        Active a = active;
        return a == null ? null : a.cx + " " + a.y0 + " " + a.cz;
    }

    public static int ticksLeft() {
        Active a = active;
        return a == null ? -1 : Math.max(0, DURATION - a.age);
    }

    /** /event time skip: шахта исчезает, местность возвращается. */
    public static void despawn(MinecraftServer server) {
        end(server, true);
    }

    public static boolean startRandom(MinecraftServer server) {
        return active == null && start(server);
    }

    // ------------------------------------------------------------------ копание

    private static void mine(ServerWorld world, ServerPlayerEntity p, BlockPos pos, BlockState state) {
        world.syncWorldEvent(2001, pos, Block.getRawIdFromState(state));
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), 3);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, GLOW, 0, false, false));

        // инструмент меняется местами со случайным другим слотом: основной инвентарь, броня (36-39) или вторая рука (40)
        PlayerInventory inv = p.inventory;
        int sel = inv.selectedSlot;
        ItemStack held = inv.getStack(sel);
        if (!held.isEmpty()) {
            List<Integer> slots = new ArrayList<>();
            for (int i = 0; i <= 40; i++) {
                if (i != sel) {
                    slots.add(i);
                }
            }
            int target = slots.get(RNG.nextInt(slots.size()));
            ItemStack other = inv.getStack(target);
            inv.setStack(sel, other);
            inv.setStack(target, held);
        }

        // лут сразу в инвентарь (не влезло: под ноги)
        for (ItemStack reward : CargoLoot.rollOne("mine")) {
            if (!inv.insertStack(reward) && !reward.isEmpty()) {
                p.dropItem(reward, false);
            }
        }
        p.currentScreenHandler.sendContentUpdates();
        p.playerScreenHandler.sendContentUpdates();
    }

    // ------------------------------------------------------------------ тик

    private static void onTick(MinecraftServer server) {
        Active a = active;
        if (a == null) {
            return;
        }
        a.age++;
        if (a.age >= DURATION) {
            end(server, true);
            return;
        }
        if (a.age % 600 == 0) {
            save();
        }
    }

    private static void broadcast(MinecraftServer server, Text text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, Util.NIL_UUID);
    }

    private static boolean start(MinecraftServer server) {
        ServerWorld world = server.getOverworld();
        Active a = findSite(world);
        if (a == null) {
            return false;
        }
        build(world, a);
        active = a;
        serverRef = server;
        com.arsenal.StunZones.addCircle(world, a.cx + 0.5, a.cz + 0.5, RADIUS, 0, 320, DURATION);
        save();
        saveBlocks(a);
        broadcast(server, new LiteralText("«").formatted(Formatting.GRAY)
                .append(new LiteralText("Смертельная шахта").formatted(Formatting.DARK_PURPLE, Formatting.BOLD))
                .append(new LiteralText("» на координатах ").formatted(Formatting.GRAY))
                .append(new LiteralText(a.cx + " " + a.y0 + " " + a.cz).formatted(Formatting.WHITE)));
        return true;
    }

    private static void end(MinecraftServer server, boolean announce) {
        Active a = active;
        if (a == null) {
            return;
        }
        active = null;
        save();   // файл ивента удаляется
        ServerWorld world = server.getOverworld();
        com.arsenal.StunZones.removeCircle(world, a.cx + 0.5, a.cz + 0.5);
        loadArea(world, a);
        // яма засыпается землёй как на смертельном грузе: кто остался внутри, задыхается в блоках
        for (Map.Entry<Long, Integer> e : a.saved.entrySet()) {
            world.setBlockState(BlockPos.fromLong(e.getKey()), Block.getStateFromRawId(e.getValue()), 2);
        }
        try {
            Files.deleteIfExists(blocksFile(server));
        } catch (Exception ignored) {
            // не критично
        }
        if (announce) {
            broadcast(server, new LiteralText("«").formatted(Formatting.GRAY)
                    .append(new LiteralText("Смертельная шахта").formatted(Formatting.DARK_PURPLE, Formatting.BOLD))
                    .append(new LiteralText("» закончилась").formatted(Formatting.GRAY)));
        }
    }

    // ------------------------------------------------------------------ сохранение

    private static Path stateFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_deadlymine.json");
    }

    private static Path blocksFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_deadlymine_blocks.json");
    }

    private static void saveBlocks(Active a) {
        MinecraftServer server = serverRef;
        if (server == null) {
            return;
        }
        try {
            JsonArray pos = new JsonArray();
            JsonArray ids = new JsonArray();
            for (Map.Entry<Long, Integer> e : a.saved.entrySet()) {
                pos.add(e.getKey());
                ids.add(e.getValue());
            }
            JsonObject o = new JsonObject();
            o.add("pos", pos);
            o.add("ids", ids);
            Files.write(blocksFile(server), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_deadlymine_blocks.json: " + ex);
        }
    }

    private static void save() {
        MinecraftServer server = serverRef;
        if (server == null) {
            return;
        }
        try {
            Active a = active;
            if (a == null) {
                Files.deleteIfExists(stateFile(server));
                return;
            }
            JsonObject o = new JsonObject();
            o.addProperty("cx", a.cx);
            o.addProperty("cz", a.cz);
            o.addProperty("y0", a.y0);
            o.addProperty("age", a.age);
            Files.write(stateFile(server), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_deadlymine.json: " + ex);
        }
    }

    private static void load(MinecraftServer server) {
        serverRef = server;
        active = null;
        try {
            Path f = stateFile(server);
            if (!Files.exists(f)) {
                return;
            }
            JsonObject o = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            Active a = new Active();
            a.cx = o.get("cx").getAsInt();
            a.cz = o.get("cz").getAsInt();
            a.y0 = o.get("y0").getAsInt();
            a.age = o.get("age").getAsInt();
            Path bf = blocksFile(server);
            if (Files.exists(bf)) {
                JsonObject b = new JsonParser().parse(new String(Files.readAllBytes(bf), StandardCharsets.UTF_8)).getAsJsonObject();
                JsonArray pos = b.getAsJsonArray("pos");
                JsonArray ids = b.getAsJsonArray("ids");
                for (int i = 0; i < pos.size(); i++) {
                    a.saved.put(pos.get(i).getAsLong(), ids.get(i).getAsInt());
                }
            }
            active = a;
            int left = DURATION - a.age;
            if (left > 0) {
                com.arsenal.StunZones.addCircle(server.getOverworld(), a.cx + 0.5, a.cz + 0.5, RADIUS, 0, 320, left);
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_deadlymine.json: " + ex);
        }
    }

    // ------------------------------------------------------------------ поиск места

    private static Active findSite(ServerWorld world) {
        for (int attempt = 0; attempt < 80; attempt++) {
            double angle = RNG.nextDouble() * Math.PI * 2;
            double dist = 300 + Math.sqrt(RNG.nextDouble()) * (MAX_DISTANCE - 300);
            int cx = (int) Math.round(Math.cos(angle) * dist);
            int cz = (int) Math.round(Math.sin(angle) * dist);
            if (!zoneFree(world, cx, cz)) {
                continue;
            }
            int[] cargo = EventManager.center();
            if (cargo != null && Math.abs(cargo[0] - cx) < 120 && Math.abs(cargo[1] - cz) < 120) {
                continue;
            }
            if (XpEvent.near(cx, cz, 120) || MysteryShip.near(cx, cz, 120)) {
                continue;
            }
            List<Integer> hs = new ArrayList<>();
            int bad = 0;
            for (int dx = -HALF; dx <= HALF; dx += 5) {
                for (int dz = -HALF; dz <= HALF; dz += 5) {
                    int y = groundY(world, cx + dx, cz + dz);
                    if (y < 0) {
                        bad++;
                    } else {
                        hs.add(y);
                    }
                }
            }
            if (bad > 8 || hs.size() < 20) {
                continue;
            }
            java.util.Collections.sort(hs);
            int lo = hs.get(hs.size() / 10);
            int hi = hs.get(hs.size() * 9 / 10);
            if (hi - lo > 6) {
                continue;
            }
            int y0 = hs.get(hs.size() / 2);
            if (y0 < 24 || y0 > 190 || hasBlockEntities(world, cx, y0, cz)) {
                continue;
            }
            Active a = new Active();
            a.cx = cx;
            a.cz = cz;
            a.y0 = y0;
            return a;
        }
        return null;
    }

    private static boolean hasBlockEntities(ServerWorld world, int cx, int y0, int cz) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int y = y0 - DEPTH - 2; y <= y0 + 12; y++) {
                    m.set(cx + dx, y, cz + dz);
                    if (world.getBlockEntity(m) != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean zoneFree(ServerWorld world, int cx, int cz) {
        int r = HALF + 6;
        int[][] pts = {{0, 0}, {r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, -r}, {r, -r}, {-r, r}};
        for (int[] p : pts) {
            BlockPos pos = new BlockPos(cx + p[0], 64, cz + p[1]);
            if (SpawnProtection.contains(world, pos) || !world.getWorldBorder().contains(pos)) {
                return false;
            }
        }
        return !PrivateManager.intersects(world, new Box(cx - r, 0, cz - r, cx + r, 256, cz + r));
    }

    private static int groundY(ServerWorld world, int x, int z) {
        world.getChunk(x >> 4, z >> 4);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y < 10 || y > 200) {
            return -1;
        }
        BlockState below = world.getBlockState(new BlockPos(x, y - 1, z));
        if (below.isAir() || !below.getFluidState().isEmpty()) {
            return -1;
        }
        return y;
    }

    // ------------------------------------------------------------------ постройка

    private static void loadArea(ServerWorld world, Active a) {
        for (int x = (a.cx - HALF - 1) >> 4; x <= (a.cx + HALF + 1) >> 4; x++) {
            for (int z = (a.cz - HALF - 1) >> 4; z <= (a.cz + HALF + 1) >> 4; z++) {
                world.getChunk(x, z);
            }
        }
    }

    private static void put(ServerWorld world, Active a, BlockPos pos, BlockState state) {
        BlockState cur = world.getBlockState(pos);
        if (cur == state) {
            return;
        }
        a.saved.putIfAbsent(pos.asLong(), Block.getRawIdFromState(cur));
        world.setBlockState(pos, state, 2);
    }

    private static void put(ServerWorld world, Active a, int dx, int y, int dz, Block block) {
        put(world, a, new BlockPos(a.cx + dx, y, a.cz + dz), block.getDefaultState());
    }

    /** Выравнивает площадку на высоту y0 (потом всё возвращается) и строит яму с обсидианом. */
    private static void build(ServerWorld world, Active a) {
        loadArea(world, a);
        int y0 = a.y0;
        BlockState air = Blocks.AIR.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                int x = a.cx + dx;
                int z = a.cz + dz;
                int top = Math.min(254, world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) + 1);
                for (int y = top; y >= y0; y--) {
                    m.set(x, y, z);
                    if (!world.getBlockState(m).isAir()) {
                        put(world, a, m, air);
                    }
                }
                put(world, a, m.set(x, y0 - 1, z), Blocks.GRASS_BLOCK.getDefaultState());
                for (int y = y0 - 2; y >= y0 - 14; y--) {
                    m.set(x, y, z);
                    BlockState st = world.getBlockState(m);
                    boolean soft = st.isAir() || !st.getFluidState().isEmpty() || st.getMaterial().isReplaceable();
                    if (y >= y0 - 4 || soft) {
                        put(world, a, m, Blocks.DIRT.getDefaultState());
                    } else {
                        break;
                    }
                }
            }
        }
        decorate(world, a);
    }

    private static void decorate(ServerWorld world, Active a) {
        int y0 = a.y0;
        int floor = y0 - 1 - DEPTH;   // дно ямы (бедрок)

        // край круглой зоны: фиолетовая шерсть
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d >= RADIUS - 1.0 && d <= RADIUS) {
                    put(world, a, dx, y0 - 1, dz, Blocks.PURPLE_WOOL);
                }
            }
        }
        // площадка вокруг ямы
        for (int dx = -9; dx <= 9; dx++) {
            for (int dz = -9; dz <= 9; dz++) {
                int ring = Math.max(Math.abs(dx), Math.abs(dz));
                if (ring >= 6) {
                    put(world, a, dx, y0 - 1, dz, ring >= 9 ? Blocks.CRYING_OBSIDIAN : Blocks.POLISHED_BLACKSTONE);
                }
            }
        }
        // стены ямы (кольцо 11x11) и бортик
        for (int dx = -PIT_HALF - 1; dx <= PIT_HALF + 1; dx++) {
            for (int dz = -PIT_HALF - 1; dz <= PIT_HALF + 1; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != PIT_HALF + 1) {
                    continue;
                }
                for (int y = floor; y <= y0 - 2; y++) {
                    put(world, a, dx, y, dz, Blocks.POLISHED_BLACKSTONE_BRICKS);
                }
                put(world, a, dx, y0 - 1, dz, Blocks.RED_NETHER_BRICKS);
            }
        }
        // внутри ямы: бедрок на дне, обсидиан с глубины GAP, пустота сверху
        for (int dx = -PIT_HALF; dx <= PIT_HALF; dx++) {
            for (int dz = -PIT_HALF; dz <= PIT_HALF; dz++) {
                put(world, a, dx, floor, dz, Blocks.BEDROCK);
                for (int y = floor + 1; y <= y0 - 1; y++) {
                    Block b;
                    if (y > y0 - 1 - GAP) {
                        b = Blocks.AIR;
                    } else {
                        b = RNG.nextInt(100) < 22 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN;
                    }
                    put(world, a, dx, y, dz, b);
                }
            }
        }
    }
}
