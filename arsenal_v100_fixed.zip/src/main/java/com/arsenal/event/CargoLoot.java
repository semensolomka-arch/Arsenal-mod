package com.arsenal.event;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Лут грузов: config/arsenal_cargo.json (создаётся сам из настроек по умолчанию). */
public final class CargoLoot {
    private static final Random RNG = new Random();
    private static JsonObject root;
    /** Числа из настроек (Mod Menu - Arsenal - Общие настройки), главнее чисел из arsenal_cargo.json. */
    private static final Map<String, Integer> SLOTS_MIN = new HashMap<>();
    private static final Map<String, Integer> SLOTS_MAX = new HashMap<>();
    private static final Map<String, Integer> STACKS_MIN = new HashMap<>();
    private static final Map<String, Integer> STACKS_MAX = new HashMap<>();

    private CargoLoot() {
    }

    public static void load() {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("arsenal_cargo.json");
            if (!Files.exists(file)) {
                try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json")) {
                    Files.copy(in, file);
                }
            }
            root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            // устаревший файл настроек заменяем новым (старый остаётся как .bak)
            int version = root.has("configVersion") ? root.get("configVersion").getAsInt() : 1;
            if (version < 4) {
                Files.copy(file, file.resolveSibling("arsenal_cargo.json.bak"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json")) {
                    Files.copy(in, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            }
            addMissingTables(file);
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_cargo.json: " + ex);
            root = null;
        }
    }

    /** Новый лут из настроек по умолчанию попадает и в старые файлы настроек, остальное в них не трогаем. */
    private static void addMissingTables(Path file) throws Exception {
        JsonObject loot = root.has("loot") ? root.getAsJsonObject("loot") : null;
        if (loot == null) {
            return;
        }
        String text;
        try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json");
             java.util.Scanner sc = new java.util.Scanner(in, "UTF-8")) {
            text = sc.useDelimiter("\\A").next();
        }
        JsonObject def = new JsonParser().parse(text).getAsJsonObject();
        if (!def.has("loot")) {
            return;
        }
        boolean changed = false;
        JsonObject defLoot = def.getAsJsonObject("loot");
        if (!loot.has("deadly") && defLoot.has("deadly")) {
            loot.add("deadly", defLoot.get("deadly"));
            root.addProperty("_help_deadly", "deadly - лут смертельного груза (без обычных и эпических талисманов и вещей из китов wither, kraken и dragon; есть кит infinity, больше шанс взрывоустойчивости, мифических сфер, Цербера и Флеша).");
            changed = true;
        }
        for (String extra : new String[]{"core", "xpevent", "mine", "ship_common", "ship_rare", "ship_secret", "ship_treasure"}) {
            if (!loot.has(extra) && defLoot.has(extra)) {
                loot.add(extra, defLoot.get(extra));
                changed = true;
            }
        }
        // новые предметы: добавляем в таблицы, где их ещё нет (остальные настройки не трогаем)
        String[][] additions = {
                {"kit:eternity:bow", "deadly"},
                {"kit:eternity:crossbow", "deadly"},
                {"kit:eternity:pickaxe", "deadly"},
                {"kit:eternity:shovel", "deadly"},
                {"kit:eternity:axe", "deadly"},
                {"kit:infinity:bow", "deadly"},
                {"kit:infinity:crossbow", "deadly"},
                {"kit:infinity:pickaxe", "deadly"},
                {"kit:infinity:shovel", "deadly"},
                {"kit:infinity:axe", "deadly"},
                {"arsenal:battle_fragment", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"arsenal:winner_potion", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"arsenal:dynamite_b2", "peace", "explosive", "deadly"},
                {"arsenal:ice_wave", "peace", "explosive", "deadly"},
                {"arsenal:jake_pickaxe", "peace", "explosive", "deadly"},
                {"minecraft:potion#minecraft:strong_healing", "peace", "explosive", "deadly"},
                {"kit:sun:helmet", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"kit:sun:boots", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"kit:sun:armor_elytra", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"kit:sun:unbreakable_elytra", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"arsenal:unbreakable_anvil", "peace", "explosive", "deadly", "goldrush", "goldrush_red"},
                {"arsenal:sphere_common", "xpevent"},
                {"arsenal:sphere_epic", "xpevent"},
                {"arsenal:sphere_legendary", "xpevent"},
                {"arsenal:sphere_mythic", "xpevent"},
                {"arsenal:talisman_common", "xpevent"},
                {"arsenal:talisman", "xpevent"},
                {"arsenal:talisman_legendary", "xpevent"}};
        // уже обработанные пары "таблица|предмет": удалённое вручную назад не возвращаем
        JsonArray applied = root.has("appliedAdditions") ? root.getAsJsonArray("appliedAdditions") : new JsonArray();
        java.util.Set<String> done = new java.util.HashSet<>();
        for (JsonElement el : applied) {
            done.add(el.getAsString());
        }
        for (String[] add : additions) {
            String itemId = add[0];
            for (int t = 1; t < add.length; t++) {
                String table = add[t];
                String mark = table + "|" + itemId;
                if (done.contains(mark) || !loot.has(table) || !defLoot.has(table)) {
                    continue;
                }
                com.google.gson.JsonArray mine = loot.getAsJsonObject(table).getAsJsonArray("entries");
                if (mine == null) {
                    continue;
                }
                if (!hasItem(mine, itemId)) {
                    for (com.google.gson.JsonElement el : defLoot.getAsJsonObject(table).getAsJsonArray("entries")) {
                        if (matches(el.getAsJsonObject(), itemId)) {
                            mine.add(el);
                            break;
                        }
                    }
                }
                applied.add(mark);
                done.add(mark);
                changed = true;
            }
        }
        root.add("appliedAdditions", applied);
        if (changed) {
            Files.write(file, new com.google.gson.GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()
                    .toJson(root).getBytes(StandardCharsets.UTF_8));
        }
    }

    private static boolean hasItem(com.google.gson.JsonArray entries, String id) {
        for (com.google.gson.JsonElement el : entries) {
            if (matches(el.getAsJsonObject(), id)) {
                return true;
            }
        }
        return false;
    }

    /** Запись лута подходит ключу: "предмет" или "предмет#зелье" (для зелий, у которых один и тот же предмет). */
    private static boolean matches(JsonObject o, String key) {
        if (key.startsWith("kit:")) {
            String[] k = key.split(":");
            return k.length == 3 && o.has("kit") && o.has("part")
                    && k[1].equals(o.get("kit").getAsString()) && k[2].equals(o.get("part").getAsString());
        }
        int hash = key.indexOf('#');
        String item = hash < 0 ? key : key.substring(0, hash);
        if (!o.has("item") || !item.equals(o.get("item").getAsString())) {
            return false;
        }
        return hash < 0 || (o.has("potion") && key.substring(hash + 1).equals(o.get("potion").getAsString()));
    }

    /** Сколько стопок кладётся в каждый шалкер груза этого вида (peace, explosive, deadly): от (max = false) или до (max = true). */
    public static void setSlots(String table, boolean max, int value) {
        (max ? SLOTS_MAX : SLOTS_MIN).put(table, Math.max(1, value));
    }

    /** Сколько стопок выпадает из контейнера этого вида: от (max = false) или до (max = true). */
    public static void setStacks(String table, boolean max, int value) {
        (max ? STACKS_MAX : STACKS_MIN).put(table, Math.max(1, value));
    }

    /** Радиус смертельного взрыва взрывного груза (блоков). */
    public static double blastRadius(double fallback) {
        if (root != null && root.has("explosiveBlastRadius")) {
            return root.get("explosiveBlastRadius").getAsDouble();
        }
        return fallback;
    }

    public static float blastPower(float fallback) {
        if (root != null && root.has("explosiveBlastPower")) {
            return root.get("explosiveBlastPower").getAsFloat();
        }
        return fallback;
    }

    /** Лут для шалкеров груза данного вида ("peace" или "explosive"). Каждый шалкер забивается полностью. */
    public static List<List<ItemStack>> roll(String table, int shulkers) {
        return rollInto(table, shulkers, 0);
    }

    /** Один случайный пункт таблицы (Смертельная шахта: награда за каждый сломанный блок). */
    public static List<ItemStack> rollOne(String table) {
        if (root == null) {
            load();
        }
        return rollInto(table, 1, 1).get(0);
    }

    /** Лут золотой лихорадки: один список стаков, их число берётся из "stacks" [мин, макс] таблицы. */
    public static List<ItemStack> rollFlat(String table) {
        if (root == null) {
            load();
        }
        int count = 12;
        if (root != null && root.has("loot") && root.getAsJsonObject("loot").has(table)) {
            JsonObject t = root.getAsJsonObject("loot").getAsJsonObject(table);
            if (t.has("stacks")) {
                JsonArray r = t.getAsJsonArray("stacks");
                int lo = r.get(0).getAsInt();
                int hi = r.get(1).getAsInt();
                count = lo + RNG.nextInt(Math.max(1, hi - lo + 1));
            }
        }
        // настройки из Mod Menu главнее файла
        if (STACKS_MIN.containsKey(table) || STACKS_MAX.containsKey(table)) {
            int lo = STACKS_MIN.containsKey(table) ? STACKS_MIN.get(table) : 1;
            int hi = STACKS_MAX.containsKey(table) ? STACKS_MAX.get(table) : lo;
            if (hi < lo) {
                int tmp = lo;
                lo = hi;
                hi = tmp;
            }
            count = lo + RNG.nextInt(Math.max(1, hi - lo + 1));
        }
        return rollInto(table, 1, count).get(0);
    }

    private static List<List<ItemStack>> rollInto(String table, int shulkers, int slotsOverride) {
        List<List<ItemStack>> result = new ArrayList<>();
        for (int i = 0; i < shulkers; i++) {
            result.add(new ArrayList<>());
        }
        if (root == null) {
            load();
        }
        if (root == null || !root.has("loot") || !root.getAsJsonObject("loot").has(table)) {
            return result;
        }
        JsonObject t = root.getAsJsonObject("loot").getAsJsonObject(table);
        JsonArray entries = t.getAsJsonArray("entries");
        int baseSlots = t.has("slotsPerShulker") ? t.get("slotsPerShulker").getAsInt() : 27;
        int slotsLo = slotsOverride > 0 ? slotsOverride : SLOTS_MIN.containsKey(table) ? SLOTS_MIN.get(table) : baseSlots;
        int slotsHi = slotsOverride > 0 ? slotsOverride : SLOTS_MAX.containsKey(table) ? SLOTS_MAX.get(table) : baseSlots;
        if (slotsHi < slotsLo) {
            int tmp = slotsLo;
            slotsLo = slotsHi;
            slotsHi = tmp;
        }
        JsonObject groupLimits = t.has("groupLimits") ? t.getAsJsonObject("groupLimits") : null;
        Map<Integer, Integer> used = new HashMap<>();
        Map<String, Integer> groupUsed = new HashMap<>();
        for (int s = 0; s < shulkers; s++) {
            List<ItemStack> list = result.get(s);
            // сколько стопок в этом шалкере: случайно от и до (настройки Mod Menu)
            int slots = slotsLo + RNG.nextInt(Math.max(1, slotsHi - slotsLo + 1));
            int guard = 0;
            while (list.size() < slots && guard++ < slots * 60) {
                int index = pick(entries);
                if (index < 0) {
                    break;
                }
                JsonObject e = entries.get(index).getAsJsonObject();
                int limit = e.has("limit") ? e.get("limit").getAsInt() : 0;
                int u = used.getOrDefault(index, 0);
                if (limit > 0 && u >= limit) {
                    continue;
                }
                String group = e.has("group") ? e.get("group").getAsString() : null;
                if (group != null && groupLimits != null && groupLimits.has(group)
                        && groupUsed.getOrDefault(group, 0) >= groupLimits.get(group).getAsInt()) {
                    continue;
                }
                List<ItemStack> made = make(e);
                if (made.isEmpty()) {
                    continue;
                }
                used.put(index, u + 1);
                if (group != null) {
                    groupUsed.put(group, groupUsed.getOrDefault(group, 0) + 1);
                }
                for (ItemStack stack : made) {
                    if (list.size() < slots) {
                        list.add(stack);
                    }
                }
            }
        }
        return result;
    }

    private static int pick(JsonArray entries) {
        int total = 0;
        for (JsonElement el : entries) {
            JsonObject e = el.getAsJsonObject();
            total += Math.max(0, e.has("weight") ? e.get("weight").getAsInt() : 10);
        }
        if (total <= 0) {
            return -1;
        }
        int r = RNG.nextInt(total);
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            r -= Math.max(0, e.has("weight") ? e.get("weight").getAsInt() : 10);
            if (r < 0) {
                return i;
            }
        }
        return -1;
    }

    /** Количество: чаще выпадает середина диапазона (а не 1), uniform:true даёт равномерный разброс. */
    private static int rollCount(JsonObject e) {
        int min = e.has("min") ? e.get("min").getAsInt() : 1;
        int max = e.has("max") ? e.get("max").getAsInt() : min;
        if (max <= min) {
            return min;
        }
        if (e.has("uniform") && e.get("uniform").getAsBoolean()) {
            return min + RNG.nextInt(max - min + 1);
        }
        double u = (RNG.nextDouble() + RNG.nextDouble()) / 2.0;
        return min + (int) Math.round(u * (max - min));
    }

    /** Один выпавший пункт: обычно один стак, но не стакающиеся предметы (зелья) выпадают отдельными штуками. */
    private static List<ItemStack> make(JsonObject e) {
        List<ItemStack> out = new ArrayList<>();
        if (e.has("kit")) {
            ItemStack gear = com.arsenal.kit.KitCommand.lootGear(e.get("kit").getAsString(), e.get("part").getAsString());
            if (gear != null && !gear.isEmpty()) {
                out.add(gear);
            }
            return out;
        }
        com.arsenal.vi.ItemRef ref = com.arsenal.vi.ItemRef.of(e.get("item").getAsString());
        if (ref == null) {
            return out;
        }
        if (e.has("enchantment")) {
            Enchantment ench = Registry.ENCHANTMENT.getOrEmpty(new Identifier(e.get("enchantment").getAsString())).orElse(null);
            if (ench == null) {
                return out;
            }
            JsonArray levels = e.getAsJsonArray("levels");
            int level = levels.get(RNG.nextInt(levels.size())).getAsInt();
            out.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ench, level)));
            return out;
        }
        // сферы и талисманы: явные эффекты ("effects": "damage2 armor1") или случайные по редкости
        // (обычная, эпическая, легендарная, мифическая - как получаются в наковальне)
        if (com.arsenal.sphere.Spheres.tier(ref.vi) > 0) {
            if (e.has("effects")) {
                try {
                    out.add(com.arsenal.sphere.Spheres.stack(ref.vi, com.arsenal.sphere.Spheres.parse(e.get("effects").getAsString())));
                } catch (IllegalArgumentException ex) {
                    System.err.println("[Arsenal] лут: " + ex.getMessage());
                }
                return out;
            }
            out.add(com.arsenal.sphere.Spheres.randomFor(ref.vi, RNG));
            return out;
        }
        int count = rollCount(e);
        if (ref.maxCount() <= 1) {
            for (int i = 0; i < Math.max(1, count); i++) {
                out.add(build(e, ref, 1));
            }
        } else {
            out.add(build(e, ref, count));
        }
        return out;
    }

    /** Уровень эффекта по редкости обычной сферы/талисмана: 1 обычная, 2 эпическая, 3 легендарная; 0 для остальных предметов. */
    private static int effectTier(com.arsenal.vi.VI item) {
        if (item == com.arsenal.Arsenal.SPHERE_COMMON || item == com.arsenal.Arsenal.TALISMAN_COMMON) {
            return 1;
        }
        if (item == com.arsenal.Arsenal.SPHERE_EPIC || item == com.arsenal.Arsenal.TALISMAN) {
            return 2;
        }
        if (item == com.arsenal.Arsenal.SPHERE_LEGENDARY || item == com.arsenal.Arsenal.TALISMAN_LEGENDARY) {
            return 3;
        }
        return 0;
    }

    private static ItemStack build(JsonObject e, com.arsenal.vi.ItemRef ref, int count) {
        if (!e.has("enchants") && !e.has("potion")) {
            ItemStack preset = com.arsenal.Arsenal.preset(ref.vi);
            if (preset != null) {
                return preset;   // меч Цербера и меч INFINITY со своими зачарованиями
            }
        }
        ItemStack stack = ref.stack(Math.max(1, Math.min(count, ref.maxCount())));
        if (e.has("enchants")) {
            for (JsonElement el : e.getAsJsonArray("enchants")) {
                JsonArray pair = el.getAsJsonArray();
                Enchantment ench = Registry.ENCHANTMENT.getOrEmpty(new Identifier(pair.get(0).getAsString())).orElse(null);
                if (ench == null) {
                    continue;
                }
                int lo = pair.get(1).getAsInt();
                int hi = pair.size() > 2 ? pair.get(2).getAsInt() : lo;
                double chance = pair.size() > 3 ? pair.get(3).getAsDouble() : 1.0;
                if (chance < 1.0 && RNG.nextDouble() >= chance) {
                    continue;
                }
                int level = lo + RNG.nextInt(Math.max(1, hi - lo + 1));
                if (level > 0) {
                    stack.addEnchantment(ench, level);
                }
            }
        }
        if (e.has("potion")) {
            Potion potion = Registry.POTION.getOrEmpty(new Identifier(e.get("potion").getAsString())).orElse(null);
            if (potion != null) {
                PotionUtil.setPotion(stack, potion);
            }
        }
        return stack;
    }

    /** Раскладывает предметы по слотам шалкера в случайном порядке. */
    public static void fill(net.minecraft.inventory.Inventory inv, List<ItemStack> stacks) {
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inv.size(); i++) {
            slots.add(i);
        }
        Collections.shuffle(slots, RNG);
        for (int i = 0; i < stacks.size() && i < slots.size(); i++) {
            inv.setStack(slots.get(i), stacks.get(i));
        }
    }
}
