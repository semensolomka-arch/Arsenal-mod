package com.arsenal;

import com.arsenal.buyer.Buyer;
import com.arsenal.event.CargoLoot;
import com.arsenal.spawn.MineConfig;
import com.arsenal.vi.ItemRef;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VI;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Связь с клиентским модом Arsenal Menu-Op (только оператор): отдаёт и принимает конфиги лута, скупщика и автошахт
 * целиком (gzip, загрузка кусками из-за лимита пакета клиента) и присылает список предметов мода с названиями.
 */
public final class MenuBridge {
    public static final Identifier FILE_REQ = new Identifier(Arsenal.MODID, "file_req");
    public static final Identifier FILE_PUT = new Identifier(Arsenal.MODID, "file_put");
    public static final Identifier FILE_DATA = new Identifier(Arsenal.MODID, "file_data");
    public static final Identifier CAT_REQ = new Identifier(Arsenal.MODID, "catalog_req");
    public static final Identifier CAT_DATA = new Identifier(Arsenal.MODID, "catalog_data");

    public static final Identifier OPEN = new Identifier(Arsenal.MODID, "open_menu");

    /** /amenu: просит клиентский мод оператора открыть меню (для тех, у кого нет клавиши U, например на телефоне). */
    public static int openFor(ServerPlayerEntity player) {
        if (!ServerPlayNetworking.canSend(player, OPEN)) {
            player.sendMessage(new LiteralText("[Arsenal] У тебя не установлен мод Arsenal Menu-Op").formatted(Formatting.RED), false);
            return 0;
        }
        ServerPlayNetworking.send(player, OPEN, PacketByteBufs.create());
        return 1;
    }

    private static final Map<String, List<byte[]>> UPLOADS = new HashMap<>();

    private MenuBridge() {
    }

    private static Path path(String name) {
        switch (name) {
            case "cargo":
                return FabricLoader.getInstance().getConfigDir().resolve("arsenal_cargo.json");
            case "buyer":
                return Buyer.configPath();
            case "mines":
                return MineConfig.file();
            default:
                return null;
        }
    }

    private static void ensure(String name) {
        if ("cargo".equals(name)) {
            if (!Files.exists(path(name))) {
                CargoLoot.load();
            }
        } else if ("buyer".equals(name)) {
            Buyer.reloadIfChanged();
        } else if ("mines".equals(name)) {
            MineConfig.reloadIfChanged();
        }
    }

    private static void reload(String name) {
        if ("cargo".equals(name)) {
            CargoLoot.load();
        } else if ("buyer".equals(name)) {
            Buyer.reloadIfChanged();
        } else if ("mines".equals(name)) {
            MineConfig.reloadIfChanged();
        }
    }

    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(FILE_REQ, (server, player, handler, buf, sender) -> {
            final String name = buf.readString(32);
            server.execute(() -> {
                if (player.hasPermissionLevel(2)) {
                    sendFile(player, name);
                }
            });
        });
        ServerPlayNetworking.registerGlobalReceiver(FILE_PUT, (server, player, handler, buf, sender) -> {
            final String name = buf.readString(32);
            final int idx = buf.readVarInt();
            final int total = buf.readVarInt();
            final byte[] chunk = buf.readByteArray();
            server.execute(() -> {
                if (player.hasPermissionLevel(2)) {
                    receive(player, name, idx, total, chunk);
                }
            });
        });
        ServerPlayNetworking.registerGlobalReceiver(CAT_REQ, (server, player, handler, buf, sender) ->
                server.execute(() -> {
                    if (player.hasPermissionLevel(2)) {
                        sendCatalog(player);
                    }
                }));
    }

    private static void sendFile(ServerPlayerEntity player, String name) {
        Path p = path(name);
        if (p == null) {
            return;
        }
        try {
            ensure(name);
            byte[] raw = Files.readAllBytes(p);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (GZIPOutputStream gz = new GZIPOutputStream(bo)) {
                gz.write(raw);
            }
            PacketByteBuf out = PacketByteBufs.create();
            out.writeString(name);
            out.writeByteArray(bo.toByteArray());
            ServerPlayNetworking.send(player, FILE_DATA, out);
        } catch (Exception ex) {
            player.sendMessage(new LiteralText("[Arsenal] Не удалось отдать файл " + name + ": " + ex).formatted(Formatting.RED), false);
        }
    }

    private static void receive(ServerPlayerEntity player, String name, int idx, int total, byte[] chunk) {
        Path p = path(name);
        if (p == null || total < 1 || total > 200) {
            return;
        }
        String key = player.getUuidAsString() + "/" + name;
        List<byte[]> parts = UPLOADS.computeIfAbsent(key, k -> new ArrayList<>());
        if (idx == 0) {
            parts.clear();
        }
        parts.add(chunk);
        if (idx != total - 1) {
            return;
        }
        UPLOADS.remove(key);
        try {
            ByteArrayOutputStream all = new ByteArrayOutputStream();
            for (byte[] b : parts) {
                all.write(b);
            }
            byte[] json;
            try (InputStream in = new GZIPInputStream(new ByteArrayInputStream(all.toByteArray()));
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] tmp = new byte[8192];
                int n;
                while ((n = in.read(tmp)) > 0) {
                    out.write(tmp, 0, n);
                    if (out.size() > 8_000_000) {
                        throw new IllegalStateException("слишком большой файл");
                    }
                }
                json = out.toByteArray();
            }
            // проверка: это должен быть JSON-объект
            new JsonParser().parse(new String(json, StandardCharsets.UTF_8)).getAsJsonObject();
            if (Files.exists(p)) {
                Files.copy(p, p.resolveSibling(p.getFileName().toString() + ".menu.bak"), StandardCopyOption.REPLACE_EXISTING);
            }
            Path tmpFile = p.resolveSibling(p.getFileName().toString() + ".tmp");
            Files.write(tmpFile, json);
            Files.move(tmpFile, p, StandardCopyOption.REPLACE_EXISTING);
            reload(name);
            player.sendMessage(new LiteralText("[Arsenal] Сохранено: " + name).formatted(Formatting.GREEN), true);
        } catch (Exception ex) {
            player.sendMessage(new LiteralText("[Arsenal] Не сохранилось (" + name + "): " + ex).formatted(Formatting.RED), false);
        }
    }

    // ------------------------------------------------------------------ каталог предметов мода

    private static String str(JsonObject o, String k) {
        return o.has(k) ? o.get(k).getAsString() : null;
    }

    /** Одинаковый "ключ" записи лута на сервере и в клиентском моде. */
    static String identity(JsonObject o) {
        if (o.has("kit")) {
            return "kit:" + str(o, "kit") + ":" + str(o, "part");
        }
        StringBuilder sb = new StringBuilder(str(o, "item"));
        if (o.has("potion")) {
            sb.append('#').append(str(o, "potion"));
        }
        if (o.has("enchantment")) {
            sb.append("|ench:").append(str(o, "enchantment"));
        }
        if (o.has("effects")) {
            sb.append("|fx:").append(str(o, "effects").trim());
        }
        return sb.toString();
    }

    private static void sendCatalog(ServerPlayerEntity player) {
        List<String[]> list = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        try (InputStream in = MenuBridge.class.getResourceAsStream("/arsenal_cargo_default.json");
             java.util.Scanner sc = new java.util.Scanner(in, "UTF-8")) {
            JsonObject def = new JsonParser().parse(sc.useDelimiter("\\A").next()).getAsJsonObject();
            for (java.util.Map.Entry<String, JsonElement> t : def.getAsJsonObject("loot").entrySet()) {
                for (JsonElement el : t.getValue().getAsJsonObject().getAsJsonArray("entries")) {
                    JsonObject e = el.getAsJsonObject();
                    boolean mine = e.has("kit")
                            || (e.has("item") && str(e, "item").startsWith("arsenal:"))
                            || (e.has("enchantment") && str(e, "enchantment").startsWith("arsenal:"));
                    if (e.has("item")) {
                        ItemRef r0 = ItemRef.of(str(e, "item"));
                        if (r0 != null && com.arsenal.sphere.Spheres.tier(r0.vi) > 0) {
                            continue;   // сферы и талисманы добавляются ниже (случайные и с точными эффектами)
                        }
                    }
                    if (!mine || !seen.add(identity(e))) {
                        continue;
                    }
                    String name = nameOf(e);
                    if (name == null) {
                        continue;
                    }
                    JsonObject tpl = new JsonObject();
                    for (String k : new String[]{"item", "potion", "enchantment", "levels", "kit", "part", "effectLevel",
                            "mythic", "limit", "group"}) {
                        if (e.has(k)) {
                            tpl.add(k, e.get(k));
                        }
                    }
                    tpl.addProperty("min", e.has("min") ? e.get("min").getAsInt() : 1);
                    tpl.addProperty("max", e.has("max") ? e.get("max").getAsInt() : 1);
                    tpl.addProperty("weight", 10);
                    String buyer = "";
                    if (e.has("kit")) {
                        buyer = identity(e);
                    } else if (!e.has("enchantment") && !e.has("potion")) {
                        buyer = str(e, "item");
                    }
                    list.add(new String[]{name, tpl.toString(), buyer});
                }
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] каталог меню: " + ex);
        }
        addEffectItems(list);
        for (VI vi : VI.all()) {
            String id = "arsenal:" + vi.id;
            if (seen.contains(id) || com.arsenal.sphere.Spheres.tier(vi) > 0) {
                continue;
            }
            try {
                JsonObject tpl = new JsonObject();
                tpl.addProperty("item", id);
                tpl.addProperty("min", 1);
                tpl.addProperty("max", 1);
                tpl.addProperty("weight", 10);
                list.add(new String[]{vi.stack().getName().getString(), tpl.toString(), id});
            } catch (Throwable ignored) {
                // предмет без имени пропускаем
            }
        }
        PacketByteBuf out = PacketByteBufs.create();
        out.writeVarInt(list.size());
        for (String[] r : list) {
            out.writeString(r[0], 512);
            out.writeString(r[1], 4096);
            out.writeString(r[2], 256);
        }
        ServerPlayNetworking.send(player, CAT_DATA, out);
    }

    /** Сферы и талисманы: случайный эффект по редкости и все точные наборы эффектов. */
    private static void addEffectItems(List<String[]> list) {
        VI[] kinds = {Arsenal.SPHERE_COMMON, Arsenal.SPHERE_EPIC, Arsenal.SPHERE_LEGENDARY, Arsenal.SPHERE_MYTHIC,
                Arsenal.TALISMAN_COMMON, Arsenal.TALISMAN, Arsenal.TALISMAN_LEGENDARY};
        for (VI vi : kinds) {
            String base;
            try {
                base = vi.stack().getName().getString();
            } catch (Throwable t) {
                continue;
            }
            String id = "arsenal:" + vi.id;
            int tier = com.arsenal.sphere.Spheres.tier(vi);
            if (tier == 0) {
                tier = vi == Arsenal.TALISMAN_COMMON ? 1 : vi == Arsenal.TALISMAN ? 2 : 3;
            }
            list.add(new String[]{base + (vi == Arsenal.SPHERE_MYTHIC ? " (случайный из трёх)" : " (случайный эффект)"),
                    template(id, null), ""});
            List<int[]> variants = new ArrayList<>();
            if (vi == Arsenal.SPHERE_MYTHIC) {
                for (int[] m : com.arsenal.sphere.Spheres.MYTHIC) {
                    variants.add(m);
                }
            } else if (tier == 1 || tier == 2) {
                variants.addAll(com.arsenal.sphere.Spheres.combos(tier));
            } else {
                variants.addAll(com.arsenal.sphere.Spheres.combos(3));
                variants.addAll(com.arsenal.sphere.Spheres.combos(4));
            }
            for (int[] lv : variants) {
                list.add(new String[]{base + ": " + com.arsenal.sphere.Spheres.describe(lv),
                        template(id, com.arsenal.sphere.Spheres.encode(lv)), ""});
            }
        }
    }

    private static String template(String itemId, String effects) {
        JsonObject tpl = new JsonObject();
        tpl.addProperty("item", itemId);
        if (effects != null) {
            tpl.addProperty("effects", effects);
        }
        tpl.addProperty("min", 1);
        tpl.addProperty("max", 1);
        tpl.addProperty("weight", 10);
        return tpl.toString();
    }

    /** Читаемое название записи лута (для предметов мода). */
    private static String nameOf(JsonObject e) {
        try {
            if (e.has("kit")) {
                net.minecraft.item.ItemStack gear = com.arsenal.kit.KitCommand.lootGear(str(e, "kit"), str(e, "part"));
                if (gear == null || gear.isEmpty()) {
                    return null;
                }
                return gear.getName().getString();
            }
            if (e.has("enchantment")) {
                String id = str(e, "enchantment");
                return "Книга: " + Lang.get("enchantment." + id.replace(':', '.'));
            }
            ItemRef ref = ItemRef.of(str(e, "item"));
            if (ref == null) {
                return null;
            }
            String base = ref.vi != null ? ref.vi.stack().getName().getString() : ref.stack(1).getName().getString();
            return base;
        } catch (Throwable t) {
            return null;
        }
    }
}
