package com.arsenal.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

/**
 * Снаряд для "Кома снега". Тип сущности ванильный (снежок), поэтому клиенту
 * не нужен отдельный рендерер, вся логика только на сервере.
 * Урона нет вообще: ванильный удар снежка (damage 0 / 3 у блейзов) не вызываем.
 */
public class SnowClumpEntity extends SnowballEntity {
    /** Настраиваются в Settings: длительность в тиках и уровень эффекта минус 1. */
    public static int SLOW_TICKS = 20 * 10;
    public static int SLOW_AMP = 5;
    public static int BLIND_TICKS = 20;
    public static int BLIND_AMP = 2;

    public SnowClumpEntity(World world, LivingEntity owner) {
        super(world, owner);
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        // super.onEntityHit(hit) специально НЕ вызываем: он наносит урон
        if (hit.getEntity() instanceof LivingEntity) {
            LivingEntity target = (LivingEntity) hit.getEntity();
            if (target instanceof net.minecraft.server.network.ServerPlayerEntity
                    && getOwner() instanceof net.minecraft.server.network.ServerPlayerEntity) {
                net.minecraft.server.network.ServerPlayerEntity owner = (net.minecraft.server.network.ServerPlayerEntity) getOwner();
                net.minecraft.server.network.ServerPlayerEntity victim = (net.minecraft.server.network.ServerPlayerEntity) target;
                if (com.arsenal.protection.SpawnProtection.noPvp(owner) || com.arsenal.protection.SpawnProtection.noPvp(victim)) {
                    com.arsenal.protection.SpawnProtection.denyPvp(owner);
                    return;
                }
                com.arsenal.combat.Combat.tag(owner, victim);
            }
            // уровень эффекта = amplifier + 1
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, SLOW_TICKS, SLOW_AMP));  // по умолчанию замедление 6, 10 сек
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, BLIND_TICKS, BLIND_AMP));  // по умолчанию слепота 3, 1 сек
        }
    }
}
