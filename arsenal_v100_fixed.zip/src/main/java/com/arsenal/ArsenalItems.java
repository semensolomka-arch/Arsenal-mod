package com.arsenal;

import com.arsenal.artifact.ArtifactEffect;
import com.arsenal.blast.Blasts;
import com.arsenal.blast.JakePickaxeItem;
import com.arsenal.exp.ExpBottles;
import com.arsenal.item.ExpBubbleItem;
import com.arsenal.rune.RuneType;
import com.arsenal.rune.Runes;
import com.arsenal.special.Specials;
import com.arsenal.sphere.SphereSkins;
import com.arsenal.sphere.Spheres;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VData;
import com.arsenal.vi.VI;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.PotionUtil;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Регистрация предметов мода. Все предметы ванильные (текстуры и модели игры), мод только ставит на них
 * метку, название и описание. Клиентам ничего устанавливать не нужно.
 */
public final class ArsenalItems {
    private ArsenalItems() {
    }

    // ---------- вспомогательное ----------

    private static Text name(String id, int rgb) {
        return new LiteralText(Lang.get("item.arsenal." + id)).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb)));
    }

    private static Text name(String id, Formatting... f) {
        return new LiteralText(Lang.get("item.arsenal." + id)).formatted(f);
    }

    private static Text plain(String id) {
        return new LiteralText(Lang.get("item.arsenal." + id));
    }

    private static VI.Action run(java.util.function.BiConsumer<net.minecraft.server.network.ServerPlayerEntity, ItemStack> f) {
        return (p, s) -> {
            f.accept(p, s);
            return true;
        };
    }

    private static List<Text> list(Text... t) {
        return new ArrayList<>(Arrays.asList(t));
    }

    /** Предмет-основа, у которого нет своих атрибутов: убираем урон меча и износ у предметов-эффектов. */
    private static void harmless(ItemStack s) {
        s.addAttributeModifier(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                new EntityAttributeModifier("arsenal_none", 0.0, EntityAttributeModifier.Operation.ADDITION),
                EquipmentSlot.MAINHAND);
        s.getOrCreateTag().putBoolean("Unbreakable", true);
        s.getOrCreateTag().putInt("HideFlags", s.getOrCreateTag().getInt("HideFlags") | 2 | 4);
    }

    private static void potion(ItemStack s, int rgb, List<StatusEffectInstance> effects) {
        PotionUtil.setCustomPotionEffects(s, effects);
        s.getOrCreateTag().putInt("CustomPotionColor", rgb);
    }

    // ---------- регистрация ----------

    public static void register() {
        // Трапка и взрывная трапка (общий кулдаун), без блеска
        Arsenal.TRAP = VI.register("trap", Items.POPPED_CHORUS_FRUIT)
                .name(s -> name("trap", 0xFF55FF))
                .lore(s -> Lore.lines("tooltip.arsenal.trap.", 5, 0xFF55FF))
                .action(run(Abilities::useTrap)).cdGroup("trap").visualCd(true);
        Arsenal.STUN = VI.register("stun", Items.NETHER_STAR)
                .name(s -> name("stun", 0xFFFFFF))
                .lore(s -> Lore.lines("tooltip.arsenal.stun.", 6, 0xFFFFFF))
                .action(run(Abilities::useStun)).glint(true).visualCd(true);
        Arsenal.SNOW_BALL = VI.register("snow_ball", Items.SNOWBALL)
                .name(s -> Lore.gradientName("item.arsenal.snow_ball", 0x0DBFDE, 0x0ADAFF, false))
                .lore(s -> Lore.lines("tooltip.arsenal.snow_ball.", 4, 0x00FFFF))
                .action(run(Abilities::useSnow)).glint(true);
        Arsenal.EXP_BUBBLE = VI.register("exp_bubble", Items.EXPERIENCE_BOTTLE)
                .name(s -> name("exp_bubble", Formatting.YELLOW))
                .action(ExpBubbleItem::use);

        // Предметы из шалкеров
        Arsenal.EXPLOSIVE_TRAP = VI.register("explosive_trap", Items.PRISMARINE_SHARD)
                .name(s -> Lore.gradientName("item.arsenal.explosive_trap", 0x5F769F, 0x7E9ED2, true))
                .lore(s -> Lore.lines("tooltip.arsenal.explosive_trap.", 6, 0x5F769F))
                .action(Specials::useExplosiveTrap).cdGroup("trap").visualCd(true);
        Arsenal.BLAST_CHARM = VI.register("blast_charm", Items.FIRE_CHARGE)
                .name(s -> Lore.gradientName("item.arsenal.blast_charm", 0xFF7707, 0xFF5905, true))
                .lore(s -> Lore.lines("tooltip.arsenal.blast_charm.", 6, 0xFF5705))
                .action(Specials::useBlastCharm).glint(true);
        Arsenal.JAKE_LANTERN = VI.register("jake_lantern", Items.CARVED_PUMPKIN)
                .name(s -> Lore.gradientName("item.arsenal.jake_lantern", 0xD4BA08, 0xFCDD0A, true))
                .lore(s -> Lore.lines("tooltip.arsenal.jake_lantern.", 7, 0xFFD700))
                .action(Specials::useJakeLantern).glint(true);
        Arsenal.JAKE_PICKAXE = VI.register("jake_pickaxe", Items.GOLDEN_PICKAXE)
                .name(s -> name("jake_pickaxe", JakePickaxeItem.COLOR))
                .lore(s -> JakePickaxeItem.lore())
                .glint(true).vanillaUse(true);

        // Боевой фрагмент: валюта для /create
        Arsenal.BF = VI.register("battle_fragment", Items.PRISMARINE_CRYSTALS)
                .glint(true)
                .name(s -> new LiteralText("Боевой фрагмент").formatted(Formatting.AQUA))
                .lore(s -> list(new LiteralText("Нужен для улучшения вещей: /create").formatted(Formatting.GRAY),
                        new LiteralText("Выпадает с ивентов, получается переплавкой брони из китов").formatted(Formatting.DARK_GRAY)));

        // Осколок сферы: даётся за переплавку сфер в печке, обменивается на сферы в /spheres
        Arsenal.SPHERE_SHARD = VI.register("orb_shard", Items.PLAYER_HEAD)
                .name(s -> new LiteralText("Осколок сферы").formatted(Formatting.LIGHT_PURPLE))
                .lore(s -> list(new LiteralText("Особенности:").formatted(Formatting.DARK_GRAY),
                        new LiteralText("- обменивайте осколки на сферы в ").formatted(Formatting.WHITE)
                                .append(new LiteralText("/spheres").formatted(Formatting.LIGHT_PURPLE))
                                .append(new LiteralText(";").formatted(Formatting.WHITE)),
                        new LiteralText("- получена после переплавки сферы в печке.").formatted(Formatting.WHITE)))
                .init(s -> com.arsenal.sphere.SphereSkins.apply(s, "orb_shard"));

        // Кирки: Мечта шахтёра (Прочность X), нерушимая и Дырявая (мега-бур 5x5x1)
        VI.register("miner_dream", Items.NETHERITE_PICKAXE).vanillaUse(true)
                .name(s -> new LiteralText("Мечта шахтёра").formatted(Formatting.GOLD))
                .init(s -> s.addEnchantment(net.minecraft.enchantment.Enchantments.UNBREAKING, 10));
        VI.register("miner_dream_unbreakable", Items.NETHERITE_PICKAXE).vanillaUse(true)
                .name(s -> new LiteralText("Мечта шахтёра").formatted(Formatting.GOLD))
                .init(s -> s.getOrCreateTag().putBoolean("Unbreakable", true));
        VI.register("holey_pickaxe", Items.NETHERITE_PICKAXE).vanillaUse(true)
                .name(s -> new LiteralText("ДыРяВаЯ кИрКа").formatted(Formatting.LIGHT_PURPLE))
                .init(s -> s.addEnchantment(com.arsenal.tool.ToolEnchants.MEGA_DRILL, 1));

        // Бутыльки опыта
        int[] expLevels = {15, 30, 50};
        int[] expColors = {0x55FF55, 0xFFFF55, 0xFF6A38};
        VI[] exp = new VI[3];
        for (int i = 0; i < 3; i++) {
            final int levels = expLevels[i];
            final int color = expColors[i];
            final String id = "exp_bottle_" + levels;
            exp[i] = VI.register(id, Items.EXPERIENCE_BOTTLE)
                    .name(s -> name(id, color))
                    .lore(s -> list(new LiteralText(Lang.format("tooltip.arsenal.exp_bottle", levels, ExpBottles.points(levels)))
                            .formatted(Formatting.GRAY)))
                    .action((p, s) -> ExpBottles.use(p, s, levels));
        }
        Arsenal.EXP_BOTTLE_15 = exp[0];
        Arsenal.EXP_BOTTLE_30 = exp[1];
        Arsenal.EXP_BOTTLE_50 = exp[2];

        // Артефакт и предметы Хранителя опыта
        final int artColor = 0xA8D0E4;
        Arsenal.ARTIFACT = VI.register("artifact", Items.CONDUIT)
                .unique(false)
                .name(s -> name("artifact", artColor))
                .lore(s -> {
                    List<Text> out = Lore.lines("tooltip.arsenal.artifact.", 3, artColor);
                    boolean any = false;
                    for (ArtifactEffect e : ArtifactEffect.values()) {
                        if (VData.get(s, e.key()) > 0) {
                            if (!any) {
                                any = true;
                                out.add(new LiteralText(Lang.get("item.arsenal.artifact.effects")).formatted(Formatting.DARK_GRAY));
                            }
                            out.add(new LiteralText(Lang.get("enchantment.arsenal.artifact_" + e.id))
                                    .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(artColor))));
                        }
                    }
                    return out;
                });
        for (ArtifactEffect effect : ArtifactEffect.values()) {
            Item base = keeperBase(effect);
            final String id = "keeper_" + effect.id;
            VI vi = VI.register(id, base)
                    .unique(effect == ArtifactEffect.HUNTER)   // всё, кроме Охотника, стакается
                    .glint(effect.glint)
                    .name(s -> name(id, effect.nameColor))
                    .lore(s -> Lore.lines("tooltip.arsenal.keeper_" + effect.id + ".", 6, effect.lineColor));
            if (base == Items.POTION) {
                vi.init(s -> {
                    s.getOrCreateTag().putInt("CustomPotionColor", 0xFFA500);
                    s.getOrCreateTag().putInt("HideFlags", s.getOrCreateTag().getInt("HideFlags") | 32);
                });
            }
            effect.vi = vi;
        }

        // Руны (красители, на которые нельзя красить)
        for (RuneType rune : RuneType.values()) {
            Item dye = Registry.ITEM.get(new Identifier("minecraft", rune.dye));
            final String id = "rune_" + rune.id;
            rune.vi = VI.register(id, dye)
                    .unique(true).glint(true)
                    .name(s -> name(id, rune.color))
                    .lore(s -> list(new LiteralText(Lang.get("item.arsenal.rune_" + rune.id + ".desc")).formatted(Formatting.GRAY),
                            new LiteralText(Lang.get("item.arsenal.rune.footer")).formatted(Formatting.DARK_GRAY)));
        }

        // Зелья (ванильные зелья с эффектами в NBT, пьются как обычные)
        Arsenal.SPEED_III_6M = VI.register("speed_3_6m", Items.POTION).vanillaUse(true)
                .name(s -> plain("speed_3_6m"))
                .init(s -> potion(s, 0x7CAFC6, list2(new StatusEffectInstance(StatusEffects.SPEED, 7200, 2, false, true, true))));
        Arsenal.SPEED_III_3M = VI.register("speed_3_3m", Items.POTION).vanillaUse(true)
                .name(s -> plain("speed_3_3m"))
                .init(s -> potion(s, 0x7CAFC6, list2(new StatusEffectInstance(StatusEffects.SPEED, 3600, 2, false, true, true))));
        Arsenal.STRENGTH_III_6M = VI.register("strength_3_6m", Items.POTION).vanillaUse(true)
                .name(s -> plain("strength_3_6m"))
                .init(s -> potion(s, 0x932423, list2(new StatusEffectInstance(StatusEffects.STRENGTH, 7200, 2, false, true, true))));
        Arsenal.STRENGTH_III_3M = VI.register("strength_3_3m", Items.POTION).vanillaUse(true)
                .name(s -> plain("strength_3_3m"))
                .init(s -> potion(s, 0x932423, list2(new StatusEffectInstance(StatusEffects.STRENGTH, 3600, 2, false, true, true))));
        Arsenal.WINNER_POTION = VI.register("winner_potion", Items.POTION).vanillaUse(true).blockWhileCooling(true)
                .name(s -> name("winner_potion", Formatting.AQUA))
                .lore(s -> {
                    List<Text> out = list(new LiteralText(""),
                            new LiteralText("Эффекты:").formatted(Formatting.GRAY));
                    String[] lines = {"Сила III (8:00)", "Скорость III (8:00)", "Невидимость (8:00)", "Спешка II (1:30)",
                            "Регенерация II (0:30)", "Сопротивление II (0:30)", "Исцеление II"};
                    for (String line : lines) {
                        out.add(new LiteralText("- " + line).formatted(Formatting.AQUA));
                    }
                    return out;
                })
                .init(s -> {
                    List<StatusEffectInstance> eff = new ArrayList<>();
                    eff.add(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 60 * 8, 2, false, true, true));
                    eff.add(new StatusEffectInstance(StatusEffects.SPEED, 20 * 60 * 8, 2, false, true, true));
                    eff.add(new StatusEffectInstance(StatusEffects.INVISIBILITY, 20 * 60 * 8, 0, false, true, true));
                    eff.add(new StatusEffectInstance(StatusEffects.HASTE, 20 * 90, 1, false, true, true));
                    eff.add(new StatusEffectInstance(StatusEffects.REGENERATION, 20 * 30, 1, false, true, true));
                    eff.add(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 30, 1, false, true, true));
                    eff.add(new StatusEffectInstance(StatusEffects.INSTANT_HEALTH, 1, 1, false, true, true));
                    potion(s, 0x3FB8F0, eff);
                    s.getOrCreateTag().putInt("HideFlags", s.getOrCreateTag().getInt("HideFlags") | 32);
                });

        // Отмычки таинственного корабля
        String[] lockpickIds = {"lockpick_common", "lockpick_rare", "lockpick_secret"};
        Formatting[] lockColors = {Formatting.GRAY, Formatting.DARK_PURPLE, Formatting.BLUE};
        for (int r = 0; r < 3; r++) {
            final int rr = r;
            final String id = lockpickIds[r];
            Arsenal.LOCKPICKS[r] = VI.register(id, Items.TRIPWIRE_HOOK).glint(true)
                    .name(s -> name(id, lockColors[rr], Formatting.BOLD))
                    .lore(s -> list(new LiteralText("Используйте, чтобы открыть бочку на таинственном корабле")
                            .formatted(lockColors[rr])));
        }

        // Мечи
        Arsenal.INFINITY_SWORD = sword("infinity_sword", NameDecor.LIME);
        Arsenal.CERBERUS_SWORD = sword("cerberus_sword", NameDecor.DARK_RED);
        Arsenal.ETERNITY_SWORD = sword("eternity_sword", NameDecor.DARK_PINK);
        Arsenal.STINGER_SWORD = sword("stinger_sword", NameDecor.LIGHT_RED);

        // Сферы (головы игроков) и талисманы (тотемы)
        Arsenal.SPHERE_COMMON = effect("sphere_common", true, Formatting.GRAY, null, null, null);
        Arsenal.SPHERE_EPIC = effect("sphere_epic", true, Formatting.DARK_PURPLE, null, null, null);
        Arsenal.SPHERE_LEGENDARY = effect("sphere_legendary", true, Formatting.BLUE, null, null, null);
        Arsenal.SPHERE_MYTHIC = effect("sphere_mythic", true, Formatting.RED, null, null, null);
        Arsenal.SPHERE_FLASH = effect("sphere_flash", true, Formatting.AQUA, null, Spheres.v(3, 0, 1, 0, 0), null);
        Arsenal.SPHERE_CERBERUS = effect("sphere_cerberus", true, Formatting.DARK_GRAY, null, Spheres.v(0, 5, 0, 1, 0), null);
        Arsenal.SPHERE_STINGER = effect("sphere_stinger", true, Formatting.BLUE, NameDecor.LIGHT_RED, Spheres.v(1, 2, 2, 0, 0), null);
        Arsenal.SPHERE_ARMORTALITY = effect("sphere_armortality", true, Formatting.GOLD, null, Spheres.v(0, 2, 2, 0, 2), null);
        Arsenal.SPHERE_IMMORTALITY = effect("sphere_immortality", true, Formatting.LIGHT_PURPLE, null, Spheres.v(2, 3, 0, 0, 0), null);
        Arsenal.SPHERE_ETERNITY = effect("sphere_eternity", true, Formatting.BLUE, NameDecor.DARK_PINK, Spheres.v(2, 2, 2, 0, 0), null);
        Arsenal.TALISMAN_COMMON = effect("talisman_common", false, Formatting.GRAY, null, null, null);
        Arsenal.TALISMAN = effect("talisman", false, Formatting.DARK_PURPLE, null, null, null);
        Arsenal.TALISMAN_LEGENDARY = effect("talisman_legendary", false, Formatting.BLUE, null, null, null);
        Arsenal.TALISMAN_STINGER = effect("talisman_stinger", false, Formatting.BLUE, NameDecor.LIGHT_RED, Spheres.v(1, 2, 2, 0, 0), null);
        Arsenal.TALISMAN_ETERNITY = effect("talisman_eternity", false, Formatting.BLUE, NameDecor.DARK_PINK, Spheres.v(2, 2, 2, 0, 0), null);
        Arsenal.TALISMAN_INFINITY = effect("talisman_infinity", false, Formatting.GOLD, NameDecor.LIME, Spheres.v(2, 2, 2, 0, 2), null);
        // Талисман Dragon: +10% скорости и +1 урон из левой руки, спасает от смерти как остальные талисманы
        Arsenal.TALISMAN_DRAGON = effect("talisman_dragon", false, Formatting.DARK_PURPLE, null,
                Spheres.v(0, 0, 0, 0, 0), new double[]{0.10, 1.0, 0.0, 0.0, 0.0});

        // Взрывчатка, приваты, наковальня
        Blasts.init();
        com.arsenal.priv.Privates.init();
        com.arsenal.anvil.UnbreakableAnvil.init();
        com.arsenal.item.FastFurnace.init();
    }

    private static List<StatusEffectInstance> list2(StatusEffectInstance... e) {
        return new ArrayList<>(Arrays.asList(e));
    }

    private static VI sword(String id, TextColor decor) {
        return VI.register(id, Items.NETHERITE_SWORD).glint(true).vanillaUse(true)
                .name(s -> NameDecor.decorate(new LiteralText(Lang.get("item.arsenal." + id)), decor));
    }

    private static Item keeperBase(ArtifactEffect e) {
        switch (e) {
            case HUNTER:
                return Items.DIAMOND_SWORD;
            case ILLUMINATOR:
                return Items.SEA_LANTERN;
            case SNOWMAN:
                return Items.SNOW_BLOCK;
            case ENDERMAN:
                return Items.ENDER_PEARL;
            case ANTI_PHANTOM:
                return Items.PHANTOM_MEMBRANE;
            case TELEKINESIS:
                return Items.HONEY_BLOCK;
            case GRAVITY:
                return Items.FEATHER;
            case BLAST_RESISTANCE:
                return Items.TNT;
            case VAMPIRISM:
                return Items.WITHER_SKELETON_SKULL;
            default:
                return Items.POTION;
        }
    }

    /** Сфера (голова игрока, без блеска) или талисман (тотем, с блеском). */
    private static VI effect(String id, boolean sphere, Formatting color, TextColor decor, int[] fixed, double[] amounts) {
        Spheres.define(id, fixed, amounts);
        VI vi = VI.register(id, sphere ? Items.PLAYER_HEAD : Items.TOTEM_OF_UNDYING)
                .unique(false)   // сферы с одинаковыми эффектами стакаются
                .glint(!sphere)
                .vanillaUse(!sphere)
                .name(s -> {
                    MutableText base = new LiteralText(Lang.get("item.arsenal." + id));
                    if (decor != null) {
                        return NameDecor.decorate(base, decor);
                    }
                    return base.formatted(color);
                })
                .lore(s -> {
                    List<Text> out = new ArrayList<>(Spheres.loreLines(s));
                    out.addAll(Runes.loreLines(s));
                    return out;
                });
        if (sphere) {
            vi.init(s -> SphereSkins.apply(s, id));
        }
        return vi;
    }
}
