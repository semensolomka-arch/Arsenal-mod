package com.arsenal.boss;

import com.arsenal.buyer.Buyer;
import com.arsenal.event.CargoLoot;
import com.arsenal.spawn.PvpArena;
import com.arsenal.spawn.SpawnWorld;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.EndermiteEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.MessageType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Боссы на дне ПВП-арены (/warp pvp, под ядром солнца). Входят в общую очередь ивентов.
 * <p>
 * Настоящее здоровье у босса около 1000 (потолок ванили 1024), а "виртуальное" (по умолчанию 12000)
 * ведётся здесь: после каждого удара настоящее здоровье возвращается обратно, а урон игрока записывается.
 */
public final class BossManager {
    public static final String TAG_BOSS = "arsenal_boss";
    public static final String TAG_MINION = "arsenal_bm";
    /** Смертельный удар, от которого "Непробиваемый" может спасти (силверфиши Вши). */
    public static final String TAG_LETHAL = "arsenal_lethal";
    /** Смертельный удар без шансов: Джо, Вошь, Смертник. */
    public static final String TAG_ABSOLUTE = "arsenal_absolute";
    public static final String TAG_DONE = "arsenal_bm_done";

    private static final Random RNG = new Random();
    private static final int REAL_HP = 1000;

    // ---- настройки (меняются в меню; значения по умолчанию заданы здесь и в Settings)
    public static int[] HP = {12000, 12000, 12000, 12000};
    public static int[] DAMAGE = {95, 95, 95, 95};
    public static int IDLE_TICKS = 20 * 60 * 10;
    public static int CAP = 150;
    public static int POINTS_MIN = 80000;
    public static int POINTS_MAX = 100000;
    public static int XP_LEVELS = 300;
    public static int LOOT_RADIUS = 50;
    public static int SUMMON_MIN = 20 * 30;
    public static int SUMMON_MAX = 20 * 50;
    public static int ARMOR_WEAR = 2;
    public static int SLOW_PCT = 20;        // на сколько процентов медленнее боссы и их мобы
    public static int HIT_CD = 20;          // кулдаун ударов босса по одному игроку, тики
    public static int EFFECT_TICKS = 20 * 8;
    public static int JOE_SIZE = 29;
    public static int JOE_SPEED = 15;       // сотые доли скорости
    public static int JOE_SLOW = 1;         // амплитуда (уровень 2)
    public static int JOE_MIN = 8;
    public static int JOE_MAX = 12;
    public static int LOUSE_MIN = 20;
    public static int LOUSE_MAX = 25;
    public static int LOUSE_NAUSEA_CHANCE = 25;
    public static int LOUSE_NAUSEA = 1;     // амплитуда (уровень 2)
    public static int SPEED_MIN = 8;
    public static int SPEED_MAX = 15;
    public static int SPEED_AURA = 6;
    public static int SPEED_BLIND = 1;
    public static int SPEED_FATIGUE = 1;
    public static int SPEED_SLOW = 1;

    // ---- состояние текущего боя
    private static UUID bossId;
    private static BossType type;
    private static double vhp;
    private static double maxHp;
    private static boolean dying;
    private static final Map<UUID, Double> DMG = new LinkedHashMap<>();
    private static final Map<UUID, String> NAMES = new HashMap<>();
    private static ServerBossBar bar;
    private static int idle;
    private static int summonIn;
    private static int joeCd;
    private static int missing;
    private static int age;
    private static double lastX;
    private static double lastY;
    private static double lastZ;
    private static boolean forced;

    private BossManager() {
    }

    /** Пока true, боссы не появляются в общей очереди ивентов (вручную /event spawn boss работает). */
    public static boolean CYCLE_PAUSED = true;

    private static java.nio.file.Path pauseFile() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("arsenal_boss_cycle.txt");
    }

    private static void setPaused(boolean v) {
        CYCLE_PAUSED = v;
        try {
            java.nio.file.Files.write(pauseFile(), (v ? "paused" : "running").getBytes(java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    public static void init() {
        try {
            if (java.nio.file.Files.exists(pauseFile())) {
                CYCLE_PAUSED = new String(java.nio.file.Files.readAllBytes(pauseFile()), java.nio.charset.StandardCharsets.UTF_8).trim().equals("paused");
            }
        } catch (Exception ignored) {
        }
        net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(
                net.minecraft.server.command.CommandManager.literal("boss").requires(src -> src.hasPermissionLevel(2))
                        .then(net.minecraft.server.command.CommandManager.literal("cycle")
                                .then(net.minecraft.server.command.CommandManager.literal("pause").executes(ctx -> {
                                    setPaused(true);
                                    ctx.getSource().sendFeedback(new LiteralText("Боссы больше не появляются в очереди ивентов"), true);
                                    return 1;
                                }))
                                .then(net.minecraft.server.command.CommandManager.literal("resume").executes(ctx -> {
                                    setPaused(false);
                                    ctx.getSource().sendFeedback(new LiteralText("Боссы снова появляются в очереди ивентов"), true);
                                    return 1;
                                }))
                                .then(net.minecraft.server.command.CommandManager.literal("status").executes(ctx -> {
                                    ctx.getSource().sendFeedback(new LiteralText(CYCLE_PAUSED ? "Боссы в очереди ивентов: пауза" : "Боссы в очереди ивентов: идут"), false);
                                    return 1;
                                })))));
        ServerTickEvents.END_SERVER_TICK.register(BossManager::tick);
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ServerWorld w = SpawnWorld.get(server);
            if (w != null) {
                forceChunks(w, false);
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (bossId != null) {
                finish(server, false, "Босс исчез: сервер останавливается");
            }
            ServerWorld w = SpawnWorld.get(server);
            if (w != null) {
                sweep(w);
                forceChunks(w, false);
            }
        });
    }

    // ------------------------------------------------------------------ состояние для остальных частей мода

    public static boolean isActive() {
        return bossId != null;
    }

    public static BossType type() {
        return type;
    }

    public static String hpText() {
        return (long) Math.ceil(vhp) + " / " + (long) maxHp;
    }

    private static boolean has(Entity e, String tag) {
        return e != null && e.getScoreboardTags().contains(tag);
    }

    /** Это сам босс, которого ведёт менеджер. */
    public static boolean isBoss(Entity e) {
        return bossId != null && e != null && bossId.equals(e.getUuid());
    }

    /** Смертельная атака: удар босса или его приспешников, помеченных как смертельные. */
    public static boolean isLethal(Entity attacker) {
        return attacker != null && !(attacker instanceof PlayerEntity) && (has(attacker, TAG_LETHAL) || has(attacker, TAG_ABSOLUTE));
    }

    private static final Map<UUID, Long> LAST_HIT = new HashMap<>();

    /** Босс бьёт одного игрока не чаще раза в HIT_CD тиков. */
    public static boolean hitReady(LivingEntity victim) {
        long now = victim.world.getTime();
        Long last = LAST_HIT.get(victim.getUuid());
        if (last != null && now - last < HIT_CD && now >= last) {
            return false;
        }
        LAST_HIT.put(victim.getUuid(), now);
        return true;
    }

    public static boolean isAbsolute(Entity attacker) {
        return attacker != null && !(attacker instanceof PlayerEntity) && has(attacker, TAG_ABSOLUTE);
    }

    /** Атакует босс или его приспешник (для ограничения износа брони). */
    public static boolean isBossSide(Entity attacker) {
        return attacker != null && !(attacker instanceof PlayerEntity)
                && (has(attacker, TAG_BOSS) || has(attacker, TAG_MINION));
    }

    /** Приспешники и сам босс: без обычной добычи и без опыта. */
    public static boolean noLoot(LivingEntity e) {
        if (e instanceof PlayerEntity) {
            return false;
        }
        if (has(e, TAG_BOSS) || has(e, TAG_MINION)) {
            return true;
        }
        return bossId != null && e instanceof Monster && PvpArena.inside(e);
    }

    // ------------------------------------------------------------------ урон

    /** Вызывается после каждого удара по боссу. delta: сколько настоящего здоровья забрал удар. */
    public static void onBossHit(LivingEntity self, DamageSource src, float delta) {
        if (dying || delta <= 0.0F) {
            return;
        }
        Entity attacker = src.getAttacker();
        if (!(attacker instanceof ServerPlayerEntity)) {
            return;
        }
        ServerPlayerEntity p = (ServerPlayerEntity) attacker;
        vhp -= delta;
        DMG.merge(p.getUuid(), (double) delta, Double::sum);
        NAMES.put(p.getUuid(), p.getName().getString());
        idle = 0;
        if (vhp <= 0.0) {
            vhp = 0.0;
            dying = true;
            self.setInvulnerable(true);
        }
    }

    // ------------------------------------------------------------------ появление

    public static boolean startRandom(MinecraftServer server) {
        return spawn(server, BossType.values()[RNG.nextInt(BossType.values().length)]);
    }

    public static boolean spawn(MinecraftServer server, BossType t) {
        if (!PvpArena.ready()) {
            return false;
        }
        if (bossId != null) {
            finish(server, false, "Босс исчезает");
        }
        ServerWorld w = SpawnWorld.get(server);
        if (w == null) {
            return false;
        }
        forceChunks(w, true);
        double[] spot = findSpot(w, t);
        if (spot == null) {
            forceChunks(w, false);
            return false;
        }
        LivingEntity boss = create(server, w, t, spot);
        if (boss == null) {
            forceChunks(w, false);
            return false;
        }
        type = t;
        bossId = boss.getUuid();
        maxHp = HP[t.ordinal()];
        vhp = maxHp;
        dying = false;
        DMG.clear();
        NAMES.clear();
        idle = 0;
        age = 0;
        missing = 0;
        joeCd = 40;
        summonIn = SUMMON_MIN + RNG.nextInt(Math.max(1, SUMMON_MAX - SUMMON_MIN + 1));
        lastX = spot[0];
        lastY = spot[1];
        lastZ = spot[2];
        bar = new ServerBossBar(new LiteralText(t.title), t.color, BossBar.Style.NOTCHED_10);
        bar.setPercent(1.0F);

        MutableText msg = new LiteralText("⚔ Появился босс ").formatted(Formatting.RED, Formatting.BOLD)
                .append(new LiteralText("«" + t.title + "»").formatted(t.format, Formatting.BOLD))
                .append(new LiteralText("! Он ждёт на дне ПВП-арены. Телепортируйся: ").formatted(Formatting.GRAY))
                .append(new LiteralText("/warp pvp").formatted(Formatting.YELLOW))
                .append(new LiteralText(" и прыгай в дыру. Награду получают все, кто бил босса.").formatted(Formatting.GRAY));
        server.getPlayerManager().broadcastChatMessage(msg, MessageType.SYSTEM, Util.NIL_UUID);
        return true;
    }

    /** Ищет свободное место на дне арены: сначала под ядром, потом под дырами. */
    private static double[] findSpot(ServerWorld w, BossType t) {
        int r = t == BossType.JOE ? Math.min(11, (int) Math.ceil(JOE_SIZE * 0.26) + 1) : 2;
        int h = t == BossType.JOE ? (int) (JOE_SIZE * 0.52) + 2 : 3;
        List<int[]> spots = new ArrayList<>();
        for (int[] s : PvpArena.bossSpots()) {
            spots.add(s);
        }
        for (int[] s : spots) {
            int cx = PvpArena.AX + s[0];
            int cz = PvpArena.AZ + s[1];
            if (clear(w, cx, cz, r, h)) {
                return new double[]{cx + 0.5, PvpArena.FY + 1.0, cz + 0.5};
            }
        }
        return null;
    }

    private static boolean clear(ServerWorld w, int cx, int cz, int r, int h) {
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int x = cx - r; x <= cx + r; x++) {
            for (int z = cz - r; z <= cz + r; z++) {
                pos.set(x, PvpArena.FY, z);
                if (w.getBlockState(pos).isAir()) {
                    return false;
                }
                for (int y = PvpArena.FY + 1; y <= PvpArena.FY + h; y++) {
                    pos.set(x, y, z);
                    if (!w.getBlockState(pos).isAir()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private static LivingEntity create(MinecraftServer server, ServerWorld w, BossType t, double[] p) {
        LivingEntity e;
        boolean summoned = false;
        switch (t) {
            case JOE: {
                String cmd = String.format(Locale.ROOT, "summon minecraft:slime %.2f %.2f %.2f {Size:%d,PersistenceRequired:1b,Tags:[\"%s\",\"%s\"]}",
                        p[0], p[1], p[2], JOE_SIZE - 1, TAG_BOSS, TAG_ABSOLUTE);
                server.getCommandManager().execute(server.getCommandSource().withWorld(w).withSilent(), cmd);
                List<SlimeEntity> found = w.getEntitiesByClass(SlimeEntity.class,
                        new Box(p[0] - 3, p[1] - 3, p[2] - 3, p[0] + 3, p[1] + 3, p[2] + 3), s -> has(s, TAG_BOSS));
                if (found.isEmpty()) {
                    return null;
                }
                e = found.get(0);
                summoned = true;
                setAttr(e, EntityAttributes.GENERIC_MOVEMENT_SPEED, JOE_SPEED / 100.0);
                setAttr(e, EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0);
                break;
            }
            case LOUSE: {
                EndermiteEntity m = EntityType.ENDERMITE.create(w);
                if (m == null) {
                    return null;
                }
                place(w, m, p);
                setAttr(m, EntityAttributes.GENERIC_ATTACK_DAMAGE, DAMAGE[1]);
                e = m;
                break;
            }
            case SMERTNIK: {
                WitherSkeletonEntity m = EntityType.WITHER_SKELETON.create(w);
                if (m == null) {
                    return null;
                }
                place(w, m, p);
                armor(m, true, true);
                setAttr(m, EntityAttributes.GENERIC_ATTACK_DAMAGE, Math.max(0, DAMAGE[2] - 7));
                e = m;
                break;
            }
            default: {
                ZombieEntity m = EntityType.ZOMBIE.create(w);
                if (m == null) {
                    return null;
                }
                place(w, m, p);
                armor(m, true, true);
                setAttr(m, EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS, 0.0);
                setAttr(m, EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34);
                setAttr(m, EntityAttributes.GENERIC_ATTACK_DAMAGE, Math.max(0, DAMAGE[3] - 7));
                e = m;
                break;
            }
        }
        if (t != BossType.SPEEDRUNNER) {
            e.addScoreboardTag(TAG_ABSOLUTE);
        }
        e.addScoreboardTag(TAG_BOSS);
        slow(e);
        normalKnockback(e);
        setAttr(e, EntityAttributes.GENERIC_MAX_HEALTH, REAL_HP);
        e.setHealth(REAL_HP);
        e.setGlowing(true);
        e.setCustomName(new LiteralText(t.title).formatted(t.format, Formatting.BOLD));
        e.setCustomNameVisible(true);
        if (e instanceof MobEntity) {
            ((MobEntity) e).setPersistent();
            ((MobEntity) e).setCanPickUpLoot(false);
        }
        if (!summoned) {
            w.spawnEntity(e);   // слизень Джо уже создан командой summon
        }
        return e;
    }

    /** Броня даёт сопротивление отбрасыванию: гасим, чтобы босс и мобы отлетали как обычные. */
    private static void normalKnockback(LivingEntity e) {
        EntityAttributeInstance a = e.getAttributeInstance(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);
        if (a != null && a.getValue() > 0.0) {
            a.addPersistentModifier(new net.minecraft.entity.attribute.EntityAttributeModifier(
                    UUID.fromString("7a1f2c3d-0b4e-4c55-9d11-5e3a9b6c0f21"), "arsenal_boss_kb", -a.getValue(),
                    net.minecraft.entity.attribute.EntityAttributeModifier.Operation.ADDITION));
        }
    }

    private static void slow(LivingEntity e) {
        EntityAttributeInstance a = e.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (a != null) {
            a.setBaseValue(a.getBaseValue() * (100 - SLOW_PCT) / 100.0);
        }
    }

    private static void place(ServerWorld w, Entity e, double[] p) {
        e.refreshPositionAndAngles(p[0], p[1], p[2], RNG.nextFloat() * 360.0F, 0.0F);
    }

    private static void setAttr(LivingEntity e, net.minecraft.entity.attribute.EntityAttribute attr, double v) {
        EntityAttributeInstance a = e.getAttributeInstance(attr);
        if (a != null) {
            a.setBaseValue(v);
        }
    }

    private static ItemStack unbreakable(ItemStack s, boolean on) {
        if (on) {
            s.getOrCreateTag().putBoolean("Unbreakable", true);
        }
        return s;
    }

    private static void armor(MobEntity m, boolean sword, boolean unbreakable) {
        m.equipStack(EquipmentSlot.HEAD, unbreakable(new ItemStack(Items.NETHERITE_HELMET), unbreakable));
        m.equipStack(EquipmentSlot.CHEST, unbreakable(new ItemStack(Items.NETHERITE_CHESTPLATE), unbreakable));
        m.equipStack(EquipmentSlot.LEGS, unbreakable(new ItemStack(Items.NETHERITE_LEGGINGS), unbreakable));
        m.equipStack(EquipmentSlot.FEET, unbreakable(new ItemStack(Items.NETHERITE_BOOTS), unbreakable));
        if (sword) {
            m.equipStack(EquipmentSlot.MAINHAND, unbreakable(new ItemStack(Items.NETHERITE_SWORD), unbreakable));
        }
    }

    // ------------------------------------------------------------------ тик

    private static Box arenaBox() {
        int h = PvpArena.innerHalf() + 25;
        return new Box(PvpArena.AX - h, PvpArena.FY - 3, PvpArena.AZ - h, PvpArena.AX + h, PvpArena.firstFloorY() + 5, PvpArena.AZ + h);
    }

    private static boolean fighter(ServerPlayerEntity p) {
        return p.isAlive() && !p.isCreative() && !p.isSpectator();
    }

    private static void tick(MinecraftServer server) {
        if (bossId == null) {
            // страховка: после сбоя на арене могли остаться помеченные существа
            if (server.getTicks() % 200 == 0) {
                ServerWorld w = SpawnWorld.get(server);
                if (w != null && PvpArena.ready()) {
                    sweep(w);
                }
            }
            return;
        }
        ServerWorld w = SpawnWorld.get(server);
        Entity ent = w.getEntity(bossId);
        age++;
        if (!(ent instanceof LivingEntity) || !ent.isAlive()) {
            if (++missing > 100) {
                finish(server, false, "Босс «" + type.title + "» пропал");
            }
            return;
        }
        missing = 0;
        LivingEntity boss = (LivingEntity) ent;
        lastX = boss.getX();
        lastY = boss.getY();
        lastZ = boss.getZ();

        if (dying) {
            finish(server, true, null);
            return;
        }
        // босс всегда держит полное настоящее здоровье
        if (boss.getHealth() < REAL_HP) {
            boss.setHealth(REAL_HP);
        }
        if (++idle >= IDLE_TICKS) {
            finish(server, false, "Босс «" + type.title + "» исчез: его никто не бил " + (IDLE_TICKS / 1200) + " мин.");
            return;
        }

        List<ServerPlayerEntity> players = new ArrayList<>();
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (PvpArena.inside(p)) {
                players.add(p);
            }
        }

        switch (type) {
            case JOE:
                tickJoe(boss, players);
                break;
            case LOUSE:
                touch(boss, players, DAMAGE[1]);
                if (age % 20 == 0) {
                    for (ServerPlayerEntity p : players) {
                        if (fighter(p) && p.squaredDistanceTo(boss) < 25.0 && RNG.nextInt(100) < LOUSE_NAUSEA_CHANCE) {
                            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, EFFECT_TICKS, LOUSE_NAUSEA));
                        }
                    }
                }
                break;
            case SMERTNIK:
                touch(boss, players, DAMAGE[2]);
                if (age % 5 == 0) {
                    for (ServerPlayerEntity p : players) {
                        if (p.squaredDistanceTo(boss) < 144.0) {
                            p.removeStatusEffect(StatusEffects.WITHER);
                        }
                    }
                }
                break;
            default:
                touch(boss, players, DAMAGE[3]);
                if (age % 10 == 0) {
                    double r2 = (double) SPEED_AURA * SPEED_AURA;
                    for (ServerPlayerEntity p : players) {
                        if (fighter(p) && p.squaredDistanceTo(boss) <= r2) {
                            aura(p, StatusEffects.BLINDNESS, SPEED_BLIND);
                            aura(p, StatusEffects.MINING_FATIGUE, SPEED_FATIGUE);
                            aura(p, StatusEffects.SLOWNESS, SPEED_SLOW);
                        }
                    }
                }
                break;
        }

        // приспешники: волна, подсчёт и целеуказание
        if (--summonIn <= 0) {
            summonIn = SUMMON_MIN + RNG.nextInt(Math.max(1, SUMMON_MAX - SUMMON_MIN + 1));
            wave(server, w, boss);
        }
        if (age % 5 == 0 && type == BossType.JOE) {
            adoptSlimes(w);
        }
        if (age % 20 == 0) {
            aim(w, players);
        }
        if (type == BossType.LOUSE && age % 4 == 0) {
            touchSilverfish(w, players);
        }

        if (age % 10 == 0) {
            updateBar(w, boss);
            actionBar(players);
        }
    }

    private static void aura(ServerPlayerEntity p, StatusEffect effect, int amp) {
        p.addStatusEffect(new StatusEffectInstance(effect, 60, amp, true, false));
    }

    /** Удар, когда хитбоксы пересеклись (частоту ограничивает кулдаун босса по игроку). */
    private static void touch(LivingEntity boss, List<ServerPlayerEntity> players, int dmg) {
        if (age % 2 != 0) {
            return;
        }
        Box reach = boss.getBoundingBox().expand(0.2, 0.1, 0.2);
        for (ServerPlayerEntity p : players) {
            if (fighter(p) && reach.intersects(p.getBoundingBox())) {
                p.damage(DamageSource.mob(boss), dmg);
            }
        }
    }

    private static final Map<UUID, Long> SF_HIT = new HashMap<>();

    private static void touchSilverfish(ServerWorld w, List<ServerPlayerEntity> players) {
        long now = w.getTime();
        for (LivingEntity m : minions(w)) {
            if (!(m instanceof SilverfishEntity) || !m.isAlive()) {
                continue;
            }
            Long last = SF_HIT.get(m.getUuid());
            if (last != null && now - last < 20) {
                continue;
            }
            Box reach = m.getBoundingBox().expand(0.15, 0.1, 0.15);
            for (ServerPlayerEntity p : players) {
                if (fighter(p) && reach.intersects(p.getBoundingBox()) && p.damage(DamageSource.mob(m), DAMAGE[1])) {
                    SF_HIT.put(m.getUuid(), now);
                    break;
                }
            }
        }
    }

    private static void tickJoe(LivingEntity joe, List<ServerPlayerEntity> players) {
        if (joeCd > 0) {
            joeCd--;
            return;
        }
        boolean hit = false;
        Box reach = joe.getBoundingBox().expand(0.3, 0.1, 0.3);
        for (ServerPlayerEntity p : players) {
            if (!fighter(p) || !reach.intersects(p.getBoundingBox())) {
                continue;
            }
            if (p.damage(DamageSource.mob(joe), DAMAGE[0])) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, EFFECT_TICKS, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, EFFECT_TICKS, JOE_SLOW));
                hit = true;
            }
        }
        joeCd = hit ? Math.max(HIT_CD, 1) : 6;
    }

    // ------------------------------------------------------------------ приспешники

    private static List<LivingEntity> minions(ServerWorld w) {
        return w.getEntitiesByClass(LivingEntity.class, arenaBox(), x -> has(x, TAG_MINION));
    }

    private static void wave(MinecraftServer server, ServerWorld w, LivingEntity boss) {
        int alive = minions(w).size();
        int want;
        switch (type) {
            case JOE:
                want = between(JOE_MIN, JOE_MAX);
                break;
            case LOUSE:
                want = between(LOUSE_MIN, LOUSE_MAX);
                break;
            case SPEEDRUNNER:
                want = between(SPEED_MIN, SPEED_MAX);
                break;
            default:
                return;   // у Смертника приспешников нет
        }
        want = Math.min(want, CAP - alive);
        int rmin = type == BossType.JOE ? 4 : 2;
        int rmax = type == BossType.JOE ? 18 : 12;
        for (int i = 0; i < want; i++) {
            BlockPos at = floorSpot(w, boss.getX(), boss.getZ(), rmin, rmax);
            if (at == null) {
                continue;
            }
            double x = at.getX() + 0.5;
            double y = at.getY();
            double z = at.getZ() + 0.5;
            if (type == BossType.JOE) {
                int size = RNG.nextBoolean() ? 1 : 3;
                String cmd = String.format(Locale.ROOT, "summon minecraft:slime %.2f %.2f %.2f {Size:%d,PersistenceRequired:1b,Tags:[\"%s\"]}", x, y, z, size, TAG_MINION);
                server.getCommandManager().execute(server.getCommandSource().withWorld(w).withSilent(), cmd);
            } else if (type == BossType.LOUSE) {
                SilverfishEntity s = EntityType.SILVERFISH.create(w);
                if (s == null) {
                    continue;
                }
                place(w, s, new double[]{x, y, z});
                setAttr(s, EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0);   // бьёт наш код, когда хитбоксы пересеклись
                s.addScoreboardTag(TAG_LETHAL);
                slow(s);
                tagMinion(s);
                w.spawnEntity(s);
            } else {
                ZombieEntity z2 = EntityType.ZOMBIE.create(w);
                if (z2 == null) {
                    continue;
                }
                place(w, z2, new double[]{x, y, z});
                z2.setBaby(true);
                armor(z2, false, false);
                normalKnockback(z2);
                ItemStack stick = new ItemStack(Items.STICK);
                stick.addEnchantment(Enchantments.KNOCKBACK, 2);
                z2.equipStack(EquipmentSlot.MAINHAND, stick);
                setAttr(z2, EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS, 0.0);
                slow(z2);
                tagMinion(z2);
                w.spawnEntity(z2);
            }
        }
    }

    private static void tagMinion(MobEntity m) {
        m.addScoreboardTag(TAG_MINION);
        m.addScoreboardTag(TAG_DONE);
        m.setPersistent();
        m.setCanPickUpLoot(false);
    }

    private static int between(int lo, int hi) {
        if (hi < lo) {
            int t = lo;
            lo = hi;
            hi = t;
        }
        return lo + RNG.nextInt(hi - lo + 1);
    }

    /** Слизни Джо: призванные и осколки от деления получают тройной урон и считаются приспешниками. */
    private static void adoptSlimes(ServerWorld w) {
        List<SlimeEntity> all = w.getEntitiesByClass(SlimeEntity.class, arenaBox(), s -> !has(s, TAG_BOSS));
        int count = 0;
        for (SlimeEntity s : all) {
            if (has(s, TAG_DONE)) {
                count++;
            }
        }
        for (SlimeEntity s : all) {
            if (has(s, TAG_DONE)) {
                continue;
            }
            if (count >= CAP) {
                s.remove();   // не больше CAP приспешников одновременно
                continue;
            }
            count++;
            s.addScoreboardTag(TAG_MINION);
            s.addScoreboardTag(TAG_DONE);
            s.setPersistent();
            slow(s);
            EntityAttributeInstance a = s.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
            if (a != null) {
                a.setBaseValue(a.getValue() * 3.0);
            }
        }
    }

    /** Приспешники всегда выбирают цель (иначе силверфиш прячется в блоки арены). */
    private static void aim(ServerWorld w, List<ServerPlayerEntity> players) {
        ServerPlayerEntity any = null;
        for (ServerPlayerEntity p : players) {
            if (fighter(p) && p.getY() < PvpArena.firstFloorY() - 1) {
                any = p;
                break;
            }
        }
        if (any == null) {
            return;
        }
        for (LivingEntity m : minions(w)) {
            if (m instanceof MobEntity && !(m instanceof SlimeEntity)) {
                MobEntity mob = (MobEntity) m;
                if (mob.getTarget() == null || !mob.getTarget().isAlive()) {
                    ServerPlayerEntity best = null;
                    double bd = Double.MAX_VALUE;
                    for (ServerPlayerEntity p : players) {
                        if (fighter(p) && p.getY() < PvpArena.firstFloorY() - 1) {
                            double d = p.squaredDistanceTo(mob);
                            if (d < bd) {
                                bd = d;
                                best = p;
                            }
                        }
                    }
                    if (best != null) {
                        mob.setTarget(best);
                    }
                }
            }
        }
    }

    /** Свободная клетка на полу дна арены (не стена, не под полом) в кольце вокруг точки. */
    private static BlockPos floorSpot(ServerWorld w, double cx, double cz, int rmin, int rmax) {
        int lim = PvpArena.innerHalf();
        for (int i = 0; i < 40; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double d = rmin + RNG.nextDouble() * Math.max(1, rmax - rmin);
            int x = (int) Math.floor(cx + Math.cos(ang) * d);
            int z = (int) Math.floor(cz + Math.sin(ang) * d);
            if (Math.abs(x - PvpArena.AX) > lim || Math.abs(z - PvpArena.AZ) > lim) {
                continue;
            }
            BlockPos floor = new BlockPos(x, PvpArena.FY, z);
            BlockPos a = floor.up();
            if (!w.getBlockState(floor).isAir() && w.getBlockState(a).isAir() && w.getBlockState(a.up()).isAir()) {
                return a;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ полоса здоровья и подсказки

    private static List<Map.Entry<UUID, Double>> ranking() {
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(DMG.entrySet());
        list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        return list;
    }

    private static void updateBar(ServerWorld w, LivingEntity boss) {
        if (bar == null) {
            return;
        }
        bar.setName(new LiteralText(type.title + " — " + hpText()).formatted(type.format, Formatting.BOLD));
        bar.setPercent((float) Math.max(0.0, Math.min(1.0, vhp / maxHp)));
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (PvpArena.inside(p)) {
                bar.addPlayer(p);
            } else {
                bar.removePlayer(p);
            }
        }
    }

    private static void actionBar(List<ServerPlayerEntity> players) {
        List<Map.Entry<UUID, Double>> rank = ranking();
        for (ServerPlayerEntity p : players) {
            if (p.getY() >= PvpArena.firstFloorY() - 1) {
                continue;   // только те, кто спрыгнул на дно
            }
            Double mine = DMG.get(p.getUuid());
            Text t;
            if (mine == null) {
                t = new LiteralText("Нанесено урона: 0").formatted(Formatting.GRAY);
            } else {
                int place = 1;
                for (Map.Entry<UUID, Double> e : rank) {
                    if (e.getKey().equals(p.getUuid())) {
                        break;
                    }
                    place++;
                }
                t = new LiteralText("Нанесено урона: " + Math.round(mine) + " (место " + place + " из " + rank.size() + ")").formatted(Formatting.GOLD);
            }
            p.sendMessage(t, true);
        }
    }

    // ------------------------------------------------------------------ конец боя

    public static void despawn(MinecraftServer server) {
        if (bossId != null) {
            finish(server, false, "Босс «" + type.title + "» исчезает");
        }
    }

    private static void finish(MinecraftServer server, boolean killed, String message) {
        ServerWorld w = SpawnWorld.get(server);
        BossType t = type;
        double x = lastX;
        double z = lastZ;
        List<Map.Entry<UUID, Double>> rank = ranking();
        double total = 0.0;
        for (Map.Entry<UUID, Double> e : rank) {
            total += e.getValue();
        }
        Map<UUID, String> names = new HashMap<>(NAMES);

        // убираем босса и всех приспешников
        if (w != null) {
            Entity e = bossId == null ? null : w.getEntity(bossId);
            if (e != null) {
                e.remove();
            }
            sweep(w);
        }
        if (bar != null) {
            bar.clearPlayers();
            bar.setVisible(false);
            bar = null;
        }
        bossId = null;
        type = null;
        dying = false;
        LAST_HIT.clear();
        SF_HIT.clear();
        DMG.clear();
        NAMES.clear();
        if (w != null) {
            forceChunks(w, false);
        }

        if (!killed) {
            if (message != null) {
                server.getPlayerManager().broadcastChatMessage(new LiteralText(message).formatted(Formatting.GRAY), MessageType.SYSTEM, Util.NIL_UUID);
            }
            return;
        }

        // ---- награды
        MutableText msg = new LiteralText("☠ Босс ").formatted(Formatting.GREEN, Formatting.BOLD)
                .append(new LiteralText("«" + t.title + "»").formatted(t.format, Formatting.BOLD))
                .append(new LiteralText(" повержен!").formatted(Formatting.GREEN, Formatting.BOLD));
        int shown = Math.min(3, rank.size());
        for (int i = 0; i < shown; i++) {
            Map.Entry<UUID, Double> e = rank.get(i);
            String nm = names.getOrDefault(e.getKey(), "?");
            long pct = total <= 0 ? 0 : Math.round(e.getValue() * 100.0 / total);
            msg.append(new LiteralText("\n" + (i + 1) + ". ").formatted(Formatting.YELLOW))
                    .append(new LiteralText(nm).formatted(Formatting.WHITE))
                    .append(new LiteralText(" — " + Math.round(e.getValue()) + " урона (" + pct + "%)").formatted(Formatting.GRAY));
        }
        server.getPlayerManager().broadcastChatMessage(msg, MessageType.SYSTEM, Util.NIL_UUID);

        if (total > 0 && !rank.isEmpty()) {
            Map.Entry<UUID, Double> top = rank.get(0);
            long base = POINTS_MIN + (long) (RNG.nextDouble() * Math.max(0, POINTS_MAX - POINTS_MIN));
            long points = Math.round(base * (top.getValue() / total));
            Buyer.addPoints(top.getKey(), points);
            ServerPlayerEntity topPlayer = server.getPlayerManager().getPlayer(top.getKey());
            if (topPlayer != null) {
                topPlayer.sendMessage(new LiteralText("Больше всех урона нанесли вы: +" + points + " очков покупателя").formatted(Formatting.GOLD), false);
            }

            int levels = RNG.nextInt(Math.max(0, XP_LEVELS) + 1);
            double xpTotal = xpForLevels(levels);
            for (Map.Entry<UUID, Double> e : rank) {
                ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
                if (p == null) {
                    continue;
                }
                int xp = (int) Math.round(xpTotal * (e.getValue() / total));
                if (xp > 0) {
                    p.addExperience(xp);
                    p.sendMessage(new LiteralText("Опыт за босса: +" + xp).formatted(Formatting.GREEN), false);
                }
            }
        }
        if (w != null) {
            dropLoot(w, x, z);
        }
    }

    private static int xpForLevels(int l) {
        if (l <= 16) {
            return l * l + 6 * l;
        }
        if (l <= 31) {
            return (int) (2.5 * l * l - 40.5 * l + 360);
        }
        return (int) (4.5 * l * l - 162.5 * l + 2220);
    }

    private static void dropLoot(ServerWorld w, double x, double z) {
        List<ItemStack> loot = CargoLoot.rollFlat("boss");
        for (ItemStack stack : loot) {
            BlockPos at = floorSpot(w, x, z, 0, Math.max(1, LOOT_RADIUS));
            if (at == null) {
                at = new BlockPos(PvpArena.AX, PvpArena.FY + 1, PvpArena.AZ);
            }
            ItemEntity item = new ItemEntity(w, at.getX() + 0.5, at.getY() + 0.3, at.getZ() + 0.5, stack.copy());
            item.setToDefaultPickupDelay();
            w.spawnEntity(item);
        }
    }

    /** Удаляет всё, что помечено как босс или приспешник. */
    private static void sweep(ServerWorld w) {
        for (Entity e : w.getEntitiesByClass(Entity.class, arenaBox(), x -> has(x, TAG_BOSS) || has(x, TAG_MINION))) {
            e.remove();
        }
    }

    private static void forceChunks(ServerWorld w, boolean on) {
        if (on == forced && on) {
            return;
        }
        int h = PvpArena.innerHalf() + 6;
        for (int cx = (PvpArena.AX - h) >> 4; cx <= (PvpArena.AX + h) >> 4; cx++) {
            for (int cz = (PvpArena.AZ - h) >> 4; cz <= (PvpArena.AZ + h) >> 4; cz++) {
                w.setChunkForced(cx, cz, on);
            }
        }
        forced = on;
    }
}
