package com.arsenal.boss;

import net.minecraft.entity.boss.BossBar;
import net.minecraft.util.Formatting;

/** Четыре босса ПВП-арены. */
public enum BossType {
    JOE("Скользкий Джо", BossBar.Color.GREEN, Formatting.GREEN, "joe", "джо"),
    LOUSE("Вошь", BossBar.Color.PURPLE, Formatting.DARK_PURPLE, "louse", "вошь"),
    SMERTNIK("Смертник", BossBar.Color.RED, Formatting.DARK_RED, "smertnik", "смертник"),
    SPEEDRUNNER("Спидраннер", BossBar.Color.YELLOW, Formatting.GOLD, "speedrunner", "спидраннер");

    public final String title;
    public final BossBar.Color color;
    public final Formatting format;
    public final String[] names;

    BossType(String title, BossBar.Color color, Formatting format, String... names) {
        this.title = title;
        this.color = color;
        this.format = format;
        this.names = names;
    }
}
