package com.arsenal.spawn;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Настройки автошахт (config/arsenal_automines.json, правятся через Mod Menu): из каких блоков и в какой доле
 * набирается шахта для каждого мира (Обычный мир, Ад, Энд) и уровня (обычная, эпическая, легендарная),
 * шансы уровней, шанс Ада для второй шахты и число залежей взрывчатого вещества в легендарной шахте Обычного мира.
 * Вес блока - его доля среди остальных (концентрация считается как вес / сумма весов).
 */
public final class MineConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final String[] REALMS = {"overworld", "nether", "end"};
    public static final String[] TIERS = {"common", "epic", "legendary"};

    public static final class Entry {
        public final Block block;
        public final int weight;

        Entry(Block block, int weight) {
            this.block = block;
            this.weight = weight;
        }
    }

    private static final Map<String, Entry[]> TABLES = new HashMap<>();
    private static final int[] TIER_WEIGHTS = {70, 25, 5};
    private static int netherChance = 50;
    private static int depositMin = 2;
    private static int depositMax = 3;
    private static long modified = Long.MIN_VALUE;

    private MineConfig() {
    }

    public static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_automines.json");
    }

    // ---------------------------------------------------------------- значения по умолчанию

    private static void put(JsonObject tables, String realm, String tier, Object... blockWeight) {
        JsonObject r = tables.has(realm) ? tables.getAsJsonObject(realm) : new JsonObject();
        JsonArray arr = new JsonArray();
        for (int i = 0; i + 1 < blockWeight.length; i += 2) {
            JsonObject e = new JsonObject();
            e.addProperty("block", (String) blockWeight[i]);
            e.addProperty("weight", (Integer) blockWeight[i + 1]);
            arr.add(e);
        }
        r.add(tier, arr);
        tables.add(realm, r);
    }

    /** Настройки по умолчанию: ровно те значения, что были в моде до появления этого файла. */
    public static JsonObject defaultJson() {
        JsonObject root = new JsonObject();
        JsonObject tw = new JsonObject();
        tw.addProperty("common", 70);
        tw.addProperty("epic", 25);
        tw.addProperty("legendary", 5);
        root.add("tierWeights", tw);
        root.addProperty("netherChancePercent", 50);
        JsonObject dep = new JsonObject();
        dep.addProperty("min", 2);
        dep.addProperty("max", 3);
        root.add("deposits", dep);
        JsonObject t = new JsonObject();
        put(t, "overworld", "common", "minecraft:stone", 580, "minecraft:coal_ore", 120, "minecraft:iron_ore", 140,
                "minecraft:gold_ore", 50, "minecraft:redstone_ore", 40, "minecraft:lapis_ore", 40,
                "minecraft:diamond_ore", 24, "minecraft:emerald_ore", 6);
        put(t, "overworld", "epic", "minecraft:stone", 325, "minecraft:coal_ore", 90, "minecraft:iron_ore", 170,
                "minecraft:gold_ore", 100, "minecraft:redstone_ore", 80, "minecraft:lapis_ore", 70,
                "minecraft:diamond_ore", 110, "minecraft:emerald_ore", 55);
        put(t, "overworld", "legendary", "minecraft:stone", 130, "minecraft:coal_ore", 60, "minecraft:iron_ore", 180,
                "minecraft:gold_ore", 150, "minecraft:redstone_ore", 100, "minecraft:lapis_ore", 100,
                "minecraft:diamond_ore", 180, "minecraft:emerald_ore", 100);
        put(t, "nether", "common", "minecraft:netherrack", 600, "minecraft:nether_bricks", 120,
                "minecraft:nether_gold_ore", 160, "minecraft:nether_quartz_ore", 120);
        put(t, "nether", "epic", "minecraft:netherrack", 380, "minecraft:nether_bricks", 120,
                "minecraft:nether_gold_ore", 260, "minecraft:nether_quartz_ore", 240);
        put(t, "nether", "legendary", "minecraft:netherrack", 200, "minecraft:nether_bricks", 100,
                "minecraft:nether_gold_ore", 360, "minecraft:nether_quartz_ore", 340);
        put(t, "end", "common", "minecraft:end_stone", 600, "minecraft:obsidian", 80,
                "minecraft:purpur_block", 160, "minecraft:purple_terracotta", 160);
        put(t, "end", "epic", "minecraft:end_stone", 400, "minecraft:obsidian", 120,
                "minecraft:purpur_block", 240, "minecraft:purple_terracotta", 240);
        put(t, "end", "legendary", "minecraft:end_stone", 220, "minecraft:obsidian", 160,
                "minecraft:purpur_block", 310, "minecraft:purple_terracotta", 310);
        root.add("tables", t);
        return root;
    }

    // ---------------------------------------------------------------- загрузка

    private static void ensureFile() {
        Path f = file();
        if (Files.exists(f)) {
            return;
        }
        try {
            Files.createDirectories(f.getParent());
            Files.write(f, GSON.toJson(defaultJson()).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось создать настройки автошахт: " + ex);
        }
    }

    /** Перечитывает файл, если он изменился. Возвращает true, когда настройки поменялись (шахты надо набрать заново). */
    public static boolean reloadIfChanged() {
        ensureFile();
        try {
            long stamp = Files.getLastModifiedTime(file()).toMillis();
            if (stamp == modified) {
                return false;
            }
            boolean first = modified == Long.MIN_VALUE;
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(file()), StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject def = defaultJson();
            Map<String, Entry[]> tables = new HashMap<>();
            JsonObject t = root.has("tables") ? root.getAsJsonObject("tables") : new JsonObject();
            JsonObject dt = def.getAsJsonObject("tables");
            for (String realm : REALMS) {
                for (String tier : TIERS) {
                    JsonArray arr = t.has(realm) && t.getAsJsonObject(realm).has(tier)
                            ? t.getAsJsonObject(realm).getAsJsonArray(tier)
                            : dt.getAsJsonObject(realm).getAsJsonArray(tier);
                    List<Entry> list = new ArrayList<>();
                    for (JsonElement el : arr) {
                        JsonObject o = el.getAsJsonObject();
                        Block b = Registry.BLOCK.getOrEmpty(new Identifier(o.get("block").getAsString())).orElse(null);
                        int w = o.has("weight") ? o.get("weight").getAsInt() : 0;
                        if (b != null && b != Blocks.AIR && w > 0) {
                            list.add(new Entry(b, w));
                        }
                    }
                    if (list.isEmpty()) {
                        list.add(new Entry(Blocks.STONE, 1));
                    }
                    tables.put(realm + "." + tier, list.toArray(new Entry[0]));
                }
            }
            JsonObject tw = root.has("tierWeights") ? root.getAsJsonObject("tierWeights") : new JsonObject();
            for (int i = 0; i < TIERS.length; i++) {
                TIER_WEIGHTS[i] = Math.max(0, tw.has(TIERS[i]) ? tw.get(TIERS[i]).getAsInt() : TIER_WEIGHTS[i]);
            }
            if (TIER_WEIGHTS[0] + TIER_WEIGHTS[1] + TIER_WEIGHTS[2] <= 0) {
                TIER_WEIGHTS[0] = 1;
            }
            netherChance = root.has("netherChancePercent")
                    ? Math.max(0, Math.min(100, root.get("netherChancePercent").getAsInt())) : 50;
            JsonObject dep = root.has("deposits") ? root.getAsJsonObject("deposits") : new JsonObject();
            depositMin = Math.max(0, dep.has("min") ? dep.get("min").getAsInt() : 2);
            depositMax = Math.max(depositMin, dep.has("max") ? dep.get("max").getAsInt() : 3);
            TABLES.clear();
            TABLES.putAll(tables);
            modified = stamp;
            return !first;
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать настройки автошахт: " + ex);
            return false;
        }
    }

    // ---------------------------------------------------------------- доступ для MineManager

    public static Entry[] table(String realm, String tier) {
        Entry[] t = TABLES.get(realm + "." + tier);
        return t == null ? new Entry[]{new Entry(Blocks.STONE, 1)} : t;
    }

    public static int tierWeight(int tierIndex) {
        return TIER_WEIGHTS[tierIndex];
    }

    public static int netherChance() {
        return netherChance;
    }

    public static int depositMin() {
        return depositMin;
    }

    public static int depositMax() {
        return depositMax;
    }
}
