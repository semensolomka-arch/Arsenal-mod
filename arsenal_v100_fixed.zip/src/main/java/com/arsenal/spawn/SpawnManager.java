package com.arsenal.spawn;

import com.arsenal.priv.PrivateType;
import com.arsenal.tp.TeleportManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.item.Items;
import net.minecraft.util.TypedActionResult;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import com.arsenal.protection.SpawnProtection;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.HorseBaseEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Box;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.block.enums.WallMountLocation;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Спавн сервера: закрытый зал со стеклянной крышей в отдельном измерении arsenal:spawn (см. SpawnWorld; если его
 * создать не вышло, зал строится далеко от центра обычного мира). Зал строится сам при первом использовании. Сюда ведёт /spawn (с ожиданием 3 секунды, как любая телепортация) и сюда возрождаются
 * после смерти те, у кого нет кровати. В зале все ходят со своими вещами.
 *
 * В зале есть яма с порталом Края: прыгаешь в неё и попадаешь на обычный /rtp. Рядом табличка.
 * Эта же яма доступна по /warp rtp. На востоке зала мастерская (/warp enchant): стол зачарования на 30 уровень,
 * верстаки и точила, на западе витрина приватов (/warp privat), на юге две автошахты (/warp mine1, /warp mine2,
 * см. MineManager). Ломать и строить в зале нельзя (см. SpawnProtection), кроме шахт.
 * Телепортация в обычный мир возможна любой командой телепорта или через яму.
 */
public final class SpawnManager {
    public static final int CX = -29_000_000;
    public static final int CZ = 29_000_000;
    public static final int FLOOR_Y = 100;
    /** Радиус зала: 57 на 57 блоков. */
    public static final int R = 28;
    private static final int HEIGHT = 8;
    /** Смещение центра ямы от центра зала (на север). */
    private static final int PIT_DZ = -14;
    /** Смещение стола зачарования от центра зала (на восток). */
    private static final int TABLE_DX = 13;
    /** Сколько блоков вокруг зала тоже защищено от строительства. */
    private static final int MARGIN = 10;

    public static final double SPAWN_X = CX + 0.5;
    public static final double SPAWN_Y = FLOOR_Y + 1.0;
    public static final double SPAWN_Z = CZ + 0.5;
    public static final float SPAWN_YAW = 180.0F;

    /** Точка /warp rtp: перед ямой, лицом к ней. */
    public static final double WARP_X = CX + 0.5;
    public static final double WARP_Y = FLOOR_Y + 1.0;
    public static final double WARP_Z = CZ - 7.5;
    public static final float WARP_YAW = 180.0F;

    /** Точка /warp privat: перед витриной приватов, лицом на запад. */
    public static final double PRIVATE_X = CX - 5.5;
    public static final double PRIVATE_Y = FLOOR_Y + 1.0;
    public static final double PRIVATE_Z = CZ + 0.5;
    public static final float PRIVATE_YAW = 90.0F;

    /** Точка /warp enchant: перед мастерской, лицом на восток. */
    public static final double ENCHANT_X = CX + 7.5;
    public static final double ENCHANT_Y = FLOOR_Y + 1.0;
    public static final double ENCHANT_Z = CZ + 0.5;
    public static final float ENCHANT_YAW = -90.0F;

    private static final Map<UUID, Long> LAST_PORTAL = new HashMap<>();

    private SpawnManager() {
    }

    public static void init() {
        // возрождение после смерти не у кровати: на спавн
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (alive) {
                return;
            }
            BlockPos bed = newPlayer.getSpawnPointPosition();
            if (bed != null && newPlayer.squaredDistanceTo(bed.getX() + 0.5, bed.getY(), bed.getZ() + 0.5) < 100.0) {
                return;
            }
            ServerWorld overworld = SpawnWorld.get(newPlayer.getServer());
            ensureBuilt(overworld);
            newPlayer.teleport(overworld, SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_YAW, 0.0F);
            newPlayer.fallDistance = 0.0F;
        });

        // измерение спавна создаётся сразу после загрузки миров
        ServerLifecycleEvents.SERVER_STARTED.register(SpawnWorld::create);
        MineManager.init();

        // жемчуг Края и хорус на спавне не работают: через них можно выбраться из зала
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack held = player.getStackInHand(hand);
            if ((held.getItem() == Items.ENDER_PEARL || held.getItem() == Items.CHORUS_FRUIT)
                    && near(player) && (!PvpArena.inside(player) || PvpArena.inLobby(player)) && !SpawnProtection.bypass(player)) {
                if (!world.isClient) {
                    ((ServerPlayerEntity) player).sendMessage(
                            new LiteralText("На спавне нельзя использовать жемчуг Края и хорус").formatted(Formatting.RED), true);
                }
                return TypedActionResult.fail(held);
            }
            return TypedActionResult.pass(held);
        });

        // мобы на спавне не появляются и не задерживаются, вредные эффекты с игроков снимаются
        ServerTickEvents.END_SERVER_TICK.register(SpawnManager::onTick);

        // яйца призыва на спавне не работают
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!(stack.getItem() instanceof SpawnEggItem) || SpawnProtection.bypass(player)) {
                return ActionResult.PASS;
            }
            if (contains(world, hit.getBlockPos()) || contains(world, hit.getBlockPos().offset(hit.getSide()))) {
                if (!world.isClient) {
                    SpawnProtection.deny((ServerPlayerEntity) player, "На спавне нельзя призывать мобов");
                }
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    private static int tick;

    private static void onTick(MinecraftServer server) {
        tick++;
        if (tick % 10 != 0) {
            return;
        }
        ServerWorld ow = SpawnWorld.get(server);
        Box zone = new Box(CX - R - MARGIN, 0, CZ - R - MARGIN, CX + R + MARGIN, 256, CZ + R + MARGIN);
        // getEntitiesByClass не загружает чанки: если там никого нет, ничего и не происходит
        for (MobEntity mob : ow.getEntitiesByClass(MobEntity.class, zone, e -> !isPet(e))) {
            mob.remove();
        }
        for (ServerPlayerEntity p : new ArrayList<>(ow.getPlayers())) {
            if (!near(p) || PvpArena.inside(p)) {
                continue;
            }
            // в отдельном измерении за стенами зала ничего нет: если игрок как-то там оказался, возвращаем на спавн
            if (SpawnWorld.key() != World.OVERWORLD && !insideHall(p) && !SpawnProtection.bypass(p)) {
                p.teleport(ow, SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_YAW, 0.0F);
                p.fallDistance = 0.0F;
                continue;
            }
            List<StatusEffect> bad = new ArrayList<>();
            for (StatusEffectInstance effect : p.getStatusEffects()) {
                if (effect.getEffectType().getType() == StatusEffectType.HARMFUL) {
                    bad.add(effect.getEffectType());
                }
            }
            for (StatusEffect effect : bad) {
                p.removeStatusEffect(effect);
            }
        }
    }

    /** Прирученные питомцы игроков не трогаем: иначе они бы гибли, если прибегут за хозяином. */
    private static boolean isPet(MobEntity e) {
        return (e instanceof TameableEntity && ((TameableEntity) e).isTamed())
                || (e instanceof HorseBaseEntity && ((HorseBaseEntity) e).isTame());
    }

    // ------------------------------------------------------------------ зона

    /** Зал и 10 блоков вокруг него: тут нельзя ломать и строить. */
    public static boolean contains(World world, BlockPos pos) {
        return world.getRegistryKey() == SpawnWorld.key()
                && Math.abs(pos.getX() - CX) <= R + MARGIN
                && Math.abs(pos.getZ() - CZ) <= R + MARGIN;
    }

    /** Пересекается ли куб привата (сторона 2*half+1 вокруг блока) с зоной спавна. */
    public static boolean overlaps(World world, BlockPos center, int half) {
        return world.getRegistryKey() == SpawnWorld.key()
                && center.getX() + half >= CX - R - MARGIN && center.getX() - half <= CX + R + MARGIN
                && center.getZ() + half >= CZ - R - MARGIN && center.getZ() - half <= CZ + R + MARGIN;
    }

    /** Рядом со спавном (для отмены урона от границы мира, спавн лежит за ней). */
    public static boolean near(Entity e) {
        if (e.world.getRegistryKey() != SpawnWorld.key()) {
            return false;
        }
        // в отдельном измерении спавна безопасно везде, в обычном мире только рядом с залом
        return SpawnWorld.key() != World.OVERWORLD
                || (Math.abs(e.getX() - CX) < R + 40 && Math.abs(e.getZ() - CZ) < R + 40);
    }

    /** Игрок внутри зала (с небольшим запасом). */
    private static boolean insideHall(Entity e) {
        return Math.abs(e.getX() - CX) <= R + 1 && Math.abs(e.getZ() - CZ) <= R + 1
                && e.getY() >= FLOOR_Y - 18 && e.getY() <= FLOOR_Y + HEIGHT + 2;
    }

    public static final String[] WARPS = {"rtp", "enchant", "privat", "private", "mine1", "mine2", "pvp"};

    /** Точка варпа {x, y, z, yaw} (зал и шахта при необходимости достраиваются), или null, если такого варпа нет. */
    public static double[] warpPoint(ServerWorld ow, String name) {
        switch (name) {
            case "rtp":
                ensureBuilt(ow);
                return new double[]{WARP_X, WARP_Y, WARP_Z, WARP_YAW};
            case "enchant":
                ensureBuilt(ow);
                return new double[]{ENCHANT_X, ENCHANT_Y, ENCHANT_Z, ENCHANT_YAW};
            case "privat":
            case "private":
                ensureBuilt(ow);
                return new double[]{PRIVATE_X, PRIVATE_Y, PRIVATE_Z, PRIVATE_YAW};
            case "mine1":
            case "mine2": {
                ensureBuilt(ow);
                int id = name.equals("mine1") ? 1 : 2;
                MineManager.ensureFresh(ow, id);
                return new double[]{MineManager.centerX(id) + 0.5, FLOOR_Y + 1.0, MineManager.centerZ(id) + 0.5, 180.0};
            }
            case "pvp":
                return PvpArena.ready() ? PvpArena.warpPoint() : null;
            default:
                return null;
        }
    }

    /** Игрок оказался внутри портала в яме (вызывается из EndPortalBlockMixin). */
    public static void portal(ServerPlayerEntity p) {
        long now = p.world.getTime();
        Long last = LAST_PORTAL.get(p.getUuid());
        if (last != null && now - last < 60) {
            return;
        }
        LAST_PORTAL.put(p.getUuid(), now);
        TeleportManager.portalRtp(p);
    }

    // ------------------------------------------------------------------ постройка

    public static void ensureBuilt(ServerWorld world) {
        if (world.getBlockState(new BlockPos(CX, FLOOR_Y, CZ)).getBlock() == Blocks.GOLD_BLOCK
                && world.getBlockState(new BlockPos(CX, FLOOR_Y - 2, CZ + PIT_DZ)).getBlock() == Blocks.END_PORTAL
                && world.getBlockState(new BlockPos(CX, FLOOR_Y + HEIGHT, CZ)).getBlock() == Blocks.GLASS
                && world.getBlockState(new BlockPos(CX + TABLE_DX, FLOOR_Y + 1, CZ)).getBlock() == Blocks.ENCHANTING_TABLE
                && world.getBlockState(new BlockPos(CX + MineManager.mineDx(1) - 8, FLOOR_Y - 5, CZ + MineManager.mineDz())).getBlock() == Blocks.BEDROCK
                && world.getBlockState(new BlockPos(CX - 12, FLOOR_Y + 1, CZ - 5)).getBlock() == Blocks.IRON_BLOCK) {
            return;
        }
        build(world);
    }

    /** Флаги 2 и 16: отправить клиентам, но без обновления соседей (так большая стройка не тормозит сервер). */
    private static void set(ServerWorld world, int x, int y, int z, Block block) {
        world.setBlockState(new BlockPos(x, y, z), block.getDefaultState(), 18);
    }

    private static boolean inWorkshop(int dx, int dz) {
        return dx >= 8 && dx <= 18 && Math.abs(dz) <= 5;
    }

    private static boolean inPrivates(int dx, int dz) {
        return dx >= -18 && dx <= -8 && Math.abs(dz) <= 5;
    }

    private static boolean inPit(int dx, int dz) {
        return Math.abs(dx) <= 3 && dz >= PIT_DZ - 3 && dz <= PIT_DZ + 3;
    }

    private static Block floorBlock(int dx, int dz, int d) {
        if (d <= 1) {
            return Blocks.GOLD_BLOCK;
        }
        if (d == 2) {
            return Blocks.CHISELED_QUARTZ_BLOCK;
        }
        boolean lampX = dx % 7 == 0;
        boolean lampZ = dz % 7 == 0;
        if (lampX && lampZ && !inPit(dx, dz)) {
            return Blocks.SEA_LANTERN;
        }
        if (inWorkshop(dx, dz)) {
            return Blocks.DARK_OAK_PLANKS;
        }
        if (inPrivates(dx, dz)) {
            return Blocks.POLISHED_BLACKSTONE;
        }
        if (d >= R - 1) {
            return Blocks.POLISHED_BLACKSTONE_BRICKS;
        }
        return ((dx + dz) & 1) == 0 ? Blocks.SMOOTH_QUARTZ : Blocks.POLISHED_ANDESITE;
    }

    private static void build(ServerWorld world) {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                int x = CX + dx;
                int z = CZ + dz;
                int d = Math.max(Math.abs(dx), Math.abs(dz));
                set(world, x, FLOOR_Y, z, floorBlock(dx, dz, d));
                for (int rel = 1; rel < HEIGHT; rel++) {
                    int y = FLOOR_Y + rel;
                    if (d < R) {
                        set(world, x, y, z, Blocks.AIR);
                        continue;
                    }
                    int along = Math.abs(dx) == R ? dz : dx;
                    Block wall;
                    if (along % 7 == 0 || Math.abs(along) == R) {
                        wall = Blocks.QUARTZ_PILLAR;
                    } else if (rel <= 2 || rel >= 6) {
                        wall = Blocks.QUARTZ_BRICKS;
                    } else {
                        wall = Blocks.GLASS;
                    }
                    set(world, x, y, z, wall);
                }
                set(world, x, FLOOR_Y + HEIGHT, z, d == R ? Blocks.QUARTZ_BLOCK : Blocks.GLASS);
            }
        }
        buildPit(world);
        buildWorkshop(world);
        buildPrivates(world);
        buildMines(world);
        PvpArena.buildEntrance(world);   // площадка входа на ПВП-арену
        sign(world, new BlockPos(CX, FLOOR_Y + 1, CZ + PIT_DZ + 4), 0,
                new LiteralText("[ RTP ]").formatted(Formatting.GOLD, Formatting.BOLD),
                new LiteralText("Рандомная").formatted(Formatting.DARK_PURPLE, Formatting.BOLD),
                new LiteralText("телепортация").formatted(Formatting.DARK_PURPLE),
                new LiteralText("прыгай в яму").formatted(Formatting.DARK_GRAY));
        sign(world, new BlockPos(CX + 5, FLOOR_Y + 1, CZ), 4,
                new LiteralText("[ ЗАЧАРКА ]").formatted(Formatting.GOLD, Formatting.BOLD),
                new LiteralText("Зачарование").formatted(Formatting.DARK_PURPLE, Formatting.BOLD),
                new LiteralText("30 уровня").formatted(Formatting.DARK_PURPLE),
                new LiteralText("верстак, точило").formatted(Formatting.DARK_GRAY));
    }

    /** Витрина приватов на западе: блок каждого вида на постаменте и табличка с размером зоны и прочностью. */
    private static void buildPrivates(ServerWorld world) {
        int ty = FLOOR_Y + 1;
        PrivateType[] types = {PrivateType.IRON, PrivateType.GOLD, PrivateType.DIAMOND, PrivateType.EMERALD,
                PrivateType.NETHERITE, PrivateType.UNIQUE};
        String[] names = {"Железный", "Золотой", "Алмазный", "Изумрудный", "Незеритовый", "Уникальный"};
        Formatting[] colors = {Formatting.GRAY, Formatting.GOLD, Formatting.AQUA, Formatting.GREEN, Formatting.DARK_PURPLE,
                Formatting.LIGHT_PURPLE};
        for (int i = 0; i < types.length; i++) {
            int z = CZ + 2 * i - 5;
            // displayBlock: настоящий блок привата (изумрудный это изумрудная руда, уникальный свой блок)
            set(world, CX - 12, ty, z, types[i].displayBlock());
            int size = types[i].size;
            sign(world, new BlockPos(CX - 10, ty, z), 12,
                    new LiteralText(names[i]).formatted(colors[i], Formatting.BOLD),
                    new LiteralText("Зона " + size + "×" + size + "×" + size).formatted(Formatting.BLACK),
                    new LiteralText("Прочность: " + types[i].durability).formatted(Formatting.DARK_GRAY),
                    new LiteralText("").formatted(Formatting.BLACK));
        }
        sign(world, new BlockPos(CX - 7, ty, CZ), 12,
                new LiteralText("[ ПРИВАТЫ ]").formatted(Formatting.GOLD, Formatting.BOLD),
                new LiteralText("Поставь блок").formatted(Formatting.DARK_PURPLE),
                new LiteralText("= защита зоны").formatted(Formatting.DARK_PURPLE),
                new LiteralText("/ps add ник").formatted(Formatting.DARK_GRAY));
    }

    /** Стенки двух автошахт: бедрок снизу и по краю, внутри камень до первого обновления (его заполняет MineManager). */
    private static void buildMines(ServerWorld world) {
        for (int id = 1; id <= 2; id++) {
            int cx = CX + MineManager.mineDx(id);
            int cz = CZ + MineManager.mineDz();
            for (int sx = -8; sx <= 8; sx++) {
                for (int sz = -8; sz <= 8; sz++) {
                    boolean ring = Math.abs(sx) == 8 || Math.abs(sz) == 8;
                    for (int y = FLOOR_Y - 15; y <= FLOOR_Y; y++) {
                        Block b;
                        if (y == FLOOR_Y - 15 || ring) {
                            boolean corner = Math.abs(sx) == 8 && Math.abs(sz) == 8 && y == FLOOR_Y;
                            b = corner ? Blocks.SEA_LANTERN : Blocks.BEDROCK;
                        } else {
                            b = Blocks.STONE;
                        }
                        set(world, cx + sx, y, cz + sz, b);
                    }
                }
            }
            sign(world, new BlockPos(cx, FLOOR_Y + 1, cz - 10), 8,
                    new LiteralText("[ ШАХТА " + id + " ]").formatted(Formatting.GOLD, Formatting.BOLD),
                    new LiteralText("Обычная 70%").formatted(Formatting.DARK_GRAY),
                    new LiteralText("Эпическая 25%").formatted(Formatting.DARK_PURPLE),
                    new LiteralText("Легенд. 5%").formatted(Formatting.GOLD));
        }
        MineManager.invalidate();
    }

    /**
     * Мастерская на востоке: стол зачарования в кольце из книжных полок (две полки в высоту, вход со стороны зала),
     * это даёт зачарование 30 уровня. Перед ней два верстака и два точила.
     */
    private static void buildWorkshop(ServerWorld world) {
        int tx = CX + TABLE_DX;
        int ty = FLOOR_Y + 1;
        set(world, tx, ty, CZ, Blocks.ENCHANTING_TABLE);
        for (int ox = -2; ox <= 2; ox++) {
            for (int oz = -2; oz <= 2; oz++) {
                if (Math.max(Math.abs(ox), Math.abs(oz)) != 2 || (ox == -2 && oz == 0)) {
                    continue;
                }
                set(world, tx + ox, ty, CZ + oz, Blocks.BOOKSHELF);
                set(world, tx + ox, ty + 1, CZ + oz, Blocks.BOOKSHELF);
            }
        }
        int sx = CX + 9;
        set(world, sx, ty, CZ - 3, Blocks.CRAFTING_TABLE);
        set(world, sx, ty, CZ + 3, Blocks.CRAFTING_TABLE);
        BlockState grind = Blocks.GRINDSTONE.getDefaultState()
                .with(Properties.WALL_MOUNT_LOCATION, WallMountLocation.FLOOR)
                .with(Properties.HORIZONTAL_FACING, Direction.WEST);
        world.setBlockState(new BlockPos(sx, ty, CZ - 1), grind, 18);
        world.setBlockState(new BlockPos(sx, ty, CZ + 1), grind, 18);
    }

    /** Яма 5 на 5, три блока вглубь: на дне портал Края, вокруг обсидиан. */
    private static void buildPit(ServerWorld world) {
        int pz = CZ + PIT_DZ;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int x = CX + dx;
                int z = pz + dz;
                if (Math.max(Math.abs(dx), Math.abs(dz)) == 3) {
                    set(world, x, FLOOR_Y, z, ((dx + dz) & 1) == 0 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
                    set(world, x, FLOOR_Y - 1, z, Blocks.OBSIDIAN);
                    set(world, x, FLOOR_Y - 2, z, Blocks.OBSIDIAN);
                    set(world, x, FLOOR_Y - 3, z, Blocks.OBSIDIAN);
                } else {
                    set(world, x, FLOOR_Y, z, Blocks.AIR);
                    set(world, x, FLOOR_Y - 1, z, Blocks.AIR);
                    set(world, x, FLOOR_Y - 2, z, Blocks.END_PORTAL);
                    set(world, x, FLOOR_Y - 3, z, Blocks.OBSIDIAN);
                }
            }
        }
    }

    private static String json(Text text) {
        return Text.Serializer.toJson(text);
    }

    /** Табличка на стойке; rotation: 0 текст на юг, 4 на запад, 8 на север, 12 на восток. */
    private static void sign(ServerWorld world, BlockPos pos, int rotation, Text l1, Text l2, Text l3, Text l4) {
        world.setBlockState(pos, Blocks.OAK_SIGN.getDefaultState().with(Properties.ROTATION, rotation));
        BlockEntity be = world.getBlockEntity(pos);
        if (be == null) {
            return;
        }
        NbtCompound tag = be.writeNbt(new NbtCompound());
        tag.putString("Text1", json(l1));
        tag.putString("Text2", json(l2));
        tag.putString("Text3", json(l3));
        tag.putString("Text4", json(l4));
        tag.putString("Color", "black");
        BlockState state = world.getBlockState(pos);
        be.fromTag(state, tag);
        be.markDirty();
        world.updateListeners(pos, state, state, 3);
    }
}
