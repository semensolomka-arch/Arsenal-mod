package com.arsenal.spawn;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * ПВП-арена (/warp pvp) в мире спавна, выглядит как карьер.
 *
 * Сверху ровная площадка-обход вокруг ямы (на ней, как на спавне, жемчуг бросать нельзя), в яму можно шагнуть с любой
 * стороны. Стенки ямы ступенями (3, 3 и 4 блока), поэтому по ним не вылезти. Дно ямы это "первый этаж" 80 на 80
 * блоков (крыша глубокой арены): тут Ядро солнца и 4 дыры 15 на 15. Из дыры падаешь примерно на 70 блоков на пол
 * глубокой арены (с колоннами, укрытиями и разным полом). Урона от падения на арене нет, как и от жемчуга; голод, трапки и
 * обычный урон работают. Жемчуг на арене можно бросать, но он не может вынести игрока за край ямы.
 *
 * Паркур идёт вдоль стен, поворачивает на углах и держится в 5-6 блоках от стены: от пола глубокой арены (через
 * проём в первом этаже) до первого этажа и дальше вдоль стенок ямы до обхода. Подниматься и спускаться можно по нему.
 * Ядро солнца (якорь возрождения) стоит на первом этаже в центре: рядом (по умолчанию 15 блоков) идёт опыт, чем ближе,
 * тем больше (в центре столько очков в секунду, сколько даёт бутылёк на 15 уровней), а раз в 15 секунд с ядра падает лут
 * (таблица core). Вход со спавна: площадка в зале мгновенно переносит на обход (или команда /warp pvp с ожиданием).
 * Арена строится сама по кускам (по паре чанков за тик) и защищена от ломания и строительства.
 */
public final class PvpArena {
    /** Центр арены. */
    public static final int AX = SpawnManager.CX + 300;
    public static final int AZ = SpawnManager.CZ;
    /** Верхний блок пола глубокой арены. */
    public static final int FY = 140;
    /** Половина стороны дна ямы и глубокой арены: 80 на 80 (стены дальше). */
    private static final int HALF = 40;
    /** Воздуха между полом и первым этажом: падение из дыры примерно 70 блоков. */
    private static final int HGT = 70;
    /** Верхняя грань первого этажа. */
    private static final int FF_Y = FY + HGT + 1;
    /** Верхняя грань обхода (спавн-уровень): первый этаж + 10 блоков. */
    private static final int RIM_Y = FF_Y + 10;
    /** Половина стороны всего карьера вместе с обходом. */
    private static final int RIM_HALF = 61;
    /** Проём в плане: дальше этого расстояния от центра уже обход (на обходе нельзя жемчуг). */
    private static final int OPEN_TOP = 48;

    private static final int HOLE_HALF = 7;
    private static final int[][] HOLES = {{-22, -22}, {22, -22}, {-22, 22}, {22, 22}};

    /** Площадка возврата на спавн на обходе (смещение по z от центра). */
    private static final int PAD_DZ = 57;
    /** Площадка входа в зале спавна (смещение от центра зала). */
    private static final int HALL_PAD_DX = -14;
    private static final int HALL_PAD_DZ = -17;

    /**
     * Настраиваются в Settings: радиус в блоках, очков опыта в секунду в самом центре (по умолчанию как даёт бутылёк
     * на 15 уровней, 315 очков) и как часто (в тиках) с Ядра солнца падает лут.
     */
    public static int XP_RADIUS = 15;
    public static int XP_MAX = 315;
    public static int DROP_TICKS = 20 * 15;
    private static int dropTimer;

    private static boolean built;
    private static boolean checked;
    private static final Deque<int[]> JOBS = new ArrayDeque<>();
    private static boolean building;
    private static int tick;
    private static final Map<UUID, Float> XP_ACC = new HashMap<>();
    private static final Map<UUID, Long> LAST_NOTE = new HashMap<>();

    // материалы
    private static final Block[] PILLAR_MATS = {Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS,
            Blocks.ANDESITE, Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.CUT_SANDSTONE, Blocks.NETHER_BRICKS,
            Blocks.PRISMARINE_BRICKS};
    private static final Block[] WALL_MATS = {Blocks.STONE, Blocks.STONE, Blocks.ANDESITE, Blocks.COBBLESTONE,
            Blocks.MOSSY_COBBLESTONE, Blocks.DIORITE, Blocks.BLACKSTONE};
    private static final Block[] ORES = {Blocks.COAL_ORE, Blocks.IRON_ORE, Blocks.GOLD_ORE, Blocks.REDSTONE_ORE,
            Blocks.LAPIS_ORE, Blocks.DIAMOND_ORE};
    private static final Block[] TREADS = {Blocks.GRAVEL, Blocks.COARSE_DIRT, Blocks.PODZOL, Blocks.STONE, Blocks.ANDESITE};
    private static final Block[] MOUND_MATS = {Blocks.GRAVEL, Blocks.COARSE_DIRT, Blocks.COBBLESTONE, Blocks.ANDESITE};

    private PvpArena() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            built = false;
            checked = false;
            building = false;
            JOBS.clear();
            XP_ACC.clear();
            LAST_NOTE.clear();
        });
        ServerTickEvents.END_SERVER_TICK.register(PvpArena::onTick);
    }

    // ------------------------------------------------------------------ геометрия и проверки

    private static int cheb(double dx, double dz) {
        return (int) Math.floor(Math.max(Math.abs(dx), Math.abs(dz)));
    }

    public static boolean contains(World world, BlockPos pos) {
        return world.getRegistryKey() == SpawnWorld.key()
                && Math.abs(pos.getX() - AX) <= RIM_HALF + 2 && Math.abs(pos.getZ() - AZ) <= RIM_HALF + 2
                && pos.getY() >= FY - 3;
    }

    public static boolean overlaps(World world, BlockPos center, int half) {
        return world.getRegistryKey() == SpawnWorld.key()
                && center.getX() + half >= AX - RIM_HALF - 2 && center.getX() - half <= AX + RIM_HALF + 2
                && center.getZ() + half >= AZ - RIM_HALF - 2 && center.getZ() - half <= AZ + RIM_HALF + 2;
    }

    /** Здесь мобы не спавнятся вообще (тот же объём, где раньше их приходилось убирать). */
    public static boolean mobFree(World world, BlockPos pos) {
        return world.getRegistryKey() == SpawnWorld.key()
                && Math.abs(pos.getX() - AX) <= RIM_HALF + 4 && Math.abs(pos.getZ() - AZ) <= RIM_HALF + 4
                && pos.getY() >= FY - 3 && pos.getY() <= RIM_Y + 40;
    }

    /** Любое существо на арене: в яме, на обходе или на паркуре. */
    public static boolean inside(Entity e) {
        return e.world.getRegistryKey() == SpawnWorld.key()
                && Math.abs(e.getX() - AX) <= RIM_HALF + 2 && Math.abs(e.getZ() - AZ) <= RIM_HALF + 2
                && e.getY() >= FY - 3 && e.getY() <= RIM_Y + 40;
    }

    /** Обход вокруг ямы (спавн-уровень): тут, как на спавне, нельзя бросать жемчуг эндера. */
    public static boolean inLobby(Entity e) {
        if (e.world.getRegistryKey() != SpawnWorld.key()) {
            return false;
        }
        int d = cheb(e.getX() - (AX + 0.5), e.getZ() - (AZ + 0.5));
        return d > OPEN_TOP && d <= RIM_HALF + 2 && e.getY() >= RIM_Y - 1 && e.getY() <= RIM_Y + 25;
    }

    /** Точка /warp pvp и мгновенного входа: обход с южной стороны, лицом к яме. */
    public static double[] warpPoint() {
        return new double[]{AX + 0.5, RIM_Y + 1.0, AZ + 51.5, 180.0};
    }

    public static boolean ready() {
        return built;
    }

    /** Y первого этажа (плита над глубокой ареной). Всё, что ниже этого, это дно арены. */
    public static int firstFloorY() {
        return FF_Y;
    }

    /** Половина стороны арены (внутри стен), для босса. */
    public static int innerHalf() {
        return HALF - 2;
    }

    /** Центры свободных зон на дне (под дырами) и центр под ядром: сюда ставят боссов. */
    public static int[][] bossSpots() {
        return new int[][]{{0, 0}, {-22, -22}, {22, -22}, {-22, 22}, {22, 22}};
    }

    private static BlockPos anchorPos() {
        return new BlockPos(AX, FF_Y + 1, AZ);
    }

    private static BlockPos exitMarker() {
        return new BlockPos(AX, RIM_Y, AZ + PAD_DZ);
    }

    private static BlockPos hallPadCenter() {
        return new BlockPos(SpawnManager.CX + HALL_PAD_DX, SpawnManager.FLOOR_Y, SpawnManager.CZ + HALL_PAD_DZ);
    }

    // ------------------------------------------------------------------ тик

    private static void onTick(MinecraftServer server) {
        tick++;
        ServerWorld world = SpawnWorld.get(server);
        if (world == null) {
            return;
        }

        if (!built) {
            if (!building) {
                // один раз после запуска: арена уже стоит или её нужно строить
                if (!checked && tick > 60) {
                    checked = true;
                    ensureEntrance(world);
                    if (world.getBlockState(anchorPos()).getBlock() == Blocks.RESPAWN_ANCHOR
                            && world.getBlockState(exitMarker()).getBlock() == Blocks.EMERALD_BLOCK) {
                        built = true;
                    } else {
                        startBuild();
                    }
                }
            } else {
                runJobs(server, world);
            }
            return;
        }

        if (tick % 4 == 0) {
            giveExperience(world);
            checkPads(world);
        }
        coreLoot(world);
        culLoosePearls(world);
        if (tick % 40 == 0 && !com.arsenal.boss.BossManager.isActive()) {
            // мобы на арене не спавнятся (SpawnRestrictionMixin); это страховка на случай, если кто-то призовёт их вручную
            Box box = new Box(AX - RIM_HALF - 2, FY - 3, AZ - RIM_HALF - 2, AX + RIM_HALF + 2, RIM_Y + 40, AZ + RIM_HALF + 2);
            for (Entity e : world.getEntitiesByClass(Entity.class, box, x -> x instanceof Monster)) {
                e.remove();
            }
        }
    }

    /** Жемчуг не должен выносить за край ямы: вылетевший за проём жемчуг пропадает (игрок остаётся на месте). */
    private static void culLoosePearls(ServerWorld world) {
        boolean any = false;
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (inside(p)) {
                any = true;
                break;
            }
        }
        if (!any) {
            return;
        }
        Box box = new Box(AX - RIM_HALF - 20, FY - 3, AZ - RIM_HALF - 20, AX + RIM_HALF + 20, RIM_Y + 60, AZ + RIM_HALF + 20);
        for (EnderPearlEntity pearl : world.getEntitiesByClass(EnderPearlEntity.class, box, x -> true)) {
            boolean over = cheb(pearl.getX() - (AX + 0.5), pearl.getZ() - (AZ + 0.5)) > OPEN_TOP;
            if (over && pearl.getY() < RIM_Y + 30) {
                // пока игрок сам стоит на обходе, бросить жемчуг ему нельзя, так что это вылет из ямы
                pearl.remove();
            }
        }
    }

    /** Опыт у Ядра солнца: чем ближе к центру, тем больше (от 0 на краю радиуса до XP_MAX очков в секунду в центре). */
    private static void giveExperience(ServerWorld world) {
        double cx = AX + 0.5;
        double cy = FF_Y + 2.0;
        double cz = AZ + 0.5;
        double r = Math.max(1, XP_RADIUS);
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.isSpectator() || !inside(p)) {
                continue;
            }
            double d = Math.sqrt(p.squaredDistanceTo(cx, cy, cz));
            if (d >= r) {
                XP_ACC.remove(p.getUuid());
                continue;
            }
            // за 4 тика (1/5 секунды) добавляем 1/5 секундной нормы (в очках)
            float add = (float) (XP_MAX * (1.0 - d / r) / 5.0);
            float acc = XP_ACC.getOrDefault(p.getUuid(), 0.0F) + add;
            int whole = (int) acc;
            if (whole > 0) {
                int score = p.getScore();   // как у бутылька: счёт игрока опыт не меняет
                p.addExperience(whole);
                p.setScore(score);
                acc -= whole;
            }
            XP_ACC.put(p.getUuid(), acc);
        }
    }

    /** Раз в DROP_TICKS (по умолчанию 15 секунд) с Ядра солнца падает лут из таблицы core (если на арене кто-то есть). */
    private static void coreLoot(ServerWorld world) {
        if (++dropTimer < Math.max(20, DROP_TICKS)) {
            return;
        }
        dropTimer = 0;
        boolean anyone = false;
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (!p.isSpectator() && inside(p)) {
                anyone = true;
                break;
            }
        }
        if (!anyone) {
            return;
        }
        for (ItemStack stack : com.arsenal.event.CargoLoot.rollFlat("core")) {
            ItemEntity item = new ItemEntity(world, AX + 0.5, FF_Y + 3.0, AZ + 0.5, stack);
            item.setVelocity((world.random.nextDouble() - 0.5) * 0.5, 0.35, (world.random.nextDouble() - 0.5) * 0.5);
            item.setGlowing(true);
            world.spawnEntity(item);
        }
    }

    private static void note(ServerPlayerEntity p, String text, Formatting color) {
        long now = p.world.getTime();
        Long last = LAST_NOTE.get(p.getUuid());
        if (last != null && now - last < 40) {
            return;
        }
        LAST_NOTE.put(p.getUuid(), now);
        p.sendMessage(new LiteralText(text).formatted(color), true);
    }

    /** Две площадки: в зале (мгновенно на арену) и на обходе (на спавн). */
    private static void checkPads(ServerWorld world) {
        BlockPos hall = hallPadCenter();
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.isSpectator()) {
                continue;
            }
            // вход: площадка в зале спавна
            if (Math.abs(p.getX() - (hall.getX() + 0.5)) <= 2.4 && Math.abs(p.getZ() - (hall.getZ() + 0.5)) <= 2.4
                    && Math.abs(p.getY() - (hall.getY() + 1)) <= 1.5) {
                if (com.arsenal.pvp.PvpManager.teleportBlocked(p)) {
                    continue;
                }
                double[] pt = warpPoint();
                p.teleport(world, pt[0], pt[1], pt[2], (float) pt[3], 0.0F);
                p.fallDistance = 0.0F;
                p.sendMessage(new LiteralText("ПВП-арена: шагни в яму").formatted(Formatting.RED), true);
                continue;
            }
            // выход: площадка на обходе
            if (inside(p) && Math.abs(p.getX() - (AX + 0.5)) <= 2.6 && Math.abs(p.getZ() - (AZ + PAD_DZ + 0.5)) <= 2.6
                    && p.getY() >= RIM_Y && p.getY() <= RIM_Y + 3) {
                p.teleport(world, SpawnManager.SPAWN_X, SpawnManager.SPAWN_Y, SpawnManager.SPAWN_Z,
                        SpawnManager.SPAWN_YAW, 0.0F);
                p.fallDistance = 0.0F;
                p.sendMessage(new LiteralText("Ты вернулся на спавн").formatted(Formatting.GREEN), true);
            }
        }
    }

    // ------------------------------------------------------------------ вход в зале

    /** Площадка входа в зале (достраивается после постройки зала и при запуске, если её нет). */
    public static void ensureEntrance(ServerWorld world) {
        BlockPos c = hallPadCenter();
        if (world.getBlockState(c).getBlock() == Blocks.CRYING_OBSIDIAN) {
            return;
        }
        buildEntrance(world);
    }

    public static void buildEntrance(ServerWorld world) {
        BlockPos c = hallPadCenter();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                Block b = edge ? Blocks.GOLD_BLOCK : ((dx + dz) & 1) == 0 ? Blocks.RED_NETHER_BRICKS : Blocks.POLISHED_BLACKSTONE;
                if (Math.abs(dx) == 2 && Math.abs(dz) == 2) {
                    b = Blocks.SEA_LANTERN;
                }
                put(world, c.getX() + dx, c.getY(), c.getZ() + dz, b);
            }
        }
        put(world, c.getX(), c.getY(), c.getZ(), Blocks.CRYING_OBSIDIAN);
        if (world.isChunkLoaded(c)) {
            MinecraftServer server = world.getServer();
            String dim = SpawnWorld.key().getValue().toString();
            run(server, "execute in " + dim + " run kill @e[type=armor_stand,tag=arsenal_pad_label]");
            label(server, dim, c.getX() + 0.5, c.getY() + 2.2, c.getZ() + 0.5, "ПВП-арена", "red", "arsenal_pad_label");
            label(server, dim, c.getX() + 0.5, c.getY() + 1.8, c.getZ() + 0.5, "встань на площадку", "gray", "arsenal_pad_label");
        }
    }

    // ------------------------------------------------------------------ постройка

    private static void startBuild() {
        building = true;
        JOBS.clear();
        int minCx = (AX - RIM_HALF) >> 4;
        int maxCx = (AX + RIM_HALF) >> 4;
        int minCz = (AZ - RIM_HALF) >> 4;
        int maxCz = (AZ + RIM_HALF) >> 4;
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                JOBS.add(new int[]{cx, cz});
            }
        }
        System.out.println("[Arsenal] Строится ПВП-арена: " + JOBS.size() + " чанков, по 2 за тик");
    }

    private static void runJobs(MinecraftServer server, ServerWorld world) {
        for (int i = 0; i < 2 && !JOBS.isEmpty(); i++) {
            int[] c = JOBS.poll();
            buildColumn(world, c[0], c[1]);
        }
        if (JOBS.isEmpty()) {
            buildFeatures(server, world);
            building = false;
            built = true;
            System.out.println("[Arsenal] ПВП-арена построена");
        }
    }

    private static void put(ServerWorld world, int x, int y, int z, Block block) {
        world.setBlockState(new BlockPos(x, y, z), block.getDefaultState(), 18);
    }

    private static void put(ServerWorld world, int x, int y, int z, BlockState state) {
        world.setBlockState(new BlockPos(x, y, z), state, 18);
    }

    // ------------------------------------------------------------------ шум

    private static int hash(int a, int b, int c) {
        int h = a * 374761393 + b * 668265263 + c * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    private static int rnd(int a, int b, int c, int n) {
        return (hash(a, b, c) >>> 1) % n;
    }

    private static boolean nearHole(int dx, int dz, int margin) {
        for (int[] h : HOLES) {
            if (Math.abs(dx - h[0]) <= HOLE_HALF + margin && Math.abs(dz - h[1]) <= HOLE_HALF + margin) {
                return true;
            }
        }
        return false;
    }

    private static int holeIndex(int dx, int dz, int margin) {
        for (int i = 0; i < HOLES.length; i++) {
            if (Math.abs(dx - HOLES[i][0]) <= HOLE_HALF + margin && Math.abs(dz - HOLES[i][1]) <= HOLE_HALF + margin) {
                return i;
            }
        }
        return -1;
    }

    /** Столб в колонке (ячейка 12 на 12): {высота, материал, шапка} или null. */
    private static int[] pillar(int dx, int dz, int salt, int minH, int maxH) {
        int cx = Math.floorDiv(dx, 12);
        int cz = Math.floorDiv(dz, 12);
        if (rnd(cx, cz, salt, 100) >= 55) {
            return null;
        }
        int ox = cx * 12 + 1 + rnd(cx, cz, salt + 1, 8);
        int oz = cz * 12 + 1 + rnd(cx, cz, salt + 2, 8);
        int s = 1 + rnd(cx, cz, salt + 3, 3);
        if (dx < ox || dx >= ox + s || dz < oz || dz >= oz + s) {
            return null;
        }
        return new int[]{minH + rnd(cx, cz, salt + 4, maxH - minH + 1), rnd(cx, cz, salt + 5, PILLAR_MATS.length),
                rnd(cx, cz, salt + 6, 3)};
    }

    /** Низкая стенка-укрытие (ячейка 14 на 14): высота 3-4 или 0. */
    private static int lowWall(int dx, int dz) {
        int cx = Math.floorDiv(dx, 14);
        int cz = Math.floorDiv(dz, 14);
        if (rnd(cx, cz, 91, 100) >= 45) {
            return 0;
        }
        boolean alongX = rnd(cx, cz, 92, 2) == 0;
        int start = 1 + rnd(cx, cz, 93, 4);
        int len = 5 + rnd(cx, cz, 94, 5);
        int row = 2 + rnd(cx, cz, 95, 10);
        int a = alongX ? dx - cx * 14 : dz - cz * 14;
        int b = alongX ? dz - cz * 14 : dx - cx * 14;
        if (b == row && a >= start && a < start + len) {
            return 3 + rnd(cx, cz, 96, 2);
        }
        return 0;
    }

    /** Курган на первом этаже (ячейка 14 на 14, 5 на 5, высота до 3): высота или 0 и материал в [1]. */
    private static int[] mound(int dx, int dz) {
        int cx = Math.floorDiv(dx, 14);
        int cz = Math.floorDiv(dz, 14);
        if (rnd(cx, cz, 71, 100) >= 55) {
            return null;
        }
        int mx = cx * 14 + 3 + rnd(cx, cz, 72, 8);
        int mz = cz * 14 + 3 + rnd(cx, cz, 73, 8);
        int h = 3 - Math.max(Math.abs(dx - mx), Math.abs(dz - mz));
        if (h <= 0) {
            return null;
        }
        int ore = rnd(cx, cz, 74, 100) < 30 ? 1 + rnd(dx, dz, 75, ORES.length) : 0;
        return new int[]{h, rnd(cx, cz, 76, MOUND_MATS.length), ore};
    }

    private static Block floorBlock(int dx, int dz) {
        if (dx % 8 == 0 && dz % 8 == 0) {
            return Blocks.SEA_LANTERN;
        }
        int r = rnd(dx, dz, 5, 100);
        if (r < 40) {
            return Blocks.STONE_BRICKS;
        }
        if (r < 55) {
            return Blocks.CRACKED_STONE_BRICKS;
        }
        if (r < 67) {
            return Blocks.MOSSY_STONE_BRICKS;
        }
        if (r < 78) {
            return Blocks.ANDESITE;
        }
        if (r < 86) {
            return Blocks.POLISHED_BLACKSTONE_BRICKS;
        }
        if (r < 94) {
            return Blocks.GRAVEL;
        }
        return Blocks.COBBLESTONE;
    }

    private static Block firstFloorBlock(int dx, int dz) {
        int d = Math.max(Math.abs(dx), Math.abs(dz));
        if (d <= 2) {
            return Blocks.GOLD_BLOCK;
        }
        if (d <= 5) {
            return ((dx + dz) & 1) == 0 ? Blocks.SMOOTH_QUARTZ : Blocks.POLISHED_ANDESITE;
        }
        int r = rnd(dx, dz, 9, 100);
        if (r < 35) {
            return Blocks.SMOOTH_STONE;
        }
        if (r < 55) {
            return Blocks.POLISHED_ANDESITE;
        }
        if (r < 70) {
            return Blocks.STONE;
        }
        if (r < 82) {
            return Blocks.CUT_SANDSTONE;
        }
        if (r < 92) {
            return Blocks.GRAVEL;
        }
        return Blocks.COARSE_DIRT;
    }

    private static Block wallBlock(int x, int y, int z) {
        if (rnd(x + y * 31, z, 41, 100) < 5) {
            return ORES[rnd(x, y, z, ORES.length)];
        }
        return WALL_MATS[rnd(x, y, z, WALL_MATS.length)];
    }

    /** Верхняя отметка колонки вне дна ямы: ступени 3, 3 и 4 блока, дальше обход. */
    private static int topOf(int d) {
        if (d <= 44) {
            return FF_Y + 3;
        }
        if (d <= 48) {
            return FF_Y + 6;
        }
        return RIM_Y;
    }

    // ------------------------------------------------------------------ паркур вдоль стен

    /** Площадки паркура: {x, верхний y, z} для номеров 1..N (верх n-й площадки = FY + n). */
    private static final int[][] PARKOUR = computeParkour();
    private static final int PARKOUR_N = (RIM_Y - FY);

    private static int[][] computeParkour() {
        int n = RIM_Y - FY;
        int[][] out = new int[n + 1][];
        double u = 0.3;
        for (int i = 1; i <= n; i++) {
            int top = FY + i;
            int rel = Math.max(0, top - FF_Y);
            double r = 34.0 + 0.8 * rel;
            if (i > n - 4) {
                r += 4.5 * (i - (n - 4)) / 4.0;
            }
            if (i > 1) {
                u += 4.4 / (2.0 * r);
            }
            int side = (int) Math.floor(u) % 4;
            double f = u - Math.floor(u);
            double px;
            double pz;
            switch (side) {
                case 0:
                    px = -r + 2 * r * f;
                    pz = r;
                    break;
                case 1:
                    px = r;
                    pz = r - 2 * r * f;
                    break;
                case 2:
                    px = r - 2 * r * f;
                    pz = -r;
                    break;
                default:
                    px = -r;
                    pz = -r + 2 * r * f;
                    break;
            }
            out[i] = new int[]{AX + (int) Math.round(px - 0.5), top, AZ + (int) Math.round(pz - 0.5)};
        }
        return out;
    }

    /** Проём в первом этаже там, где паркур поднимается сквозь него (площадки, у которых голова упирается в плиту). */
    private static boolean inNotch(int x, int z) {
        for (int i = PARKOUR_N - 14; i <= PARKOUR_N; i++) {
            int[] p = PARKOUR[i];
            if (p == null || p[1] < FF_Y - 4 || p[1] > FF_Y) {
                continue;
            }
            if (x >= p[0] - 1 && x <= p[0] + 2 && z >= p[2] - 1 && z <= p[2] + 2) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ колонки

    /** Одна колонка чанка: пол и колонны глубокой арены, первый этаж, ступени карьера и обход. */
    private static void buildColumn(ServerWorld world, int chunkX, int chunkZ) {
        world.getChunk(chunkX, chunkZ);   // загрузить (создать) чанк
        for (int x = chunkX << 4; x < (chunkX << 4) + 16; x++) {
            for (int z = chunkZ << 4; z < (chunkZ << 4) + 16; z++) {
                int dx = x - AX;
                int dz = z - AZ;
                int d = Math.max(Math.abs(dx), Math.abs(dz));
                if (d > RIM_HALF) {
                    continue;
                }
                if (d <= HALF) {
                    buildInterior(world, x, z, dx, dz);
                } else {
                    buildRim(world, x, z, dx, dz, d);
                }
            }
        }
    }

    private static boolean decorOk(int dx, int dz, int limit) {
        return Math.max(Math.abs(dx), Math.abs(dz)) <= limit && !nearHole(dx, dz, 3) && !inNotch(AX + dx, AZ + dz);
    }

    private static void buildInterior(ServerWorld world, int x, int z, int dx, int dz) {
        // пол глубокой арены
        put(world, x, FY - 1, z, Blocks.STONE_BRICKS);
        put(world, x, FY, z, floorBlock(dx, dz));

        // воздух (в том числе убираем случайный рельеф)
        for (int y = FY + 1; y <= FF_Y - 2; y++) {
            if (!world.getBlockState(new BlockPos(x, y, z)).isAir()) {
                put(world, x, y, z, Blocks.AIR);
            }
        }

        // колонны и укрытия на полу (подальше от дыр, где приземляются, и от стены с паркуром)
        if (decorOk(dx, dz, 29) && !nearHole(dx, dz, 4)) {
            int[] p = pillar(dx, dz, 11, 6, 28);
            if (p != null) {
                Block mat = PILLAR_MATS[p[1]];
                for (int y = FY + 1; y <= FY + p[0]; y++) {
                    put(world, x, y, z, mat);
                }
                put(world, x, FY + p[0] + 1, z, p[2] == 0 ? Blocks.SEA_LANTERN : mat);
            }
            int w = lowWall(dx, dz);
            for (int y = FY + 1; y <= FY + w; y++) {
                put(world, x, y, z, WALL_MATS[rnd(dx, dz, 51, WALL_MATS.length)]);
            }
        }

        // первый этаж: плита в два слоя с дырами, проёмом паркура и лампами снизу
        int hole = holeIndex(dx, dz, 0);
        boolean notch = inNotch(x, z);
        if (hole >= 0 || notch) {
            put(world, x, FF_Y - 1, z, Blocks.AIR);
            put(world, x, FF_Y, z, Blocks.AIR);
        } else {
            put(world, x, FF_Y - 1, z, (Math.floorMod(dx, 8) == 4 && Math.floorMod(dz, 8) == 4) ? Blocks.SEA_LANTERN : Blocks.STONE_BRICKS);
            Block top = firstFloorBlock(dx, dz);
            if (holeIndex(dx, dz, 1) >= 0) {
                top = Blocks.GOLD_BLOCK;   // кайма дыры
            }
            put(world, x, FF_Y, z, top);
        }

        // курганы, колонны и руда на первом этаже (подальше от дыр, ядра и стен)
        if (hole < 0 && !notch && Math.max(Math.abs(dx), Math.abs(dz)) > 7 && decorOk(dx, dz, 30) && !nearHole(dx, dz, 2)) {
            int[] m = mound(dx, dz);
            if (m != null) {
                for (int h = 1; h <= m[0]; h++) {
                    Block b = m[2] > 0 && h == m[0] ? ORES[m[2] - 1] : MOUND_MATS[m[1]];
                    put(world, x, FF_Y + h, z, b);
                }
            } else {
                int[] p = pillar(dx, dz, 31, 2, 6);
                if (p != null && Math.max(Math.abs(dx), Math.abs(dz)) > 9) {
                    Block mat = PILLAR_MATS[p[1]];
                    for (int y = FF_Y + 1; y <= FF_Y + p[0]; y++) {
                        put(world, x, y, z, mat);
                    }
                    put(world, x, FF_Y + p[0] + 1, z, p[2] == 0 ? Blocks.SEA_LANTERN : mat);
                }
            }
        }
    }

    /** Колонки вне дна ямы: стены глубокой арены, ступени карьера, обход с оградой и фонарями. */
    private static void buildRim(ServerWorld world, int x, int z, int dx, int dz, int d) {
        int top = topOf(d);
        int base = d <= 44 ? FY - 1 : FF_Y - 6;
        for (int y = base; y < top; y++) {
            put(world, x, y, z, wallBlock(x, y, z));
        }
        // верхний слой: у ступеней "земля", на обходе плитка
        Block surface;
        if (d >= 49) {
            int r = rnd(dx, dz, 21, 100);
            surface = r < 40 ? Blocks.STONE_BRICKS : r < 65 ? Blocks.ANDESITE : r < 80 ? Blocks.POLISHED_ANDESITE
                    : r < 92 ? Blocks.GRAVEL : Blocks.COBBLESTONE;
            if (d == 49) {
                surface = Blocks.GOLD_BLOCK;   // кромка ямы
            }
        } else {
            surface = TREADS[rnd(dx, dz, 22, TREADS.length)];
        }
        put(world, x, top, z, surface);

        if (d >= 49) {
            // ограда по внешнему краю обхода
            if (d == RIM_HALF) {
                for (int y = top + 1; y <= top + 3; y++) {
                    put(world, x, y, z, Blocks.STONE_BRICKS);
                }
            }
            // фонари на столбиках вдоль обхода
            boolean post = (Math.abs(dx) == 55 && Math.floorMod(dz, 12) == 0) || (Math.abs(dz) == 55 && Math.floorMod(dx, 12) == 0);
            if (post) {
                put(world, x, top + 1, z, Blocks.COBBLESTONE_WALL);
                put(world, x, top + 2, z, Blocks.COBBLESTONE_WALL);
                put(world, x, top + 3, z, Blocks.SEA_LANTERN);
            }
        } else if (Math.floorMod(dx + dz, 9) == 0 && d == 41) {
            // лампы в стене у первого этажа
            put(world, x, FF_Y + 2, z, Blocks.GLOWSTONE);
        }
    }

    /** Ядро солнца, паркур, площадка возврата и подписи. */
    private static void buildFeatures(MinecraftServer server, ServerWorld world) {
        // Ядро солнца на первом этаже в центре: золотое основание 5x5, якорь возрождения с полными зарядами
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean corner = Math.abs(dx) == 2 && Math.abs(dz) == 2;
                put(world, AX + dx, FF_Y, AZ + dz, corner ? Blocks.SEA_LANTERN : Blocks.GOLD_BLOCK);
            }
        }
        put(world, AX, FF_Y, AZ, Blocks.GLOWSTONE);
        put(world, AX, FF_Y + 1, AZ, Blocks.RESPAWN_ANCHOR.getDefaultState().with(RespawnAnchorBlock.CHARGES, 4));
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                for (int h = 1; h <= 3; h++) {
                    put(world, AX + sx * 4, FF_Y + h, AZ + sz * 4, Blocks.POLISHED_BLACKSTONE_BRICKS);
                }
                put(world, AX + sx * 4, FF_Y + 4, AZ + sz * 4, Blocks.SEA_LANTERN);
            }
        }

        // паркур вдоль стен: от пола глубокой арены до обхода
        for (int i = 1; i <= PARKOUR_N; i++) {
            int[] p = PARKOUR[i];
            platform(world, p[0], p[1], p[2], 2);
        }

        // площадка возврата на спавн на обходе: 5 на 5
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                put(world, AX + dx, RIM_Y, AZ + PAD_DZ + dz, Blocks.GOLD_BLOCK);
            }
        }
        put(world, AX, RIM_Y, AZ + PAD_DZ, Blocks.EMERALD_BLOCK);

        // подписи (невидимые стойки с именем), старые убираются
        String dim = SpawnWorld.key().getValue().toString();
        run(server, "execute in " + dim + " run kill @e[type=armor_stand,tag=arsenal_pvp_label]");
        label(server, dim, AX + 0.5, FF_Y + 3.2, AZ + 0.5, "Ядро солнца", "gold", "arsenal_pvp_label");
        label(server, dim, AX + 0.5, RIM_Y + 2.2, AZ + PAD_DZ + 0.5, "На спавн", "green", "arsenal_pvp_label");
        label(server, dim, AX + 0.5, RIM_Y + 3.0, AZ + 51.5, "ПВП-арена: шагни в яму", "red", "arsenal_pvp_label");
    }

    /** Квадратная площадка side x side, верхняя грань на высоте topY (один угол лампа). */
    private static void platform(ServerWorld world, int x0, int topY, int z0, int side) {
        for (int a = 0; a < side; a++) {
            for (int b = 0; b < side; b++) {
                put(world, x0 + a, topY, z0 + b, (a == 0 && b == 0) ? Blocks.SEA_LANTERN : Blocks.QUARTZ_BLOCK);
            }
        }
    }

    private static void label(MinecraftServer server, String dim, double x, double y, double z, String text, String color, String tag) {
        run(server, "execute in " + dim + " run summon armor_stand " + x + " " + y + " " + z
                + " {Invisible:1b,Marker:1b,NoGravity:1b,CustomNameVisible:1b,Tags:[\"" + tag + "\"],"
                + "CustomName:'{\"text\":\"" + text + "\",\"color\":\"" + color + "\",\"bold\":true}'}");
    }

    private static void run(MinecraftServer server, String command) {
        try {
            server.getCommandManager().execute(server.getCommandSource().withSilent(), command);
        } catch (Exception ex) {
            System.err.println("[Arsenal] Арена: команда не выполнилась: " + ex);
        }
    }
}
