package com.arsenal.item;

import com.arsenal.Arsenal;
import com.arsenal.vi.VI;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/**
 * Боевые фрагменты и пузыри опыта нельзя "спрятать" выходом: при выходе с сервера и при входе в /hub они выпадают из инвентаря.
 * В эндер-сундуке можно хранить не больше одного стака БФ.
 */
public final class LeaveDrop {
    public static final int ENDER_BF_MAX = 64;

    private LeaveDrop() {
    }

    private static boolean valuable(ItemStack s) {
        if (s.isEmpty()) {
            return false;
        }
        VI vi = VI.of(s);
        return vi != null && (vi == Arsenal.BF || vi == Arsenal.EXP_BUBBLE);
    }

    /** Выбрасывает из инвентаря (и руки) боевые фрагменты и пузыри опыта. */
    public static void dropValuables(ServerPlayerEntity p) {
        List<ItemStack> all = new ArrayList<>(p.inventory.main);
        all.addAll(p.inventory.offHand);
        for (ItemStack s : all) {
            if (valuable(s)) {
                p.dropItem(s.copy(), true, false);
                s.setCount(0);
            }
        }
    }

    private static void limitEnderChest(ServerPlayerEntity p) {
        Inventory ec = p.getEnderChestInventory();
        int total = 0;
        for (int i = 0; i < ec.size(); i++) {
            ItemStack s = ec.getStack(i);
            if (!s.isEmpty() && VI.of(s) == Arsenal.BF) {
                total += s.getCount();
            }
        }
        int extra = total - ENDER_BF_MAX;
        if (extra <= 0) {
            return;
        }
        for (int i = ec.size() - 1; i >= 0 && extra > 0; i--) {
            ItemStack s = ec.getStack(i);
            if (s.isEmpty() || VI.of(s) != Arsenal.BF) {
                continue;
            }
            int take = Math.min(extra, s.getCount());
            ItemStack back = s.copy();
            back.setCount(take);
            s.decrement(take);
            if (s.isEmpty()) {
                ec.setStack(i, ItemStack.EMPTY);
            }
            extra -= take;
            p.inventory.offerOrDrop(p.world, back);
        }
        ec.markDirty();
        p.sendMessage(new LiteralText("В эндер-сундуке можно хранить не больше " + ENDER_BF_MAX
                + " боевых фрагментов: лишние возвращены вам.").formatted(Formatting.RED), false);
    }

    public static void init() {
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> dropValuables(handler.player));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) {
                return;
            }
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                limitEnderChest(p);
            }
        });
    }
}
