package com.arsenal.item;

import com.arsenal.Arsenal;
import com.arsenal.Lore;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Шлем и ботинки солнца (золотые с чарами Infinity без Починки и Прочности, неразрушимые, свойства незерита),
 * броневые элитры (свойства алмазного нагрудника) и нерушимые элитры.
 * Это обычные предметы с тегами, отдельной регистрации не нужно.
 */
public final class SunGear {
    private static final int SUN = 0xFFFF55;
    private static final int ORANGE = 0xFFAA00;

    private SunGear() {
    }

    /** Шлем солнца: чары шлема Infinity, кроме Прочности и Починки; неразрушим; как незеритовый шлем (с сопротивлением отбрасыванию). */
    public static ItemStack helmet() {
        ItemStack s = new ItemStack(Items.GOLDEN_HELMET);
        protections(s);
        s.addEnchantment(Enchantments.RESPIRATION, 3);
        s.addEnchantment(Enchantments.AQUA_AFFINITY, 1);
        attributes(s, "head", "sun_helmet", 3.0, 3.0, 0.1);
        s.getOrCreateTag().putString("ArsenalKit", "sun_helmet");
        unbreakable(s, true);
        name(s, "Шлем солнца", Formatting.YELLOW, false);
        lore(s, SUN,
                "- имеет свойства [[незеритового шлема]];",
                "- полностью [[неразрушим]];",
                "- возможно накладывать [[зачарования]].");
        return s;
    }

    /** Ботинки солнца: чары ботинок Infinity, кроме Прочности и Починки; неразрушимы; как незеритовые ботинки. */
    public static ItemStack boots() {
        ItemStack s = new ItemStack(Items.GOLDEN_BOOTS);
        protections(s);
        s.addEnchantment(Enchantments.SOUL_SPEED, 3);
        s.addEnchantment(Enchantments.DEPTH_STRIDER, 3);
        s.addEnchantment(Enchantments.FEATHER_FALLING, 4);
        attributes(s, "feet", "sun_boots", 3.0, 3.0, 0.1);
        unbreakable(s, true);
        name(s, "Ботинки солнца", Formatting.YELLOW, false);
        lore(s, SUN,
                "- имеет свойства [[незеритовых ботинок]];",
                "- полностью [[неразрушимы]];",
                "- можно накладывать [[зачарования]].");
        return s;
    }

    /** Броневые элитры: без чар, броня как у алмазного нагрудника, летают как обычные. */
    public static ItemStack armorElytra() {
        ItemStack s = new ItemStack(Items.ELYTRA);
        attributes(s, "chest", "armor_elytra", 8.0, 0.0, 0.0);
        s.getOrCreateTag().putString("ArsenalKit", "sun_armor_elytra");
        name(s, "Броневые элитры", Formatting.GOLD, false);
        lore(s, ORANGE,
                "- имеет свойства [[алмазного нагрудника]];",
                "- позволяет [[летать]] как обычная элитра;",
                "- возможно накладывать [[зачарования]].");
        return s;
    }

    /** Нерушимые элитры: обычные элитры с тегом Unbreakable. */
    public static ItemStack unbreakableElytra() {
        ItemStack s = new ItemStack(Items.ELYTRA);
        unbreakable(s, false);
        s.getOrCreateTag().putString("ArsenalKit", "sun_unbreakable_elytra");
        name(s, "Нерушимые элитры", Formatting.LIGHT_PURPLE, false);
        return s;
    }

    // ------------------------------------------------------------------ помощники

    /** Все защиты V и Непробиваемый II, как на броне Infinity. */
    private static void protections(ItemStack s) {
        s.addEnchantment(Enchantments.PROTECTION, 5);
        s.addEnchantment(Enchantments.FIRE_PROTECTION, 5);
        s.addEnchantment(Enchantments.BLAST_PROTECTION, 5);
        s.addEnchantment(Enchantments.PROJECTILE_PROTECTION, 5);
        s.addEnchantment(Arsenal.IMPENETRABLE, 2);
    }

    private static void unbreakable(ItemStack s, boolean hideLine) {
        NbtCompound tag = s.getOrCreateTag();
        tag.putBoolean("Unbreakable", true);
        if (hideLine) {
            tag.putInt("HideFlags", 4);
        }
    }

    private static void name(ItemStack s, String text, Formatting color, boolean bold) {
        s.setCustomName(new LiteralText(text).setStyle(Style.EMPTY.withColor(color).withItalic(false).withBold(bold)));
    }

    /** Строки «Особенности»: [[...]] красится цветом выделения. */
    private static void lore(ItemStack s, int highlight, String... lines) {
        NbtList list = new NbtList();
        list.add(NbtString.of(Text.Serializer.toJson(new LiteralText(""))));
        list.add(NbtString.of(Text.Serializer.toJson(
                new LiteralText("Особенности:").formatted(Formatting.DARK_GRAY).styled(st -> st.withItalic(false)))));
        for (String line : lines) {
            list.add(NbtString.of(Text.Serializer.toJson(Lore.parse(line, highlight))));
        }
        s.getOrCreateSubTag("display").put("Lore", list);
    }

    /** Свои модификаторы вместо золотых: броня, твёрдость, сопротивление отбрасыванию (0 - не добавлять). */
    private static void attributes(ItemStack s, String slot, String id, double armor, double toughness, double knockback) {
        NbtList list = new NbtList();
        modifier(list, "generic.armor", armor, slot, id);
        if (toughness > 0) {
            modifier(list, "generic.armor_toughness", toughness, slot, id);
        }
        if (knockback > 0) {
            modifier(list, "generic.knockback_resistance", knockback, slot, id);
        }
        s.getOrCreateTag().put("AttributeModifiers", list);
    }

    private static void modifier(NbtList list, String attribute, double amount, String slot, String id) {
        NbtCompound c = new NbtCompound();
        c.putString("AttributeName", attribute);
        c.putString("Name", attribute);
        c.putDouble("Amount", amount);
        c.putInt("Operation", 0);
        c.putString("Slot", slot);
        c.putUuid("UUID", UUID.nameUUIDFromBytes(("arsenal:" + id + ":" + attribute).getBytes(StandardCharsets.UTF_8)));
        list.add(c);
    }
}
