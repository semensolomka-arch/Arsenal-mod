package com.arsenal.item;

/** Зелье победителя: Сила III, Скорость III и Невидимость на 8 минут, Спешка II на 1:30, Регенерация II и Сопротивление II на 30 секунд и Исцеление II. Откат 5 минут. */
public final class WinnerPotionItem {
    public static int COOLDOWN_TICKS = 20 * 60 * 5;

    private WinnerPotionItem() {
    }
}
