package com.arsenal.item;

import com.arsenal.Lore;
import com.arsenal.vi.Lang;
import com.arsenal.vi.VI;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

/** Быстрая печка: выглядит как обычная печка, в инвентаре с блеском, плавит быстрее (множитель в настройках). */
public final class FastFurnace {
    public static final String ID = "fast_furnace";
    /** Во сколько раз быстрее (настройка fast_furnace_mult). */
    public static int MULT = 3;
    public static VI VI_ITEM;

    private FastFurnace() {
    }

    public static void init() {
        VI_ITEM = VI.register(ID, Items.FURNACE)
                .vanillaUse(true)
                .glint(true)
                .placeBlock(Blocks.FURNACE)
                .name(s -> new LiteralText(Lang.get("block.arsenal.fast_furnace")).formatted(Formatting.GOLD))
                .lore(s -> Lore.lines("tooltip.arsenal.fast_furnace.", 2, 0xFFA500));
    }
}
