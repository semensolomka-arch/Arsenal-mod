package com.arsenal.item;

import com.arsenal.vi.Cd;
import com.arsenal.Arsenal;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

/**
 * Пузырь опыта: ПКМ с ним в руке (из хотбара) чинит на 25% от максимальной прочности
 * всю надетую броню с Починкой. Кулдаун 3 минуты. Если чинить нечего, предмет не тратится.
 */
public final class ExpBubbleItem {
    public static int COOLDOWN_TICKS = 20 * 60 * 3;
    public static final int REPAIR_PERCENT = 25;

    private ExpBubbleItem() {
    }

    private static boolean canRepair(ItemStack armor) {
        return !armor.isEmpty() && armor.isDamaged() && EnchantmentHelper.getLevel(Enchantments.MENDING, armor) > 0;
    }

    public static boolean use(ServerPlayerEntity user, ItemStack stack) {
        boolean anything = false;
        for (ItemStack armor : user.getArmorItems()) {
            if (canRepair(armor)) {
                anything = true;
                break;
            }
        }
        if (!anything) {
            user.sendMessage(new LiteralText("Нечего чинить: нужна надетая повреждённая броня с Починкой.")
                    .formatted(Formatting.YELLOW), true);
            return false;
        }
        for (ItemStack armor : user.getArmorItems()) {
            if (canRepair(armor)) {
                int amount = Math.max(1, armor.getMaxDamage() * REPAIR_PERCENT / 100);
                armor.setDamage(Math.max(0, armor.getDamage() - amount));
            }
        }
        user.world.playSound(null, user.getX(), user.getY(), user.getZ(),
                SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
        Cd.set(user, Arsenal.EXP_BUBBLE, COOLDOWN_TICKS);
        if (!user.isCreative()) {
            stack.decrement(1);
        }
        return true;
    }
}
