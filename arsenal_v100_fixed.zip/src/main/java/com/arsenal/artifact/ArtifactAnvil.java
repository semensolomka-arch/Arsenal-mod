package com.arsenal.artifact;

import com.arsenal.Arsenal;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;

/**
 * Рецепт наковальни: Артефакт + предмет-эффект Хранителя опыта = Артефакт с этим эффектом, 10 уровней.
 * Предметы-эффекты между собой не совмещаются, только с Артефактом.
 */
public final class ArtifactAnvil {
    public static final int EFFECT_COST = 10;

    public static class Result {
        public final ItemStack stack;
        public final int cost;

        Result(ItemStack stack, int cost) {
            this.stack = stack;
            this.cost = cost;
        }
    }

    private ArtifactAnvil() {
    }

    /** null = это не наш рецепт, остаётся обычное поведение наковальни. */
    public static Result compute(ItemStack left, ItemStack right) {
        if (Arsenal.ARTIFACT.is(left)) {
            return add(left, right);
        }
        if (Arsenal.ARTIFACT.is(right)) {
            return add(right, left);
        }
        return null;
    }

    private static Result add(ItemStack artifact, ItemStack other) {
        ArtifactEffect effect = ArtifactEffect.byStack(other);
        if (effect == null) {
            return null;
        }
        if (com.arsenal.vi.VData.get(artifact, effect.key()) > 0) {
            return null; // такой эффект на Артефакте уже есть
        }
        ItemStack result = artifact.copy();
        result.setCount(1);
        com.arsenal.vi.VData.set(result, effect.key(), 1);
        return new Result(result, EFFECT_COST);
    }
}
