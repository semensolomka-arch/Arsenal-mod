package com.arsenal.priv;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Предмет привата: прочность хранится в NBT (PrivateDurability). С Shift (кроме уникального) ставится обычный блок. */
public final class PrivateBlockItem {
    public static final String DURABILITY_TAG = "PrivateDurability";

    private PrivateBlockItem() {
    }

    /** Прочность из предмета (нет тега значит полная). */
    public static int durabilityOf(ItemStack stack, PrivateType type) {
        NbtCompound tag = stack.getTag();
        if (tag != null && tag.contains(DURABILITY_TAG, 3)) {
            return Math.max(1, Math.min(type.durability, tag.getInt(DURABILITY_TAG)));
        }
        return type.durability;
    }

    /** Предмет привата с заданной прочностью (полная прочность хранится без тега, чтобы стакались). */
    public static ItemStack stackWith(PrivateType type, int durability) {
        ItemStack stack = type == PrivateType.UNIQUE ? type.vi.stack() : new ItemStack(type.vanillaBlock().asItem());
        if (durability < type.durability) {
            stack.getOrCreateTag().putInt(DURABILITY_TAG, durability);
            if (type == PrivateType.UNIQUE) {
                com.arsenal.vi.VI.refresh(stack);
            } else {
                // у обычных блоков своего описания нет, поэтому прочность пишем в Lore
                net.minecraft.nbt.NbtList lore = new net.minecraft.nbt.NbtList();
                lore.add(net.minecraft.nbt.NbtString.of(Text.Serializer.toJson(
                        new LiteralText("Прочность привата: " + durability + "/" + type.durability)
                                .formatted(Formatting.GRAY).styled(s -> s.withItalic(false)))));
                stack.getOrCreateSubTag("display").put("Lore", lore);
            }
        }
        return stack;
    }
}
