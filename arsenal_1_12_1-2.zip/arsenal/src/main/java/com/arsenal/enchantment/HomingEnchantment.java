package com.arsenal.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

/**
 * Самонаводка (только трезубец), уровни I-IV. Сама логика в TridentEntityMixin.
 * Уровень задаёт угол захвата цели относительно направления броска: 15 / 45 / 90 / 180 градусов.
 * Из стола зачарований можно получить только I или II (на книгу или трезубец), III и IV: наковальня и киты.
 * Все числа ниже можно менять здесь.
 */
public class HomingEnchantment extends Enchantment {
    /** Угол захвата по уровням (индекс = уровень - 1). */
    public static final double[] CONE_DEGREES = {15.0, 45.0, 90.0, 180.0};
    /** На сколько градусов за тик трезубец может довернуть к цели. */
    public static final double TURN_RATE_DEGREES = 10.0;
    /** Радиус поиска цели, блоков. */
    public static final double SEARCH_RADIUS = 64.0;
    /** Дальше этого расстояния от точки броска самонаводка отключается, блоков. */
    public static final double MAX_HOMING_DISTANCE = 80.0;
    /**
     * Прибавка урона за каждый пролетевший блок (по прямой от точки броска).
     * 73/60: на 60 блоках урон 8 + 73 = 81 до брони (по расчёту это чуть больше половины ХП
     * через полный незерит с Защитой V на всех частях и Сопротивлением I).
     */
    public static final double DAMAGE_PER_BLOCK = 73.0 / 60.0;

    public HomingEnchantment() {
        super(Rarity.UNCOMMON, EnchantmentTarget.TRIDENT, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
    }

    @Override
    public int getMaxLevel() {
        return 4;
    }

    // Стол зачарований: I на низких уровнях стола, II на высоких. III и IV стол выдать не может.
    @Override
    public int getMinPower(int level) {
        if (level == 1) {
            return 1;
        }
        if (level == 2) {
            return 20;
        }
        return 10000;
    }

    @Override
    public int getMaxPower(int level) {
        return level <= 2 ? getMinPower(level) + 30 : 10050;
    }

    // В торговле книгами с жителями не появляется
    @Override
    public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
}
