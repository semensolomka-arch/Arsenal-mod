package com.arsenal.mixin;

import com.arsenal.Arsenal;
import com.arsenal.enchantment.HomingEnchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Трезубец:
 *  1) самонаводка I-IV: захватывает ближайшую цель в конусе вокруг направления броска и доворачивает к ней;
 *     после 80 блоков от точки броска самонаводка отключается;
 *  2) урон растёт с расстоянием, которое пролетел трезубец (у любого трезубца, с самонаводкой или без).
 */
@Mixin(TridentEntity.class)
public abstract class TridentEntityMixin extends PersistentProjectileEntity {
    @Shadow
    private ItemStack tridentStack;

    @Shadow
    private boolean dealtDamage;

    /** Точка, где трезубец появился (начало полёта). */
    @Unique
    private Vec3d arsenal$origin;

    /** Направление в момент броска, от него считается угол захвата. */
    @Unique
    private Vec3d arsenal$launchDir;

    @Unique
    private LivingEntity arsenal$target;

    protected TridentEntityMixin(EntityType<? extends PersistentProjectileEntity> type, World world) {
        super(type, world);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void arsenal$homing(CallbackInfo ci) {
        if (arsenal$origin == null) {
            arsenal$origin = this.getPos();
            Vec3d v = this.getVelocity();
            if (v.lengthSquared() > 1.0E-6) {
                arsenal$launchDir = v.normalize();
            }
        }
        if (this.world.isClient || this.inGround || this.dealtDamage || this.isNoClip() || arsenal$launchDir == null) {
            return;
        }
        int level = EnchantmentHelper.getLevel(Arsenal.HOMING, this.tridentStack);
        if (level <= 0) {
            return;
        }
        level = Math.min(level, HomingEnchantment.CONE_DEGREES.length);
        double cone = HomingEnchantment.CONE_DEGREES[level - 1];

        // дальше 80 блоков от точки броска самонаводка не работает
        Vec3d pos = this.getPos();
        if (pos.distanceTo(arsenal$origin) > HomingEnchantment.MAX_HOMING_DISTANCE) {
            arsenal$target = null;
            return;
        }

        Entity owner = this.getOwner();

        // держим захваченную цель, пока она жива и всё ещё в конусе; иначе ищем ближайшую
        if (arsenal$target != null && !arsenal$stillValid(arsenal$target, pos, cone)) {
            arsenal$target = null;
        }
        if (arsenal$target == null) {
            arsenal$target = arsenal$findTarget(owner, pos, cone);
        }
        if (arsenal$target == null) {
            return;
        }

        Vec3d velocity = this.getVelocity();
        double speed = velocity.length();
        if (speed < 1.0E-4) {
            return;
        }
        Vec3d aim = arsenal$center(arsenal$target).subtract(pos);
        if (aim.lengthSquared() < 1.0E-6) {
            return;
        }
        Vec3d newDir = arsenal$rotateToward(velocity.normalize(), aim.normalize(),
                Math.toRadians(HomingEnchantment.TURN_RATE_DEGREES));
        // +0.05 по Y гасит гравитацию, которую трезубец применит в этом же тике
        this.setVelocity(newDir.multiply(speed).add(0.0, 0.05, 0.0));
        this.velocityModified = true; // отправить новую скорость клиентам сразу
    }

    @Unique
    private boolean arsenal$stillValid(LivingEntity target, Vec3d pos, double cone) {
        if (!target.isAlive() || target.world != this.world) {
            return false;
        }
        Vec3d to = arsenal$center(target).subtract(pos);
        double dist = to.length();
        return dist <= HomingEnchantment.SEARCH_RADIUS && dist > 1.0E-6 && arsenal$angle(arsenal$launchDir, to.multiply(1.0 / dist)) <= cone + 1.0E-3;
    }

    @Unique
    private LivingEntity arsenal$findTarget(Entity owner, Vec3d pos, double cone) {
        double r = HomingEnchantment.SEARCH_RADIUS;
        List<LivingEntity> list = this.world.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(r),
                e -> e != owner && e.isAlive() && !e.isSpectator() && !(e instanceof ArmorStandEntity)
                        && !(e instanceof PlayerEntity && ((PlayerEntity) e).isCreative())
                        && !(owner != null && e.isTeammate(owner)));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            Vec3d to = arsenal$center(e).subtract(pos);
            double dist = to.length();
            if (dist < 1.0E-6 || dist > r || dist >= bestDist) {
                continue;
            }
            if (arsenal$angle(arsenal$launchDir, to.multiply(1.0 / dist)) > cone + 1.0E-3) {
                continue;
            }
            if (!e.canSee(this)) { // цель за стеной не захватываем
                continue;
            }
            best = e;
            bestDist = dist;
        }
        return best;
    }

    @Unique
    private static Vec3d arsenal$center(Entity e) {
        return e.getPos().add(0.0, e.getHeight() * 0.5, 0.0);
    }

    /** Угол между двумя единичными векторами, градусы. */
    @Unique
    private static double arsenal$angle(Vec3d a, Vec3d b) {
        return Math.toDegrees(Math.acos(MathHelper.clamp(a.dotProduct(b), -1.0, 1.0)));
    }

    /** Поворачивает единичный вектор cur к единичному want не больше чем на maxRad радиан. */
    @Unique
    private static Vec3d arsenal$rotateToward(Vec3d cur, Vec3d want, double maxRad) {
        double angle = Math.acos(MathHelper.clamp(cur.dotProduct(want), -1.0, 1.0));
        if (angle <= maxRad) {
            return want;
        }
        Vec3d axis = cur.crossProduct(want);
        if (axis.lengthSquared() < 1.0E-8) { // цель строго позади: ось любая, перпендикулярная движению
            axis = cur.crossProduct(new Vec3d(0.0, 1.0, 0.0));
            if (axis.lengthSquared() < 1.0E-8) {
                axis = new Vec3d(1.0, 0.0, 0.0);
            }
        }
        axis = axis.normalize();
        return cur.multiply(Math.cos(maxRad)).add(axis.crossProduct(cur).multiply(Math.sin(maxRad))).normalize();
    }

    /** Урон трезубца растёт с пролетевшим расстоянием (по прямой от точки броска). */
    @ModifyArg(method = "onEntityHit", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"), index = 1)
    private float arsenal$distanceDamage(float damage) {
        if (arsenal$origin == null) {
            return damage;
        }
        double distance = this.getPos().distanceTo(arsenal$origin);
        return damage + (float) (distance * HomingEnchantment.DAMAGE_PER_BLOCK);
    }
}
