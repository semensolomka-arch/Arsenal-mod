package com.arsenal.rune;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.util.Formatting;

/**
 * Руны для тотемов и талисманов. Руна лежит на тотеме служебным зачарованием и срабатывает вместе с ним.
 * Текстура предмета-руны это зачарованный краситель (dye), цвет надписи на тотеме совпадает с цветом красителя.
 */
public enum RuneType {
    IMMORTALITY("immortality", "Бессмертие", "yellow_dye", Formatting.YELLOW),
    RESTORATION("restoration", "Восстановление", "red_dye", Formatting.RED),
    THORNS("thorns", "Шипы", "blue_dye", Formatting.BLUE),
    LAST_CHANCE("last_chance", "Последний шанс", "green_dye", Formatting.DARK_GREEN),
    RESISTANCE("resistance", "Сопротивление", "gray_dye", Formatting.DARK_GRAY),
    RUN("run", "Пора бежать", "light_blue_dye", Formatting.AQUA),
    STRENGTH("strength", "Сила", "pink_dye", Formatting.LIGHT_PURPLE),
    // жёлтый краситель, как и у Бессмертия; цвет надписи чуть темнее, чтобы руны различались
    REGENERATION("regeneration", "Регенерация", "yellow_dye", Formatting.GOLD),
    LEAP("leap", "Прыжки веры", "lime_dye", Formatting.GREEN);

    public final String id;
    public final String title;
    public final String dye;
    public final Formatting color;

    /** Заполняются при регистрации. */
    public Item item;
    public Enchantment enchantment;

    RuneType(String id, String title, String dye, Formatting color) {
        this.id = id;
        this.title = title;
        this.dye = dye;
        this.color = color;
    }

    /** Несовместимые руны: Сопротивление и Бессмертие, Регенерация и Восстановление. */
    public boolean conflictsWith(RuneType other) {
        return (this == RESISTANCE && other == IMMORTALITY) || (this == IMMORTALITY && other == RESISTANCE)
                || (this == REGENERATION && other == RESTORATION) || (this == RESTORATION && other == REGENERATION);
    }
}
