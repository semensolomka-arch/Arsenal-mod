package com.arsenal.blast;

import com.arsenal.Lore;
import com.arsenal.vi.Lang;
import com.arsenal.vi.Marks;
import com.arsenal.vi.VI;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.Generic3x3ContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ТНТ-пушка: выглядит как зачарованный раздатчик. Работает только средний слот и только ТНТ (не стиллеры и не ледяная волна).
 * Редстоун-сигнал выстреливает один ТНТ вперёд (см. BlastDispenser и CannonShell).
 */
public final class TntCannon {
    public static final String ID = "tnt_cannon";
    /** Дальность полёта, блоков (настройка cannon_range). */
    public static int RANGE = 150;
    /** Скорость, десятых блока за тик (настройка cannon_speed). */
    public static int SPEED = 15;
    public static VI VI_ITEM;

    private TntCannon() {
    }

    public static void register() {
        VI_ITEM = VI.register(ID, Items.DISPENSER)
                .vanillaUse(true)
                .glint(true)
                .placeBlock(Blocks.DISPENSER)
                .name(s -> new LiteralText(Lang.get("block.arsenal.tnt_cannon")).formatted(Formatting.RED))
                .lore(s -> Lore.lines("tooltip.arsenal.tnt_cannon.", 9, 0xFF5555));
    }

    public static boolean isCannon(World world, BlockPos pos) {
        return ID.equals(Marks.idAt(world, pos)) && world.getBlockState(pos).getBlock() == Blocks.DISPENSER;
    }

    /** Подходящий заряд: обычный ТНТ или взрывчатка мода, кроме стиллеров и ледяной волны. */
    public static boolean canLoad(ItemStack st) {
        if (st.isEmpty() || st.getItem() != Items.TNT) {
            return false;
        }
        VI vi = VI.of(st);
        if (vi == null) {
            return !st.hasTag() || st.getTag().isEmpty();
        }
        BlastKind k = BlastKind.byId(vi.id);
        return k != null && k.mode != BlastKind.Mode.STEALER && k.mode != BlastKind.Mode.ICE && k.mode != BlastKind.Mode.VAPORIZE;
    }

    /** Выстрел из пушки в позиции pos в сторону facing. Заряд не расходуется здесь. */
    public static void fire(World world, BlockPos pos, Direction facing, ItemStack ammo) {
        VI vi = VI.of(ammo);
        BlastKind kind = vi == null ? null : BlastKind.byId(vi.id);
        Vec3d dir = new Vec3d(facing.getOffsetX(), facing.getOffsetY(), facing.getOffsetZ());
        Vec3d start = Vec3d.ofCenter(pos).add(dir.multiply(0.7));
        BlockPos next = pos.offset(facing);
        if (!world.getBlockState(next).getCollisionShape(world, next).isEmpty()) {
            // упёрлись в блок вплотную: взрыв сразу у дула
            Vec3d at = Vec3d.ofCenter(pos).add(dir.multiply(0.55));
            CannonShell shell = new CannonShell(world, at.x, at.y, at.z, dir, 0.0, 0.0, kind);
            world.spawnEntity(shell);
            return;
        }
        CannonShell shell = new CannonShell(world, start.x, start.y, start.z, dir, SPEED / 10.0, RANGE, kind);
        world.spawnEntity(shell);
        world.playSound(null, start.x, start.y, start.z, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
        world.playSound(null, start.x, start.y, start.z, SoundEvents.BLOCK_DISPENSER_LAUNCH, SoundCategory.BLOCKS, 1.0F, 0.6F);
    }

    /** Окно пушки: ванильное 3x3, но класть можно только ТНТ и только в средний слот. */
    private static final class View implements Inventory {
        private final DispenserBlockEntity be;

        View(DispenserBlockEntity be) {
            this.be = be;
        }

        @Override
        public int size() {
            return 9;
        }

        @Override
        public boolean isEmpty() {
            return be.isEmpty();
        }

        @Override
        public ItemStack getStack(int slot) {
            return be.getStack(slot);
        }

        @Override
        public ItemStack removeStack(int slot, int amount) {
            return be.removeStack(slot, amount);
        }

        @Override
        public ItemStack removeStack(int slot) {
            return be.removeStack(slot);
        }

        @Override
        public void setStack(int slot, ItemStack stack) {
            be.setStack(slot, stack);
        }

        @Override
        public void markDirty() {
            be.markDirty();
        }

        @Override
        public boolean canPlayerUse(PlayerEntity player) {
            return be.canPlayerUse(player);
        }

        @Override
        public boolean isValid(int slot, ItemStack stack) {
            return slot == 4 && canLoad(stack);
        }

        @Override
        public void clear() {
            be.clear();
        }
    }

    public static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || player.isSpectator() || player.isSneaking()) {
                return ActionResult.PASS;
            }
            BlockPos pos = hit.getBlockPos();
            if (!isCannon(world, pos)) {
                return ActionResult.PASS;
            }
            BlockEntity be = world.getBlockEntity(pos);
            if (!(be instanceof DispenserBlockEntity) || !(player instanceof ServerPlayerEntity)) {
                return ActionResult.PASS;
            }
            final View view = new View((DispenserBlockEntity) be);
            player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                    (id, pi, pl) -> new Generic3x3ContainerScreenHandler(id, pi, view),
                    new LiteralText("ТНТ-пушка (только средний слот)")));
            return ActionResult.SUCCESS;
        });
    }
}
