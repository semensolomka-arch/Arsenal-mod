package com.arsenal.coin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.AmbientEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.WaterCreatureEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.registry.Registry;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Монеты (¤): баланс игроков и награда за убийство мобов. Настройки лежат в config/arsenal_coins.json
 * (правятся через меню оп): мирные от-до, враждебные от-до и исключения по конкретным мобам.
 * Монеты также выдаёт скупщик (поле "coins" у предмета).
 */
public final class Coins {
    public static final String SIGN = "¤";   // ¤
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Random RNG = new Random();

    private static final Map<UUID, Long> BALANCE = new HashMap<>();
    private static boolean dirty;
    private static MinecraftServer server;

    private static int passiveMin = 1;
    private static int passiveMax = 3;
    private static int hostileMin = 2;
    private static int hostileMax = 5;
    /** id моба -> {min, max}. */
    private static final Map<String, int[]> EXCEPTIONS = new HashMap<>();
    private static long cfgModified = Long.MIN_VALUE;
    /** Чтобы за одну смерть не начислить дважды. */
    private static final Set<UUID> REWARDED = new HashSet<>();

    private Coins() {
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(Coins::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            int t = s.getTicks();
            if (t % 600 == 0 && dirty) {
                save();
            }
        });
        CommandRegistrationCallback.EVENT.register((d, dedicated) -> d.register(CommandManager.literal("coins")
                .executes(c -> show(c.getSource()))
                .then(CommandManager.literal("give").requires(s -> s.hasPermissionLevel(2))
                        .then(CommandManager.argument("ник", StringArgumentType.word())
                                .then(CommandManager.argument("сколько", LongArgumentType.longArg())
                                        .executes(c -> give(c.getSource(), StringArgumentType.getString(c, "ник"),
                                                LongArgumentType.getLong(c, "сколько"))))))));
    }

    // ---------------------------------------------------------------- баланс

    public static long balance(UUID id) {
        Long v = BALANCE.get(id);
        return v == null ? 0L : v;
    }

    public static void add(UUID id, long amount) {
        if (amount == 0) {
            return;
        }
        BALANCE.put(id, Math.max(0L, balance(id) + amount));
        dirty = true;
    }

    private static int show(ServerCommandSource src) {
        try {
            ServerPlayerEntity p = src.getPlayer();
            p.sendMessage(new LiteralText("Ваши монеты: " + balance(p.getUuid()) + SIGN).formatted(Formatting.GOLD), false);
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    private static int give(ServerCommandSource src, String nick, long n) {
        ServerPlayerEntity t = src.getMinecraftServer().getPlayerManager().getPlayer(nick);
        if (t == null) {
            src.sendFeedback(new LiteralText("Игрок не в сети").formatted(Formatting.RED), false);
            return 0;
        }
        add(t.getUuid(), n);
        src.sendFeedback(new LiteralText(nick + ": " + balance(t.getUuid()) + SIGN).formatted(Formatting.GREEN), false);
        return 1;
    }

    /** /b wipe: обнуляет монеты у всех. */
    public static int wipeAll() {
        int n = BALANCE.size();
        BALANCE.clear();
        dirty = true;
        save();
        return n;
    }

    public static void wipe(UUID id) {
        BALANCE.remove(id);
        dirty = true;
        save();
    }

    // ---------------------------------------------------------------- убийства

    private static boolean isHostile(Entity e) {
        return e instanceof Monster;
    }

    private static boolean isPassive(Entity e) {
        return e instanceof AnimalEntity || e instanceof PassiveEntity || e instanceof WaterCreatureEntity
                || e instanceof AmbientEntity;
    }

    /** Вызывается при смерти моба (не игрока). */
    public static void onKill(LivingEntity victim, DamageSource source) {
        if (source == null || !(source.getAttacker() instanceof ServerPlayerEntity)) {
            return;
        }
        if (victim.getScoreboardTags().contains("arsenal_boss") || victim.getScoreboardTags().contains("arsenal_bm")
                || victim.getScoreboardTags().contains("arsenal_proxy")) {
            return;
        }
        if (!REWARDED.add(victim.getUuid())) {
            return;
        }
        if (REWARDED.size() > 500) {
            REWARDED.clear();
            REWARDED.add(victim.getUuid());
        }
        reloadIfChanged();
        String id = Registry.ENTITY_TYPE.getId(victim.getType()).toString();
        int min;
        int max;
        int[] ex = EXCEPTIONS.get(id);
        if (ex != null) {
            min = ex[0];
            max = ex[1];
        } else if (isHostile(victim)) {
            min = hostileMin;
            max = hostileMax;
        } else if (isPassive(victim)) {
            min = passiveMin;
            max = passiveMax;
        } else {
            return;
        }
        if (max < min) {
            max = min;
        }
        int amount = min + RNG.nextInt(max - min + 1);
        ServerPlayerEntity k0 = (ServerPlayerEntity) source.getAttacker();
        int rich = net.minecraft.enchantment.EnchantmentHelper.getLevel(com.arsenal.tool.ToolEnchants.RICH, k0.getMainHandStack());
        if (rich > 1 && amount > 0) {
            amount *= rich;   // Богач: монеты с мобов умножаются на уровень
        }
        if (amount <= 0) {
            return;
        }
        ServerPlayerEntity killer = (ServerPlayerEntity) source.getAttacker();
        add(killer.getUuid(), amount);
        killer.sendMessage(new LiteralText("Вы убили " + RuNames.accusative(id, victim) + " и получили " + amount + SIGN)
                .formatted(Formatting.GOLD), false);
    }

    // ---------------------------------------------------------------- файлы

    public static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_coins.json");
    }

    public static JsonObject defaultJson() {
        JsonObject root = new JsonObject();
        root.add("passive", range(1, 3));
        root.add("hostile", range(2, 5));
        JsonArray ex = new JsonArray();
        ex.add(exception("minecraft:ender_dragon", 500, 500));
        ex.add(exception("minecraft:wither", 300, 300));
        ex.add(exception("minecraft:villager", 0, 0));
        ex.add(exception("minecraft:wandering_trader", 0, 0));
        ex.add(exception("minecraft:iron_golem", 0, 0));
        root.add("exceptions", ex);
        return root;
    }

    private static JsonObject range(int min, int max) {
        JsonObject o = new JsonObject();
        o.addProperty("min", min);
        o.addProperty("max", max);
        return o;
    }

    private static JsonObject exception(String mob, int min, int max) {
        JsonObject o = range(min, max);
        o.addProperty("mob", mob);
        return o;
    }

    public static void ensureConfig() {
        try {
            if (!Files.exists(configPath())) {
                Files.createDirectories(configPath().getParent());
                Files.write(configPath(), GSON.toJson(defaultJson()).getBytes(StandardCharsets.UTF_8));
            }
        } catch (IOException e) {
            System.err.println("[Arsenal] Не удалось создать arsenal_coins.json: " + e);
        }
    }

    private static int num(JsonObject o, String k, int def) {
        try {
            return o.has(k) ? Math.max(0, o.get(k).getAsInt()) : def;
        } catch (Exception e) {
            return def;
        }
    }

    public static void reloadIfChanged() {
        ensureConfig();
        try {
            long stamp = Files.getLastModifiedTime(configPath()).toMillis();
            if (stamp == cfgModified) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(configPath()), StandardCharsets.UTF_8)).getAsJsonObject();
            if (root.has("passive")) {
                passiveMin = num(root.getAsJsonObject("passive"), "min", 1);
                passiveMax = num(root.getAsJsonObject("passive"), "max", 3);
            }
            if (root.has("hostile")) {
                hostileMin = num(root.getAsJsonObject("hostile"), "min", 2);
                hostileMax = num(root.getAsJsonObject("hostile"), "max", 5);
            }
            EXCEPTIONS.clear();
            if (root.has("exceptions")) {
                for (JsonElement el : root.getAsJsonArray("exceptions")) {
                    JsonObject o = el.getAsJsonObject();
                    if (o.has("mob")) {
                        int min = num(o, "min", 0);
                        EXCEPTIONS.put(o.get("mob").getAsString(), new int[]{min, Math.max(min, num(o, "max", min))});
                    }
                }
            }
            cfgModified = stamp;
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_coins.json: " + e);
        }
    }

    private static Path dataFile(MinecraftServer s) {
        return s.getSavePath(WorldSavePath.ROOT).resolve("arsenal_coins_data.json");
    }

    private static void load(MinecraftServer s) {
        server = s;
        BALANCE.clear();
        cfgModified = Long.MIN_VALUE;
        reloadIfChanged();
        Path f = dataFile(s);
        if (!Files.exists(f)) {
            return;
        }
        try {
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : root.entrySet()) {
                BALANCE.put(UUID.fromString(e.getKey()), e.getValue().getAsLong());
            }
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать монеты: " + e);
        }
    }

    private static void save() {
        if (server == null) {
            return;
        }
        JsonObject root = new JsonObject();
        for (Map.Entry<UUID, Long> e : BALANCE.entrySet()) {
            root.addProperty(e.getKey().toString(), e.getValue());
        }
        try {
            Files.write(dataFile(server), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
            dirty = false;
        } catch (IOException e) {
            System.err.println("[Arsenal] Не удалось сохранить монеты: " + e);
        }
    }
}
