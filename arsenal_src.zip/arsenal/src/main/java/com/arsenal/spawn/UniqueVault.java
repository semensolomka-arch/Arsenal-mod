package com.arsenal.spawn;

import com.arsenal.event.CargoLoot;
import com.arsenal.item.UniversalKey;
import com.arsenal.vi.VI;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

/**
 * Хранилище на спавне (/warp unique): шалкер, который открывается универсальным ключом. Внутри место как в двойном сундуке
 * и очень хороший лут (таблица "vault" в arsenal_cargo.json, правится в меню оп). Первые 60 секунд лут может брать только
 * тот, кто открыл. Пока в хранилище что-то осталось, ключ не нужен (после 60 секунд остатки может забрать любой).
 */
public final class UniqueVault {
    /** Смещение шалкера от центра зала. */
    public static final int DX = 22;
    public static final int DZ = -22;
    public static final int LOCK_TICKS = 20 * 60;

    private static final SimpleInventory INV = new SimpleInventory(54);
    private static UUID owner;
    private static String ownerName = "";
    private static long lockUntil;
    private static boolean dirty;
    private static MinecraftServer server;

    private UniqueVault() {
    }

    public static BlockPos pos() {
        return new BlockPos(SpawnManager.CX + DX, SpawnManager.FLOOR_Y + 1, SpawnManager.CZ + DZ);
    }

    /** Точка /warp unique: перед хранилищем, лицом к нему. */
    public static double[] warpPoint() {
        BlockPos p = pos();
        return new double[]{p.getX() + 0.5, SpawnManager.FLOOR_Y + 1.0, p.getZ() + 5.5, 180.0};
    }

    /** Строит постамент, шалкер и табличку (если их ещё нет). */
    public static void ensure(ServerWorld world) {
        BlockPos p = pos();
        if (world.getBlockState(p).getBlock() == Blocks.PURPLE_SHULKER_BOX
                && world.getBlockState(p.down()).getBlock() == Blocks.GOLD_BLOCK) {
            return;
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                world.setBlockState(p.add(dx, -1, dz), Blocks.GOLD_BLOCK.getDefaultState(), 18);
                if (dx != 0 || dz != 0) {
                    world.setBlockState(p.add(dx, 0, dz), Blocks.AIR.getDefaultState(), 18);
                }
            }
        }
        world.setBlockState(p, Blocks.PURPLE_SHULKER_BOX.getDefaultState(), 18);
        SpawnManager.sign(world, p.add(0, 0, 3), 0,
                new LiteralText("[ ХРАНИЛИЩЕ ]").formatted(Formatting.GOLD, Formatting.BOLD),
                new LiteralText("Открывается").formatted(Formatting.DARK_PURPLE),
                new LiteralText("универсальным").formatted(Formatting.DARK_PURPLE),
                new LiteralText("ключом").formatted(Formatting.DARK_PURPLE));
    }

    public static boolean isVault(net.minecraft.world.World world, BlockPos pos) {
        return pos.equals(pos()) && world.getBlockState(pos).getBlock() instanceof ShulkerBoxBlock;
    }

    private static boolean hasLoot() {
        return !INV.isEmpty();
    }

    private static ItemStack findKey(PlayerEntity p) {
        for (ItemStack st : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            VI vi = VI.of(st);
            if (vi != null && UniversalKey.ID.equals(vi.id)) {
                return st;
            }
        }
        return null;
    }

    /** Окно хранилища: только брать, класть нельзя. */
    private static final class View implements Inventory {
        @Override
        public int size() {
            return INV.size();
        }

        @Override
        public boolean isEmpty() {
            return INV.isEmpty();
        }

        @Override
        public ItemStack getStack(int slot) {
            return INV.getStack(slot);
        }

        @Override
        public ItemStack removeStack(int slot, int amount) {
            return INV.removeStack(slot, amount);
        }

        @Override
        public ItemStack removeStack(int slot) {
            return INV.removeStack(slot);
        }

        @Override
        public void setStack(int slot, ItemStack stack) {
            INV.setStack(slot, stack);
        }

        @Override
        public void markDirty() {
            INV.markDirty();
        }

        @Override
        public boolean canPlayerUse(PlayerEntity player) {
            return true;
        }

        @Override
        public boolean isValid(int slot, ItemStack stack) {
            return false;
        }

        @Override
        public void clear() {
        }
    }

    private static void open(ServerPlayerEntity p) {
        final View view = new View();
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, pi, pl) -> GenericContainerScreenHandler.createGeneric9x6(id, pi, view),
                new LiteralText("Хранилище")));
    }

    private static ActionResult use(ServerPlayerEntity p) {
        long now = p.getServer().getTicks();
        if (hasLoot()) {
            if (owner != null && !owner.equals(p.getUuid()) && now < lockUntil) {
                long left = (lockUntil - now + 19) / 20;
                p.sendMessage(new LiteralText("Хранилище открыл " + ownerName + ": его лут доступен только ему ещё " + left + " сек")
                        .formatted(Formatting.RED), false);
                return ActionResult.FAIL;
            }
            open(p);
            return ActionResult.SUCCESS;
        }
        ItemStack key = findKey(p);
        if (key == null) {
            p.sendMessage(new LiteralText("Нужен универсальный ключ").formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }
        key.decrement(1);
        INV.clear();
        List<ItemStack> loot = CargoLoot.rollFlat("vault");
        CargoLoot.fill(INV, loot);
        owner = p.getUuid();
        ownerName = p.getGameProfile().getName();
        lockUntil = now + LOCK_TICKS;
        dirty = true;
        p.sendMessage(new LiteralText("Хранилище открыто! Первые 60 секунд лут только ваш").formatted(Formatting.GOLD), false);
        open(p);
        return ActionResult.SUCCESS;
    }

    // ---------------------------------------------------------------- сохранение остатков

    private static Path file(MinecraftServer s) {
        return s.getSavePath(WorldSavePath.ROOT).resolve("arsenal_vault.json");
    }

    private static void load(MinecraftServer s) {
        server = s;
        INV.clear();
        owner = null;
        Path f = file(s);
        if (!Files.exists(f)) {
            return;
        }
        try {
            JsonArray arr = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                ItemStack st = new ItemStack(Registry.ITEM.get(new Identifier(o.get("id").getAsString())), o.get("count").getAsInt());
                if (o.has("tag")) {
                    st.setTag(StringNbtReader.parse(o.get("tag").getAsString()));
                }
                int slot = o.get("slot").getAsInt();
                if (slot >= 0 && slot < INV.size()) {
                    INV.setStack(slot, st);
                }
            }
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось прочитать хранилище: " + e);
        }
        dirty = false;
    }

    private static void save() {
        if (server == null) {
            return;
        }
        JsonArray arr = new JsonArray();
        for (int i = 0; i < INV.size(); i++) {
            ItemStack st = INV.getStack(i);
            if (st.isEmpty()) {
                continue;
            }
            JsonObject o = new JsonObject();
            o.addProperty("slot", i);
            o.addProperty("id", Registry.ITEM.getId(st.getItem()).toString());
            o.addProperty("count", st.getCount());
            if (st.hasTag()) {
                o.addProperty("tag", st.getTag().toString());
            }
            arr.add(o);
        }
        try {
            Files.write(file(server), arr.toString().getBytes(StandardCharsets.UTF_8));
            dirty = false;
        } catch (Exception e) {
            System.err.println("[Arsenal] Не удалось сохранить хранилище: " + e);
        }
    }

    public static void init() {
        INV.addListener(i -> dirty = true);
        ServerLifecycleEvents.SERVER_STARTED.register(UniqueVault::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (s.getTicks() % 200 == 0 && dirty) {
                save();
            }
        });
        // раньше защиты зоны: иначе "шалкеры замка нельзя открывать" перехватит клик
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity) || player.isSpectator()) {
                return ActionResult.PASS;
            }
            if (!isVault(world, hit.getBlockPos())) {
                return ActionResult.PASS;
            }
            if (hand != net.minecraft.util.Hand.MAIN_HAND) {
                return ActionResult.FAIL;
            }
            return use((ServerPlayerEntity) player);
        });
    }
}
