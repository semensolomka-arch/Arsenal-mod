package com.arsenal.event;

import com.arsenal.priv.PrivateManager;
import com.arsenal.protection.SpawnProtection;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.MessageType;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Ивент "Груз": раз в 15 минут в Обычном мире (до 4000 блоков от центра) появляется мирный или взрывной груз.
 * 4 шалкера на кварцевых (мирный) или бастионных (взрывной) площадках, круглая зона 50x50 с краем из шерсти.
 * Через 8 минут груз открывается: мирный отталкивает всех без урона, взрывной взрывает каждый шалкер как
 * динамит Б (блоки не ломаются). Ещё 5 минут лут можно забирать, потом груз исчезает, местность возвращается.
 * В мирной зоне нет PvP. В зоне нельзя ломать, строить, взрывать блоки, ставить приваты и трапки.
 *
 * Команды: /event, /event freeze|unfreeze, /event spawn груз мирный|взрывной, /event time skip.
 */
public final class EventManager {
    public enum Type {
        PEACE("peace", "Мирный груз", Formatting.AQUA, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.QUARTZ_BLOCK, Blocks.LIGHT_BLUE_WOOL),
        EXPLOSIVE("explosive", "Взрывной груз", Formatting.GOLD, Blocks.ORANGE_SHULKER_BOX, Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.ORANGE_WOOL);

        final String key;
        public final String title;
        final Formatting color;
        final Block shulker;
        final Block base;
        final Block ring;

        Type(String key, String title, Formatting color, Block shulker, Block base, Block ring) {
            this.key = key;
            this.title = title;
            this.color = color;
            this.shulker = shulker;
            this.base = base;
            this.ring = ring;
        }

        static Type byKey(String key) {
            return "explosive".equals(key) ? EXPLOSIVE : PEACE;
        }
    }

    static final class Cargo {
        Type type;
        int cx, cy, cz;
        int age;
        boolean opened;
        boolean blasting;
        int blastTick;
        int blastIndex;
        final List<BlockPos> shulkers = new ArrayList<>();
        final Map<Long, Integer> saved = new LinkedHashMap<>();
    }

    public static final int INTERVAL = 20 * 60 * 15;
    public static final int OPEN_AT = 20 * 60 * 8;
    public static final int STAY = 20 * 60 * 5;
    /** Радиус зоны: 50 блоков в диаметре. */
    public static final double RADIUS = 25.5;
    private static final int MAX_DISTANCE = 4000;
    private static final int HALF = 11;
    private static final Random RNG = new Random();

    private static int nextIn = INTERVAL;
    private static boolean frozen;
    private static Cargo active;
    private static boolean loaded;

    private EventManager() {
    }

    // ------------------------------------------------------------------ зона

    public static boolean inZone(World world, double x, double z) {
        Cargo c = active;
        if (c == null || world.getRegistryKey() != World.OVERWORLD) {
            return false;
        }
        double dx = x - (c.cx + 0.5);
        double dz = z - (c.cz + 0.5);
        return dx * dx + dz * dz <= RADIUS * RADIUS;
    }

    public static boolean inZone(World world, BlockPos pos) {
        return inZone(world, pos.getX() + 0.5, pos.getZ() + 0.5);
    }

    /** В зоне мирного груза PvP выключено. */
    public static boolean peaceAt(World world, double x, double z) {
        return active != null && active.type == Type.PEACE && inZone(world, x, z);
    }

    /** Шалкер текущего груза. -1: не шалкер груза, 0: закрыт, 1: можно открывать. */
    static int shulkerState(World world, BlockPos pos) {
        Cargo c = active;
        if (c == null || world.getRegistryKey() != World.OVERWORLD || !c.shulkers.contains(pos)) {
            return -1;
        }
        return c.opened ? 1 : 0;
    }

    static String untilOpen() {
        Cargo c = active;
        if (c == null) {
            return "";
        }
        return fmt(Math.max(0, OPEN_AT - c.age));
    }

    // ------------------------------------------------------------------ запуск

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(EventManager::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            save();
            active = null;
            loaded = false;
        });
        ServerTickEvents.END_SERVER_TICK.register(EventManager::tick);
        CargoProtection.init();
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(buildCommand()));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> buildCommand() {
        LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("event")
                .executes(ctx -> {
                    info(ctx.getSource());
                    return 1;
                });
        root.then(CommandManager.literal("freeze").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> {
            frozen = true;
            save();
            ctx.getSource().sendFeedback(new LiteralText("Новые ивенты не будут появляться, пока не введёте /event unfreeze"), true);
            return 1;
        }));
        root.then(CommandManager.literal("unfreeze").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> {
            frozen = false;
            save();
            ctx.getSource().sendFeedback(new LiteralText("Ивенты снова появляются"), true);
            return 1;
        }));

        LiteralArgumentBuilder<ServerCommandSource> spawn = CommandManager.literal("spawn").requires(s -> s.hasPermissionLevel(2));
        for (String cargo : new String[]{"груз", "crate"}) {
            LiteralArgumentBuilder<ServerCommandSource> node = CommandManager.literal(cargo);
            for (String name : new String[]{"мирный", "peaceful"}) {
                node.then(CommandManager.literal(name).executes(ctx -> spawnCommand(ctx.getSource(), Type.PEACE)));
            }
            for (String name : new String[]{"взрывной", "explosive"}) {
                node.then(CommandManager.literal(name).executes(ctx -> spawnCommand(ctx.getSource(), Type.EXPLOSIVE)));
            }
            spawn.then(node);
        }
        for (String rush : new String[]{"лихорадка", "goldrush"}) {
            spawn.then(CommandManager.literal(rush).executes(ctx -> spawnRushCommand(ctx.getSource())));
        }
        root.then(spawn);

        root.then(CommandManager.literal("time").requires(s -> s.hasPermissionLevel(2))
                .then(CommandManager.literal("skip").executes(ctx -> skip(ctx.getSource()))));
        return root;
    }

    /** Раз в 15 минут: мирный груз, взрывной груз или золотая лихорадка (поровну). */
    private static boolean startRandom(MinecraftServer server) {
        int r = RNG.nextInt(3);
        if (r == 2 && com.arsenal.shulker.ShulkerEvent.startGoldRush(server)) {
            nextIn = INTERVAL;
            save();
            return true;
        }
        return spawn(server, r == 0 ? Type.PEACE : Type.EXPLOSIVE);
    }

    private static int spawnRushCommand(ServerCommandSource source) {
        MinecraftServer server = source.getMinecraftServer();
        if (!loaded) {
            source.sendFeedback(new LiteralText("Ивенты ещё не загружены").formatted(Formatting.RED), false);
            return 0;
        }
        if (!com.arsenal.shulker.ShulkerEvent.startGoldRush(server)) {
            source.sendFeedback(new LiteralText("Нет мест для шалкеров (/shulker add)").formatted(Formatting.RED), false);
            return 0;
        }
        return 1;
    }

    private static int spawnCommand(ServerCommandSource source, Type type) {
        MinecraftServer server = source.getMinecraftServer();
        if (!loaded) {
            source.sendFeedback(new LiteralText("Ивенты ещё не загружены").formatted(Formatting.RED), false);
            return 0;
        }
        if (active != null) {
            remove(server, false);
        }
        if (!spawn(server, type)) {
            source.sendFeedback(new LiteralText("Не удалось найти подходящее место, попробуйте ещё раз").formatted(Formatting.RED), false);
            return 0;
        }
        return 1;
    }

    private static int skip(ServerCommandSource source) {
        MinecraftServer server = source.getMinecraftServer();
        if (!loaded) {
            return 0;
        }
        if (active == null && com.arsenal.shulker.ShulkerEvent.isRush()) {
            com.arsenal.shulker.ShulkerEvent.stopGoldRush(server, true);
            source.sendFeedback(new LiteralText("Золотая лихорадка закончена"), true);
            return 1;
        }
        if (active == null) {
            if (!startRandom(server)) {
                source.sendFeedback(new LiteralText("Не удалось найти подходящее место, попробуйте ещё раз").formatted(Formatting.RED), false);
                return 0;
            }
            source.sendFeedback(new LiteralText("Время до ивента пропущено"), true);
        } else if (!active.opened && !active.blasting) {
            active.age = OPEN_AT;
            source.sendFeedback(new LiteralText("Груз открывается"), true);
        } else if (active.opened) {
            active.age = OPEN_AT + STAY;
            source.sendFeedback(new LiteralText("Груз исчезает"), true);
        } else {
            source.sendFeedback(new LiteralText("Груз сейчас взрывается").formatted(Formatting.RED), false);
        }
        return 1;
    }

    private static void info(ServerCommandSource source) {
        MutableText out = new LiteralText("");
        Cargo c = active;
        if (c != null) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(c.type.title).formatted(c.type.color, Formatting.BOLD));
            out.append(new LiteralText("\nКоординаты: ").formatted(Formatting.GRAY));
            out.append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.WHITE));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
            if (c.opened) {
                out.append(new LiteralText("Груз открыт, исчезнет через ").formatted(Formatting.GRAY));
                out.append(new LiteralText(fmt(OPEN_AT + STAY - c.age)).formatted(Formatting.GREEN));
            } else if (c.blasting) {
                out.append(new LiteralText("Груз взрывается!").formatted(Formatting.RED));
            } else {
                out.append(new LiteralText(c.type == Type.PEACE ? "Откроется через " : "Взорвётся через ").formatted(Formatting.GRAY));
                out.append(new LiteralText(fmt(OPEN_AT - c.age)).formatted(Formatting.GREEN));
            }
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        if (com.arsenal.shulker.ShulkerEvent.isRush()) {
            out.append(new LiteralText("Идёт ивент: ").formatted(Formatting.GRAY));
            out.append(new LiteralText("Золотая лихорадка").formatted(Formatting.GOLD, Formatting.BOLD));
            out.append(new LiteralText("\nЗакончится через ").formatted(Formatting.GRAY));
            out.append(new LiteralText(fmt(com.arsenal.shulker.ShulkerEvent.rushTicksLeft())).formatted(Formatting.GREEN));
            out.append(new LiteralText("\n").formatted(Formatting.GRAY));
        }
        out.append(new LiteralText("Следующий ивент через ").formatted(Formatting.GRAY));
        if (frozen) {
            out.append(new LiteralText("неизвестно (ивенты заморожены)").formatted(Formatting.RED));
        } else {
            out.append(new LiteralText(fmt(Math.max(0, nextIn))).formatted(Formatting.GREEN));
        }
        source.sendFeedback(out, false);
    }

    // ------------------------------------------------------------------ тик

    private static void tick(MinecraftServer server) {
        if (!loaded) {
            return;
        }
        if (!frozen && nextIn > 0) {
            nextIn--;
        }
        Cargo c = active;
        if (c == null) {
            if (!frozen && nextIn <= 0 && server.getPlayerManager().getCurrentPlayerCount() > 0) {
                startRandom(server);
                if (active == null && !com.arsenal.shulker.ShulkerEvent.isRush()) {
                    nextIn = 20 * 30;
                }
            }
            return;
        }
        ServerWorld world = server.getOverworld();
        c.age++;
        if (c.blasting) {
            tickBlasts(server, world, c);
        } else if (!c.opened && c.age >= OPEN_AT) {
            open(server, world, c);
        }
        if (c.opened && c.age >= OPEN_AT + STAY) {
            remove(server, true);
            return;
        }
        if (c.age % 20 == 0) {
            updateLabels(world, c);
        }
        if (c.age % 600 == 0) {
            save();
        }
    }

    private static void open(MinecraftServer server, ServerWorld world, Cargo c) {
        if (c.type == Type.PEACE) {
            double cx = c.cx + 0.5;
            double cz = c.cz + 0.5;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.getServerWorld() != world || p.isSpectator()) {
                    continue;
                }
                double dx = p.getX() - cx;
                double dz = p.getZ() - cz;
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 16.0) {
                    continue;
                }
                if (dist < 0.01) {
                    double a = RNG.nextDouble() * Math.PI * 2;
                    dx = Math.cos(a);
                    dz = Math.sin(a);
                    dist = 1.0;
                }
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 20 * 8, 0, false, false));
                p.setVelocity(dx / dist * 1.7, 0.8, dz / dist * 1.7);
                p.velocityModified = true;
                p.fallDistance = 0.0F;
                p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
            }
            for (BlockPos pos : c.shulkers) {
                world.spawnParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 40, 0.5, 0.5, 0.5, 0.15);
                world.playSound(null, pos, SoundEvents.BLOCK_SHULKER_BOX_OPEN, SoundCategory.BLOCKS, 2.0F, 1.0F);
            }
            c.opened = true;
            broadcast(server, new LiteralText("«Мирный груз» открыт! Забирайте лут на ").formatted(Formatting.GRAY)
                    .append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.AQUA)));
            save();
        } else {
            c.blasting = true;
            c.blastTick = 0;
            c.blastIndex = 0;
            broadcast(server, new LiteralText("«Взрывной груз» взрывается на ").formatted(Formatting.GRAY)
                    .append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.GOLD)).append(
                            new LiteralText("! Лут можно забирать после взрывов.").formatted(Formatting.GRAY)));
        }
    }

    private static void tickBlasts(MinecraftServer server, ServerWorld world, Cargo c) {
        if (c.blastIndex < c.shulkers.size() && c.blastTick % 10 == 0) {
            BlockPos p = c.shulkers.get(c.blastIndex++);
            // как динамит Б: сила из настроек (по умолчанию 40), блоки не ломаются, урон есть
            world.createExplosion(null, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5,
                    CargoLoot.blastPower(com.arsenal.blast.BlastKind.DYNAMITE_B.power), Explosion.DestructionType.NONE);
        }
        c.blastTick++;
        if (c.blastIndex >= c.shulkers.size() && c.blastTick > c.shulkers.size() * 10 + 10) {
            c.blasting = false;
            c.opened = true;
            broadcast(server, new LiteralText("«Взрывной груз» открыт! Лут можно забирать.").formatted(Formatting.GOLD));
            save();
        }
    }

    // ------------------------------------------------------------------ появление и удаление

    private static boolean spawn(MinecraftServer server, Type type) {
        ServerWorld world = server.getOverworld();
        Cargo c = findSite(world);
        if (c == null) {
            return false;
        }
        c.type = type;
        build(world, c);
        List<List<net.minecraft.item.ItemStack>> loot = CargoLoot.roll(type.key, c.shulkers.size());
        for (int i = 0; i < c.shulkers.size(); i++) {
            BlockEntity be = world.getBlockEntity(c.shulkers.get(i));
            if (be instanceof net.minecraft.inventory.Inventory) {
                CargoLoot.fill((net.minecraft.inventory.Inventory) be, loot.get(i));
                be.markDirty();
            }
        }
        active = c;
        nextIn = INTERVAL;
        spawnLabels(world, c);
        updateLabels(world, c);
        saveBlocks(c);
        save();
        MutableText msg = new LiteralText("Появился «").formatted(Formatting.GRAY);
        msg.append(new LiteralText(type.title).formatted(type.color, Formatting.BOLD));
        msg.append(new LiteralText("» на координатах ").formatted(Formatting.GRAY));
        msg.append(new LiteralText(c.cx + " " + (c.cy + 1) + " " + c.cz).formatted(Formatting.WHITE));
        msg.append(new LiteralText(type == Type.PEACE ? ". Откроется через 8 минут, PvP в зоне выключено." : ". Взорвётся через 8 минут!").formatted(Formatting.GRAY));
        broadcast(server, msg);
        return true;
    }

    /** Убирает груз и возвращает местность как была. */
    private static void remove(MinecraftServer server, boolean announce) {
        Cargo c = active;
        if (c == null) {
            return;
        }
        ServerWorld world = server.getOverworld();
        // чтобы убрать надписи и вернуть блоки, окрестности должны быть загружены
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                world.getChunk((c.cx >> 4) + dx, (c.cz >> 4) + dz);
            }
        }
        server.getCommandManager().execute(server.getCommandSource().withWorld(world).withSilent(),
                "kill @e[type=minecraft:armor_stand,tag=arsenal_cargo]");
        for (BlockPos p : c.shulkers) {
            world.setBlockState(p, Blocks.AIR.getDefaultState(), 2);
        }
        for (Map.Entry<Long, Integer> e : c.saved.entrySet()) {
            world.setBlockState(BlockPos.fromLong(e.getKey()), Block.getStateFromRawId(e.getValue()), 2);
        }
        active = null;
        try {
            Files.deleteIfExists(blocksFile());
        } catch (Exception ignored) {
            // не критично
        }
        save();
        if (announce) {
            broadcast(server, new LiteralText("«" + c.type.title + "» исчез.").formatted(Formatting.GRAY));
        }
    }

    // ------------------------------------------------------------------ место и постройка

    private static Cargo findSite(ServerWorld world) {
        for (int attempt = 0; attempt < 80; attempt++) {
            double angle = RNG.nextDouble() * Math.PI * 2;
            double dist = 300 + Math.sqrt(RNG.nextDouble()) * (MAX_DISTANCE - 300);
            int cx = (int) Math.round(Math.cos(angle) * dist);
            int cz = (int) Math.round(Math.sin(angle) * dist);
            if (!zoneFree(world, cx, cz)) {
                continue;
            }
            int y0 = groundY(world, cx, cz);
            if (y0 < 0) {
                continue;
            }
            int min = y0;
            int max = y0;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double a = i * Math.PI / 4;
                int y = groundY(world, cx + (int) Math.round(Math.cos(a) * 10), cz + (int) Math.round(Math.sin(a) * 10));
                if (y < 0) {
                    ok = false;
                } else {
                    min = Math.min(min, y);
                    max = Math.max(max, y);
                }
            }
            if (!ok || max - min > 5) {
                continue;
            }
            if (hasBlockEntities(world, cx, y0, cz)) {
                continue;
            }
            Cargo c = new Cargo();
            c.cx = cx;
            c.cy = y0;
            c.cz = cz;
            return c;
        }
        return null;
    }

    private static boolean zoneFree(ServerWorld world, int cx, int cz) {
        int r = (int) RADIUS + 6;
        int[][] pts = {{0, 0}, {r, 0}, {-r, 0}, {0, r}, {0, -r}, {r, r}, {-r, -r}, {r, -r}, {-r, r}};
        for (int[] p : pts) {
            BlockPos pos = new BlockPos(cx + p[0], 64, cz + p[1]);
            if (SpawnProtection.contains(world, pos) || !world.getWorldBorder().contains(pos)) {
                return false;
            }
        }
        return !PrivateManager.intersects(world, new Box(cx - r, 0, cz - r, cx + r, 256, cz + r));
    }

    /** Первая свободная высота над твёрдой землёй (не вода), или -1. */
    private static int groundY(ServerWorld world, int x, int z) {
        world.getChunk(x >> 4, z >> 4);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y < 10 || y > 200) {
            return -1;
        }
        BlockState below = world.getBlockState(new BlockPos(x, y - 1, z));
        if (below.isAir() || !below.getFluidState().isEmpty()) {
            return -1;
        }
        return y;
    }

    private static boolean hasBlockEntities(ServerWorld world, int cx, int y0, int cz) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int y = y0 - 6; y <= y0 + 8; y++) {
                    m.set(cx + dx, y, cz + dz);
                    if (world.getBlockEntity(m) != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void put(ServerWorld world, Cargo c, BlockPos pos, BlockState state) {
        long key = pos.asLong();
        if (!c.saved.containsKey(key)) {
            c.saved.put(key, Block.getRawIdFromState(world.getBlockState(pos)));
        }
        world.setBlockState(pos, state, 2);
    }

    private static void square(ServerWorld world, Cargo c, int y, int half, Block block) {
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                put(world, c, new BlockPos(c.cx + dx, y, c.cz + dz), block.getDefaultState());
            }
        }
    }

    private static void build(ServerWorld world, Cargo c) {
        int y0 = c.cy;
        Type t = c.type;
        BlockState air = Blocks.AIR.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -HALF; dx <= HALF; dx++) {
            for (int dz = -HALF; dz <= HALF; dz++) {
                for (int y = y0 + 8; y >= y0; y--) {
                    m.set(c.cx + dx, y, c.cz + dz);
                    if (!world.getBlockState(m).isAir()) {
                        put(world, c, m.toImmutable(), air);
                    }
                }
                for (int y = y0 - 1; y >= y0 - 6; y--) {
                    m.set(c.cx + dx, y, c.cz + dz);
                    BlockState s = world.getBlockState(m);
                    if (s.isAir() || !s.getFluidState().isEmpty() || s.getMaterial().isReplaceable()) {
                        put(world, c, m.toImmutable(), Blocks.DIRT.getDefaultState());
                    } else {
                        break;
                    }
                }
            }
        }
        // пирамида в центре
        square(world, c, y0, 4, t.base);
        square(world, c, y0 + 1, 3, t.base);
        square(world, c, y0 + 2, 2, t.base);
        square(world, c, y0 + 3, 1, t.base);
        // четыре шалкера на площадках
        int[][] corners = {{8, 8}, {-8, 8}, {8, -8}, {-8, -8}};
        for (int[] corner : corners) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    put(world, c, new BlockPos(c.cx + corner[0] + dx, y0, c.cz + corner[1] + dz), t.base.getDefaultState());
                }
            }
            BlockPos s = new BlockPos(c.cx + corner[0], y0 + 1, c.cz + corner[1]);
            put(world, c, s, t.shulker.getDefaultState());
            c.shulkers.add(s);
        }
        // край зоны из шерсти
        int r = (int) RADIUS + 1;
        double inner = RADIUS - 2.0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < inner || d > RADIUS) {
                    continue;
                }
                int x = c.cx + dx;
                int z = c.cz + dz;
                world.getChunk(x >> 4, z >> 4);
                int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                BlockPos pos = new BlockPos(x, y, z);
                BlockState s = world.getBlockState(pos);
                if (y < 1 || s.isAir() || !s.getFluidState().isEmpty()) {
                    continue;
                }
                put(world, c, pos, t.ring.getDefaultState());
            }
        }
    }

    // ------------------------------------------------------------------ надписи

    private static void run(ServerWorld world, String command) {
        MinecraftServer server = world.getServer();
        server.getCommandManager().execute(server.getCommandSource().withWorld(world).withSilent(), command);
    }

    private static String json(Text text) {
        return Text.Serializer.toJson(text).replace("\\", "\\\\").replace("'", "\\'");
    }

    private static void spawnLabels(ServerWorld world, Cargo c) {
        Text title = new LiteralText(c.type.title).setStyle(Style.EMPTY.withColor(c.type.color).withBold(true));
        for (BlockPos p : c.shulkers) {
            double x = p.getX() + 0.5;
            double z = p.getZ() + 0.5;
            run(world, String.format(Locale.ROOT,
                    "summon minecraft:armor_stand %.2f %.2f %.2f {Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,"
                            + "CustomNameVisible:1b,Tags:[\"arsenal_cargo\",\"arsenal_cargo_t\"],CustomName:'%s'}",
                    x, p.getY() + 1.55, z, json(title)));
            run(world, String.format(Locale.ROOT,
                    "summon minecraft:armor_stand %.2f %.2f %.2f {Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,"
                            + "CustomNameVisible:1b,Tags:[\"arsenal_cargo\",\"arsenal_cargo_s\"],CustomName:'%s'}",
                    x, p.getY() + 1.25, z, json(new LiteralText(" "))));
        }
    }

    private static void updateLabels(ServerWorld world, Cargo c) {
        MutableText text;
        if (c.blasting) {
            text = new LiteralText("Взрывается!").formatted(Formatting.RED);
        } else if (c.opened) {
            text = new LiteralText("Исчезнет через ").formatted(Formatting.GRAY)
                    .append(new LiteralText(fmt(OPEN_AT + STAY - c.age)).formatted(c.type.color));
        } else {
            text = new LiteralText(c.type == Type.PEACE ? "Будет открыт через " : "Взорвётся через ").formatted(Formatting.GRAY)
                    .append(new LiteralText(fmt(OPEN_AT - c.age)).formatted(c.type.color));
        }
        Box box = new Box(c.cx - 14, c.cy - 2, c.cz - 14, c.cx + 14, c.cy + 8, c.cz + 14);
        for (ArmorStandEntity stand : world.getEntitiesByClass(ArmorStandEntity.class, box,
                e -> e.getScoreboardTags().contains("arsenal_cargo_s"))) {
            stand.setCustomName(text);
        }
    }

    // ------------------------------------------------------------------ утилиты

    static String fmt(int ticks) {
        int seconds = (Math.max(0, ticks) + 19) / 20;
        int m = seconds / 60;
        int s = seconds % 60;
        return m > 0 ? m + " мин. " + s + " сек." : s + " сек.";
    }

    private static void broadcast(MinecraftServer server, Text text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, Util.NIL_UUID);
    }

    // ------------------------------------------------------------------ сохранение

    private static Path stateFile(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("arsenal_event.json");
    }

    private static Path blocksFile() {
        return serverRef.getSavePath(WorldSavePath.ROOT).resolve("arsenal_event_blocks.json");
    }

    private static MinecraftServer serverRef;

    private static void save() {
        if (serverRef == null) {
            return;
        }
        try {
            JsonObject root = new JsonObject();
            root.addProperty("nextIn", nextIn);
            root.addProperty("frozen", frozen);
            Cargo c = active;
            if (c != null) {
                JsonObject o = new JsonObject();
                o.addProperty("type", c.type.key);
                o.addProperty("cx", c.cx);
                o.addProperty("cy", c.cy);
                o.addProperty("cz", c.cz);
                o.addProperty("age", c.age);
                o.addProperty("opened", c.opened || c.blasting);
                JsonArray sh = new JsonArray();
                for (BlockPos p : c.shulkers) {
                    sh.add(p.asLong());
                }
                o.add("shulkers", sh);
                root.add("active", o);
            }
            Files.write(stateFile(serverRef), root.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_event.json: " + ex);
        }
    }

    private static void saveBlocks(Cargo c) {
        try {
            JsonArray pos = new JsonArray();
            JsonArray ids = new JsonArray();
            for (Map.Entry<Long, Integer> e : c.saved.entrySet()) {
                pos.add(e.getKey());
                ids.add(e.getValue());
            }
            JsonObject o = new JsonObject();
            o.add("pos", pos);
            o.add("ids", ids);
            Files.write(blocksFile(), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_event_blocks.json: " + ex);
        }
    }

    private static void load(MinecraftServer server) {
        serverRef = server;
        CargoLoot.load();
        nextIn = INTERVAL;
        frozen = false;
        active = null;
        try {
            Path f = stateFile(server);
            if (Files.exists(f)) {
                JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
                nextIn = root.get("nextIn").getAsInt();
                frozen = root.get("frozen").getAsBoolean();
                if (root.has("active")) {
                    JsonObject o = root.getAsJsonObject("active");
                    Cargo c = new Cargo();
                    c.type = Type.byKey(o.get("type").getAsString());
                    c.cx = o.get("cx").getAsInt();
                    c.cy = o.get("cy").getAsInt();
                    c.cz = o.get("cz").getAsInt();
                    c.age = o.get("age").getAsInt();
                    c.opened = o.get("opened").getAsBoolean();
                    for (JsonElement el : o.getAsJsonArray("shulkers")) {
                        c.shulkers.add(BlockPos.fromLong(el.getAsLong()));
                    }
                    Path bf = blocksFile();
                    if (Files.exists(bf)) {
                        JsonObject b = new JsonParser().parse(new String(Files.readAllBytes(bf), StandardCharsets.UTF_8)).getAsJsonObject();
                        JsonArray pos = b.getAsJsonArray("pos");
                        JsonArray ids = b.getAsJsonArray("ids");
                        for (int i = 0; i < pos.size(); i++) {
                            c.saved.put(pos.get(i).getAsLong(), ids.get(i).getAsInt());
                        }
                    }
                    active = c;
                }
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_event.json: " + ex);
        }
        loaded = true;
    }
}
