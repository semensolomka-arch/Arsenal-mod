package com.arsenal.blast;

import com.arsenal.Lore;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;

/** Виды взрывчатки: время до взрыва, сила и особенности взрыва. Текстура у всех как у обычного TNT. */
public enum BlastKind {
    /** Взрыв через 5 секунд, в 3 раза сильнее обычного TNT (сила 4). */
    DYNAMITE_A("dynamite_a", 20 * 5, 4.0F * 3, Mode.VANILLA, 0xFF4500),
    /** Взрыв через 15 секунд, в 10 раз сильнее обычного TNT. */
    DYNAMITE_B("dynamite_b", 20 * 15, 4.0F * 10, Mode.VANILLA, 0xFF00E0),
    /** Как обычный TNT, но обсидиан ломает не очень хорошо. */
    C4("c4", 80, 4.0F, Mode.C4, 0x55FFFF),
    /** Как обычный TNT, но взрывается в воде и хорошо ломает обсидиан. */
    WAVE("burst_wave", 80, 4.0F, Mode.WAVE, 0xFF00E0);

    public enum Mode {
        VANILLA, C4, WAVE
    }

    /** Эффективная стойкость обсидиана к взрыву (у ванильного 1200, у камня 6): чем меньше, тем легче ломается. */
    public static final float C4_OBSIDIAN_RESISTANCE = 12.0F;
    public static final float WAVE_OBSIDIAN_RESISTANCE = 4.0F;

    public final String id;
    public final int fuseTicks;
    public final float power;
    public final Mode mode;
    /** Цвет выделения в описании. */
    public final int highlight;

    BlastKind(String id, int fuseTicks, float power, Mode mode, int highlight) {
        this.id = id;
        this.fuseTicks = fuseTicks;
        this.power = power;
        this.mode = mode;
        this.highlight = highlight;
    }

    /** Название с оформлением: А как у светильника Джейка, Б фиолетовое, C4 бело-фиолетовое, волна жёлто-фиолетовая. */
    public Text displayName(String translationKey) {
        switch (this) {
            case DYNAMITE_A:
                return Lore.gradientName(translationKey, 0xFF8C00, 0xFFB000, true);
            case C4:
                return Lore.gradientName(translationKey, 0xE040FB, 0xB388FF, false);
            case WAVE:
                return Lore.gradientName(translationKey, 0xFF2020, 0xFF00DC, false);
            default:
                return new TranslatableText(translationKey)
                        .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xE53BFF)).withItalic(false));
        }
    }
}
