package com.arsenal.bind;

import com.arsenal.Abilities;
import com.arsenal.Arsenal;
import com.arsenal.special.Specials;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.UseAction;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Бинды предметов (/binds). Для каждого из пяти предметов игрок выбирает клавишу:
 * вторая рука (F), выбросить предмет (Q), использовать (ПКМ) или выключено.
 *
 * Работает только с мечом в руке (не топор, не трезубец). По умолчанию все бинды выключены. Клавиши Q и F перехватывает клиент
 * (MinecraftClientMixin) и присылает пакет, ПКМ обрабатывается через UseBlockCallback/UseItemCallback.
 * Решения (использовать, кулдаун, предмета нет) и сообщения в чат всегда на сервере.
 * Настройки хранятся в config/arsenal_binds.json и пересылаются клиенту при входе и при изменении.
 */
public final class Binds {
    public static final Identifier SYNC = new Identifier(Arsenal.MODID, "binds_sync");
    public static final Identifier USE_BIND = new Identifier(Arsenal.MODID, "use_bind");

    /** Варианты бинда. Порядок = порядок строк в меню. */
    public enum Key {
        OFF("Выключено"),
        OFFHAND("Вторая рука (F)"),
        DROP("Выбросить предмет (Q)"),
        USE("Использовать (ПКМ)");

        public final String title;

        Key(String title) {
            this.title = title;
        }
    }

    /** Предметы, которые можно забиндить (порядок = приоритет при одной клавише и порядок в меню). */
    public enum Bind {
        TRAP("Трапка", () -> Arsenal.TRAP, Abilities.TRAP_COOLDOWN, Key.OFF),
        STUN("Стан", () -> Arsenal.STUN, Abilities.STUN_COOLDOWN, Key.OFF),
        EXPLOSIVE_TRAP("Взрывная трапка", () -> Arsenal.EXPLOSIVE_TRAP, Abilities.TRAP_COOLDOWN, Key.OFF),
        BLAST_CHARM("Взрывная штучка", () -> Arsenal.BLAST_CHARM, Specials.CHARM_COOLDOWN, Key.OFF),
        SNOW("Ком снега", () -> Arsenal.SNOW_BALL, Abilities.SNOW_COOLDOWN, Key.OFF);

        public final String title;
        private final Supplier<Item> item;
        /** Полный кулдаун в тиках (нужен, чтобы показать, сколько секунд осталось). */
        public final int cooldownTicks;
        public final Key defaultKey;

        Bind(String title, Supplier<Item> item, int cooldownTicks, Key defaultKey) {
            this.title = title;
            this.item = item;
            this.cooldownTicks = cooldownTicks;
            this.defaultKey = defaultKey;
        }

        public Item item() {
            return item.get();
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    /** Настройки игроков на сервере. */
    private static final Map<UUID, EnumMap<Bind, Key>> SERVER = new HashMap<>();
    /** Свои настройки на клиенте (приходят с сервера). */
    private static EnumMap<Bind, Key> client = defaults();
    /** Чтобы не спамить одним и тем же сообщением (удержание ПКМ и т.п.). */
    private static final Map<String, Long> LAST_MESSAGE = new HashMap<>();

    private Binds() {
    }

    // ---------- данные ----------

    private static EnumMap<Bind, Key> defaults() {
        EnumMap<Bind, Key> map = new EnumMap<>(Bind.class);
        for (Bind b : Bind.values()) {
            map.put(b, b.defaultKey);
        }
        return map;
    }

    /** Настройки игрока: на клиенте свои синхронизированные, на сервере из памяти. */
    public static EnumMap<Bind, Key> of(PlayerEntity player) {
        if (player.world.isClient) {
            return client;
        }
        return SERVER.computeIfAbsent(player.getUuid(), u -> defaults());
    }

    public static List<Bind> boundTo(PlayerEntity player, Key key) {
        List<Bind> list = new ArrayList<>();
        EnumMap<Bind, Key> map = of(player);
        for (Bind b : Bind.values()) {
            if (map.get(b) == key) {
                list.add(b);
            }
        }
        return list;
    }

    /** Можно ли сейчас вообще использовать бинды на эту клавишу (оружие в руке и т.п.). */
    public static boolean keyAvailable(PlayerEntity p, Key key) {
        if (key == Key.OFF || p.isSpectator()) {
            return false;
        }
        // бинды работают только с мечом в основной руке (не топор и не трезубец)
        if (!(p.getMainHandStack().getItem() instanceof SwordItem)) {
            return false;
        }
        if (key == Key.USE) {
            ItemStack off = p.getOffHandStack();
            return off.isEmpty() || off.getUseAction() == UseAction.NONE;
        }
        return true;
    }

    private static boolean has(PlayerEntity p, Bind b) {
        return !Abilities.find(p, b.item()).isEmpty();
    }

    private static boolean cooling(PlayerEntity p, Bind b) {
        return p.getItemCooldownManager().isCoolingDown(b.item());
    }

    private static int secondsLeft(PlayerEntity p, Bind b) {
        float progress = p.getItemCooldownManager().getCooldownProgress(b.item(), 0.0F);
        return Math.max(1, (int) Math.ceil(progress * b.cooldownTicks / 20.0));
    }

    /** Первый забинденный на клавишу предмет, который есть в инвентаре и не на кулдауне (иначе null). */
    public static Bind pickReady(PlayerEntity p, Key key) {
        for (Bind b : boundTo(p, key)) {
            if (has(p, b) && !cooling(p, b)) {
                return b;
            }
        }
        return null;
    }

    // ---------- использование ----------

    /**
     * Нажата клавиша key. Возвращает true, если какой-то предмет сработал.
     * Если нет (кулдаун или предмета нет), игроку пишется причина.
     */
    public static boolean trigger(ServerPlayerEntity p, Key key) {
        if (!keyAvailable(p, key)) {
            return false;
        }
        List<Bind> bound = boundTo(p, key);
        if (bound.isEmpty()) {
            return false;
        }
        Bind ready = pickReady(p, key);
        if (ready != null) {
            use(p, ready);
            return true;
        }
        if (key == Key.USE && !p.getOffHandStack().isEmpty()) {
            return false;   // во второй руке что-то есть (например блоки): не мешаем сообщениями
        }
        for (Bind b : bound) {
            if (has(p, b) && cooling(p, b)) {
                message(p, b, "cd", b.title + " на перезарядке: ещё ", secondsLeft(p, b) + " сек.");
                return false;
            }
        }
        StringBuilder names = new StringBuilder();
        for (Bind b : bound) {
            if (names.length() > 0) {
                names.append(" / ");
            }
            names.append(b.title);
        }
        message(p, bound.get(0), "none", "Нет предмета в инвентаре: ", names.toString());
        return false;
    }

    private static void use(ServerPlayerEntity p, Bind b) {
        ItemStack stack = Abilities.find(p, b.item());
        switch (b) {
            case TRAP:
                Abilities.useTrap(p, stack);
                break;
            case STUN:
                Abilities.useStun(p, stack);
                break;
            case EXPLOSIVE_TRAP:
                Specials.useExplosiveTrap(p, stack);
                break;
            case BLAST_CHARM:
                Specials.useBlastCharm(p, stack);
                break;
            case SNOW:
                Abilities.useSnow(p, stack);
                break;
            default:
                break;
        }
    }

    private static void message(ServerPlayerEntity p, Bind b, String kind, String text, String highlight) {
        long now = p.world.getTime();
        String id = p.getUuid() + ":" + b.name() + ":" + kind;
        Long last = LAST_MESSAGE.get(id);
        if (last != null && now - last < 30) {
            return;
        }
        LAST_MESSAGE.put(id, now);
        MutableText msg = new LiteralText("▶ ").formatted(Formatting.GOLD);
        msg.append(new LiteralText(text).formatted(Formatting.WHITE));
        msg.append(new LiteralText(highlight).formatted(Formatting.RED));
        p.sendMessage(msg, false);
    }

    // ---------- изменение настроек ----------

    public static void set(ServerPlayerEntity player, Bind bind, Key key) {
        of(player).put(bind, key);
        save();
        sync(player);
    }

    public static void sync(ServerPlayerEntity player) {
        PacketByteBuf buf = PacketByteBufs.create();
        EnumMap<Bind, Key> map = of(player);
        for (Bind b : Bind.values()) {
            buf.writeByte(map.get(b).ordinal());
        }
        ServerPlayNetworking.send(player, SYNC, buf);
    }

    /** Клиент получил свои настройки (вызывается из ArsenalClient). */
    public static void applySync(byte[] ordinals) {
        EnumMap<Bind, Key> map = defaults();
        Bind[] binds = Bind.values();
        Key[] keys = Key.values();
        for (int i = 0; i < binds.length && i < ordinals.length; i++) {
            if (ordinals[i] >= 0 && ordinals[i] < keys.length) {
                map.put(binds[i], keys[ordinals[i]]);
            }
        }
        client = map;
    }

    // ---------- сохранение ----------

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_binds.json");
    }

    private static void load() {
        SERVER.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) {
                return;
            }
            JsonObject root = new JsonParser().parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, com.google.gson.JsonElement> e : root.entrySet()) {
                EnumMap<Bind, Key> map = defaults();
                JsonObject o = e.getValue().getAsJsonObject();
                for (Bind b : Bind.values()) {
                    if (o.has(b.name())) {
                        try {
                            map.put(b, Key.valueOf(o.get(b.name()).getAsString()));
                        } catch (IllegalArgumentException ignored) {
                            // неизвестное значение: остаётся по умолчанию
                        }
                    }
                }
                SERVER.put(UUID.fromString(e.getKey()), map);
            }
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось прочитать arsenal_binds.json: " + ex);
        }
    }

    private static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, EnumMap<Bind, Key>> e : SERVER.entrySet()) {
                JsonObject o = new JsonObject();
                for (Bind b : Bind.values()) {
                    o.addProperty(b.name(), e.getValue().get(b).name());
                }
                root.add(e.getKey().toString(), o);
            }
            Files.write(file(), GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            System.err.println("[Arsenal] не удалось сохранить arsenal_binds.json: " + ex);
        }
    }

    // ---------- инициализация ----------

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> load());
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            SERVER.clear();
            LAST_MESSAGE.clear();
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sync(handler.player));

        ServerPlayNetworking.registerGlobalReceiver(USE_BIND, (server, player, handler, buf, sender) -> {
            int ordinal = buf.readByte();
            server.execute(() -> {
                if (ordinal > 0 && ordinal < Key.values().length) {
                    trigger(player, Key.values()[ordinal]);
                }
            });
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("binds").executes(ctx -> {
                    BindsMenu.open(ctx.getSource().getPlayer());
                    return 1;
                })));
    }
}
