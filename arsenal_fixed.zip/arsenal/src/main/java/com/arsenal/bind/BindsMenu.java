package com.arsenal.bind;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumMap;

/**
 * Меню /binds (сундук 6x9, как /exp).
 * Верхний ряд: подсказка. Второй ряд: пять предметов. Под каждым четыре кнопки:
 * вторая рука, выбросить предмет, использовать, выключено. Выбранная зелёная, остальные серые.
 */
public final class BindsMenu {
    private static final int HINT_SLOT = 4;
    /** Колонки предметов в ряду 1 (слоты 11..15). */
    private static final int FIRST_COLUMN = 2;
    /** Порядок кнопок сверху вниз. */
    private static final Binds.Key[] ROWS = {
            Binds.Key.OFFHAND, Binds.Key.DROP, Binds.Key.USE, Binds.Key.OFF
    };

    private BindsMenu() {
    }

    public static void open(ServerPlayerEntity player) {
        SimpleInventory inventory = new SimpleInventory(54);
        fill(player, inventory);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) -> new BindsScreenHandler(syncId, playerInventory, inventory),
                new LiteralText("Бинды")));
    }

    private static int itemSlot(int index) {
        return 9 + FIRST_COLUMN + index;
    }

    private static int buttonSlot(int index, int row) {
        return 9 * (2 + row) + FIRST_COLUMN + index;
    }

    private static void fill(ServerPlayerEntity player, SimpleInventory inventory) {
        for (int i = 0; i < inventory.size(); i++) {
            inventory.setStack(i, ItemStack.EMPTY);
        }
        EnumMap<Binds.Bind, Binds.Key> current = Binds.of(player);

        ItemStack hint = new ItemStack(Items.PAPER);
        hint.setCustomName(new LiteralText("Бинды").formatted(Formatting.GOLD).styled(s -> s.withItalic(false)));
        lore(hint,
                gray("Выбери клавишу под каждым предметом."),
                gray("Предмет должен лежать в инвентаре,"),
                gray("в основной руке меч (топор и трезубец не подходят)."),
                gray("Q без стана: меч не выбрасывается."));
        inventory.setStack(HINT_SLOT, hint);

        Binds.Bind[] binds = Binds.Bind.values();
        for (int i = 0; i < binds.length; i++) {
            // сам предмет (при наведении виден его цветной тултип)
            inventory.setStack(itemSlot(i), new ItemStack(binds[i].item()));

            for (int r = 0; r < ROWS.length; r++) {
                boolean selected = current.get(binds[i]) == ROWS[r];
                ItemStack button = new ItemStack(selected ? Items.LIME_STAINED_GLASS_PANE : Items.GRAY_STAINED_GLASS_PANE);
                MutableText name = new LiteralText((selected ? "✔ " : "") + ROWS[r].title)
                        .formatted(selected ? Formatting.GREEN : Formatting.WHITE);
                button.setCustomName(name.styled(s -> s.withItalic(false)));
                lore(button, gray(binds[i].title));
                inventory.setStack(buttonSlot(i, r), button);
            }
        }
    }

    private static Text gray(String s) {
        return new LiteralText(s).formatted(Formatting.GRAY).styled(st -> st.withItalic(false));
    }

    private static void lore(ItemStack stack, Text... lines) {
        NbtList list = new NbtList();
        for (Text line : lines) {
            list.add(NbtString.of(Text.Serializer.toJson(line)));
        }
        NbtCompound display = stack.getOrCreateSubTag("display");
        display.put("Lore", list);
    }

    static void onClick(ServerPlayerEntity player, int slot, SimpleInventory menu) {
        Binds.Bind[] binds = Binds.Bind.values();
        for (int i = 0; i < binds.length; i++) {
            for (int r = 0; r < ROWS.length; r++) {
                if (buttonSlot(i, r) == slot) {
                    Binds.set(player, binds[i], ROWS[r]);
                    fill(player, menu);
                    return;
                }
            }
        }
    }
}
