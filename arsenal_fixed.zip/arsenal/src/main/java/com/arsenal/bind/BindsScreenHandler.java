package com.arsenal.bind;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

/** Меню /binds: сундук 6x9, предметы из него взять нельзя, клик по кнопке выбирает бинд. */
public class BindsScreenHandler extends GenericContainerScreenHandler {
    private final SimpleInventory menu;

    public BindsScreenHandler(int syncId, PlayerInventory playerInventory, SimpleInventory menu) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, menu, 6);
        this.menu = menu;
    }

    @Override
    public ItemStack onSlotClick(int slotIndex, int clickData, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < 54) {
            if ((actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)
                    && player instanceof ServerPlayerEntity) {
                BindsMenu.onClick((ServerPlayerEntity) player, slotIndex, menu);
            }
            return ItemStack.EMPTY;
        }
        if (actionType == SlotActionType.QUICK_MOVE
                || actionType == SlotActionType.PICKUP_ALL
                || actionType == SlotActionType.QUICK_CRAFT) {
            return ItemStack.EMPTY;
        }
        return super.onSlotClick(slotIndex, clickData, actionType, player);
    }
}
