package com.arsenal.item;

import com.arsenal.artifact.ArtifactEffect;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import com.arsenal.Lore;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;
import java.util.Map;

/**
 * Артефакт: выглядит как морской источник, в наковальне в него можно вложить предметы-эффекты
 * Хранителя опыта (10 уровней за каждый). Какие эффекты вложены, хранится служебными зачарованиями
 * и показывается в подсказке списком.
 *
 * Это BlockItem от морского источника только ради вида (его рисует сама игра), поставить блок нельзя.
 */
public class ArtifactItem extends BlockItem {
    public ArtifactItem(Settings settings) {
        super(Blocks.CONDUIT, settings);
    }

    /** Блок не ставится. */
    @Override
    public ActionResult place(ItemPlacementContext context) {
        return ActionResult.FAIL;
    }

    /** Не подменяем ванильный предмет морского источника в соответствии "блок -> предмет". */
    @Override
    public void appendBlocks(Map<Block, Item> map, Item item) {
    }

    @Override
    public String getTranslationKey() {
        return "item.arsenal.artifact";
    }

    private static final int COLOR = 0xA8D0E4;

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText("item.arsenal.artifact").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(COLOR)).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal.artifact.", 3, COLOR);
        boolean any = false;
        for (ArtifactEffect effect : ArtifactEffect.values()) {
            if (effect.enchantment != null && EnchantmentHelper.getLevel(effect.enchantment, stack) > 0) {
                any = true;
                break;
            }
        }
        if (any) {
            // дальше игра сама допишет строки зачарований: " - Гравитация", " - Эндермен" и т.д. (цвет задаёт само зачарование)
            tooltip.add(new TranslatableText("item.arsenal.artifact.effects").setStyle(Style.EMPTY.withColor(Formatting.DARK_GRAY).withItalic(false)));
        }
    }
}
