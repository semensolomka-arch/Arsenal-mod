package com.arsenal.shulker;

import com.arsenal.protection.SpawnProtection;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.util.ItemScatterer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.network.MessageType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.explosion.Explosion;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Событие "Шалкеры в замке": на заданных точках появляются шалкер-боксы трёх видов
 * (серый 5, голубой 8, фиолетовый 13 прочности). Их нужно ломать (рукой или любым инструментом):
 * каждый сломанный раз снимает 1 прочность, а блок остаётся на месте. Когда прочность кончилась, падает лут.
 * Настройки и лут: config/arsenal_shulker.json (создаётся сам при первом запуске).
 * Команды оператора: /shulker spawn | respawn | despawn | reload.
 */
public final class ShulkerEvent {
    public enum Tier {
        GRAY("gray", Blocks.GRAY_SHULKER_BOX),
        BLUE("blue", Blocks.LIGHT_BLUE_SHULKER_BOX),
        PURPLE("purple", Blocks.PURPLE_SHULKER_BOX),
        /** Золотая лихорадка: золотой (жёлтый) и красный шалкеры. */
        GOLD("gold", Blocks.YELLOW_SHULKER_BOX),
        RED("red", Blocks.RED_SHULKER_BOX);

        final String key;
        final Block block;

        Tier(String key, Block block) {
            this.key = key;
            this.block = block;
        }

        static Tier byKey(String key) {
            for (Tier t : values()) {
                if (t.key.equals(key)) {
                    return t;
                }
            }
            return GRAY;
        }
    }

    private static final class Active {
        final Tier tier;
        int left;

        Active(Tier tier, int left) {
            this.tier = tier;
            this.left = left;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Random RNG = new Random();
    private static final Map<BlockPos, Active> ACTIVE = new LinkedHashMap<>();
    private static ShulkerConfig config;
    private static boolean started;
    private static int ticksToWave;
    /** Золотая лихорадка: сколько тиков осталось (0 = не идёт) и сколько до следующего появления шалкеров. */
    private static int rushLeft;
    private static int rushNext;

    private ShulkerEvent() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ShulkerEvent::tick);

        // каждое сломанное по шалкеру: минус прочность, а блок остаётся
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || !(state.getBlock() instanceof ShulkerBoxBlock)) {
                return true;
            }
            Active a = ACTIVE.get(pos);
            if (a == null) {
                // чужие шалкеры в зоне замка ломать нельзя (кроме операторов в творческом режиме)
                return !(SpawnProtection.contains(world, pos) && !SpawnProtection.bypass(player));
            }
            if (player instanceof ServerPlayerEntity) {
                hit((ServerWorld) world, (ServerPlayerEntity) player, pos.toImmutable(), a);
            }
            return false;
        });

        // открывать шалкеры события нельзя
        UseBlockCallback.EVENT.register((player, world, hand, hit) ->
                ACTIVE.containsKey(hit.getBlockPos()) ? ActionResult.FAIL : ActionResult.PASS);

        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("shulker")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("spawn").executes(ctx -> {
                            ServerWorld w = ctx.getSource().getMinecraftServer().getOverworld();
                            ensureStarted(ctx.getSource().getMinecraftServer());
                            int n = spawnAll(w);
                            ctx.getSource().sendFeedback(new LiteralText("Шалкеров появилось: " + n), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("respawn").executes(ctx -> {
                            ServerWorld w = ctx.getSource().getMinecraftServer().getOverworld();
                            ensureStarted(ctx.getSource().getMinecraftServer());
                            int n = respawnWave(w);
                            ctx.getSource().sendFeedback(new LiteralText("Шалкеры обновлены, новых: " + n), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("despawn").executes(ctx -> {
                            ServerWorld w = ctx.getSource().getMinecraftServer().getOverworld();
                            ensureStarted(ctx.getSource().getMinecraftServer());
                            int n = despawnAll(w);
                            ctx.getSource().sendFeedback(new LiteralText("Шалкеров убрано: " + n), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("add").executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            ensureStarted(ctx.getSource().getMinecraftServer());
                            BlockHitResult hit = lookedAt(player);
                            if (hit == null) {
                                ctx.getSource().sendFeedback(new LiteralText("Наведись на блок, рядом с которым нужно место").formatted(Formatting.RED), false);
                                return 0;
                            }
                            // там, где встал бы поставленный блок
                            BlockPos target = hit.getBlockPos().offset(hit.getSide()).toImmutable();
                            if (config.points.contains(target)) {
                                ctx.getSource().sendFeedback(new LiteralText("Здесь уже есть место: " + fmt(target)).formatted(Formatting.RED), false);
                                return 0;
                            }
                            config.points.add(target);
                            boolean saved = savePoints();
                            ctx.getSource().sendFeedback(new LiteralText("Место добавлено: " + fmt(target) + ". Всего мест: "
                                    + config.points.size() + (saved ? "" : " (файл настроек не сохранился)")), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("del").executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            ServerWorld w = ctx.getSource().getMinecraftServer().getOverworld();
                            ensureStarted(ctx.getSource().getMinecraftServer());
                            BlockHitResult hit = lookedAt(player);
                            BlockPos found = null;
                            if (hit != null) {
                                BlockPos at = hit.getBlockPos().toImmutable();
                                BlockPos beside = at.offset(hit.getSide()).toImmutable();
                                if (config.points.contains(at) || ACTIVE.containsKey(at)) {
                                    found = at;
                                } else if (config.points.contains(beside) || ACTIVE.containsKey(beside)) {
                                    found = beside;
                                }
                            }
                            if (found == null) {
                                ctx.getSource().sendFeedback(new LiteralText("Здесь нет места с шалкером").formatted(Formatting.RED), false);
                                return 0;
                            }
                            boolean hadShulker = ACTIVE.remove(found) != null;
                            if (hadShulker && w.getBlockState(found).getBlock() instanceof ShulkerBoxBlock) {
                                w.setBlockState(found, Blocks.AIR.getDefaultState());
                            }
                            boolean hadPoint = config.points.remove(found);
                            if (hadPoint) {
                                savePoints();
                            }
                            saveState();
                            ctx.getSource().sendFeedback(new LiteralText("Удалено: " + fmt(found)
                                    + (hadPoint ? " (место)" : "") + (hadShulker ? " (шалкер)" : "")
                                    + ". Мест осталось: " + config.points.size()), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("reset").executes(ctx -> {
                            ServerWorld w = ctx.getSource().getMinecraftServer().getOverworld();
                            ensureStarted(ctx.getSource().getMinecraftServer());
                            despawnAll(w);
                            int n = config.points.size();
                            config.points.clear();
                            savePoints();
                            ctx.getSource().sendFeedback(new LiteralText("Все места удалены: " + n + ". Шалкеры убраны"), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("rush").executes(ctx -> {
                            MinecraftServer srv = ctx.getSource().getMinecraftServer();
                            if (!startGoldRush(srv)) {
                                ctx.getSource().sendFeedback(new LiteralText("Нет мест для шалкеров (/shulker add)").formatted(Formatting.RED), false);
                                return 0;
                            }
                            ctx.getSource().sendFeedback(new LiteralText("Золотая лихорадка началась"), true);
                            return 1;
                        }).then(CommandManager.literal("stop").executes(ctx -> {
                            MinecraftServer srv = ctx.getSource().getMinecraftServer();
                            ensureStarted(srv);
                            if (rushLeft <= 0) {
                                ctx.getSource().sendFeedback(new LiteralText("Золотая лихорадка сейчас не идёт").formatted(Formatting.RED), false);
                                return 0;
                            }
                            stopGoldRush(srv, true);
                            ctx.getSource().sendFeedback(new LiteralText("Золотая лихорадка закончена"), true);
                            return 1;
                        })))
                        .then(CommandManager.literal("reload").executes(ctx -> {
                            config = ShulkerConfig.load();
                            ctx.getSource().sendFeedback(new LiteralText("Настройки шалкеров перечитаны. Точек: "
                                    + config.points.size()), true);
                            return 1;
                        }))));
    }

    private static BlockHitResult lookedAt(ServerPlayerEntity player) {
        HitResult hit = player.raycast(20.0D, 1.0F, false);
        return hit.getType() == HitResult.Type.BLOCK ? (BlockHitResult) hit : null;
    }

    private static String fmt(BlockPos p) {
        return p.getX() + " " + p.getY() + " " + p.getZ();
    }

    /** Записывает список мест обратно в config/arsenal_shulker.json (остальные настройки не трогаем). */
    private static boolean savePoints() {
        if (config.root == null || config.file == null) {
            return false;
        }
        try {
            JsonArray arr = new JsonArray();
            for (BlockPos p : config.points) {
                JsonObject o = new JsonObject();
                o.addProperty("x", p.getX());
                o.addProperty("y", p.getY());
                o.addProperty("z", p.getZ());
                arr.add(o);
            }
            config.root.add("points", arr);
            Files.write(config.file, GSON.toJson(config.root).getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось сохранить arsenal_shulker.json: " + ex);
            return false;
        }
    }

    // ------------------------------------------------------------------ тик и волны

    private static void ensureStarted(MinecraftServer server) {
        if (started) {
            return;
        }
        started = true;
        config = ShulkerConfig.load();
        loadState(server.getOverworld());
        scheduleNextWave();
    }

    private static void scheduleNextWave() {
        int min = Math.max(1, config.minMinutes);
        int max = Math.max(min, config.maxMinutes);
        ticksToWave = (min + RNG.nextInt(max - min + 1)) * 60 * 20;
    }

    private static void tick(MinecraftServer server) {
        ensureStarted(server);
        if (rushLeft > 0) {
            // золотая лихорадка: обычные шалкеры не появляются
            if (--rushLeft <= 0) {
                stopGoldRush(server, true);
                return;
            }
            if (--rushNext <= 0) {
                rushNext = config.rushSpawnMinutes * 60 * 20;
                spawnRushWave(server.getOverworld());
            }
            if (rushLeft % 600 == 0) {
                saveState();
            }
            return;
        }
        if (--ticksToWave > 0) {
            return;
        }
        scheduleNextWave();
        if (server.getPlayerManager().getCurrentPlayerCount() > 0) {
            respawnWave(server.getOverworld());
        }
    }

    /** Убирает всех старых шалкеров и ставит новую волну 5-6 штук в случайных точках. */
    private static int respawnWave(ServerWorld world) {
        if (rushLeft > 0) {
            return 0;
        }
        despawnAll(world);
        int count = config.waveMin + RNG.nextInt(Math.max(1, config.waveMax - config.waveMin + 1));
        List<BlockPos> points = new ArrayList<>(config.points);
        Collections.shuffle(points, RNG);
        int placed = 0;
        for (BlockPos p : points) {
            if (placed >= count) {
                break;
            }
            spawnAt(world, p, rollTier());
            placed++;
        }
        saveState();
        return placed;
    }

    /** Шалкеры сразу на всех точках, где их ещё нет. */
    private static int spawnAll(ServerWorld world) {
        int placed = 0;
        if (rushLeft > 0) {
            return 0;
        }
        for (BlockPos p : config.points) {
            if (!ACTIVE.containsKey(p)) {
                spawnAt(world, p, rollTier());
                placed++;
            }
        }
        saveState();
        return placed;
    }

    private static int despawnAll(ServerWorld world) {
        int n = ACTIVE.size();
        for (BlockPos p : new ArrayList<>(ACTIVE.keySet())) {
            if (world.getBlockState(p).getBlock() instanceof ShulkerBoxBlock) {
                world.setBlockState(p, Blocks.AIR.getDefaultState());
            }
        }
        ACTIVE.clear();
        saveState();
        return n;
    }

    // ------------------------------------------------------------------ золотая лихорадка

    public static boolean isRush() {
        return rushLeft > 0;
    }

    public static int rushTicksLeft() {
        return Math.max(0, rushLeft);
    }

    /** Запускает золотую лихорадку: на всех точках золотые (95%) и красные (5%) шалкеры, обычные не появляются. */
    public static boolean startGoldRush(MinecraftServer server) {
        ensureStarted(server);
        if (config.points.isEmpty()) {
            return false;
        }
        ServerWorld world = server.getOverworld();
        despawnAll(world);
        rushLeft = config.rushMinutes * 60 * 20;
        rushNext = config.rushSpawnMinutes * 60 * 20;
        spawnRushWave(world);
        broadcast(server, new LiteralText("Началась ").formatted(Formatting.GRAY)
                .append(new LiteralText("«Золотая лихорадка»").formatted(Formatting.GOLD, Formatting.BOLD))
                .append(new LiteralText("!").formatted(Formatting.GRAY)));
        saveState();
        return true;
    }

    public static void stopGoldRush(MinecraftServer server, boolean announce) {
        ensureStarted(server);
        despawnAll(server.getOverworld());
        rushLeft = 0;
        rushNext = 0;
        scheduleNextWave();
        saveState();
        if (announce) {
            broadcast(server, new LiteralText("«Золотая лихорадка» закончилась.").formatted(Formatting.GRAY));
        }
    }

    /** Шалкеры на всех свободных точках: красный с шансом redChance, иначе золотой. */
    private static int spawnRushWave(ServerWorld world) {
        int placed = 0;
        for (BlockPos p : config.points) {
            if (ACTIVE.containsKey(p)) {
                continue;
            }
            spawnAt(world, p, RNG.nextInt(100) < config.rushRedChance ? Tier.RED : Tier.GOLD);
            placed++;
        }
        saveState();
        return placed;
    }

    private static void broadcast(MinecraftServer server, net.minecraft.text.Text text) {
        server.getPlayerManager().broadcastChatMessage(text, MessageType.SYSTEM, Util.NIL_UUID);
    }

    /** Последний удар по золотому/красному шалкеру: либо взрыв, либо лут прямо на пол. */
    private static void breakRushShulker(ServerWorld world, ServerPlayerEntity player, BlockPos pos, Tier tier) {
        int chance = tier == Tier.GOLD ? config.goldLootChance : config.redLootChance;
        if (RNG.nextInt(100) < chance) {
            world.playSound(null, pos, SoundEvents.BLOCK_SHULKER_BOX_OPEN, SoundCategory.BLOCKS, 1.0F, 1.0F);
            player.sendMessage(new LiteralText("Шалкер сломан! Лут на земле").formatted(Formatting.GOLD), true);
            for (ItemStack stack : com.arsenal.event.CargoLoot.rollFlat(tier == Tier.GOLD ? "goldrush" : "goldrush_red")) {
                drop(world, pos, stack);
            }
        } else {
            player.sendMessage(new LiteralText("Шалкер взорвался!").formatted(Formatting.RED), true);
            for (int i = 0; i < config.rushExplosions; i++) {
                world.createExplosion(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        config.rushExplosionPower, Explosion.DestructionType.NONE);
            }
        }
    }

    private static Tier rollTier() {
        int total = config.chanceGray + config.chanceBlue + config.chancePurple;
        int r = RNG.nextInt(Math.max(1, total));
        if (r < config.chanceGray) {
            return Tier.GRAY;
        }
        if (r < config.chanceGray + config.chanceBlue) {
            return Tier.BLUE;
        }
        return Tier.PURPLE;
    }

    private static void spawnAt(ServerWorld world, BlockPos pos, Tier tier) {
        BlockPos p = pos.toImmutable();
        world.setBlockState(p, tier.block.getDefaultState());
        ACTIVE.put(p, new Active(tier, config.durability(tier)));
        // взрыв примерно как у 3 TNT: урон есть, блоки не ломаются
        for (int i = 0; i < config.explosions; i++) {
            world.createExplosion(null, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5,
                    config.explosionPower, Explosion.DestructionType.NONE);
        }
    }

    // ------------------------------------------------------------------ удары

    private static void hit(ServerWorld world, ServerPlayerEntity player, BlockPos pos, Active a) {
        a.left--;
        if (a.left > 0) {
            player.sendMessage(new LiteralText("У шалкера осталось " + a.left + " прочности").formatted(Formatting.YELLOW), true);
            world.playSound(null, pos, SoundEvents.BLOCK_SHULKER_BOX_CLOSE, SoundCategory.BLOCKS, 1.0F, 1.3F);
            saveState();
            return;
        }
        ACTIVE.remove(pos);
        world.setBlockState(pos, Blocks.AIR.getDefaultState());
        if (a.tier == Tier.GOLD || a.tier == Tier.RED) {
            breakRushShulker(world, player, pos, a.tier);
            saveState();
            return;
        }
        world.playSound(null, pos, SoundEvents.BLOCK_SHULKER_BOX_OPEN, SoundCategory.BLOCKS, 1.0F, 1.0F);
        player.sendMessage(new LiteralText("Шалкер сломан!").formatted(Formatting.GREEN), true);
        for (ItemStack stack : rollLoot(a.tier)) {
            drop(world, pos, stack);
        }
        saveState();
    }

    private static void drop(ServerWorld world, BlockPos pos, ItemStack stack) {
        while (!stack.isEmpty()) {
            ItemStack part = stack.split(Math.min(stack.getCount(), stack.getMaxCount()));
            ItemScatterer.spawn(world, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, part);
        }
    }

    // ------------------------------------------------------------------ лут

    private static final class Pick {
        final JsonObject entry;
        final double multiplier;

        Pick(JsonObject entry, double multiplier) {
            this.entry = entry;
            this.multiplier = multiplier;
        }

        int weight() {
            return entry.has("weight") ? Math.max(0, entry.get("weight").getAsInt()) : 10;
        }
    }

    private static void collect(String tier, double mult, List<Pick> out, int depth) {
        if (depth > 5) {
            return;
        }
        JsonObject t = config.loot.get(tier);
        if (t == null) {
            return;
        }
        if (t.has("include")) {
            for (JsonElement inc : t.getAsJsonArray("include")) {
                JsonObject o = inc.getAsJsonObject();
                double m = o.has("multiplier") ? o.get("multiplier").getAsDouble() : 1.0;
                collect(o.get("tier").getAsString(), mult * m, out, depth + 1);
            }
        }
        if (t.has("entries")) {
            for (JsonElement el : t.getAsJsonArray("entries")) {
                out.add(new Pick(el.getAsJsonObject(), mult));
            }
        }
    }

    private static List<ItemStack> rollLoot(Tier tier) {
        List<ItemStack> result = new ArrayList<>();
        List<Pick> pool = new ArrayList<>();
        collect(tier.key, 1.0, pool, 0);
        int total = 0;
        for (Pick p : pool) {
            total += p.weight();
        }
        if (total <= 0) {
            return result;
        }
        JsonObject t = config.loot.get(tier.key);
        int rollsMin = 3;
        int rollsMax = 5;
        if (t != null && t.has("rolls")) {
            JsonArray r = t.getAsJsonArray("rolls");
            rollsMin = r.get(0).getAsInt();
            rollsMax = r.get(1).getAsInt();
        }
        int rolls = rollsMin + RNG.nextInt(Math.max(1, rollsMax - rollsMin + 1));
        for (int i = 0; i < rolls; i++) {
            int r = RNG.nextInt(total);
            for (Pick p : pool) {
                r -= p.weight();
                if (r < 0) {
                    ItemStack s = makeStack(p);
                    if (s != null && !s.isEmpty()) {
                        result.add(s);
                    }
                    break;
                }
            }
        }
        return result;
    }

    /**
     * Незеритовый меч из фиолетового шалкера: Острота 6, Заговор огня 2, Добыча 0-4,
     * Прочность 3-4, Разящий клинок 0-3 (ноль = зачарования нет).
     */
    private static ItemStack shulkerSword() {
        ItemStack sword = new ItemStack(net.minecraft.item.Items.NETHERITE_SWORD);
        sword.addEnchantment(net.minecraft.enchantment.Enchantments.SHARPNESS, 6);
        sword.addEnchantment(net.minecraft.enchantment.Enchantments.FIRE_ASPECT, 2);
        int looting = RNG.nextInt(5);
        if (looting > 0) {
            sword.addEnchantment(net.minecraft.enchantment.Enchantments.LOOTING, looting);
        }
        sword.addEnchantment(net.minecraft.enchantment.Enchantments.UNBREAKING, 3 + RNG.nextInt(2));
        int sweeping = RNG.nextInt(4);
        if (sweeping > 0) {
            sword.addEnchantment(net.minecraft.enchantment.Enchantments.SWEEPING, sweeping);
        }
        return sword;
    }

    private static ItemStack makeStack(Pick p) {
        JsonObject e = p.entry;
        Item item = Registry.ITEM.getOrEmpty(new Identifier(e.get("item").getAsString())).orElse(null);
        if (item == null) {
            return null;
        }
        if (e.has("enchantment")) {
            Enchantment ench = Registry.ENCHANTMENT.getOrEmpty(new Identifier(e.get("enchantment").getAsString())).orElse(null);
            if (ench == null) {
                return null;
            }
            JsonArray levels = e.getAsJsonArray("levels");
            int level = levels.get(RNG.nextInt(levels.size())).getAsInt();
            return EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ench, level));
        }
        if (e.has("special") && "shulker_sword".equals(e.get("special").getAsString())) {
            return shulkerSword();
        }
        int min = e.has("min") ? e.get("min").getAsInt() : 1;
        int max = e.has("max") ? e.get("max").getAsInt() : min;
        int count = min + RNG.nextInt(Math.max(1, max - min + 1));
        if (!e.has("potion")) {
            count = Math.max(1, (int) Math.round(count * p.multiplier));
        }
        ItemStack stack = new ItemStack(item, count);
        if (e.has("potion")) {
            Potion potion = Registry.POTION.getOrEmpty(new Identifier(e.get("potion").getAsString())).orElse(null);
            if (potion != null) {
                PotionUtil.setPotion(stack, potion);
            }
        }
        return stack;
    }

    // ------------------------------------------------------------------ сохранение состояния

    private static Path stateFile() {
        return FabricLoader.getInstance().getConfigDir().resolve("arsenal_shulker_state.json");
    }

    private static void saveState() {
        try {
            JsonArray arr = new JsonArray();
            for (Map.Entry<BlockPos, Active> en : ACTIVE.entrySet()) {
                JsonObject o = new JsonObject();
                o.addProperty("x", en.getKey().getX());
                o.addProperty("y", en.getKey().getY());
                o.addProperty("z", en.getKey().getZ());
                o.addProperty("tier", en.getValue().tier.key);
                o.addProperty("left", en.getValue().left);
                arr.add(o);
            }
            JsonObject root = new JsonObject();
            root.add("active", arr);
            root.addProperty("rushLeft", rushLeft);
            root.addProperty("rushNext", rushNext);
            Files.write(stateFile(), root.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
            // не критично: после перезапуска шалкеры просто перестанут считаться событием
        }
    }

    private static void loadState(ServerWorld world) {
        ACTIVE.clear();
        rushLeft = 0;
        rushNext = 0;
        try {
            Path f = stateFile();
            if (!Files.exists(f)) {
                return;
            }
            String text = new String(Files.readAllBytes(f), StandardCharsets.UTF_8);
            JsonObject root = new JsonParser().parse(text).getAsJsonObject();
            if (root.has("rushLeft")) {
                rushLeft = root.get("rushLeft").getAsInt();
                rushNext = root.has("rushNext") ? root.get("rushNext").getAsInt() : 0;
            }
            for (JsonElement el : root.getAsJsonArray("active")) {
                JsonObject o = el.getAsJsonObject();
                BlockPos p = new BlockPos(o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt());
                if (world.getBlockState(p).getBlock() instanceof ShulkerBoxBlock) {
                    ACTIVE.put(p, new Active(Tier.byKey(o.get("tier").getAsString()), o.get("left").getAsInt()));
                }
            }
        } catch (Exception ignored) {
            ACTIVE.clear();
        }
    }

    // ------------------------------------------------------------------ конфиг

    private static final class ShulkerConfig {
        int minMinutes = 3;
        int maxMinutes = 5;
        int waveMin = 5;
        int waveMax = 6;
        int chanceGray = 50;
        int chanceBlue = 30;
        int chancePurple = 20;
        int durGray = 5;
        int durBlue = 8;
        int durPurple = 13;
        int explosions = 3;
        float explosionPower = 4.0F;
        // золотая лихорадка (если в файле настроек нет раздела goldRush, работают эти значения)
        int rushMinutes = 10;
        int rushSpawnMinutes = 3;
        int rushRedChance = 5;
        int durGold = 30;
        int durRed = 45;
        int goldLootChance = 20;
        int redLootChance = 50;
        int rushExplosions = 3;
        float rushExplosionPower = 4.0F;
        final List<BlockPos> points = new ArrayList<>();
        final Map<String, JsonObject> loot = new HashMap<>();
        /** Весь файл настроек и путь к нему: нужны, чтобы команды add/del/reset могли сохранять точки. */
        JsonObject root;
        Path file;

        int durability(Tier t) {
            switch (t) {
                case GRAY: return durGray;
                case BLUE: return durBlue;
                case GOLD: return durGold;
                case RED: return durRed;
                default: return durPurple;
            }
        }

        static int num(JsonObject o, String key, int def) {
            return o.has(key) ? o.get(key).getAsInt() : def;
        }

        static JsonObject readDefault() {
            try (InputStream in = ShulkerEvent.class.getResourceAsStream("/arsenal_shulker_default.json")) {
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                return new JsonParser().parse(new String(out.toByteArray(), StandardCharsets.UTF_8)).getAsJsonObject();
            } catch (Exception ex) {
                return null;
            }
        }

        static ShulkerConfig load() {
            ShulkerConfig c = new ShulkerConfig();
            try {
                Path file = FabricLoader.getInstance().getConfigDir().resolve("arsenal_shulker.json");
                if (!Files.exists(file)) {
                    try (InputStream in = ShulkerEvent.class.getResourceAsStream("/arsenal_shulker_default.json")) {
                        Files.copy(in, file);
                    }
                }
                c.file = file;
                String text = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
                JsonObject root = new JsonParser().parse(text).getAsJsonObject();
                // старый файл настроек: берём новый лут по умолчанию, а места появления сохраняем
                JsonObject def = readDefault();
                int fileVersion = root.has("configVersion") ? root.get("configVersion").getAsInt() : 1;
                if (def != null && fileVersion < def.get("configVersion").getAsInt()) {
                    Files.copy(file, file.resolveSibling("arsenal_shulker.json.bak"),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    if (root.has("points")) {
                        def.add("points", root.get("points"));
                    }
                    Files.write(file, GSON.toJson(def).getBytes(StandardCharsets.UTF_8));
                    root = def;
                }
                c.root = root;
                c.minMinutes = root.getAsJsonObject("spawnEveryMinutes").get("min").getAsInt();
                c.maxMinutes = root.getAsJsonObject("spawnEveryMinutes").get("max").getAsInt();
                c.waveMin = root.getAsJsonObject("waveSize").get("min").getAsInt();
                c.waveMax = root.getAsJsonObject("waveSize").get("max").getAsInt();
                JsonObject ch = root.getAsJsonObject("chances");
                c.chanceGray = ch.get("gray").getAsInt();
                c.chanceBlue = ch.get("blue").getAsInt();
                c.chancePurple = ch.get("purple").getAsInt();
                JsonObject du = root.getAsJsonObject("durability");
                c.durGray = du.get("gray").getAsInt();
                c.durBlue = du.get("blue").getAsInt();
                c.durPurple = du.get("purple").getAsInt();
                if (root.has("explosions")) {
                    c.explosions = root.get("explosions").getAsInt();
                }
                if (root.has("explosionPower")) {
                    c.explosionPower = root.get("explosionPower").getAsFloat();
                }
                if (root.has("goldRush")) {
                    JsonObject gr = root.getAsJsonObject("goldRush");
                    c.rushMinutes = num(gr, "durationMinutes", c.rushMinutes);
                    c.rushSpawnMinutes = num(gr, "spawnEveryMinutes", c.rushSpawnMinutes);
                    c.rushRedChance = num(gr, "redChancePercent", c.rushRedChance);
                    c.rushExplosions = num(gr, "breakExplosions", c.rushExplosions);
                    c.rushExplosionPower = (float) num(gr, "breakExplosionPower", (int) c.rushExplosionPower);
                    if (gr.has("durability")) {
                        c.durGold = num(gr.getAsJsonObject("durability"), "gold", c.durGold);
                        c.durRed = num(gr.getAsJsonObject("durability"), "red", c.durRed);
                    }
                    if (gr.has("lootChancePercent")) {
                        c.goldLootChance = num(gr.getAsJsonObject("lootChancePercent"), "gold", c.goldLootChance);
                        c.redLootChance = num(gr.getAsJsonObject("lootChancePercent"), "red", c.redLootChance);
                    }
                }
                for (JsonElement el : root.getAsJsonArray("points")) {
                    JsonObject o = el.getAsJsonObject();
                    c.points.add(new BlockPos(o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt()));
                }
                JsonObject loot = root.getAsJsonObject("loot");
                for (Map.Entry<String, JsonElement> en : loot.entrySet()) {
                    c.loot.put(en.getKey(), en.getValue().getAsJsonObject());
                }
            } catch (Exception ex) {
                System.err.println("[Arsenal] Не удалось прочитать arsenal_shulker.json: " + ex);
            }
            return c;
        }
    }
}
