package com.arsenal.event;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Лут грузов: config/arsenal_cargo.json (создаётся сам из настроек по умолчанию). */
public final class CargoLoot {
    private static final Random RNG = new Random();
    private static JsonObject root;

    private CargoLoot() {
    }

    public static void load() {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("arsenal_cargo.json");
            if (!Files.exists(file)) {
                try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json")) {
                    Files.copy(in, file);
                }
            }
            root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            // устаревший файл настроек заменяем новым (старый остаётся как .bak)
            int version = root.has("configVersion") ? root.get("configVersion").getAsInt() : 1;
            if (version < 4) {
                Files.copy(file, file.resolveSibling("arsenal_cargo.json.bak"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json")) {
                    Files.copy(in, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                root = new JsonParser().parse(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            }
            addMissingTables(file);
        } catch (Exception ex) {
            System.err.println("[Arsenal] Не удалось прочитать arsenal_cargo.json: " + ex);
            root = null;
        }
    }

    /** Новый лут из настроек по умолчанию попадает и в старые файлы настроек, остальное в них не трогаем. */
    private static void addMissingTables(Path file) throws Exception {
        JsonObject loot = root.has("loot") ? root.getAsJsonObject("loot") : null;
        if (loot == null) {
            return;
        }
        String text;
        try (InputStream in = CargoLoot.class.getResourceAsStream("/arsenal_cargo_default.json");
             java.util.Scanner sc = new java.util.Scanner(in, "UTF-8")) {
            text = sc.useDelimiter("\\A").next();
        }
        JsonObject def = new JsonParser().parse(text).getAsJsonObject();
        if (!def.has("loot")) {
            return;
        }
        boolean changed = false;
        JsonObject defLoot = def.getAsJsonObject("loot");
        if (!loot.has("deadly") && defLoot.has("deadly")) {
            loot.add("deadly", defLoot.get("deadly"));
            root.addProperty("_help_deadly", "deadly - лут смертельного груза (без обычных и эпических талисманов и вещей из китов wither, kraken и dragon; есть кит infinity, больше шанс взрывоустойчивости, мифических сфер, Цербера и Флеша).");
            changed = true;
        }
        // зелье победителя: добавляем в каждую таблицу, где его ещё нет
        for (String table : new String[]{"peace", "explosive", "deadly", "goldrush", "goldrush_red"}) {
            if (!loot.has(table) || !defLoot.has(table)) {
                continue;
            }
            com.google.gson.JsonArray mine = loot.getAsJsonObject(table).getAsJsonArray("entries");
            if (mine == null || hasItem(mine, "arsenal:winner_potion")) {
                continue;
            }
            for (com.google.gson.JsonElement el : defLoot.getAsJsonObject(table).getAsJsonArray("entries")) {
                if (el.getAsJsonObject().has("item") && "arsenal:winner_potion".equals(el.getAsJsonObject().get("item").getAsString())) {
                    mine.add(el);
                    changed = true;
                    break;
                }
            }
        }
        if (changed) {
            Files.write(file, new com.google.gson.GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()
                    .toJson(root).getBytes(StandardCharsets.UTF_8));
        }
    }

    private static boolean hasItem(com.google.gson.JsonArray entries, String id) {
        for (com.google.gson.JsonElement el : entries) {
            JsonObject o = el.getAsJsonObject();
            if (o.has("item") && id.equals(o.get("item").getAsString())) {
                return true;
            }
        }
        return false;
    }

    /** Радиус смертельного взрыва взрывного груза (блоков). */
    public static double blastRadius(double fallback) {
        if (root != null && root.has("explosiveBlastRadius")) {
            return root.get("explosiveBlastRadius").getAsDouble();
        }
        return fallback;
    }

    public static float blastPower(float fallback) {
        if (root != null && root.has("explosiveBlastPower")) {
            return root.get("explosiveBlastPower").getAsFloat();
        }
        return fallback;
    }

    /** Лут для шалкеров груза данного вида ("peace" или "explosive"). Каждый шалкер забивается полностью. */
    public static List<List<ItemStack>> roll(String table, int shulkers) {
        return rollInto(table, shulkers, 0);
    }

    /** Лут золотой лихорадки: один список стаков, их число берётся из "stacks" [мин, макс] таблицы. */
    public static List<ItemStack> rollFlat(String table) {
        if (root == null) {
            load();
        }
        int count = 12;
        if (root != null && root.has("loot") && root.getAsJsonObject("loot").has(table)) {
            JsonObject t = root.getAsJsonObject("loot").getAsJsonObject(table);
            if (t.has("stacks")) {
                JsonArray r = t.getAsJsonArray("stacks");
                int lo = r.get(0).getAsInt();
                int hi = r.get(1).getAsInt();
                count = lo + RNG.nextInt(Math.max(1, hi - lo + 1));
            }
        }
        return rollInto(table, 1, count).get(0);
    }

    private static List<List<ItemStack>> rollInto(String table, int shulkers, int slotsOverride) {
        List<List<ItemStack>> result = new ArrayList<>();
        for (int i = 0; i < shulkers; i++) {
            result.add(new ArrayList<>());
        }
        if (root == null) {
            load();
        }
        if (root == null || !root.has("loot") || !root.getAsJsonObject("loot").has(table)) {
            return result;
        }
        JsonObject t = root.getAsJsonObject("loot").getAsJsonObject(table);
        JsonArray entries = t.getAsJsonArray("entries");
        int slots = slotsOverride > 0 ? slotsOverride : (t.has("slotsPerShulker") ? t.get("slotsPerShulker").getAsInt() : 27);
        JsonObject groupLimits = t.has("groupLimits") ? t.getAsJsonObject("groupLimits") : null;
        Map<Integer, Integer> used = new HashMap<>();
        Map<String, Integer> groupUsed = new HashMap<>();
        for (int s = 0; s < shulkers; s++) {
            List<ItemStack> list = result.get(s);
            int guard = 0;
            while (list.size() < slots && guard++ < slots * 60) {
                int index = pick(entries);
                if (index < 0) {
                    break;
                }
                JsonObject e = entries.get(index).getAsJsonObject();
                int limit = e.has("limit") ? e.get("limit").getAsInt() : 0;
                int u = used.getOrDefault(index, 0);
                if (limit > 0 && u >= limit) {
                    continue;
                }
                String group = e.has("group") ? e.get("group").getAsString() : null;
                if (group != null && groupLimits != null && groupLimits.has(group)
                        && groupUsed.getOrDefault(group, 0) >= groupLimits.get(group).getAsInt()) {
                    continue;
                }
                List<ItemStack> made = make(e);
                if (made.isEmpty()) {
                    continue;
                }
                used.put(index, u + 1);
                if (group != null) {
                    groupUsed.put(group, groupUsed.getOrDefault(group, 0) + 1);
                }
                for (ItemStack stack : made) {
                    if (list.size() < slots) {
                        list.add(stack);
                    }
                }
            }
        }
        return result;
    }

    private static int pick(JsonArray entries) {
        int total = 0;
        for (JsonElement el : entries) {
            JsonObject e = el.getAsJsonObject();
            total += Math.max(0, e.has("weight") ? e.get("weight").getAsInt() : 10);
        }
        if (total <= 0) {
            return -1;
        }
        int r = RNG.nextInt(total);
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            r -= Math.max(0, e.has("weight") ? e.get("weight").getAsInt() : 10);
            if (r < 0) {
                return i;
            }
        }
        return -1;
    }

    /** Количество: чаще выпадает середина диапазона (а не 1), uniform:true даёт равномерный разброс. */
    private static int rollCount(JsonObject e) {
        int min = e.has("min") ? e.get("min").getAsInt() : 1;
        int max = e.has("max") ? e.get("max").getAsInt() : min;
        if (max <= min) {
            return min;
        }
        if (e.has("uniform") && e.get("uniform").getAsBoolean()) {
            return min + RNG.nextInt(max - min + 1);
        }
        double u = (RNG.nextDouble() + RNG.nextDouble()) / 2.0;
        return min + (int) Math.round(u * (max - min));
    }

    /** Один выпавший пункт: обычно один стак, но не стакающиеся предметы (зелья) выпадают отдельными штуками. */
    private static List<ItemStack> make(JsonObject e) {
        List<ItemStack> out = new ArrayList<>();
        if (e.has("kit")) {
            ItemStack gear = com.arsenal.kit.KitCommand.lootGear(e.get("kit").getAsString(), e.get("part").getAsString());
            if (gear != null && !gear.isEmpty()) {
                out.add(gear);
            }
            return out;
        }
        Item item = Registry.ITEM.getOrEmpty(new Identifier(e.get("item").getAsString())).orElse(null);
        if (item == null) {
            return out;
        }
        if (e.has("enchantment")) {
            Enchantment ench = Registry.ENCHANTMENT.getOrEmpty(new Identifier(e.get("enchantment").getAsString())).orElse(null);
            if (ench == null) {
                return out;
            }
            JsonArray levels = e.getAsJsonArray("levels");
            int level = levels.get(RNG.nextInt(levels.size())).getAsInt();
            out.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(ench, level)));
            return out;
        }
        if (e.has("mythic")) {
            out.add(com.arsenal.sphere.Spheres.mythic(RNG));
            return out;
        }
        if (e.has("effectLevel")) {
            out.add(com.arsenal.sphere.Spheres.randomEffect(item, e.get("effectLevel").getAsInt(), RNG));
            return out;
        }
        int count = rollCount(e);
        if (item.getMaxCount() <= 1) {
            for (int i = 0; i < Math.max(1, count); i++) {
                out.add(build(e, item, 1));
            }
        } else {
            out.add(build(e, item, count));
        }
        return out;
    }

    private static ItemStack build(JsonObject e, Item item, int count) {
        ItemStack stack = new ItemStack(item, Math.max(1, Math.min(count, item.getMaxCount())));
        if (e.has("enchants")) {
            for (JsonElement el : e.getAsJsonArray("enchants")) {
                JsonArray pair = el.getAsJsonArray();
                Enchantment ench = Registry.ENCHANTMENT.getOrEmpty(new Identifier(pair.get(0).getAsString())).orElse(null);
                if (ench == null) {
                    continue;
                }
                int lo = pair.get(1).getAsInt();
                int hi = pair.size() > 2 ? pair.get(2).getAsInt() : lo;
                double chance = pair.size() > 3 ? pair.get(3).getAsDouble() : 1.0;
                if (chance < 1.0 && RNG.nextDouble() >= chance) {
                    continue;
                }
                int level = lo + RNG.nextInt(Math.max(1, hi - lo + 1));
                if (level > 0) {
                    stack.addEnchantment(ench, level);
                }
            }
        }
        if (e.has("potion")) {
            Potion potion = Registry.POTION.getOrEmpty(new Identifier(e.get("potion").getAsString())).orElse(null);
            if (potion != null) {
                PotionUtil.setPotion(stack, potion);
            }
        }
        return stack;
    }

    /** Раскладывает предметы по слотам шалкера в случайном порядке. */
    public static void fill(net.minecraft.inventory.Inventory inv, List<ItemStack> stacks) {
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inv.size(); i++) {
            slots.add(i);
        }
        Collections.shuffle(slots, RNG);
        for (int i = 0; i < stacks.size() && i < slots.size(); i++) {
            inv.setStack(slots.get(i), stacks.get(i));
        }
    }
}
