package com.arsenal.priv;

import com.arsenal.protection.SpawnProtection;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /ps add ник, /ps owneradd ник, /ps del ник, /ps info. Работает, пока игрок стоит на территории привата.
 * Добавленный игрок строит и ломает на территории. Владелец дополнительно ломает и чинит сам приват и добавляет других.
 */
public final class PrivateCommand {
    private PrivateCommand() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(CommandManager.literal("ps")
                .executes(ctx -> help(ctx.getSource().getPlayer()))
                .then(CommandManager.literal("add").then(CommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, b) -> CommandSource.suggestMatching(ctx.getSource().getMinecraftServer().getPlayerManager().getPlayerNames(), b))
                        .executes(ctx -> add(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "player"), false))))
                .then(CommandManager.literal("owneradd").then(CommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, b) -> CommandSource.suggestMatching(ctx.getSource().getMinecraftServer().getPlayerManager().getPlayerNames(), b))
                        .executes(ctx -> add(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "player"), true))))
                .then(CommandManager.literal("del").then(CommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, b) -> {
                            List<String> names = new ArrayList<>();
                            if (ctx.getSource().getEntity() instanceof ServerPlayerEntity) {
                                PrivateManager.Entry e = region((ServerPlayerEntity) ctx.getSource().getEntity());
                                if (e != null) {
                                    names.addAll(e.coOwners.values());
                                    names.addAll(e.members.values());
                                }
                            }
                            return CommandSource.suggestMatching(names, b);
                        })
                        .executes(ctx -> del(ctx.getSource().getPlayer(), StringArgumentType.getString(ctx, "player")))))
                .then(CommandManager.literal("info").executes(ctx -> info(ctx.getSource().getPlayer())))));
    }

    private static void say(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(new LiteralText(text).formatted(color), false);
    }

    private static int help(ServerPlayerEntity p) {
        say(p, "/ps add ник: добавить игрока\n/ps owneradd ник: добавить владельца\n/ps del ник: убрать из привата\n/ps info: кто в привате\n"
                + "Команды работают, пока вы стоите на территории привата.", Formatting.YELLOW);
        return 1;
    }

    /** Приват, на территории которого стоит игрок (если их несколько, то тот, где он владелец). */
    private static PrivateManager.Entry region(ServerPlayerEntity p) {
        List<PrivateManager.Entry> list = PrivateManager.regionsAt(p.world, p.getBlockPos());
        PrivateManager.Entry first = null;
        for (PrivateManager.Entry e : list) {
            if (e.isOwner(p.getUuid())) {
                return e;
            }
            if (first == null) {
                first = e;
            }
        }
        return first;
    }

    private static PrivateManager.Entry needRegion(ServerPlayerEntity p) {
        PrivateManager.Entry e = region(p);
        if (e == null) {
            say(p, "Вы должны находиться в зоне привата", Formatting.RED);
        }
        return e;
    }

    private static GameProfile resolve(MinecraftServer server, String name) {
        ServerPlayerEntity online = server.getPlayerManager().getPlayer(name);
        if (online != null) {
            return online.getGameProfile();
        }
        return server.getUserCache().findByName(name);
    }

    private static int add(ServerPlayerEntity p, String nick, boolean asOwner) {
        PrivateManager.Entry e = needRegion(p);
        if (e == null) {
            return 0;
        }
        boolean bypass = SpawnProtection.bypass(p);
        boolean creator = e.owner.equals(p.getUuid()) || bypass;
        if (!e.isOwner(p.getUuid()) && !bypass) {
            say(p, "Добавлять игроков могут только владельцы привата", Formatting.RED);
            return 0;
        }
        if (asOwner && !creator) {
            say(p, "Добавлять владельцев может только создатель привата", Formatting.RED);
            return 0;
        }
        GameProfile profile = resolve(p.getServer(), nick);
        if (profile == null || profile.getId() == null) {
            say(p, "Игрок не найден (он должен хотя бы раз зайти на сервер)", Formatting.RED);
            return 0;
        }
        UUID id = profile.getId();
        String name = profile.getName();
        if (id.equals(e.owner)) {
            say(p, "Это создатель привата", Formatting.RED);
            return 0;
        }
        if (e.coOwners.containsKey(id)) {
            say(p, "Игрок " + name + " уже владелец привата", Formatting.RED);
            return 0;
        }
        if (!asOwner && e.members.containsKey(id)) {
            say(p, "Игрок " + name + " уже добавлен в приват", Formatting.RED);
            return 0;
        }
        if (asOwner) {
            e.members.remove(id);
            e.coOwners.put(id, name);
        } else {
            e.members.put(id, name);
        }
        PrivateManager.save();
        say(p, "Игрок " + name + (asOwner ? " теперь владелец привата" : " добавлен в приват"), Formatting.GREEN);
        ServerPlayerEntity target = p.getServer().getPlayerManager().getPlayer(id);
        if (target != null) {
            say(target, "Игрок " + p.getGameProfile().getName() + (asOwner ? " назначил вас владельцем своего привата" : " добавил вас в свой приват")
                    + " (" + e.pos.getX() + " " + e.pos.getY() + " " + e.pos.getZ() + ")", Formatting.GREEN);
        }
        return 1;
    }

    private static UUID find(Map<UUID, String> map, String nick) {
        for (Map.Entry<UUID, String> en : map.entrySet()) {
            if (en.getValue().equalsIgnoreCase(nick)) {
                return en.getKey();
            }
        }
        return null;
    }

    private static int del(ServerPlayerEntity p, String nick) {
        PrivateManager.Entry e = needRegion(p);
        if (e == null) {
            return 0;
        }
        boolean bypass = SpawnProtection.bypass(p);
        boolean creator = e.owner.equals(p.getUuid()) || bypass;
        if (!e.isOwner(p.getUuid()) && !bypass) {
            say(p, "Убирать игроков могут только владельцы привата", Formatting.RED);
            return 0;
        }
        if (e.ownerName.equalsIgnoreCase(nick)) {
            say(p, "Создателя привата убрать нельзя", Formatting.RED);
            return 0;
        }
        UUID id = find(e.coOwners, nick);
        if (id != null) {
            if (!creator && !id.equals(p.getUuid())) {
                say(p, "Убрать владельца может только создатель привата", Formatting.RED);
                return 0;
            }
            String name = e.coOwners.remove(id);
            PrivateManager.save();
            say(p, "Владелец " + name + " убран из привата", Formatting.GREEN);
            return 1;
        }
        id = find(e.members, nick);
        if (id != null) {
            String name = e.members.remove(id);
            PrivateManager.save();
            say(p, "Игрок " + name + " убран из привата", Formatting.GREEN);
            return 1;
        }
        say(p, "Игрок " + nick + " не найден в этом привате", Formatting.RED);
        return 0;
    }

    private static int info(ServerPlayerEntity p) {
        PrivateManager.Entry e = needRegion(p);
        if (e == null) {
            return 0;
        }
        BlockPos pos = e.pos;
        StringBuilder sb = new StringBuilder();
        sb.append("Приват ").append(e.type.size).append("×").append(e.type.size)
                .append(" (").append(pos.getX()).append(" ").append(pos.getY()).append(" ").append(pos.getZ()).append(")\n");
        sb.append("Создатель: ").append(e.ownerName).append("\n");
        sb.append("Владельцы: ").append(e.coOwners.isEmpty() ? "нет" : String.join(", ", e.coOwners.values())).append("\n");
        sb.append("Добавленные: ").append(e.members.isEmpty() ? "нет" : String.join(", ", e.members.values()));
        say(p, sb.toString(), Formatting.AQUA);
        return 1;
    }
}
