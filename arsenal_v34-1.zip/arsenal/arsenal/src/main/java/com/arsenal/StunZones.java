package com.arsenal;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Зоны стана: пока зона активна, игрок внутри (включая активатора) не может бросать жемчуг эндера
 * и есть хорус (плод коралла: он телепортирует, так что действует то же правило).
 *
 * Как сделано (без мигания): когда игрок оказывается в зоне, ему один раз ставится кулдаун на жемчуг
 * ровно до конца зоны (на предмете виден обычный счётчик). Когда игрок выходит из зоны,
 * кулдаун снимается, а если до этого он бросал жемчуг, возвращается остаток обычных 15 секунд.
 */
public final class StunZones {
    /** Обычный кулдаун жемчуга после броска (тики). */
    public static final int PEARL_COOLDOWN_TICKS = 20 * 15;

    private static final List<Zone> ZONES = new ArrayList<>();
    /** Кому мы поставили кулдаун из-за зоны. */
    private static final Map<UUID, Long> BLOCKED = new HashMap<>();
    /** Кому мы поставили кулдаун на хорус из-за зоны. */
    private static final Map<UUID, Long> BLOCKED_CHORUS = new HashMap<>();
    /** Когда игрок в последний раз бросал жемчуг (игровое время). */
    private static final Map<UUID, Long> LAST_THROW = new HashMap<>();

    private static class Zone {
        final ServerWorld world;
        final Box box;
        final long endTime;
        /** Круглая зона (центр и радиус по горизонтали); box тогда задаёт только высоту и охват. */
        final boolean circle;
        final double cx;
        final double cz;
        final double r2;

        Zone(ServerWorld world, Box box, long endTime) {
            this(world, box, endTime, false, 0, 0, 0);
        }

        Zone(ServerWorld world, Box box, long endTime, boolean circle, double cx, double cz, double r) {
            this.world = world;
            this.box = box;
            this.endTime = endTime;
            this.circle = circle;
            this.cx = cx;
            this.cz = cz;
            this.r2 = r * r;
        }

        boolean contains(net.minecraft.util.math.Vec3d pos) {
            if (!box.contains(pos)) {
                return false;
            }
            if (!circle) {
                return true;
            }
            double dx = pos.x - cx;
            double dz = pos.z - cz;
            return dx * dx + dz * dz <= r2;
        }
    }

    private StunZones() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(StunZones::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            ZONES.clear();
            BLOCKED.clear();
            BLOCKED_CHORUS.clear();
            LAST_THROW.clear();
        });
    }

    public static void add(ServerWorld world, Box box, int ticks) {
        ZONES.add(new Zone(world, box, world.getTime() + ticks));
    }

    /** Круглая зона стана (смертельный груз): по горизонтали радиус r вокруг (cx, cz), по высоте от minY до maxY. */
    public static void addCircle(ServerWorld world, double cx, double cz, double r, double minY, double maxY, int ticks) {
        Box box = new Box(cx - r, minY, cz - r, cx + r, maxY, cz + r);
        ZONES.add(new Zone(world, box, world.getTime() + ticks, true, cx, cz, r));
    }

    /** Убрать круглую зону с этим центром (груз исчез раньше времени). */
    public static void removeCircle(ServerWorld world, double cx, double cz) {
        ZONES.removeIf(z -> z.circle && z.world == world && z.cx == cx && z.cz == cz);
    }

    /** Вызывается, когда игрок бросил жемчуг (см. EnderPearlItemMixin). */
    public static void onPearlThrown(PlayerEntity player) {
        LAST_THROW.put(player.getUuid(), player.world.getTime());
    }

    private static void tick(MinecraftServer server) {
        if (ZONES.isEmpty() && BLOCKED.isEmpty() && BLOCKED_CHORUS.isEmpty()) {
            return;
        }
        Iterator<Zone> it = ZONES.iterator();
        while (it.hasNext()) {
            Zone zone = it.next();
            if (zone.world.getTime() >= zone.endTime) {
                it.remove();
            }
        }

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            ServerWorld world = player.getServerWorld();
            long now = world.getTime();

            long end = 0;
            for (Zone zone : ZONES) {
                if (zone.world == world && zone.contains(player.getPos())) {
                    end = Math.max(end, zone.endTime);
                }
            }

            if (end > now) {
                // в зоне: если кулдауна на жемчуг нет, ставим его до конца зоны (один раз)
                if (!player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL)) {
                    player.getItemCooldownManager().set(Items.ENDER_PEARL, (int) (end - now));
                    BLOCKED.put(player.getUuid(), end);
                }
            } else if (BLOCKED.remove(player.getUuid()) != null) {
                // вышел из зоны или зона закончилась: снимаем блок, возвращая остаток обычного кулдауна
                Long last = LAST_THROW.get(player.getUuid());
                int remaining = last == null ? 0 : (int) Math.max(0, PEARL_COOLDOWN_TICKS - (now - last));
                player.getItemCooldownManager().set(Items.ENDER_PEARL, remaining);
            }

            // хорус: то же самое, только без остатка обычного кулдауна (у хоруса его нет)
            if (end > now) {
                if (player.isUsingItem() && player.getActiveItem().getItem() == Items.CHORUS_FRUIT) {
                    player.stopUsingItem();     // уже начал есть, когда зона появилась: прерываем
                }
                if (!player.getItemCooldownManager().isCoolingDown(Items.CHORUS_FRUIT)) {
                    player.getItemCooldownManager().set(Items.CHORUS_FRUIT, (int) (end - now));
                    BLOCKED_CHORUS.put(player.getUuid(), end);
                }
            } else if (BLOCKED_CHORUS.remove(player.getUuid()) != null) {
                player.getItemCooldownManager().set(Items.CHORUS_FRUIT, 0);
            }
        }
    }
}
