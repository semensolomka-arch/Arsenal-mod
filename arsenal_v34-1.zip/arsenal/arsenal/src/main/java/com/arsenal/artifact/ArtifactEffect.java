package com.arsenal.artifact;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;

/**
 * Десять эффектов "предметов Хранителя опыта". Каждый работает, пока предмет-эффект лежит у игрока
 * в инвентаре, либо пока в инвентаре лежит Артефакт с этим эффектом.
 */
public enum ArtifactEffect {
    HUNTER("hunter", "Охотник", false, 0xFF8000, 0xFF8000),
    ILLUMINATOR("illuminator", "Иллюминатор", false, 0xF0F0F0, 0xC8C8C8),
    SNOWMAN("snowman", "Снеговик", true, 0x7FDDEF, 0x7FDDEF),
    ENDERMAN("enderman", "Эндермен", true, 0x35A89C, 0x35A89C),
    ANTI_PHANTOM("anti_phantom", "АнтиФантом", false, 0xFFB300, 0xFFB300),
    TELEKINESIS("telekinesis", "Телекинез", false, 0xDD44DD, 0xDD44DD),
    GRAVITY("gravity", "Гравитация", false, 0xFFA000, 0xFFA000),
    BLAST_RESISTANCE("blast_resistance", "Взрывоустойчивость", false, 0xFF6A00, 0xFF6A00),
    VAMPIRISM("vampirism", "Вампиризм", false, 0xEE1111, 0xEE1111),
    JUSTICE("justice", "Справедливость", true, 0xFFA500, 0xFFA500);

    public final String id;
    public final String title;
    /** Блестит ли предмет-эффект как зачарованный. */
    public final boolean glint;
    /** Цвет названия и цвет выделенных слов в описании (как на сервере). */
    public final int nameColor;
    public final int lineColor;

    /** Заполняется при регистрации. */
    public Item item;
    /** Служебное зачарование, которым эффект записывается на Артефакт. */
    public Enchantment enchantment;

    ArtifactEffect(String id, String title, boolean glint, int nameColor, int lineColor) {
        this.id = id;
        this.title = title;
        this.glint = glint;
        this.nameColor = nameColor;
        this.lineColor = lineColor;
    }

    public static ArtifactEffect byItem(Item item) {
        for (ArtifactEffect e : values()) {
            if (e.item == item) {
                return e;
            }
        }
        return null;
    }
}
