package com.arsenal.combat;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Режим боя. Включается только уроном или станом игрока по игроку (мобы не считаются), длится 30 секунд,
 * каждый новый удар или стан продлевает его до 30 секунд заново.
 *
 *  - Время до конца показывается полоской сверху (как здоровье босса) и в панели над хотбаром (где кулдаун исцеления).
 *  - В чат пишется, когда игрок вошёл в режим боя и когда вышел.
 *  - Если выйти с сервера в режиме боя, всё из инвентаря рассыпается и игрок умирает.
 *  - Пока идёт режим боя, никакие команды не работают, даже у операторов (см. CommandManagerMixin).
 */
public final class Combat {
    public static final int TICKS = 20 * 30;

    private static final Map<UUID, Integer> LEFT = new HashMap<>();
    private static final Map<UUID, ServerBossBar> BARS = new HashMap<>();

    private Combat() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(Combat::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> clearAll());
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity player = handler.player;
            boolean fighting = LEFT.containsKey(player.getUuid());
            removeBar(player.getUuid());
            LEFT.remove(player.getUuid());
            if (fighting && !server.isStopping() && !player.isDead()) {
                // вышел в бою: вещи рассыпаются, игрок умирает
                player.inventory.dropAll();
                player.damage(DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);
                server.getPlayerManager().broadcastChatMessage(
                        new LiteralText("Игрок " + player.getGameProfile().getName() + " вышел из игры в режиме боя")
                                .formatted(Formatting.RED), net.minecraft.network.MessageType.SYSTEM, player.getUuid());
            }
        });
    }

    public static boolean isInCombat(ServerPlayerEntity player) {
        return LEFT.containsKey(player.getUuid());
    }

    /** Игрок ударил или застанил игрока: режим боя у обоих (включается или продлевается до 30 секунд). */
    public static void tag(ServerPlayerEntity a, ServerPlayerEntity b) {
        if (a == b || a.isSpectator() || b.isSpectator()) {
            return;
        }
        extend(a);
        extend(b);
    }

    /** Включить или продлить режим боя до полных 30 секунд (постоянный режим боя в смертельном грузе). */
    public static void refresh(ServerPlayerEntity player) {
        if (!player.isSpectator() && !player.isDead()) {
            extend(player);
        }
    }

    /** Продлить, только если игрок уже в бою. */
    public static void extendIfActive(ServerPlayerEntity player) {
        if (isInCombat(player)) {
            extend(player);
        }
    }

    private static void extend(ServerPlayerEntity player) {
        boolean entering = !LEFT.containsKey(player.getUuid());
        LEFT.put(player.getUuid(), TICKS);
        if (entering) {
            player.sendMessage(new LiteralText("Вы вошли в режим боя на 30 секунд. Не выходите из игры и не используйте команды!")
                    .formatted(Formatting.RED), false);
            ServerBossBar bar = new ServerBossBar(new LiteralText(""), BossBar.Color.RED, BossBar.Style.PROGRESS);
            bar.addPlayer(player);
            BARS.put(player.getUuid(), bar);
            update(player, TICKS);
        }
    }

    private static void update(ServerPlayerEntity player, int ticks) {
        int seconds = (ticks + 19) / 20;
        ServerBossBar bar = BARS.get(player.getUuid());
        if (bar != null) {
            bar.setPercent(Math.max(0.0F, Math.min(1.0F, ticks / (float) TICKS)));
            bar.setName(new LiteralText("Режим боя: " + seconds + " с").formatted(Formatting.RED));
        }
    }

    private static void removeBar(UUID uuid) {
        ServerBossBar bar = BARS.remove(uuid);
        if (bar != null) {
            bar.clearPlayers();
        }
    }

    /** Сразу завершает режим боя игрока (например, победителю смертельной схватки). */
    public static void clear(ServerPlayerEntity player) {
        if (LEFT.remove(player.getUuid()) != null) {
            removeBar(player.getUuid());
            player.sendMessage(new LiteralText("Вы вышли из режима боя").formatted(Formatting.GREEN), false);
        }
    }

    private static void clearAll() {
        for (ServerBossBar bar : BARS.values()) {
            bar.clearPlayers();
        }
        BARS.clear();
        LEFT.clear();
    }

    private static void tick(MinecraftServer server) {
        if (LEFT.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<UUID, Integer>> it = LEFT.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> entry = it.next();
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());
            if (player == null) {
                removeBar(entry.getKey());
                it.remove();
                continue;
            }
            int left = entry.getValue() - 1;
            if (left <= 0 || player.isDead()) {
                it.remove();
                removeBar(entry.getKey());
                player.sendMessage(new LiteralText("Вы вышли из режима боя").formatted(Formatting.GREEN), false);
                continue;
            }
            entry.setValue(left);
            update(player, left);
            if (left % 10 == 0) {
                // панель над хотбаром, там же где кулдаун исцеления
                player.sendMessage(new LiteralText("Режим боя: " + ((left + 19) / 20) + " с").formatted(Formatting.RED), true);
            }
        }
    }
}
