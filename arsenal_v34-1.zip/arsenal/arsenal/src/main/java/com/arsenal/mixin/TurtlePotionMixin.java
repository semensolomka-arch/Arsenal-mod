package com.arsenal.mixin;

import com.arsenal.TurtleCooldown;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Выпитое зелье Черепашьей мощи: кулдаун 5 минут. Во время кулдауна зелье не тратится и ничего не делает. */
@Mixin(PotionItem.class)
public abstract class TurtlePotionMixin {
    @Inject(method = "finishUsing", at = @At("HEAD"), cancellable = true)
    private void arsenal$turtleStart(ItemStack stack, World world, LivingEntity user, CallbackInfoReturnable<ItemStack> cir) {
        if (world.isClient || !TurtleCooldown.isTurtle(stack)) {
            return;
        }
        if (!TurtleCooldown.canDrink(user)) {
            TurtleCooldown.notifyBlocked(user);
            cir.setReturnValue(stack);
            return;
        }
        TurtleCooldown.active = true;
    }

    @Inject(method = "finishUsing", at = @At("RETURN"))
    private void arsenal$turtleEnd(ItemStack stack, World world, LivingEntity user, CallbackInfoReturnable<ItemStack> cir) {
        TurtleCooldown.active = false;
    }
}
