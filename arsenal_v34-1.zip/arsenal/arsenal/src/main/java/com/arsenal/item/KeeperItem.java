package com.arsenal.item;

import com.arsenal.artifact.ArtifactEffect;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import com.arsenal.Lore;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.world.World;

import java.util.List;

/** Предмет-эффект Хранителя опыта. Сам по себе ничего не делает в руке, эффект работает из инвентаря. */
public class KeeperItem extends Item {
    private final ArtifactEffect effect;

    public KeeperItem(Settings settings, ArtifactEffect effect) {
        super(settings);
        this.effect = effect;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return effect.glint;
    }

    @Override
    public Text getName(ItemStack stack) {
        return new TranslatableText(getTranslationKey(stack))
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(effect.nameColor)).withItalic(false));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Lore.addTooltip(tooltip, "tooltip.arsenal.keeper_" + effect.id + ".", 6, effect.lineColor);
    }
}
