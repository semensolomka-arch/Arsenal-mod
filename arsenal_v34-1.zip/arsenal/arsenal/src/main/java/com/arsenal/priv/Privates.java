package com.arsenal.priv;

import com.arsenal.Arsenal;
import com.arsenal.blast.BlastBlock;
import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.Material;
import net.minecraft.block.TntBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.entity.LockableContainerBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorStandItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.DecorationItem;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MinecartItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Приваты: регистрация блоков и события.
 *  - В чужом привате нельзя ломать и ставить блоки, открывать сундуки, печки, люки и двери. TNT поджигать можно.
 *  - Приват взрывается: у обычных одна прочность, у защищённого 2, у уникального 4. Остальные блоки на территории
 *    привата от взрывов не страдают (взрыв надо направить в сам блок привата).
 *  - Чинит владелец: ПКМ незеритовым слитком по привату (только если прочность больше одной).
 *  - Вход на чужую территорию и выход из неё пишутся в чат. Трапки в привате не работают (см. Abilities и Specials).
 */
public final class Privates {
    /** true: взрывы не ломают обычные блоки на территории привата. Сейчас выключено: взрывами можно ломать блоки в обход привата. */
    public static final boolean EXPLOSION_PROOF_REGION = false;

    private static final Map<UUID, Map<String, String>> INSIDE = new HashMap<>();

    private static final List<Pending> PENDING = new java.util.ArrayList<>();

    private static final class Pending {
        final ServerWorld world;
        final BlockPos pos;
        final PrivateType type;
        final int durability;
        final UUID owner;
        final String ownerName;

        Pending(ServerWorld world, BlockPos pos, PrivateType type, int durability, UUID owner, String ownerName) {
            this.world = world;
            this.pos = pos;
            this.type = type;
            this.durability = durability;
            this.owner = owner;
            this.ownerName = ownerName;
        }
    }

    private Privates() {
    }

    /** Какой приват ставит этот предмет (null, если это не приват). */
    private static PrivateType typeOf(Item item) {
        if (item instanceof PrivateBlockItem) {
            return ((PrivateBlockItem) item).type;
        }
        if (item instanceof BlockItem) {
            PrivateType t = PrivateType.ofBlock(((BlockItem) item).getBlock());
            return t == PrivateType.UNIQUE ? null : t;
        }
        return null;
    }

    /** Регистрируется только уникальный приват; железо, золото, алмаз, изумрудная руда и незерит это обычные блоки. */
    public static void init(ItemGroup group) {
        PrivateType type = PrivateType.UNIQUE;
        Block block = Registry.register(Registry.BLOCK, new Identifier(Arsenal.MODID, type.id),
                new PrivateBlock(AbstractBlock.Settings.of(Material.METAL)
                        .strength(5.0F, type.resistance).sounds(BlockSoundGroup.NETHERITE).dropsNothing(), type));
        type.block = block;
        type.item = Registry.register(Registry.ITEM, new Identifier(Arsenal.MODID, type.id),
                new PrivateBlockItem(block, new Item.Settings().group(group), type));
    }

    public static void addCreativeStacks(List<ItemStack> stacks) {
        stacks.add(new ItemStack(PrivateType.UNIQUE.item));
    }

    // ---------- проверки ----------

    /** Можно ли игроку менять блок в этой точке (нет чужих приватов). */
    public static boolean canModify(World world, BlockPos pos, PlayerEntity player) {
        return SpawnProtection.bypass(player) || PrivateManager.foreignAt(world, pos, player) == null;
    }

    private static void denyForeign(ServerPlayerEntity player, PrivateManager.Entry owner, String what) {
        SpawnProtection.deny(player, "Это приват игрока " + owner.ownerName + ": " + what);
    }

    /**
     * Клиент уже уменьшил стак у себя при попытке поставить блок, а сервер отказал (стак на сервере цел).
     * Отправляем игроку актуальный предмет из руки, чтобы приват не "пропадал".
     */
    private static void giveBack(ServerPlayerEntity player, Hand hand) {
        int slot = hand == Hand.MAIN_HAND ? player.inventory.selectedSlot : 40;
        player.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(-2, slot, player.getStackInHand(hand)));
    }

    private static boolean places(Item item) {
        return item instanceof BlockItem || item instanceof FlintAndSteelItem || item instanceof FireChargeItem
                || item instanceof ArmorStandItem || item instanceof DecorationItem || item instanceof MinecartItem;
    }

    /** Сундуки, печки и прочие контейнеры, люки, двери и калитки. */
    private static boolean locked(World world, BlockPos pos, BlockState state) {
        Block block = state.getBlock();
        return block instanceof DoorBlock || block instanceof TrapdoorBlock || block instanceof FenceGateBlock
                || world.getBlockEntity(pos) instanceof LockableContainerBlockEntity;
    }

    // ---------- взрывы ----------

    /** Приват попал под взрыв: минус одна прочность, на нуле приват разрушается и выпадает снова. */
    public static void explosionHit(ServerWorld world, BlockPos pos) {
        PrivateManager.Entry e = PrivateManager.get(world, pos);
        if (e == null) {
            return;
        }
        PrivateType type = e.type;
        int left = e.durability - 1;
        if (left > 0) {
            PrivateManager.setDurability(world, e, left);
            world.playSound(null, pos, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 1.0F, 0.6F);
            world.spawnParticles(ParticleTypes.CRIT, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 20, 0.5, 0.5, 0.5, 0.1);
            notifyOwner(world, e, "Ваш приват повреждён, прочность " + left + "/" + type.durability, Formatting.YELLOW);
            return;
        }
        PrivateManager.remove(world, pos);
        world.removeBlock(pos, false);
        Block.dropStack(world, pos, type.freshStack());
        notifyOwner(world, e, "Ваш приват разрушен (" + pos.getX() + " " + pos.getY() + " " + pos.getZ() + ")", Formatting.RED);
    }

    private static void notifyOwner(ServerWorld world, PrivateManager.Entry e, String text, Formatting color) {
        ServerPlayerEntity owner = world.getServer().getPlayerManager().getPlayer(e.owner);
        if (owner != null) {
            owner.sendMessage(new LiteralText(text).formatted(color), false);
        }
        for (UUID id : e.coOwners.keySet()) {
            ServerPlayerEntity co = world.getServer().getPlayerManager().getPlayer(id);
            if (co != null) {
                co.sendMessage(new LiteralText(text).formatted(color), false);
            }
        }
    }

    // ---------- ремонт ----------

    private static ActionResult repair(ServerPlayerEntity player, ServerWorld world, BlockPos pos, ItemStack ingot) {
        PrivateManager.Entry e = PrivateManager.get(world, pos);
        if (e == null || e.type.durability <= 1) {
            return ActionResult.PASS;
        }
        if (!e.isOwner(player.getUuid()) && !SpawnProtection.bypass(player)) {
            SpawnProtection.deny(player, "Чинить приват могут только владельцы");
            return ActionResult.FAIL;
        }
        if (e.durability >= e.type.durability) {
            SpawnProtection.deny(player, "Приват не повреждён");
            return ActionResult.FAIL;
        }
        PrivateManager.setDurability(world, e, e.durability + 1);
        if (!player.isCreative()) {
            ingot.decrement(1);
        }
        world.playSound(null, pos, SoundEvents.BLOCK_ANVIL_USE, SoundCategory.BLOCKS, 1.0F, 1.2F);
        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 12, 0.4, 0.4, 0.4, 0.0);
        player.sendMessage(new LiteralText("Приват починен: прочность " + e.durability + "/" + e.type.durability)
                .formatted(Formatting.GREEN), true);
        return ActionResult.SUCCESS;
    }

    // ---------- события ----------

    public static void initEvents() {
        ServerLifecycleEvents.SERVER_STARTED.register(PrivateManager::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            PrivateManager.save();
            PrivateManager.clear();
            INSIDE.clear();
        });

        // ломать в чужом привате нельзя; свой приват ломает владелец и получает предмет
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient) {
                return true;
            }
            if (!canModify(world, pos, player)) {
                denyForeign((ServerPlayerEntity) player, PrivateManager.foreignAt(world, pos, player), "ломать блоки нельзя");
                return false;
            }
            PrivateManager.Entry e = PrivateManager.get(world, pos);
            if (e != null && !e.isOwner(player.getUuid()) && !SpawnProtection.bypass(player)) {
                SpawnProtection.deny((ServerPlayerEntity) player, "Ломать приват могут только его владельцы");
                return false;
            }
            if (e != null && e.type != PrivateType.UNIQUE) {
                // обычный блок-приват: падает сам блок (с прочностью), с Shift обычный дроп (у руды изумруд)
                if (!player.isCreative()) {
                    ItemStack drop = player.isSneaking() ? new ItemStack(e.type.shiftDrop())
                            : PrivateBlockItem.stackWith(e.type, e.durability);
                    Block.dropStack(world, pos, drop);
                }
                PrivateManager.remove(world, pos);
                world.removeBlock(pos, false);
                return false;   // ванильный дроп отменён
            }
            return true;
        });
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.isClient) {
                return ActionResult.PASS;
            }
            if (!canModify(world, pos, player)) {
                denyForeign((ServerPlayerEntity) player, PrivateManager.foreignAt(world, pos, player), "ломать блоки нельзя");
                return ActionResult.FAIL;
            }
            PrivateManager.Entry own = PrivateManager.get(world, pos);
            if (own != null && !own.isOwner(player.getUuid()) && !SpawnProtection.bypass(player)) {
                SpawnProtection.deny((ServerPlayerEntity) player, "Ломать приват могут только его владельцы");
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        // ставить блоки, открывать сундуки и двери в чужом привате нельзя; ремонт; установка приватов
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity) || player.isSpectator()) {
                return ActionResult.PASS;
            }
            ServerPlayerEntity sp = (ServerPlayerEntity) player;
            ServerWorld sw = (ServerWorld) world;
            BlockPos clicked = hit.getBlockPos();
            BlockState clickedState = world.getBlockState(clicked);
            ItemStack stack = player.getStackInHand(hand);

            if (stack.getItem() == Items.NETHERITE_INGOT && PrivateManager.get(world, clicked) != null) {
                return repair(sp, sw, clicked, stack);
            }
            boolean bypass = SpawnProtection.bypass(player);
            // поджигать TNT можно везде
            boolean igniter = stack.getItem() == Items.FLINT_AND_STEEL || stack.getItem() == Items.FIRE_CHARGE;
            if (igniter && (clickedState.getBlock() instanceof TntBlock || clickedState.getBlock() instanceof BlastBlock)) {
                return ActionResult.PASS;
            }

            PrivateManager.Entry foreignClicked = bypass ? null : PrivateManager.foreignAt(world, clicked, player);
            if (foreignClicked != null && locked(world, clicked, clickedState)) {
                denyForeign(sp, foreignClicked, "открывать нельзя");
                return ActionResult.FAIL;
            }
            if (!places(stack.getItem())) {
                return ActionResult.PASS;
            }
            ItemPlacementContext ctx = new ItemPlacementContext(player, hand, stack, hit);
            BlockPos target = ctx.getBlockPos();
            PrivateManager.Entry foreign = foreignClicked != null ? foreignClicked
                    : bypass ? null : PrivateManager.foreignAt(world, target, player);
            if (foreign != null) {
                // кнопки, рычаги и т.п. работают как обычно
                if (!player.isSneaking()) {
                    ActionResult result = clickedState.onUse(world, player, hand, hit);
                    if (result.isAccepted()) {
                        return result;
                    }
                }
                denyForeign(sp, foreign, "ставить блоки нельзя");
                giveBack(sp, hand);
                return ActionResult.FAIL;
            }

            // установка привата: без Shift обычный блок становится приватом (уникальный всегда)
            PrivateType placing = typeOf(stack.getItem());
            if (placing != null) {
                boolean plain = placing.canBePlainBlock() && player.isSneaking();
                if (!plain) {
                    if (!bypass && (SpawnProtection.overlapsZone(world, target, placing.half)
                            || com.arsenal.event.EventManager.overlapsZone(world, target, placing.half))) {
                        SpawnProtection.deny(sp, "Приват нельзя ставить в замке и рядом с замком или грузом");
                        giveBack(sp, hand);
                        return ActionResult.FAIL;
                    }
                    PrivateManager.Entry other = bypass ? null : PrivateManager.overlapAny(world, target, placing);
                    if (other != null) {
                        SpawnProtection.deny(sp, other.isOwner(player.getUuid())
                                ? "Рядом ваш другой приват: территории пересекаются"
                                : "Рядом приват игрока " + other.ownerName + ": территории пересекаются");
                        giveBack(sp, hand);
                        return ActionResult.FAIL;
                    }
                    if (placing != PrivateType.UNIQUE && ctx.canPlace()) {
                        // обычный блок: проверим в конце тика, что он действительно встал
                        PENDING.add(new Pending(sw, target.toImmutable(), placing, PrivateBlockItem.durabilityOf(stack, placing),
                                player.getUuid(), player.getGameProfile().getName()));
                    }
                }
            }
            return ActionResult.PASS;
        });

        // вёдра
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || !(stack.getItem() instanceof BucketItem) || SpawnProtection.bypass(player)) {
                return TypedActionResult.pass(stack);
            }
            HitResult hit = player.raycast(5.0D, 1.0F, true);
            if (hit.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = ((BlockHitResult) hit).getBlockPos();
                PrivateManager.Entry foreign = PrivateManager.foreignAt(world, pos, player);
                if (foreign == null) {
                    foreign = PrivateManager.foreignAt(world, pos.offset(((BlockHitResult) hit).getSide()), player);
                }
                if (foreign != null) {
                    denyForeign((ServerPlayerEntity) player, foreign, "ставить блоки нельзя");
                    return TypedActionResult.fail(stack);
                }
            }
            return TypedActionResult.pass(stack);
        });

        // поставленные блоки-приваты и проверка записей
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!PENDING.isEmpty()) {
                for (Pending p : PENDING) {
                    if (p.world.getBlockState(p.pos).getBlock() == p.type.vanillaBlock() && PrivateManager.get(p.world, p.pos) == null) {
                        PrivateManager.add(p.world, p.pos, p.owner, p.ownerName, p.type, p.durability);
                    }
                }
                PENDING.clear();
            }
            if (server.getTicks() % 100 == 0) {
                for (ServerWorld w : server.getWorlds()) {
                    PrivateManager.validate(w);
                }
            }
        });

        // вход на чужую территорию и выход
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 10 != 0) {
                return;
            }
            Set<UUID> online = new HashSet<>();
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                online.add(p.getUuid());
                Map<String, String> now = new HashMap<>();
                if (!p.isSpectator()) {
                    for (PrivateManager.Entry e : PrivateManager.regionsAt(p.world, p.getBlockPos())) {
                        if (!e.isTrusted(p.getUuid())) {
                            now.put(e.key(), e.ownerName);
                        }
                    }
                }
                Map<String, String> before = INSIDE.getOrDefault(p.getUuid(), new HashMap<>());
                for (Map.Entry<String, String> in : now.entrySet()) {
                    if (!before.containsKey(in.getKey())) {
                        p.sendMessage(new LiteralText("Вы вторглись на территорию игрока ").formatted(Formatting.WHITE)
                                .append(new LiteralText(in.getValue()).formatted(Formatting.AQUA)), false);
                    }
                }
                for (Map.Entry<String, String> out : before.entrySet()) {
                    if (!now.containsKey(out.getKey())) {
                        p.sendMessage(new LiteralText("Вы покинули территорию игрока ").formatted(Formatting.WHITE)
                                .append(new LiteralText(out.getValue()).formatted(Formatting.AQUA)), false);
                    }
                }
                INSIDE.put(p.getUuid(), now);
            }
            INSIDE.keySet().retainAll(online);
        });
    }
}
