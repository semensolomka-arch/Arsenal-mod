package com.arsenal;

import com.arsenal.artifact.ArtifactEffect;
import com.arsenal.bind.Binds;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;

/** Uses Minecraft's own potion bottle and overlay textures, tinted like vanilla potions. */
public class ArsenalClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Настройки биндов (/binds) приходят с сервера при входе и при изменении
        ClientPlayNetworking.registerGlobalReceiver(Binds.SYNC, (client, handler, buf, sender) -> {
            byte[] ordinals = new byte[buf.readableBytes()];
            buf.readBytes(ordinals);
            client.execute(() -> Binds.applySync(ordinals));
        });

        // Vanilla potion overlay colors: swiftness blue, strength red.
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0x7CAFC6 : -1,
                Arsenal.SPEED_III_6M, Arsenal.SPEED_III_3M);
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0x932423 : -1,
                Arsenal.STRENGTH_III_6M, Arsenal.STRENGTH_III_3M);
        // Зелье победителя: голубая жидкость
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0x3FB8F0 : -1, Arsenal.WINNER_POTION);
        // Справедливость: как ванильное зелье исцеления
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 1 ? 0xF82423 : -1,
                ArtifactEffect.JUSTICE.item);
    }
}
