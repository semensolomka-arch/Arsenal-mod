package com.arsenal.anvil;

import com.arsenal.Arsenal;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Material;
import net.minecraft.block.MaterialColor;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

/**
 * Нерушимая наковальня: работает как обычная, падает как обычная, но не портится от использования и от падения.
 * Блока нет в теге minecraft:anvil, поэтому ванильные проверки «наковальня стала повреждённой или сломалась»
 * её не касаются, а окно наковальни открывается через свой обработчик (см. Handler).
 * Если её сломать или взорвать, выпадает она сама (таблица добычи data/arsenal/loot_tables/blocks).
 */
public class UnbreakableAnvilBlock extends AnvilBlock {
    public static Block BLOCK;
    public static Item ITEM;

    public UnbreakableAnvilBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    public static void init(ItemGroup group) {
        BLOCK = Registry.register(Registry.BLOCK, new Identifier(Arsenal.MODID, "unbreakable_anvil"),
                new UnbreakableAnvilBlock(AbstractBlock.Settings.of(Material.REPAIR_STATION, MaterialColor.IRON)
                        .requiresTool().strength(5.0F, 6.0F).sounds(BlockSoundGroup.ANVIL)));
        ITEM = Registry.register(Registry.ITEM, new Identifier(Arsenal.MODID, "unbreakable_anvil"),
                new UnbreakableAnvilItem(BLOCK, new Item.Settings().group(group).rarity(Rarity.UNCOMMON)));
    }

    @Override
    public NamedScreenHandlerFactory createScreenHandlerFactory(BlockState state, World world, BlockPos pos) {
        return new SimpleNamedScreenHandlerFactory(
                (syncId, inventory, player) -> new Handler(syncId, inventory, ScreenHandlerContext.create(world, pos)),
                new TranslatableText("container.repair"));
    }

    /** Окно наковальни, которое считает нерушимую наковальню наковальней (она не в ванильном теге). */
    public static class Handler extends AnvilScreenHandler {
        public Handler(int syncId, PlayerInventory inventory, ScreenHandlerContext context) {
            super(syncId, inventory, context);
        }

        @Override
        protected boolean canUse(BlockState state) {
            return state.getBlock() instanceof UnbreakableAnvilBlock;
        }
    }
}
