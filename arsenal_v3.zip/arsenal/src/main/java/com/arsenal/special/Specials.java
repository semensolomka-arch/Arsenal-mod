package com.arsenal.special;

import com.arsenal.Abilities;
import com.arsenal.Arsenal;
import com.arsenal.StunZones;
import com.arsenal.TrapManager;
import com.arsenal.protection.SpawnProtection;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Три особых предмета из шалкеров:
 *  - Взрывная трапка: клетка вокруг игрока (стекло или земляная коробка), стан-зона, урон всем рядом, кроме активатора;
 *  - Взрывная штучка: взрыв под ногами подбрасывает на 5 блоков (на 7, если в воздухе);
 *  - Светильник Джейка: свечение игрокам рядом и тыква на голову тем, у кого нет шлема.
 * Все числа ниже можно менять.
 */
public final class Specials {
    // --- взрывная трапка ---
    public static final int TRAP_LIFETIME = Abilities.TRAP_LIFETIME;   // 15 секунд
    public static final int TRAP_COOLDOWN = Abilities.TRAP_COOLDOWN;   // общий с обычной трапкой
    public static final float TRAP_DAMAGE = 10.0F;                     // половина ХП, броня уменьшает
    public static final int TRAP_ZONE_MARGIN = 4;                      // стан-зона и урон: от стен ещё на 4 блока
    public static final double DIRT_CHANCE = 0.35;                     // шанс земляной коробки на открытой местности

    // --- взрывная штучка ---
    public static final float CHARM_POWER = 5.0F;                      // убивает голого игрока с 3 блоков
    public static final double CHARM_LAUNCH_GROUND = 0.91;             // подброс примерно на 5 блоков
    public static final double CHARM_LAUNCH_AIR = 1.099;               // примерно на 7 блоков
    public static final int CHARM_COOLDOWN = 20 * 60;

    // --- светильник Джейка ---
    public static final double JAKE_RADIUS = 15.0;
    public static final int JAKE_GLOW_TICKS = 20 * 10;
    public static final int JAKE_PUMPKIN_TICKS = 20 * 15;
    public static final int JAKE_COOLDOWN = 20 * 30;
    private static final String JAKE_TAG = "ArsenalJakeUntil";

    private Specials() {
    }

    public static void init() {
        // блоки взрывной трапки не ломаются, пока она стоит
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !(TrapManager.isProtected(pos) && !player.isCreative()));
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) ->
                TrapManager.isProtected(pos) && !player.isCreative() ? ActionResult.FAIL : ActionResult.PASS);

        // раз в секунду: у тыквы Джейка через 15 секунд пропадает несъёмность (сама тыква остаётся)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) {
                return;
            }
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                ItemStack head = p.getEquippedStack(EquipmentSlot.HEAD);
                if (head.isEmpty() || !head.hasTag() || !head.getTag().contains(JAKE_TAG)) {
                    continue;
                }
                if (p.world.getTime() >= head.getTag().getLong(JAKE_TAG)) {
                    EnchantmentHelper.set(new LinkedHashMap<>(), head);
                    head.getTag().remove(JAKE_TAG);
                }
            }
        });
    }

    // =====================================================================
    // Взрывная трапка
    // =====================================================================

    public static boolean useExplosiveTrap(ServerPlayerEntity p, ItemStack source) {
        ServerWorld world = p.getServerWorld();
        BlockPos c = p.getBlockPos();
        if (SpawnProtection.contains(world, c) && !SpawnProtection.bypass(p)) {
            SpawnProtection.deny(p, "В зоне замка нельзя ставить трапки");
            return false;
        }
        Random rnd = world.random;
        Set<BlockPos> webs = pickWebs(rnd, c);
        boolean dirt = world.isSkyVisible(c) && rnd.nextDouble() < DIRT_CHANCE;
        if (dirt) {
            buildDirt(world, c, webs, rnd);
        } else {
            buildGlass(world, c, webs);
        }

        // стан-зона: сама клетка и 4 блока от стен; по тем же границам взрыв бьёт всех, кроме активатора
        int outer = (dirt ? 5 : 3) + TRAP_ZONE_MARGIN;
        Box zone = new Box(c.getX() - outer, c.getY() - TRAP_ZONE_MARGIN, c.getZ() - outer,
                c.getX() + outer + 1, c.getY() + 4 + TRAP_ZONE_MARGIN, c.getZ() + outer + 1);
        StunZones.add(world, zone, TRAP_LIFETIME);

        List<LivingEntity> victims = world.getEntitiesByClass(LivingEntity.class, zone,
                e -> e != p && e.isAlive() && !e.isSpectator() && !(e instanceof ArmorStandEntity));
        for (LivingEntity e : victims) {
            e.damage(DamageSource.explosion((LivingEntity) p), TRAP_DAMAGE);
        }

        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.getX() + 0.5, c.getY() + 1.0, c.getZ() + 0.5, 1, 0, 0, 0, 0);
        world.playSound(null, c, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 4.0F, 0.8F);

        p.getItemCooldownManager().set(Arsenal.TRAP, TRAP_COOLDOWN);
        p.getItemCooldownManager().set(Arsenal.EXPLOSIVE_TRAP, TRAP_COOLDOWN);
        if (!p.isCreative()) {
            source.decrement(1);
        }
        return true;
    }

    /** 3-6 клеток паутины на полу вдоль стен внутри. */
    private static Set<BlockPos> pickWebs(Random rnd, BlockPos c) {
        List<BlockPos> edge = new ArrayList<>();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) == 2) {
                    edge.add(c.add(dx, 0, dz));
                }
            }
        }
        Collections.shuffle(edge, rnd);
        int n = 3 + rnd.nextInt(4);
        return new HashSet<>(edge.subList(0, Math.min(n, edge.size())));
    }

    /** Ставит блок, запоминая исходный (вернётся через TRAP_LIFETIME, пока стоит, ломать нельзя). */
    private static void put(ServerWorld w, BlockPos pos, BlockState target, Block placed) {
        if (pos.getY() < 0 || pos.getY() > 255) {
            return;
        }
        BlockState cur = w.getBlockState(pos);
        if (cur.isOf(Arsenal.TRAP_BLOCK) || TrapManager.isProtected(pos)) {
            return;   // уже чья-то трапка
        }
        if (cur.isAir()) {
            if (target.isAir()) {
                return;
            }
        } else if (cur.getHardness(w, pos) < 0) {
            return;   // бедрок и т.п.
        }
        BlockEntity be = w.getBlockEntity(pos);
        if (be != null) {
            w.removeBlockEntity(pos);
        }
        TrapManager.add(w, pos, cur, be, TRAP_LIFETIME, placed);
        w.setBlockState(pos, target, TrapManager.FLAGS);
    }

    /** Если под стенкой пусто (склон, яма), достраиваем стенку вниз, чтобы не было лаза. */
    private static void extendDown(ServerWorld w, BlockPos from, BlockState state, Block placed) {
        for (int i = 1; i <= 3; i++) {
            BlockPos pos = from.down(i);
            BlockState cur = w.getBlockState(pos);
            if (cur.isAir() || cur.getMaterial().isReplaceable()) {
                put(w, pos, state, placed);
            } else {
                break;
            }
        }
    }

    /**
     * Стеклянная клетка: внутри 5x5x3, стенки из панелей стекла, крыша из стекла.
     * Углы пустые: панели у угла продлены до края блока, получается щель по диагонали
     * (меньше ширины игрока, но эндер-жемчуг пролетает).
     */
    private static void buildGlass(ServerWorld w, BlockPos c, Set<BlockPos> webs) {
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState glass = Blocks.GLASS.getDefaultState();
        BlockState web = Blocks.COBWEB.getDefaultState();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                boolean ring = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                boolean corner = Math.abs(dx) == 3 && Math.abs(dz) == 3;
                BlockState pane = pane(dx, dz);
                for (int dy = 0; dy <= 3; dy++) {
                    BlockPos pos = c.add(dx, dy, dz);
                    if (corner) {
                        put(w, pos, air, null);
                    } else if (dy == 3) {
                        put(w, pos, glass, Blocks.GLASS);
                    } else if (!ring) {
                        if (webs.contains(pos)) {
                            put(w, pos, web, Blocks.COBWEB);
                        } else {
                            put(w, pos, air, null);
                        }
                    } else {
                        put(w, pos, pane, Blocks.GLASS_PANE);
                    }
                }
                if (ring && !corner) {
                    extendDown(w, c.add(dx, 0, dz), pane, Blocks.GLASS_PANE);
                }
            }
        }
    }

    private static BlockState pane(int dx, int dz) {
        BlockState s = Blocks.GLASS_PANE.getDefaultState();
        if (Math.abs(dx) == 3) {
            return s.with(Properties.NORTH, true).with(Properties.SOUTH, true);   // стенка вдоль Z
        }
        return s.with(Properties.EAST, true).with(Properties.WEST, true);          // стенка вдоль X
    }

    /**
     * Земляная коробка без крыши: внутри 5x5, стены 3 блока высотой толщиной 2.
     * Иногда (50%) с одной стороны снаружи есть уступы, по которым можно забраться на стену и спрыгнуть внутрь.
     */
    private static void buildDirt(ServerWorld w, BlockPos c, Set<BlockPos> webs, Random rnd) {
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState dirt = Blocks.DIRT.getDefaultState();
        BlockState web = Blocks.COBWEB.getDefaultState();
        int ex = 0;
        int ez = 0;
        if (rnd.nextBoolean()) {
            int side = rnd.nextInt(4);
            ex = side == 0 ? 1 : side == 1 ? -1 : 0;
            ez = side == 2 ? 1 : side == 3 ? -1 : 0;
        }
        boolean entrance = ex != 0 || ez != 0;
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                int d = Math.max(Math.abs(dx), Math.abs(dz));
                // на стороне входа: ось вдоль входа равна d, а поперёк не дальше 1 от середины
                boolean onEntranceSide = entrance && (ex * dx + ez * dz) == d
                        && Math.abs(ex != 0 ? dz : dx) <= 1;
                int height;
                if (d <= 2) {
                    for (int dy = 0; dy <= 2; dy++) {
                        BlockPos pos = c.add(dx, dy, dz);
                        if (webs.contains(pos)) {
                            put(w, pos, web, Blocks.COBWEB);
                        } else {
                            put(w, pos, air, null);
                        }
                    }
                    continue;
                } else if (d == 3) {
                    height = 3;
                } else if (d == 4) {
                    height = onEntranceSide ? 2 : 3;
                } else {
                    height = onEntranceSide ? 1 : 0;
                }
                for (int dy = 0; dy < height; dy++) {
                    put(w, c.add(dx, dy, dz), dirt, Blocks.DIRT);
                }
                if (height > 0) {
                    extendDown(w, c.add(dx, 0, dz), dirt, Blocks.DIRT);
                }
            }
        }
    }

    // =====================================================================
    // Взрывная штучка
    // =====================================================================

    public static boolean useBlastCharm(ServerPlayerEntity p, ItemStack source) {
        ServerWorld world = p.getServerWorld();
        boolean airborne = !p.isOnGround();
        // взрыв бьёт всех рядом, включая активатора; блоки не ломает
        world.createExplosion(null, p.getX(), p.getY() + 0.1, p.getZ(), CHARM_POWER, Explosion.DestructionType.NONE);
        if (p.isAlive()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, airborne ? CHARM_LAUNCH_AIR : CHARM_LAUNCH_GROUND, v.z);
            p.velocityModified = true;
        }
        p.getItemCooldownManager().set(Arsenal.BLAST_CHARM, CHARM_COOLDOWN);
        if (!p.isCreative()) {
            source.decrement(1);
        }
        return true;
    }

    // =====================================================================
    // Светильник Джейка
    // =====================================================================

    public static boolean useJakeLantern(ServerPlayerEntity p, ItemStack source) {
        ServerWorld world = p.getServerWorld();
        List<PlayerEntity> targets = world.getEntitiesByClass(PlayerEntity.class, p.getBoundingBox().expand(JAKE_RADIUS),
                e -> e != p && !e.isSpectator() && e.squaredDistanceTo(p) <= JAKE_RADIUS * JAKE_RADIUS);
        for (PlayerEntity t : targets) {
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, JAKE_GLOW_TICKS, 0));
            if (t.getEquippedStack(EquipmentSlot.HEAD).isEmpty()) {
                ItemStack pumpkin = new ItemStack(Items.CARVED_PUMPKIN);
                pumpkin.addEnchantment(Enchantments.BINDING_CURSE, 1);
                pumpkin.getOrCreateTag().putLong(JAKE_TAG, world.getTime() + JAKE_PUMPKIN_TICKS);
                t.equipStack(EquipmentSlot.HEAD, pumpkin);
            }
        }
        world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0F, 1.5F);
        p.getItemCooldownManager().set(Arsenal.JAKE_LANTERN, JAKE_COOLDOWN);
        if (!p.isCreative()) {
            source.decrement(1);
        }
        return true;
    }
}
